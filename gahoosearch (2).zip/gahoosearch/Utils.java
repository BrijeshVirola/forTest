package tests.gahoosearch;

import tests.gahoosearch.responseobjects.DebugInfo;
import tests.gahoosearch.responseobjects.UserSearchDetails;

public class Utils {

	public static UserSearchDetails expSearchDetailsBeetlejuice() {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(1)
				.indexRanking(0)
				.productGameId(17355)
				.why("Starts with match on beetlejuice")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(9646)
				.gt("Beetlejuice Megaways")
				.tkn("BeetlejuiceMegaways")
				.p(4)
				.ibn("BeetlejuiceMegaways2")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expSearchDetailsDealOrNoDeal() {

		DebugInfo expecteddebuginfo = new DebugInfo.Builder().defaults()
				.indexPriority(2)
				.indexRanking(48)
				.productGameId(20212)
				.why("Key word matches on [game]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(10719)
				.gt("Deal or No Deal: The Golden Game")
				.tkn("DONDTheGoldenGame")
				.p(4)
				.ibn("DealOrNoDealTheGoldenGame2")
				.hci(null)
				.addDebugInfo(expecteddebuginfo)
				.build();
	}

	public static UserSearchDetails expSearchDetailsMedusaGoldenGaze() {

		DebugInfo expecteddebuginfo = new DebugInfo.Builder().defaults()
				.indexPriority(4)
				.indexRanking(118)
				.productGameId(11385)
				.why("Edit distance match on gae (gaze)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7518)
				.gt("Medusa's Golden Gaze")
				.tkn("MedusasGoldenGaze")
				.p(4)
				.ibn("MedusasGoldenGaze")
				.hci(true)
				.addDebugInfo(expecteddebuginfo)
				.build();
	}

	public static UserSearchDetails expSearchDetailsFurysGate() {

		DebugInfo expecteddebuginfo = new DebugInfo.Builder().defaults()
				.indexPriority(4)
				.indexRanking(120)
				.productGameId(11593)
				.why("Edit distance match on gae (gate)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7608)
				.gt("Fury�s Gate")
				.tkn("FurysGate")
				.ipei("games/SGP/GamePod/OriginalsIcon.svg")
				.p(4)
				.ibn("FurysGate")
				.hci(null)
				.addDebugInfo(expecteddebuginfo)
				.build();
	}

	public static UserSearchDetails expSearchDetailsLiveGameShows() {

		DebugInfo expecteddebuginfo = new DebugInfo.Builder().defaults()
				.indexPriority(2)
				.indexRanking(26)
				.productGameId(10389)
				.why("Key word matches on [game]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7053)
				.gt("Live Game Shows Lobby")
				.tkn("LiveAotGRouletteTest")
				.p(2)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expecteddebuginfo)
				.build();
	}

}
