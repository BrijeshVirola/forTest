package tests.gahoosearch;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.gahoosearch.enums.GahooSearchEndpoints;
import tests.gahoosearch.request.GahooSearchReq;
import tests.gahoosearch.response.GahooSearchNullResp;
import tests.gahoosearch.response.GahooSearchResp;
import tests.gahoosearch.responseobjects.DebugInfo;
import tests.gahoosearch.responseobjects.UserSearchDetails;

public class GahooSearchTests extends BaseClassSetup {

	private String searchText = "Beetlejuice";
	private Integer productId = 4;
	private Integer countryId = 36;
	private Integer countryStateId = 72;
	private Integer languageId = 1;
	private String technologyId = "2";
	private Integer platformTypeId = 1;
	private Integer deviceGroupId = 1;
	private String currencyCode = "CAD";
	private Boolean userAgeVerified = true;
	private Boolean searchCrossProduct = true;

	@Test(description = "Make a request to Gahoo Search. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Exact_Match_Search_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.p(productId)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expSearchDetailsBeetlejuice())
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}


	@Test(description = "Make a request to gahooSearch. Optional parameter: cs.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void createGameRound_Missing_cs_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.cs(null)
				.build();
		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expSearchDetailsBeetlejuice())
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}


	@Test(description = "Make a request to Gahoo Search - Optional uv. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch__Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.uv(null)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expSearchDetailsBeetlejuice())
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}


	@Test(description = "Make a request to Gahoo Search - Cross Product Set to false. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Cross_Product_False_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expSearchDetailsBeetlejuice())
				.build();

		assertReflectionEquals(expResponse, actualResponse);

	}

	@Test(description = "Make a request to Gahoo Search - Country - Denmark and Language - English Search. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Denmark_Country_English_Language_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("game")
				.p(4)
				.c(54)
				.cs(72)
				.l(1)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expSearchDetailsDealOrNoDeal())
				.addUserSearchDetails(Utils.expSearchDetailsMedusaGoldenGaze())
				.addUserSearchDetails(Utils.expSearchDetailsFurysGate())
				.addUserSearchDetails(Utils.expSearchDetailsLiveGameShows())
				.build();

		assertReflectionEquals(expResponse, actualResponse);

	}

	@Test(description = "Make a request to Gahoo Search - Search by a word - Card Search. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Search_By_Word_CARD_Positive_Scenario(String baseUri) {
		searchText = "Card";

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t(searchText)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		Integer getId1 = actualResponse.getUserSearchDetails().get(0).id();
		String getgt1 = actualResponse.getUserSearchDetails().get(0).gt();
		String gettkn1 = actualResponse.getUserSearchDetails().get(0).tkn();		
		Integer getp1 = actualResponse.getUserSearchDetails().get(0).p();
		String getibn1 = actualResponse.getUserSearchDetails().get(0).ibn();
		Integer getindexpriority1 = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getIndexPriority();
		Integer getindexRanking1 = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getIndexRanking();
		Integer getProductGameId1 = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getProductGameId();
		String getWhy1 = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getWhy();

		Integer getId2 = actualResponse.getUserSearchDetails().get(1).id();
		String getgt2 = actualResponse.getUserSearchDetails().get(1).gt();
		String gettkn2 = actualResponse.getUserSearchDetails().get(1).tkn();		
		Integer getp2 = actualResponse.getUserSearchDetails().get(1).p();
		String getibn2 = actualResponse.getUserSearchDetails().get(1).ibn();
		Boolean gethci2 = actualResponse.getUserSearchDetails().get(1).hci();
		Integer getindexpriority2 = actualResponse.getUserSearchDetails().get(1).getDebugInfo().getIndexPriority();
		Integer getindexRanking2 = actualResponse.getUserSearchDetails().get(1).getDebugInfo().getIndexRanking();
		Integer getProductGameId2 = actualResponse.getUserSearchDetails().get(1).getDebugInfo().getProductGameId();
		String getWhy2 = actualResponse.getUserSearchDetails().get(1).getDebugInfo().getWhy();

		Integer getId3 = actualResponse.getUserSearchDetails().get(2).id();
		String getgt3 = actualResponse.getUserSearchDetails().get(2).gt();
		String gettkn3 = actualResponse.getUserSearchDetails().get(2).tkn();		
		Integer getp3 = actualResponse.getUserSearchDetails().get(2).p();
		String getibn3 = actualResponse.getUserSearchDetails().get(2).ibn();
		Integer getindexpriority3 = actualResponse.getUserSearchDetails().get(2).getDebugInfo().getIndexPriority();
		Integer getindexRanking3 = actualResponse.getUserSearchDetails().get(2).getDebugInfo().getIndexRanking();
		Integer getProductGameId3 = actualResponse.getUserSearchDetails().get(2).getDebugInfo().getProductGameId();
		String getWhy3 = actualResponse.getUserSearchDetails().get(2).getDebugInfo().getWhy();

		DebugInfo expecteddebuginfo1 = new DebugInfo.Builder().defaults()
				.indexPriority(getindexpriority1)
				.indexRanking(getindexRanking1)
				.productGameId(getProductGameId1)
				.why(getWhy1)
				.build();

		DebugInfo expecteddebuginfo2 = new DebugInfo.Builder().defaults()
				.indexPriority(getindexpriority2)
				.indexRanking(getindexRanking2)
				.productGameId(getProductGameId2)
				.why(getWhy2)
				.build();

		DebugInfo expecteddebuginfo3 = new DebugInfo.Builder().defaults()
				.indexPriority(getindexpriority3)
				.indexRanking(getindexRanking3)
				.productGameId(getProductGameId3)
				.why(getWhy3)
				.build();

		UserSearchDetails searchdetails1 = new UserSearchDetails.Builder()
				.defaults()
				.id(getId1)
				.gt(getgt1)
				.tkn(gettkn1)
				.p(getp1)
				.ibn(getibn1)
				.hci(null)
				.addDebugInfo(expecteddebuginfo1)
				.build();

		UserSearchDetails searchdetails2 = new UserSearchDetails.Builder()
				.defaults()
				.id(getId2)
				.gt(getgt2)
				.tkn(gettkn2)
				.p(getp2)
				.ibn(getibn2)
				.hci(gethci2)
				.addDebugInfo(expecteddebuginfo2)
				.build();

		UserSearchDetails searchdetails3 = new UserSearchDetails.Builder()
				.defaults()
				.id(getId3)
				.gt(getgt3)
				.tkn(gettkn3)
				.p(getp3)
				.ibn(getibn3)
				.hci(null)
				.addDebugInfo(expecteddebuginfo3)
				.build();

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(searchdetails1)
				.addUserSearchDetails(searchdetails2)
				.addUserSearchDetails(searchdetails3)
				.build();

		assertReflectionEquals(expResponse, actualResponse);

	}

	@Test(description = "Make a request to Gahoo Search - Search by Technology Id 1 and 2. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Search_By_Technology_Id_1_2_Positive_Scenario(String baseUri) {
		searchText = "Card";
		technologyId = "1,2";
		currencyCode = "GBP";
		countryId = 54;
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t(searchText)
				.tn(technologyId)
				.c(countryId)
				.cc(currencyCode)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		Integer getId1 = actualResponse.getUserSearchDetails().get(0).id();
		String getgt1 = actualResponse.getUserSearchDetails().get(0).gt();
		String gettkn1 = actualResponse.getUserSearchDetails().get(0).tkn();		
		Integer getp1 = actualResponse.getUserSearchDetails().get(0).p();
		String getibn1 = actualResponse.getUserSearchDetails().get(0).ibn();
		Integer getindexpriority1 = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getIndexPriority();
		Integer getindexRanking1 = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getIndexRanking();
		Integer getProductGameId1 = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getProductGameId();
		String getWhy1 = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getWhy();

		Integer getId2 = actualResponse.getUserSearchDetails().get(1).id();
		String getgt2 = actualResponse.getUserSearchDetails().get(1).gt();
		String gettkn2 = actualResponse.getUserSearchDetails().get(1).tkn();		
		Integer getp2 = actualResponse.getUserSearchDetails().get(1).p();
		String getibn2 = actualResponse.getUserSearchDetails().get(1).ibn();
		Boolean gethci2 = actualResponse.getUserSearchDetails().get(1).hci();
		Integer getindexpriority2 = actualResponse.getUserSearchDetails().get(1).getDebugInfo().getIndexPriority();
		Integer getindexRanking2 = actualResponse.getUserSearchDetails().get(1).getDebugInfo().getIndexRanking();
		Integer getProductGameId2 = actualResponse.getUserSearchDetails().get(1).getDebugInfo().getProductGameId();
		String getWhy2 = actualResponse.getUserSearchDetails().get(1).getDebugInfo().getWhy();

		Integer getId3 = actualResponse.getUserSearchDetails().get(2).id();
		String getgt3 = actualResponse.getUserSearchDetails().get(2).gt();
		String gettkn3 = actualResponse.getUserSearchDetails().get(2).tkn();		
		Integer getp3 = actualResponse.getUserSearchDetails().get(2).p();
		String getibn3 = actualResponse.getUserSearchDetails().get(2).ibn();
		Integer getindexpriority3 = actualResponse.getUserSearchDetails().get(2).getDebugInfo().getIndexPriority();
		Integer getindexRanking3 = actualResponse.getUserSearchDetails().get(2).getDebugInfo().getIndexRanking();
		Integer getProductGameId3 = actualResponse.getUserSearchDetails().get(2).getDebugInfo().getProductGameId();
		String getWhy3 = actualResponse.getUserSearchDetails().get(2).getDebugInfo().getWhy();

		DebugInfo expecteddebuginfo1 = new DebugInfo.Builder().defaults()
				.indexPriority(getindexpriority1)
				.indexRanking(getindexRanking1)
				.productGameId(getProductGameId1)
				.why(getWhy1)
				.build();

		DebugInfo expecteddebuginfo2 = new DebugInfo.Builder().defaults()
				.indexPriority(getindexpriority2)
				.indexRanking(getindexRanking2)
				.productGameId(getProductGameId2)
				.why(getWhy2)
				.build();

		DebugInfo expecteddebuginfo3 = new DebugInfo.Builder().defaults()
				.indexPriority(getindexpriority3)
				.indexRanking(getindexRanking3)
				.productGameId(getProductGameId3)
				.why(getWhy3)
				.build();

		UserSearchDetails searchdetails1 = new UserSearchDetails.Builder()
				.defaults()
				.id(getId1)
				.gt(getgt1)
				.tkn(gettkn1)
				.p(getp1)
				.ibn(getibn1)
				.hci(null)
				.addDebugInfo(expecteddebuginfo1)
				.build();

		UserSearchDetails searchdetails2 = new UserSearchDetails.Builder()
				.defaults()
				.id(getId2)
				.gt(getgt2)
				.tkn(gettkn2)
				.p(getp2)
				.ibn(getibn2)
				.hci(gethci2)
				.addDebugInfo(expecteddebuginfo2)
				.build();

		UserSearchDetails searchdetails3 = new UserSearchDetails.Builder()
				.defaults()
				.id(getId3)
				.gt(getgt3)
				.tkn(gettkn3)
				.p(getp3)
				.ibn(getibn3)
				.hci(null)
				.addDebugInfo(expecteddebuginfo3)
				.build();

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(searchdetails1)
				.addUserSearchDetails(searchdetails2)
				.addUserSearchDetails(searchdetails3)
				.build();

		assertReflectionEquals(expResponse, actualResponse);

	}

	@Test(description = "Make a request to Gahoo Search - Exact Match for Estonia country and Estonian language. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Exact_Match_Estonia_Country_Estonian_Language_Positive_Scenario(String baseUri) {
		String searchText = "robocop";
		Integer productId = 2;
		Integer countryId = 64;
		Integer countryStateId = 0;
		Integer languageId = 29;
		String technologyId = "1,2";
		Integer platformTypeId = 1;
		Integer deviceGroupId = 1;
		String currencyCode = "EUR";
		Boolean userAgeVerified = true;
		Boolean searchCrossProduct = true;

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t(searchText)
				.p(productId)
				.c(countryId)
				.cs(countryStateId)
				.l(languageId)
				.tn(technologyId)
				.pt(platformTypeId)
				.dg(deviceGroupId)
				.cc(currencyCode)
				.uv(userAgeVerified)
				.cp(searchCrossProduct)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		Integer getId = actualResponse.getUserSearchDetails().get(0).id();
		String getgt = actualResponse.getUserSearchDetails().get(0).gt();
		String gettkn = actualResponse.getUserSearchDetails().get(0).tkn();		
		Integer getp = actualResponse.getUserSearchDetails().get(0).p();
		String getibn = actualResponse.getUserSearchDetails().get(0).ibn();
		Boolean gethci = actualResponse.getUserSearchDetails().get(0).hci();
		Integer getindexpriority = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getIndexPriority();
		Integer getindexRanking = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getIndexRanking();
		Integer getProductGameId = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getProductGameId();
		String getWhy = actualResponse.getUserSearchDetails().get(0).getDebugInfo().getWhy();

		DebugInfo expecteddebuginfo = new DebugInfo.Builder().defaults()
				.indexPriority(getindexpriority)
				.indexRanking(getindexRanking)
				.productGameId(getProductGameId)
				.why(getWhy)
				.build();

		UserSearchDetails searchdetails = new UserSearchDetails.Builder()
				.defaults()
				.id(getId)
				.gt(getgt)
				.tkn(gettkn)
				.p(getp)
				.ibn(getibn)
				.hci(gethci)
				.addDebugInfo(expecteddebuginfo)
				.build();

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(searchdetails)
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Null result. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Null_Result_Search_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("abcdfefijfiejifjeijfie")
				.build();

		GahooSearchNullResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchNullSuccess, baseUri);

		GahooSearchNullResp expResponse = new GahooSearchNullResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.result(null)
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Wrong method.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void gahooSearch_Wrong_Method(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: t.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void createGameRound_Missing_t_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: t")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: p.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void createGameRound_Missing_p_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.p(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: p")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: c.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void createGameRound_Missing_c_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.c(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: c")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	@Test(description = "Make a request to gahooSearch. Missing parameter: tn.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void createGameRound_Missing_tn_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.tn(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: tn")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: pt.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void createGameRound_Missing_pt_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.pt(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: pt")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: dg.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void createGameRound_Missing_dg_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.dg(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: dg")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Age Not Verified - uv. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch__Age_Not_Verified_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("Abracardabra")
				.uv(false)
				.build();

		GahooSearchNullResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchNullSuccess, baseUri);

		GahooSearchNullResp expResponse = new GahooSearchNullResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.result(null)
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

}
