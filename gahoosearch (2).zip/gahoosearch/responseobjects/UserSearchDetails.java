package tests.gahoosearch.responseobjects;

public class UserSearchDetails {

	@SuppressWarnings("unused")
	protected Integer id;
	@SuppressWarnings("unused")
	protected String gt;
	@SuppressWarnings("unused")
	protected String tkn;
	@SuppressWarnings("unused")
	protected Integer p;
	@SuppressWarnings("unused")
	protected String ibn;
	@SuppressWarnings("unused")
	protected Boolean hci;
	@SuppressWarnings("unused")
	protected String ipei;
	@SuppressWarnings("unused")
	protected DebugInfo debugInfo;

	private UserSearchDetails(Builder builder) {
		this.id = builder.id;
		this.gt = builder.gt;
		this.tkn = builder.tkn;
		this.p = builder.p;
		this.ibn = builder.ibn;
		this.hci = builder.hci;
		this.ipei = builder.ipei;
		this.debugInfo = builder.debugInfo;
	}

	public Integer id() {
		return id;
	}

	public String gt() {
		return gt;
	}

	public String tkn() {
		return tkn;
	}

	public Integer p() {
		return p;
	}

	public String ibn() {
		return ibn;
	}

	public Boolean hci() {
		return hci;
	}

	public DebugInfo getDebugInfo(){
		return debugInfo;
	}

	public static class Builder {
		public Boolean hci;
		public String ibn;
		public Integer p;
		public String tkn;
		public String gt;
		public Integer id;
		public String ipei;
		private DebugInfo debugInfo;

		public Builder id(Integer id) {
			this.id = id;
			return this;
		}

		public Builder ibn(String ibn) {
			this.ibn = ibn;
			return this;
		}

		public Builder p(Integer p) {
			this.p = p;
			return this;
		}

		public Builder tkn(String tkn) {
			this.tkn = tkn;
			return this;
		}

		public Builder gt(String gt) {
			this.gt = gt;
			return this;
		}
		
		public Builder ipei(String ipei) {
			this.ipei = ipei;
			return this;
		}

		public Builder hci(Boolean hci) {
			this.hci = hci;
			return this;
		}

		
      public Builder addDebugInfo(DebugInfo debugInfo) { 
			  this.debugInfo = debugInfo;
			  return this; 
	   }
		 
		public Builder defaults() {
			this.id = 10415;
			this.gt = "games test";		
			this.tkn = "gamestest";	
			this.p = 4;
			this.ibn = "WildWildWest";
			this.hci = true;
			this.debugInfo = new DebugInfo.Builder().defaults().build();
			return this;
		}

		public UserSearchDetails build() {
			UserSearchDetails result = new UserSearchDetails(this);
			return result;
		}
	}
}
