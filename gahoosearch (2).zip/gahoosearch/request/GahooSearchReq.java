package tests.gahoosearch.request;

public class GahooSearchReq {
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Params Params;
	
	private GahooSearchReq(Builder builder) {
		this.Method = builder.Method;
		this.ID = builder.ID;
		this.Params = new Params(builder);
	}
	
	public static class Builder {
		private String Method;
		private String ID;
		private String t;
		private Integer p;
		private Integer c;
		private Integer cs;
		private Integer l;
		private String tn;
		private Integer pt;
		private Integer dg;
		private String cc;
		private Boolean uv;
		private Boolean cp;
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder id(String id) {
			this.ID = id;
			return this;
		}
				
		public Builder t(String t) {
			this.t = t;
			return this;
		}
		
		public Builder p(Integer p) {
			this.p = p ;
			return this;
		}
		
		public Builder c(Integer c) {
			this.c = c;
			return this;
		}
		
		public Builder cs(Integer cs) {
			this.cs = cs;
			return this;
		}
		
		public Builder l(Integer l) {
			this.l = l;
			return this;
		}
		
		public Builder tn(String tn) {
			this.tn = tn;
			return this;
		}
		
		public Builder pt(Integer pt) {
			this.pt = pt;
			return this;
		}
		
		public Builder dg(Integer dg) {
			this.dg = dg;
			return this;
		}
		
		public Builder cc(String cc) {
			this.cc = cc;
			return this;
		}
		
		public Builder uv(Boolean uv) {
			this.uv = uv;
			return this;
		}
		
		public Builder cp(Boolean cp) {
			this.cp = cp;
			return this;
		}
		
		public Builder defaults() {
			this.Method = "search";
			this.ID = "1646753181754";
			this.t = "Beetlejuice";
			this.p = 4;
			this.c = 36;
			this.cs = 72;
			this.l = 1;
			this.tn = "2";
			this.pt = 1;
			this.dg = 1;
			this.cc = "CAD";
			this.uv = true;
			this.cp = true;
			return this;
		}
		
		public GahooSearchReq build() {
			return new GahooSearchReq(this);
		}
	}
	
	private class Params {
		@SuppressWarnings("unused")
		String t;
		@SuppressWarnings("unused")
		Integer p;
		@SuppressWarnings("unused")
		Integer c;
		@SuppressWarnings("unused")
		Integer cs;
		@SuppressWarnings("unused")
		Integer l;
		@SuppressWarnings("unused")
		String tn;
		@SuppressWarnings("unused")
		Integer pt;
		@SuppressWarnings("unused")
		Integer dg;
		@SuppressWarnings("unused")
		String cc;
		@SuppressWarnings("unused")
		Boolean uv;
		@SuppressWarnings("unused")
		Boolean cp;
		
		public Params(Builder builder) {
			this.t = builder.t;
			this.p = builder.p;
			this.c = builder.c;
			this.cs = builder.cs;
			this.l = builder.l;
			this.tn = builder.tn;
			this.pt = builder.pt;
			this.dg = builder.dg;
			this.cc = builder.cc;
			this.uv = builder.uv;
			this.cp = builder.cp;
		}
	}
}
