package resources.payloads;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import common.Utils;

public class PtewPayloads {

	public static String startGameSessionRequestBody(String userName, String publicToken, String userCurrency, String remoteSessionCode, int remoteSessionType) {

		int flowId = Utils.getRandomMessageId();
		int messageId = Utils.getRandomMessageId();
		String remoteSessionStartDate = Utils.getZoneLocalDateFormat("UTC", DateTimeFormatter.ISO_LOCAL_DATE_TIME).replace("T", " ");
		String windowSessionId = Utils.generateRandomString();

		String startGameSessionRequestBody = "<ns2:startGameSessionRequest xmlns:ns2=\"http://www.playtech.com/services/external/wallet\" xmlns:ns4=\"playtech.com/galaxy/core\" xmlns:ns3=\"http://www.playtech.com/services/common\">\r\n"
				+ "  <ns4:flow id=\""+flowId+":1\"/>\r\n"
				+ "  <ns2:messageId>"+messageId+"</ns2:messageId>\r\n"
				+ "  <ns2:replyToAddress>replyToAddress</ns2:replyToAddress>\r\n"
				+ "  <ns2:playerIdentityByCasinoAndUsername>\r\n"
				+ "    <ns3:casino>ptstaging2.15</ns3:casino>\r\n"
				+ "    <ns3:username>"+userName+"</ns3:username>\r\n"
				+ "  </ns2:playerIdentityByCasinoAndUsername>\r\n"
				+ "  <ns2:authenticationBySessionToken>\r\n"
				+ "    <ns3:sessionToken>"+publicToken+"</ns3:sessionToken>\r\n"
				+ "    <ns3:systemId>1234</ns3:systemId>\r\n"
				+ "  </ns2:authenticationBySessionToken>\r\n"
				+ "  <ns2:contextByClientParameters>\r\n"
				+ "    <ns3:clientPlatform>download</ns3:clientPlatform>\r\n"
				+ "    <ns3:clientType>poker</ns3:clientType>\r\n"
				+ "    <ns3:gameType>ps</ns3:gameType>\r\n"
				+ "  </ns2:contextByClientParameters>\r\n"
				+ "  <ns2:timeout>118985</ns2:timeout>\r\n"
				+ "  <ns2:customData>\r\n"
				+ "    <ns2:gameType>ps</ns2:gameType>\r\n"
				+ "  </ns2:customData>\r\n"
				+ "  <ns2:currencyCode>"+userCurrency+"</ns2:currencyCode>\r\n"
				+ "  <ns2:networkId>1234</ns2:networkId>\r\n"
				+ "  <ns2:remoteSessionCode>"+remoteSessionCode+"</ns2:remoteSessionCode>\r\n"
				+ "  <ns2:remoteSessionStartDate>"+remoteSessionStartDate+"</ns2:remoteSessionStartDate>\r\n"
				+ "  <ns2:remoteSessionParameters>\r\n"
				+ "    <ns2:clientPlatform>download</ns2:clientPlatform>\r\n"
				+ "    <ns2:clientType>poker</ns2:clientType>\r\n"
				+ "    <ns2:gameType>ps</ns2:gameType>\r\n"
				+ "    <ns2:remoteSessionType>"+remoteSessionType+"</ns2:remoteSessionType>\r\n"
				+ "  </ns2:remoteSessionParameters>\r\n"
				+ "  <ns2:windowSessionId>"+windowSessionId+"</ns2:windowSessionId>\r\n"
				+ "</ns2:startGameSessionRequest>";

		return startGameSessionRequestBody;
	}
	
	public static String gameMultiBalanceTransactionRequestBody(String userName, String publicToken, String userCurrency, String remoteSessionCode, String actionType1, BigDecimal betAmount) {

		int flowId = Utils.getRandomMessageId();
		int messageId = Utils.getRandomMessageId();
		String transactionCode = Utils.generateRandomString();
		String transactionDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

		String gameMultiBalanceTransactionRequestBody = "<ns2:gameMultiBalanceTransactionRequest xmlns:ns2=\"http://www.playtech.com/services/external/wallet\" "
				+ "xmlns:ns4=\"playtech.com/galaxy/core\" xmlns:ns3=\"http://www.playtech.com/services/common\">\r\n"
				+ "  <ns4:flow id=\""+flowId+":1\"/>\r\n"
				+ "  <ns2:actionType>"+actionType1+"</ns2:actionType>\r\n"
				+ "  <ns2:authenticationBySessionToken>\r\n"
				+ "    <ns3:sessionToken>"+publicToken+"</ns3:sessionToken>\r\n"
				+ "    <ns3:systemId>1234</ns3:systemId>\r\n"
				+ "  </ns2:authenticationBySessionToken>\r\n"
				+ "  <ns2:balanceChanges>\r\n"
				+ "    <ns2:balanceChange>\r\n"
				+ "      <ns3:amount>\r\n"
				+ "        <ns3:amount>"+betAmount+"</ns3:amount>\r\n"
				+ "        <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "      </ns3:amount>\r\n"
				+ "      <ns3:balanceType>external_real_balance</ns3:balanceType>\r\n"
				+ "    </ns2:balanceChange>\r\n"
				+ "  </ns2:balanceChanges>\r\n"
				+ "  <ns2:contextByClientParameters>\r\n"
				+ "    <ns3:clientPlatform>web</ns3:clientPlatform>\r\n"
				+ "    <ns3:clientType>poker</ns3:clientType>\r\n"
				+ "    <ns3:gameType>ps</ns3:gameType>\r\n"
				+ "  </ns2:contextByClientParameters>\r\n"
				+ "  <ns2:customData>\r\n"
				+ "    <ns2:gameType>ps</ns2:gameType>\r\n"
				+ "  </ns2:customData>\r\n"
				+ "  <ns2:displayAmount>\r\n"
				+ "    <ns3:amount>"+betAmount+"</ns3:amount>\r\n"
				+ "    <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "  </ns2:displayAmount>\r\n"
				+ "  <ns2:externalBalanceChanges/>\r\n"
				+ "  <ns2:messageId>"+messageId+"</ns2:messageId>\r\n"
				+ "  <ns2:networkId>1234</ns2:networkId>\r\n"
				+ "  <ns2:playerIdentityByCasinoAndUsername>\r\n"
				+ "    <ns3:casino>ptstaging2.15</ns3:casino>\r\n"
				+ "    <ns3:username>"+userName+"</ns3:username>\r\n"
				+ "  </ns2:playerIdentityByCasinoAndUsername>\r\n"
				+ "  <ns2:pokerTournamentDepositParameters>\r\n"
				+ "    <ns2:amount>\r\n"
				+ "      <ns3:amount>1</ns3:amount>\r\n"
				+ "      <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "    </ns2:amount>\r\n"
				+ "    <ns2:containerCode>43284608</ns2:containerCode>\r\n"
				+ "    <ns2:containerName>Tourney Rebuy</ns2:containerName>\r\n"
				+ "    <ns2:fee>\r\n"
				+ "      <ns3:amount>0.07</ns3:amount>\r\n"
				+ "      <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "    </ns2:fee>\r\n"
				+ "  </ns2:pokerTournamentDepositParameters>\r\n"
				+ "  <ns2:remoteSessionCode>"+remoteSessionCode+"</ns2:remoteSessionCode>\r\n"
				+ "  <ns2:replyToAddress>replyToAddress</ns2:replyToAddress>\r\n"
				+ "  <ns2:taxableBonusAmount>\r\n"
				+ "    <ns3:amount>0</ns3:amount>\r\n"
				+ "    <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "  </ns2:taxableBonusAmount>\r\n"
				+ "  <ns2:timeout>118985</ns2:timeout>\r\n"
				+ "  <ns2:transactionBreakdown>\r\n"
				+ "    <ns2:balanceChange>\r\n"
				+ "      <ns3:amount>\r\n"
				+ "        <ns3:amount>0</ns3:amount>\r\n"
				+ "        <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "      </ns3:amount>\r\n"
				+ "      <ns3:balanceType>real</ns3:balanceType>\r\n"
				+ "    </ns2:balanceChange>\r\n"
				+ "    <ns2:balanceChange>\r\n"
				+ "      <ns3:amount>\r\n"
				+ "        <ns3:amount>0</ns3:amount>\r\n"
				+ "        <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "      </ns3:amount>\r\n"
				+ "      <ns3:balanceType>bonus</ns3:balanceType>\r\n"
				+ "    </ns2:balanceChange>\r\n"
				+ "  </ns2:transactionBreakdown>\r\n"
				+ "  <ns2:transactionCode>"+transactionCode+"</ns2:transactionCode>\r\n"
				+ "  <ns2:transactionDate>"+transactionDate+"</ns2:transactionDate>\r\n"
				+ "  <ns2:transactionExtraParameters>\r\n"
				+ "    <ns2:description>Registration to tournament Tourney Rebuy (43284608) for EUR 4 ( + Fee 1).</ns2:description>\r\n"
				+ "  </ns2:transactionExtraParameters>\r\n"
				+ "  <ns2:windowSessionId>FfDMhQrnWqEffREzf9/DWicw3LvIuFFLueCr+OzK684=</ns2:windowSessionId>\r\n"
				+ "</ns2:gameMultiBalanceTransactionRequest>";

		return gameMultiBalanceTransactionRequestBody;
	}
	
	public static String gameWinMultiBalanceTransactionRequestBody(String userName, String publicToken, String userCurrency, String remoteSessionCode, String actionType2, BigDecimal winAmount) {

		int flowId = Utils.getRandomMessageId();
		int messageId = Utils.getRandomMessageId();
		String transactionCode = Utils.generateRandomString();
		String transactionDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

		String gameWinMultiBalanceTransactionRequestBody = "<ns2:gameMultiBalanceTransactionRequest xmlns:ns2=\"http://www.playtech.com/services/external/wallet\" "
				+ "xmlns:ns4=\"playtech.com/galaxy/core\" xmlns:ns3=\"http://www.playtech.com/services/common\">\r\n"
				+ "  <ns4:flow id=\""+flowId+":1\"/>\r\n"
				+ "  <ns2:actionType>"+actionType2+"</ns2:actionType>\r\n"
				+ "  <ns2:authenticationBySessionToken>\r\n"
				+ "    <ns3:sessionToken>"+publicToken+"</ns3:sessionToken>\r\n"
				+ "    <ns3:systemId>1234</ns3:systemId>\r\n"
				+ "  </ns2:authenticationBySessionToken>\r\n"
				+ "  <ns2:balanceChanges>\r\n"
				+ "    <ns2:balanceChange>\r\n"
				+ "      <ns3:amount>\r\n"
				+ "        <ns3:amount>"+winAmount+"</ns3:amount>\r\n"
				+ "        <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "      </ns3:amount>\r\n"
				+ "      <ns3:balanceType>external_real_balance</ns3:balanceType>\r\n"
				+ "    </ns2:balanceChange>\r\n"
				+ "  </ns2:balanceChanges>\r\n"
				+ "  <ns2:contextByClientParameters>\r\n"
				+ "    <ns3:clientPlatform>web</ns3:clientPlatform>\r\n"
				+ "    <ns3:clientType>poker</ns3:clientType>\r\n"
				+ "    <ns3:gameType>ps</ns3:gameType>\r\n"
				+ "  </ns2:contextByClientParameters>\r\n"
				+ "  <ns2:customData>\r\n"
				+ "    <ns2:gameType>ps</ns2:gameType>\r\n"
				+ "  </ns2:customData>\r\n"
				+ "  <ns2:displayAmount>\r\n"
				+ "    <ns3:amount>"+winAmount+"</ns3:amount>\r\n"
				+ "    <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "  </ns2:displayAmount>\r\n"
				+ "  <ns2:externalBalanceChanges/>\r\n"
				+ "  <ns2:messageId>"+messageId+"</ns2:messageId>\r\n"
				+ "  <ns2:networkId>1234</ns2:networkId>\r\n"
				+ "  <ns2:playerIdentityByCasinoAndUsername>\r\n"
				+ "    <ns3:casino>ptstaging2.15</ns3:casino>\r\n"
				+ "    <ns3:username>"+userName+"</ns3:username>\r\n"
				+ "  </ns2:playerIdentityByCasinoAndUsername>\r\n"
				+ "  <ns2:pokerTournamentWinParameters>\r\n"
				+ "    <ns2:amount>\r\n"
				+ "      <ns3:amount>0</ns3:amount>\r\n"
				+ "      <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "    </ns2:amount>\r\n"
				+ "    <ns2:containerCode>43284608</ns2:containerCode>\r\n"
				+ "    <ns2:containerName>Tourney Rebuy</ns2:containerName>\r\n"
				+ "    <ns2:finishingPlace>1</ns2:finishingPlace>\r\n"
				+ "  </ns2:pokerTournamentWinParameters>"
				+ "  <ns2:remoteSessionCode>"+remoteSessionCode+"</ns2:remoteSessionCode>\r\n"
				+ "  <ns2:replyToAddress>replyToAddress</ns2:replyToAddress>\r\n"
				+ "  <ns2:taxableBonusAmount>\r\n"
				+ "    <ns3:amount>0</ns3:amount>\r\n"
				+ "    <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "  </ns2:taxableBonusAmount>\r\n"
				+ "  <ns2:timeout>118985</ns2:timeout>\r\n"
				+ "  <ns2:transactionBreakdown>\r\n"
				+ "    <ns2:balanceChange>\r\n"
				+ "      <ns3:amount>\r\n"
				+ "        <ns3:amount>0</ns3:amount>\r\n"
				+ "        <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "      </ns3:amount>\r\n"
				+ "      <ns3:balanceType>real</ns3:balanceType>\r\n"
				+ "    </ns2:balanceChange>\r\n"
				+ "    <ns2:balanceChange>\r\n"
				+ "      <ns3:amount>\r\n"
				+ "        <ns3:amount>0</ns3:amount>\r\n"
				+ "        <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "      </ns3:amount>\r\n"
				+ "      <ns3:balanceType>bonus</ns3:balanceType>\r\n"
				+ "    </ns2:balanceChange>\r\n"
				+ "  </ns2:transactionBreakdown>\r\n"
				+ "  <ns2:transactionCode>"+transactionCode+"</ns2:transactionCode>\r\n"
				+ "  <ns2:transactionDate>"+transactionDate+"</ns2:transactionDate>\r\n"
				+ "  <ns2:transactionExtraParameters>\r\n"
				+ "    <ns2:description>Prize 2.15 for place 1 in tournament Tourney Rebuy (43284608) for EUR 4 ( + Fee 1).</ns2:description>\r\n"
				+ "  </ns2:transactionExtraParameters>\r\n"
				+ "  <ns2:windowSessionId>FfDMhQrnWqEffREzf9/DWicw3LvIuFFLueCr+OzK684=</ns2:windowSessionId>\r\n"
				+ "</ns2:gameMultiBalanceTransactionRequest>";

		return gameWinMultiBalanceTransactionRequestBody;
	}
	
	public static String endGameRequestBody(String userName, String publicToken, String userCurrency, String remoteSessionCode) {

		int flowId = Utils.getRandomMessageId();
		int messageId = Utils.getRandomMessageId();
		String remoteSessionEndDate = Utils.getZoneLocalDateFormat("UTC", DateTimeFormatter.ISO_LOCAL_DATE_TIME).replace("T", " ");

		String endGameRequestBody = "<ns2:endGameSessionRequest xmlns:ns2=\"http://www.playtech.com/services/external/wallet\" xmlns:ns4=\"playtech.com/galaxy/core\" xmlns:ns3=\"http://www.playtech.com/services/common\">\r\n"
				+ "  <ns4:flow id=\""+flowId+":1\"/>\r\n"
				+ "  <ns2:messageId>"+messageId+"</ns2:messageId>\r\n"
				+ "  <ns2:playerIdentityByCasinoAndUsername>\r\n"
				+ "    <ns3:casino>ptstaging2.15</ns3:casino>\r\n"
				+ "    <ns3:username>"+userName+"</ns3:username>\r\n"
				+ "  </ns2:playerIdentityByCasinoAndUsername>\r\n"
				+ "  <ns2:authenticationBySessionToken>\r\n"
				+ "    <ns3:sessionToken>"+publicToken+"</ns3:sessionToken>\r\n"
				+ "    <ns3:systemId>1234</ns3:systemId>\r\n"
				+ "  </ns2:authenticationBySessionToken>\r\n"
				+ "  <ns2:contextByClientParameters>\r\n"
				+ "    <ns3:clientPlatform>download</ns3:clientPlatform>\r\n"
				+ "    <ns3:clientType>poker</ns3:clientType>\r\n"
				+ "    <ns3:gameType>ps</ns3:gameType>\r\n"
				+ "  </ns2:contextByClientParameters>\r\n"
				+ "  <ns2:customData>\r\n"
				+ "    <ns2:gameType>ps</ns2:gameType>\r\n"
				+ "  </ns2:customData>\r\n"
				+ "  <ns2:remoteSessionCode>"+remoteSessionCode+"</ns2:remoteSessionCode>\r\n"
				+ "  <ns2:networkId>1234</ns2:networkId>\r\n"
				+ "  <ns2:remoteSessionParameters>\r\n"
				+ "    <ns2:serviceFee>0.05932956</ns2:serviceFee>\r\n"
				+ "  </ns2:remoteSessionParameters>\r\n"
				+ "  <ns2:remoteSessionEndDate>"+remoteSessionEndDate+"</ns2:remoteSessionEndDate>\r\n"
				+ "  <ns2:jackpotBet>\r\n"
				+ "    <ns3:amount>0</ns3:amount>\r\n"
				+ "    <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "  </ns2:jackpotBet>\r\n"
				+ "  <ns2:jackpotWin>\r\n"
				+ "    <ns3:amount>0</ns3:amount>\r\n"
				+ "    <ns3:currencyCode>"+userCurrency+"</ns3:currencyCode>\r\n"
				+ "  </ns2:jackpotWin>\r\n"
				+ "  <ns2:windowSessionId>6u7P74IeDMRqRWnX1oEC</ns2:windowSessionId>\r\n"
				+ "</ns2:endGameSessionRequest>";
		
		return endGameRequestBody;
	}
	
	public static String loginRequestBody(String userName, String token) {

		int flowId = Utils.getRandomMessageId();
		int messageId = Utils.getRandomMessageId();
		String loginTime = Utils.getZoneLocalDateFormat("UTC", DateTimeFormatter.ISO_LOCAL_DATE_TIME).replace("T", " ");

		String endGameRequestBody = "<ns2:loginRequest\r\n"
				+ "	xmlns:ns2=\"http://www.playtech.com/services/external/wallet\"\r\n"
				+ "	xmlns:ns6=\"playtech.com/galaxy/core\"\r\n"
				+ "	xmlns:ns4=\"http://www.playtech.com/services/common\">\r\n"
				+ "	<ns4:flow id=\""+flowId+":1\"/>\r\n"
				+ "	<ns2:messageId>"+messageId+"</ns2:messageId>\r\n"
				+ "	<ns2:replyToAddress>AgGE6QMJph8=</ns2:replyToAddress>\r\n"
				+ "	<ns2:playerIdentityByCasinoAndUsername>\r\n"
				+ "		<ns6:casino>ptstaging2.15</ns6:casino>\r\n"
				+ "		<ns6:username>"+userName+"</ns6:username>\r\n"
				+ "	</ns2:playerIdentityByCasinoAndUsername>\r\n"
				+ "	<ns2:authenticationByPassword>\r\n"
				+ "		<ns6:systemId>377</ns6:systemId>\r\n"
				+ "		<ns6:password>"+token+"</ns6:password>\r\n"
				+ "	</ns2:authenticationByPassword>\r\n"
				+ "	<ns2:contextByClientParameters>\r\n"
				+ "		<ns6:clientType>poker</ns6:clientType>\r\n"
				+ "		<ns6:clientPlatform>web</ns6:clientPlatform>\r\n"
				+ "		<ns6:clientSkinName>ptstaging2.15</ns6:clientSkinName>\r\n"
				+ "		<ns6:languageCode>EN</ns6:languageCode>\r\n"
				+ "		<ns6:ipAddress>178.237.164.20</ns6:ipAddress>\r\n"
				+ "		<ns6:deliveryPlatform>HTML5</ns6:deliveryPlatform>\r\n"
				+ "		<ns6:userAgent>Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36</ns6:userAgent>\r\n"
				+ "	</ns2:contextByClientParameters>\r\n"
				+ "	<ns2:customData/>\r\n"
				+ "	<ns2:ipAddress>178.237.164.20</ns2:ipAddress>\r\n"
				+ "	<ns2:loginTime>"+loginTime+"</ns2:loginTime>\r\n"
				+ "</ns2:loginRequest>";
		
		return endGameRequestBody;
	}


}
