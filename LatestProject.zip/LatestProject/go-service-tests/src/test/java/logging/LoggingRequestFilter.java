package logging;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;

public class LoggingRequestFilter implements Filter {

	@Override
	public Response filter(FilterableRequestSpecification requestSpec, FilterableResponseSpecification responseSpec, FilterContext ctx) {
		String requestMethod = requestSpec.getMethod();
		Log.requestMethod(requestMethod);

		String requestUri = requestSpec.getURI();
		Log.requestUri(requestUri);

		Headers headers = requestSpec.getHeaders();
		Log.headers(headers);

		String requestBody = requestSpec.getBody();
		if(requestBody != null) {
			String jsonRequestBody = JsonFormatter.getFormattedJson(requestBody);
			Log.requestBody(jsonRequestBody);
		}

		Response response = ctx.next(requestSpec, responseSpec);
		String responseBody = response.getBody().asString();
		String jsonResponseBody = "";
		String contentType = response.getHeader("Content-Type") == null ? "" : response.getHeader("Content-Type");
		if (contentType.contains("application/json")) {
			jsonResponseBody = JsonFormatter.getFormattedJson(responseBody);	
		} else {
			jsonResponseBody = responseBody;
		}
		
		Log.responseBody(jsonResponseBody);

		return response; 
	}
	
}
