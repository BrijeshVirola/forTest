package logging;

import org.testng.Reporter;

import io.restassured.http.Headers;

public class Log {
	
	final static String HTML_END = " </font> </div>&emsp;";
	final static String HTML_BEGIN = "<div class=\"test-result\"><font><strong> %s: </strong> <font color=\"%s\">";
	final static String WRAPPER_BEGIN = "<div id=\"wrapper\">";
	final static String WRAPPER_END = "</div>";
	
	final static String GET_METHOD = " <div id=\"getMethod\"> %s </div>";
	final static String POST_METHOD = " <div id=\"psotMethod\"> %s </div>";
	final static String PUT_METHOD = " <div id=\"putMethod\"> %s </div>";
	
	final static String PAYLOAD = " <div id=\"payload\"> <strong> <pre> %s </pre> </strong> </div>";
	
	public static void event(String description) {
		Reporter.log(description, true);
	}
	
	public static void requestMethod(String method) {
		String methodHTML = method.equalsIgnoreCase("get") ? GET_METHOD : 
			method.equalsIgnoreCase("post") ? POST_METHOD  : PUT_METHOD;
		final String RERQUEST_HTML_BEGIN = String.format(HTML_BEGIN, "Request Method", "white");
		Reporter.log(WRAPPER_BEGIN + RERQUEST_HTML_BEGIN + String.format(methodHTML, method) + HTML_END);

	}
	
	public static void requestUri(String uri) {
		final String RERQUEST_HTML_BEGIN = String.format(HTML_BEGIN, "Request URI", "blue");
		Reporter.log(RERQUEST_HTML_BEGIN + "<i>" + uri + "</i>" + HTML_END);

	}
	
	public static void headers(Headers headers) {
		final String RERQUEST_HTML_BEGIN = String.format(HTML_BEGIN, "Request Headers", "#585858");
		Reporter.log(RERQUEST_HTML_BEGIN + headers + HTML_END);

	}
	
	public static void requestBody(String body) {
		final String RERQUEST_HTML_BEGIN = String.format(HTML_BEGIN, "Request Body", "#8601af");
		Reporter.log(RERQUEST_HTML_BEGIN + String.format(PAYLOAD, body) + HTML_END);

	}

	public static void responseBody(String body) {
		final String RERQUEST_HTML_BEGIN = String.format(HTML_BEGIN, "Response Body", "#cd5700");
		Reporter.log(RERQUEST_HTML_BEGIN + String.format(PAYLOAD, body) + HTML_END + WRAPPER_END);

	}
	
}
