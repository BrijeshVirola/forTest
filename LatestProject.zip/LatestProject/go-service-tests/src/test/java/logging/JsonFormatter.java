package logging;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

public class JsonFormatter {
	
	public static String getFormattedJson(String input) {
		JsonElement je = jp.parse(input);
		return gson.toJson(je);			
	}
	
	private static Gson gson = new GsonBuilder().setPrettyPrinting().create();
	private static JsonParser jp = new JsonParser();
}
