package common.RetryTestFailures;

import java.util.Map;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ISuiteResult;
import org.testng.ITestContext;

/**
 * Removes retried tests from the reporting after every run. This class should be added as listener in the xml file if the re-run logic is needed
 * @author petarpetrov
 *
 */
public class SuiteResultListener implements ISuiteListener {

	@Override
	public void onStart(ISuite suite) {
	}

	@Override
	public void onFinish(ISuite suite) {
		final Map<String, ISuiteResult> results = suite.getResults();

		for (ISuiteResult result : results.values()) {
			final ITestContext testContext = result.getTestContext();
			CleanUpDuplicate.cleanUpSkippedTests(testContext);
			CleanUpDuplicate.cleanUpDuplicateFailures(testContext);
		}
	}
}

