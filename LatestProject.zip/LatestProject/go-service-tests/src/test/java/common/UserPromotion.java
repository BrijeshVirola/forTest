package common;

import java.util.UUID;

public class UserPromotion {
	
	public UUID goldenChiptoken;
	int userPromotionHistoryId;
	String userName;
	int userID;
	public UUID freeSpinToken;
	
	public UserPromotion(String userName) {
		this.userName = userName;
		this.userID = DatabaseQueries.getUserIdFromUserTable(userName);
		this.freeSpinToken = UUID.randomUUID();
	}

	/**
	 * Remove user from promotion
	 * @param promotionID
	 */
	public void removeUserFromPromotion(int promotionID) {
		DatabaseQueries.removeUserFromPromotionById(userID, promotionID);
	}
	
	/**
	 * Adds user to free spin promotion
	 * @param promotionID
	 * @param claimed
	 * @param remainingSpins
	 */
	public void addUserToFreeSpinPromotion(int promotionID, int claimed, int remainingSpins) {
		DatabaseQueries.freeSpinAddUserToPromotion(promotionID, userID, freeSpinToken, claimed, remainingSpins);
	}
	
}
