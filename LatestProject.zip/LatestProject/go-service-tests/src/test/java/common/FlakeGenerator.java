package common;

import java.util.Date;

public class FlakeGenerator {

	public static long nextId(long nodeId) {
		Date date = new Date();
		long time = date.getTime();
		long sequenceId = time & 0X7FFFFFFFFFFFL;
		
		long flakeId = (nodeId << 47L | sequenceId);
		
		return flakeId;
	}
}
