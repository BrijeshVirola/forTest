package common;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.testng.Reporter;

import common.enumsconstants.LoginGGI;
import common.enumsconstants.ProductId;
import io.restassured.RestAssured;
import io.restassured.filter.Filter;
import io.restassured.http.ContentType;
import io.restassured.internal.support.Prettifier;
import io.restassured.parsing.Parser;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import resources.payloads.PtewPayloads;

public class XmlUtils {

	private static Filter requestFilter;
	public static boolean printconsoleoutput = false;
	private static SecureRandom randomMessageId = null;
	final static String MESSAGE_HTML_BEGIN = "<div class=\"test-message\">&emsp;";
	final static String MESSAGE_HTML_END = "</div>";
	final static String EVENT_HTML_BEGIN = "<div class=\"test-event\"> <font color=\"maroon\"> <small> &emsp; &emsp;--- "; 
	final static String EVENT_HTML_END = "</small> </font> </div>";
	public static String HTML_PRECONDITIONS_START = "<p><b><i><font color=\"dimgray\" style=\"font-size:17px\"> <strong> Preconditions: </strong></font></i></b></p><i><font color=\"lightslategray\"";
	public static String HTML_PRECONDITIONS_END = "</font></i>";

	static {
		requestFilter = (req, response, ctx) -> {
			preformattedMessage("<b>Request method:</b> " + req.getMethod() + "\n<b>Request URI:</b> " + req.getURI()); 
			preformattedMessage("<b>Request headers:</b>\n" + req.getHeaders()); 
			if (req.getBody() != null) {
				xmlMessage("<b>Request body</b>" + " :\n", req.getBody());
			}
			return ctx.next(req, response); 
		};

		try {
			randomMessageId = SecureRandom.getInstance("SHA1PRNG");
		} catch (NoSuchAlgorithmException e) {
			event("Cannot create randomMessageId object: " + e.getMessage());
		}
	}

	public static void event(String description) {

		String currDate = new SimpleDateFormat("dd MMM HH:mm:ss SSS").format(Calendar.getInstance().getTime());
		Reporter.log(EVENT_HTML_BEGIN + currDate + " - " + description + EVENT_HTML_END);

		if (printconsoleoutput)
			System.out.println("\t--- " + description + "[Time: " + currDate + "]");

	}

	public static String createTestToken(String username, int regulatedGameId, ProductId productId) {

		return createTestToken(username, productId, regulatedGameId, 30, 600);

	}

	public static Filter getRequestFilter() {

		return requestFilter;

	}

	public static void preformattedMessage(String description) {

		Reporter.log("<pre>" + description + "</pre>");

		if (printconsoleoutput)
			System.out.println(description.replace("&emsp;", "\t"));

	}

	public static void xmlMessage(String preformattetContent, String xmlContent) {

		Reporter.log("<pre>" + preformattetContent + "</pre>");
		Reporter.log("<xmp>" + xmlContent + "</xmp>");

		if (printconsoleoutput)
			System.out.println(xmlContent.replace("&emsp;", "\t"));
	}

	public static void prettyBodyMessage(Response response, String requestApi) {

		Prettifier prettifier = new Prettifier();
		String prettyBody = prettifier.getPrettifiedBodyIfPossible(response, response.getBody());
		int statusCode = response.statusCode();
		preformattedMessage("<b>Response status:</b> " + statusCode);
		xmlMessage("<b>Response body</b> of " + requestApi + " :\n", prettyBody);

	}

	public static void prettyBodyMessageRequest(String xmlBody) {

		Prettifier prettifier = new Prettifier();
		String prettyBody = prettifier.prettify(xmlBody, Parser.XML);
		preformattedMessage("<b>Request body:</b>\n" + prettyBody);

	}

	public static String getUserLoginName (String userName) {

		String userCountry = DatabaseQueries.getUserCountryFromUserTable(userName);

		if (userCountry.equals("UK")) {
			return LoginGGI.LOGIN_UK.getUsername();
		}
		if (userCountry.equals("Denmark")) {
			return LoginGGI.LOGIN_DK.getUsername();
		}
		if (userCountry.equals("Spain")) {
			return LoginGGI.LOGIN_ES.getUsername();
		}
		if (userCountry.equals("Netherlands")) {
			return LoginGGI.LOGIN_NL.getUsername();
		}
		if (userCountry.equals("Mexico")) {
			return LoginGGI.LOGIN_MX.getUsername();
		}
		if (userCountry.equals("Sweden")) {
			return LoginGGI.LOGIN_SE.getUsername();
		}
		if (userCountry.equals("BAC")) {
			return LoginGGI.LOGIN_BAC.getUsername();
		}
		if (userCountry.equals("BAP")) {
			return LoginGGI.LOGIN_BAP.getUsername();
		}
		if (userCountry.equals("Ontario")) {
			return LoginGGI.LOGIN_ONT.getUsername();
		}
		if (userCountry.equals("Greece")) {
			return LoginGGI.LOGIN_GR.getUsername();
		} else {return null;}
	}

	public static String getUserLoginPassword (String userName) {

		String userCountry = DatabaseQueries.getUserCountryFromUserTable(userName);

		if (userCountry.equals("UK")) {
			return LoginGGI.LOGIN_UK.getPassword();
		}
		if (userCountry.equals("Denmark")) {
			return LoginGGI.LOGIN_DK.getPassword();
		}
		if (userCountry.equals("Spain")) {
			return LoginGGI.LOGIN_ES.getPassword();
		}
		if (userCountry.equals("Netherlands")) {
			return LoginGGI.LOGIN_NL.getPassword();
		}
		if (userCountry.equals("Mexico")) {
			return LoginGGI.LOGIN_MX.getPassword();
		}
		if (userCountry.equals("Sweden")) {
			return LoginGGI.LOGIN_SE.getPassword();
		}
		if (userCountry.equals("BAC")) {
			return LoginGGI.LOGIN_BAC.getPassword();
		}
		if (userCountry.equals("BAP")) {
			return LoginGGI.LOGIN_BAP.getPassword();
		}
		if (userCountry.equals("Ontario")) {
			return LoginGGI.LOGIN_ONT.getPassword();
		}
		if (userCountry.equals("Greece")) {
			return LoginGGI.LOGIN_GR.getPassword();
		} else {return null;}
	}

	public static void message(String description) {

		Reporter.log(MESSAGE_HTML_BEGIN + description + MESSAGE_HTML_END);

		if (printconsoleoutput)
			System.out.println(description.replace("&emsp;", "\t"));
	}

	public static String randomMessageIdString() {
		int id = randomMessageId.nextInt() & Integer.MAX_VALUE;
		return String.valueOf(id);
	}

	public static String createTestToken(String username, ProductId productId, int regulatedGameId, int realityCheckInterval, int realityCheckSecondsUntil) {

		String tokenEndPoint = "/api/createtoken-test";
		int tokenQuantity = 1;

		Map<String, Object> params = new HashMap<>();
		params.put("username", username);
		params.put("regulated_game_id", regulatedGameId);
		params.put("token_quantity", tokenQuantity);
		params.put("reality_check_interval", realityCheckInterval);
		params.put("reality_check_seconds_until", realityCheckSecondsUntil);
		params.put("set_last_token_as_currently_in_play", true);
		params.put("override_product_id", productId.getId()); //This is only used if regulatedGameId is 0 or null
		params.put("override_provider_implementation_id", 30); ////This is only used if regulatedGameId is 0 or null. Use only 30 for the moment.

		Map<String, Object> jsonMap = new HashMap<>();
		jsonMap.put("Method", "createtoken-test");
		jsonMap.put("Params", params);
		JSONObject requestBody = new JSONObject(jsonMap);

		RequestSpecification request = RestAssured.given()
				.baseUri(BaseURI.tokenURI)
				.headers("Accept", "application/json")
				.contentType(ContentType.JSON).body(requestBody).filter(Utils.getRequestFilter());
		Response response = request.when().post(tokenEndPoint);
		prettyBodyMessage(response, tokenEndPoint);

		JsonPath jsonPath = response.jsonPath();
		String token = jsonPath.getString("result.test_tokens[0]");

		return token;

	}

	public static String[] preconditionLogin(String seq, String publicToken, String userName) {

		message(HTML_PRECONDITIONS_START);

		String loginEndPoint = "/MicrogamingGGi.svc/Invoke";

		String getUserLoginName = getUserLoginName(userName);
		String getUserLoginPassword = getUserLoginPassword(userName);

		String requestBody = "<pkt>\r\n"
				+ "  <methodcall name=\"login\" timestamp=\""+Utils.getTimeStamp()+"\" system=\"casino\">\r\n"
				+ "    <auth login=\""+getUserLoginName+"\" password=\""+getUserLoginPassword+"\"/>\r\n"
				+ "    <call seq=\""+seq+"\" token=\""+publicToken+"\"/>\r\n"
				+ "  </methodcall>\r\n"
				+ "</pkt>";

		System.out.println("------Login request------");
		System.out.println(requestBody); 

		RequestSpecification request = RestAssured.given()
				.baseUri(BaseURI.loginURI)
				.headers("Accept", "*/*")
				.contentType("application/xml; charset=UTF-8;").body(requestBody).filter(getRequestFilter());
		Response response = request.when().post(loginEndPoint);

		prettyBodyMessage(response, loginEndPoint);

		System.out.println("------Login response------");
		response.prettyPrint();

		String responseInString = response.toString();

		String[] responseProperties = {
				StringUtils.substringBetween(responseInString, "token=\"", "\""),
				StringUtils.substringBetween(responseInString, "balance=\"", "\""),
				StringUtils.substringBetween(responseInString, "loginname=\"", "\""),
		};

		message(HTML_PRECONDITIONS_END);

		return responseProperties;

	}

	public static void makeASpinMicroGaming (String userName, int regulatedGameId, String gameCode, int betAmount, ProductId productId) {

		String playEndPoint = "/MicrogamingGGi.svc/Invoke";

		String getUserLoginName = getUserLoginName(userName);
		String getUserLoginPassword = getUserLoginPassword(userName);
		String userCurrency = DatabaseQueries.getUserCurrencyFromUserTable(userName);

		String seq = Utils.generateRandomString();
		String publicToken = createTestToken(userName, regulatedGameId, productId);
		String gameId = randomMessageIdString();
		String actionId = Utils.generateRandomString();

		String[] loginResposne = preconditionLogin(seq, publicToken, userName);
		String privateToken = loginResposne[0];

		String requestBody = "<pkt>\r\n"
				+ "  <methodcall name=\"play\" timestamp=\""+Utils.getTimeStamp()+"\" system=\"casino\">\r\n"
				+ "    <auth login=\""+getUserLoginName+"\" password=\""+getUserLoginPassword+"\"/>\r\n"
				+ "    <call seq=\""+seq+"\" token=\""+privateToken+"\" playtype=\"bet\" gameid=\""+gameId+"\" gamereference=\""+gameCode+"\" "
				+ "actionid=\""+actionId+"\" actiondesc=\"\" amount=\""+betAmount+"\" start=\"true\" finish=\"true\" offline=\"true\" "
				+ "currency=\""+userCurrency+"\" freegame=\"nxZigsDCxOtlpw6Zolyl\"/>\r\n"
				+ "  </methodcall>\r\n"
				+ "</pkt>";

		System.out.println("------Spin request------");
		System.out.println(requestBody); 

		RequestSpecification request = RestAssured.given()
				.baseUri(BaseURI.loginURI)
				.headers("Accept", "*/*")
				.contentType("application/xml; charset=UTF-8;").body(requestBody).filter(getRequestFilter());
		Response response = request.when().post(playEndPoint);

		prettyBodyMessage(response, playEndPoint);

		System.out.println("------Spin response------");
		response.prettyPrint();

	}

	public static void PTEWSpinAndWin(String userName, BigDecimal betAmount, BigDecimal winAmount, String token, Boolean isTournament) {

		String publicToken = token;
		String baseUri = "http://mn2svwwti011su0:8083";
		String endPoint = "";
		String userCurrency = DatabaseQueries.getUserCurrencyFromUserTable(userName);
		String remoteSessionCode = randomMessageIdString();
		String actionType1 = "";
		String actionType2 = "";
		int remoteSessionType = 0;

		if (isTournament) {
			actionType1 = "po_tourn_reg";
			actionType2 = "po_tourn_win";
			remoteSessionType = 1;
		} else {
			actionType1 = "po_buying_chips";
			actionType2 = "po_selling_chips";
			remoteSessionType = 2;
		}		

		String startGameSessionRequestBody = PtewPayloads.startGameSessionRequestBody(userName, publicToken, userCurrency, remoteSessionCode, remoteSessionType);

		System.out.println("------Start Game Request------");
		System.out.println(startGameSessionRequestBody); 

		RequestSpecification request = RestAssured.given()
				.baseUri(baseUri)
				.headers("Accept", "*/*")
				.contentType("application/xml; charset=UTF-8;").body(startGameSessionRequestBody).filter(getRequestFilter());
		Response response = request.when().post(endPoint);

		prettyBodyMessage(response, endPoint);
		
		System.out.println("------Start Game Response------");
		response.prettyPrint();

		String gameMultiBalanceTransactionRequestBody = PtewPayloads.gameMultiBalanceTransactionRequestBody(userName, publicToken, userCurrency, remoteSessionCode, actionType1, betAmount);

		System.out.println("------Stake Transaction Request------");
		System.out.println(gameMultiBalanceTransactionRequestBody); 

		request = RestAssured.given()
				.baseUri(baseUri)
				.headers("Accept", "*/*")
				.contentType("application/xml; charset=UTF-8;").body(gameMultiBalanceTransactionRequestBody).filter(getRequestFilter());
		response = request.when().post(endPoint);
		
		prettyBodyMessage(response, endPoint);
		
		System.out.println("------Stake Transaction Response------");
		response.prettyPrint();

		String gameWinMultiBalanceTransactionRequestBody = PtewPayloads.gameWinMultiBalanceTransactionRequestBody(userName, publicToken, userCurrency, remoteSessionCode, actionType2, winAmount);

		System.out.println("------Win Transaction Request------");
		System.out.println(gameWinMultiBalanceTransactionRequestBody); 

		request = RestAssured.given()
				.baseUri(baseUri)
				.headers("Accept", "*/*")
				.contentType("application/xml; charset=UTF-8;").body(gameWinMultiBalanceTransactionRequestBody).filter(getRequestFilter());
		response = request.when().post(endPoint);
		
		prettyBodyMessage(response, endPoint);

		System.out.println("------Win Transaction Response------");
		response.prettyPrint();

		String endGameRequestBody = PtewPayloads.endGameRequestBody(userName, publicToken, userCurrency, remoteSessionCode);

		System.out.println("------End Game Request------");
		System.out.println(endGameRequestBody); 

		request = RestAssured.given()
				.baseUri(baseUri)
				.headers("Accept", "*/*")
				.contentType("application/xml; charset=UTF-8;").body(endGameRequestBody).filter(getRequestFilter());
		response = request.when().post(endPoint);
		
		prettyBodyMessage(response, endPoint);

		System.out.println("------End Game Response------");
		response.prettyPrint();

	}

}
