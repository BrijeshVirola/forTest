package common;

public class RegEx {
	
	public static final String utcTimeStamp = "\\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[1-2]\\d|3[0-1])T(?:[0-1]\\d|2[0-3]):[0-5]\\d:[0-5]\\d\\.\\d{0,7}Z";
	public static final String GUID  = "^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$";
	public static final String longNumber = "^-?\\d{1,19}$";

}
