package common;

import java.io.IOException;
import java.util.List;

import org.testng.ISuite;
import org.testng.log4testng.Logger;
import org.testng.reporters.EmailableReporter2;
import org.testng.xml.XmlSuite;

import logging.Log;


public class CustomReporter extends EmailableReporter2 {

	private static final Logger LOG = Logger.getLogger(CustomReporter.class);

	@Override
	public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {

		Log.event("Generating Known Issues Report");
		
		this.setFileName("known-issues-report.html");

		try {
			writer = createWriter(outputDirectory);
		} catch (IOException e) {
			LOG.error("Unable to create output file", e);
			return;
		}
		for (ISuite suite : suites) {
			suiteResults.add(new SuiteResult(suite));
		}

		writeDocumentStart();
		writeHead();
		writeBody();
		writeDocumentEnd();

		writer.close();
		Log.event("Done!");
	}
	
	@Override
	protected void writeBody() {
		writer.println("<body>");
		writeKnownIssues();
		writer.println("</body>");
	}

	private void writeKnownIssues() {
		
		List<KnownIssue> knownIssues = KnownIssuesCompiler.getKnownIssues();
		
	    writer.println("<table>");
	    writer.println("<thead>");
	    writer.print("<tr>");
	    writer.print("<th colspan=\"4\">Known Issues</th>");
	    writer.println("</tr>");
	    writer.println("</thead>");
	    writer.println("<tbody>");
	    writer.print("<tr>");
	    writer.print("<th>Test</th>");
	    writer.print("<th>Jira</th>");
	    writer.print("<th>Action</th>");
	    writer.print("</tr>");
	    
		knownIssues.forEach(knownIssue ->{
		    writer.print("<tr>");

		    String test = knownIssue.getTest();
			writer.print("<td>" + test + "</td>");

			String jiraRef = knownIssue.getJiraRef();
			writer.print("<td>" + jiraRef + "</td>");

			String action = knownIssue.getAction();
			writer.print("<td>" + action + "</td>");
		    writer.print("</tr>");
		});
	    
	    writer.println("</tbody>");
	    writer.println("</table>");
	}
}
