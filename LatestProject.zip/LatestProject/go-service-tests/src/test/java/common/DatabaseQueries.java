package common;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.bet365.dbIntegration.SqlQueries;

import tests.pokertournamentsservice.request.PokerGameSessionDB;
import tests.pokertournamentsservice.request.PokerTournamentsDB;

public class DatabaseQueries {

	/**
	 * SQL to return userID
	 * @param userName
	 * @param print
	 * @return
	 */
	public static Integer getUserIdFromUserTable(String userName) {
		String query = "SELECT TOP 1 USERID "
				+ "FROM [User] WITH (NOLOCK) "
				+ "WHERE UserName = '%s'";

		String formattedQuery = String.format(query, userName);

		String output = SqlQueries.executeAQuery(formattedQuery, false).trim();
		return Integer.parseInt(output);

	}

	public static String getUserCountryFromUserTable(String userName) {

		String query = "SELECT TOP 1 C.shortname\r\n"
				+ "FROM [user] U WITH (NOLOCK)\r\n"
				+ "INNER JOIN [Country] C WITH (NOLOCK)\r\n"
				+ "ON U.CountryID = C.ID\r\n"
				+ "WHERE U.UserName = '%s'";

		String formattedQuery = String.format(query, userName);

		String output = SqlQueries.executeAQuery(formattedQuery).trim();
		return output;
	}

	public static String getUserCurrencyFromUserTable(String userName) {

		String query = "SELECT TOP 1 CUR.ISOCode\r\n"
				+ "FROM [user] U WITH (NOLOCK)\r\n"
				+ "INNER JOIN [Currency] CUR WITH (NOLOCK)\r\n"
				+ "ON U.CurrencyID = CUR.ID\r\n"
				+ "WHERE U.UserName = '%s'";

		String formattedQuery = String.format(query, userName);

		String output = SqlQueries.executeAQuery(formattedQuery).trim();
		return output;
	}

	/**
	 * SQL to verify if BonusTemplateVersionId exists
	 * @param bonusTemplateVersionId
	 * @return
	 */
	public static Boolean verifyIfExistsBonusTemplateVersionId(Integer bonusTemplateVersionId) {

		String query = "SELECT CASE WHEN EXISTS (SELECT BonusTemplateVersionId "
				+ "FROM GamingBonusAPI.dbo.BonusTemplateVersion WITH (NOLOCK) "
				+ "WHERE bonusTemplateVersionId = '%s') "
				+ "THEN 'TRUE' "
				+ "ELSE 'FALSE' END";

		String formattedQuery = String.format(query, bonusTemplateVersionId);

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", formattedQuery).trim();
		return new Boolean(output);
	}

	/**
	 * Get GameWeight from GameWeightTemplateMapping
	 * <p>Server: MN2GAMSQL0001U0, Database: GamingBonusAPI</p>
	 * @param gameWeightTemplateId
	 * @param regulatedGameId
	 * @return
	 */
	public static int getGameWeighFromGameWeightTemplateMapping(int gameWeightTemplateId, int regulatedGameId) {

		String query = "SELECT GameWeight"
				+ " FROM [GamingBonusAPI].[dbo].[GameWeightTemplateMapping] WITH(NOLOCK)"
				+ " WHERE GameWeightTemplateId = '%s'"
				+ " AND RegulatedGameId = '%s';";

		String formattedQuery = String.format(query, gameWeightTemplateId, regulatedGameId);

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", formattedQuery).trim();
		return Integer.parseInt(output);
	}

	/**
	 * SQL to return last UserBonusId
	 * @param userId
	 * @return
	 */
	public static Integer getLastUserBonusIdFromUserBonus(Integer userId) {

		String query = "SELECT TOP 1 UserBonusId "
				+ "FROM UserBonus WITH (NOLOCK) "
				+ "WHERE UserId = '%s' ORDER BY UserBonusId desc;";

		String formattedQuery = String.format(query, userId);

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", formattedQuery).trim();
		return output.equals("") ? null : Integer.parseInt(output);
	}

	/**
	 * SQL to return last UserPromotionHistoryId
	 * @param userId
	 * @return
	 */
	public static Integer getLastUserPromotionHistoryId(Integer userId) {

		String query = "SELECT TOP 1 UserPromotionHistoryId "
				+ "FROM UserPromotionHistory WITH (NOLOCK) "
				+ "WHERE UserId = '%s' ORDER BY UserPromotionHistoryId desc;";

		String formattedQuery = String.format(query, userId);

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "Bet365_Games_Logical_V3", formattedQuery).trim();
		return output == "" ? null : Integer.parseInt(output);
	}

	public static Map<String, Object> getUserGoldenChipPromotionHistory(Integer userPromotionHistoryId) throws Exception {

		String query = "SELECT * "
				+ "FROM UserGoldenChipPromotionHistory WITH (NOLOCK) "
				+ "WHERE UserPromotionHistoryId = '%s';";

		String formattedQuery = String.format(query, userPromotionHistoryId);

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "Bet365_Games_Logical_V3", formattedQuery).trim();
		List<String> list = new ArrayList<>(Arrays.asList(output.split("\t")));

		Map<String, Object> goldenChipPromotionHistory = new LinkedHashMap<>();
		try {
			goldenChipPromotionHistory.put("UserPromotionHistoryId", Integer.parseInt(list.get(0)));
			goldenChipPromotionHistory.put("GBPValue", new BigDecimal(list.get(1)));
			goldenChipPromotionHistory.put("Quantity", Integer.parseInt(list.get(2)));
		} catch (NumberFormatException e) {
			throw new Exception("User doesn't have promotion history id;");
		}

		return goldenChipPromotionHistory;
	}

	public static Map<String, Integer> getUserFreeSpinPromotionHistory(Integer userPromotionHistoryId) throws Exception {

		String query = "SELECT * "
				+ "FROM UserFreeSpinPromotionHistory WITH (NOLOCK) "
				+ "WHERE UserPromotionHistoryId = '%s';";

		String formattedQuery = String.format(query, userPromotionHistoryId);

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "Bet365_Games_Logical_V3", formattedQuery).trim();
		List<String> list = new ArrayList<>(Arrays.asList(output.split("\t")));

		Map<String, Integer> freeSpinPromotionHistory = new LinkedHashMap<>();
		try {
			freeSpinPromotionHistory.put("UserPromotionHistoryId", Integer.parseInt(list.get(0)));
			freeSpinPromotionHistory.put("RemainingSpins", Integer.parseInt(list.get(1)));
			freeSpinPromotionHistory.put("AwardedSpins", Integer.parseInt(list.get(2)));
		} catch (NumberFormatException e) {
			throw new Exception("User doesn't have promotion history id;");
		}

		return freeSpinPromotionHistory;
	}

	public static void removeUserFromPromotionById(Integer userId, Integer promotionId) {

		String query = "EXEC dbo.TEST_Promotion_RemoveUserFromPromotionById @UserId = %s, @PromotionId = %s;";

		String formattedQuery = String.format(query, userId, promotionId);

		SqlQueries.executeAQuery("MN2GAMSQL0001U0", "Bet365_Games_Logical_V3", formattedQuery);
	}

	public static void deleteBonusTemplateVersion(Integer bonusTemplateVersionId) {

		String query = "EXEC dbo.Test_Delete_BonusTemplateVersion @BonusTemplateVersionId = %s;";

		String formattedQuery = String.format(query, bonusTemplateVersionId);

		SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", formattedQuery);
	}


	public static PokerTournamentsDB getPokerTournamentDetails(Long flakeId) {

		String query = "SELECT * FROM [gam_pokertournaments].[dbo].[PokerTournaments] WITH (NOLOCK) WHERE TransactionFlakeId ='%s'";

		String formattedQuery = String.format(query, flakeId);

		String output = SqlQueries.executeAQuery("UATGAMINGSQL", 
				"gam_pokertournaments", 
				formattedQuery);

		String[] outputData = output.trim().split("\t");

		PokerTournamentsDB data = new PokerTournamentsDB();

		data.setTournamentId(outputData[1]);
		data.setFeeAmount(Double.parseDouble(outputData[2]));
		data.setDisplayAmount(Double.parseDouble(outputData[4]));
		data.setTransactionFlakeId(Long.parseLong(outputData[0]));
		data.setFeeCurrencyId(Integer.parseInt(outputData[3]));
		data.setDisplayCurrencyId(Integer.parseInt(outputData[5]));
		return data;
	}

	public static PokerGameSessionDB getPokerGameSession(Long gameRoundSno) {

		String query = "SELECT * FROM [gam_pokertournaments].[dbo].[PokerGameSession] WITH (NOLOCK) WHERE GameRoundSNO ='%s'";

		String formattedQuery = String.format(query, gameRoundSno);

		String output = SqlQueries.executeAQuery("UATGAMINGSQL", 
				"gam_pokertournaments", 
				formattedQuery);

		String[] outputData = output.trim().split("\t");

		PokerGameSessionDB data = new PokerGameSessionDB();

		data.setCasino(outputData[4]);
		data.setClientPlatform(outputData[2]);
		data.setClientType(outputData[1]);
		data.setGameRoundSno(Long.parseLong(outputData[0]));
		data.setGameType(outputData[3]);
		data.setRakeAmount(Double.parseDouble(outputData[5]));
		return data;
	}

	/**
	 * Get details of BonusTemplateGamePosition
	 * @param bonusTemplateId
	 * @param gameTokenId
	 * @return
	 */
	public static Map<String, Integer> getBonusTemplateGamePosition(int bonusTemplateId, int gameTokenId) {

		String query = "SELECT * FROM [GamingBonusAPI].[dbo].[BonusTemplateGamePositions] WITH(NOLOCK)"
				+ " WHERE BonusTemplateId = '%s'"
				+ " AND GameTokenId = '%s';";

		String formattedQuery = String.format(query, bonusTemplateId, gameTokenId);

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", formattedQuery);
		output = output.trim();
		Map<String, Integer> data = new HashMap<>();

		if(output.equals("")) {
			return data;
		}

		String[] outputData = output.split("\t");

		data.put("BonusTemplateId", Integer.parseInt(outputData[1]));
		data.put("RegulatedZoneId", Integer.parseInt(outputData[2]));
		data.put("Position", Integer.parseInt(outputData[3]));
		data.put("GameTokenId", Integer.parseInt(outputData[4]));
		data.put("ProductId", Integer.parseInt(outputData[5]));
		return data;
	}

	/**
	 * Get last bonus template game positions id.
	 * @return
	 */
	public static int getLastBonusTemplateGamePositionsId() {

		String query = "SELECT TOP 1 BonusTemplateGamePositionsId"
				+ " FROM [GamingBonusAPI].[dbo].[BonusTemplateGamePositions] WITH(NOLOCK)"
				+ " ORDER BY BonusTemplateGamePositionsId desc;";

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", query).trim();

		return Integer.parseInt(output);
	}

	/**
	 * Get last bonus template game positions id.
	 * @return
	 */
	public static String checkJackpotDetails (String columnName, String tableName, BigInteger checkedId) {

		String query = "SELECT TOP 1 " + columnName
				+ " FROM " + tableName + ".dbo.JackpotDetails"
				+ " WHERE " + columnName + " = " + checkedId;

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", tableName, query).trim();

		return output;
	}

	/**
	 * SQL to return SakuraTokenSNO
	 * @param gameSessionId
	 * @return SakuraTokenSNO
	 */
	public static int getSakuraTokenSNOByGameSessionId(String gameSessionId) {
		String query = "SELECT TOP 1 SakuraTokenSNO "
				+ "FROM SakuraSlotsSessionTokens WITH (NOLOCK) " 
				+ "WHERE GameSessionID = '%s'";

		String formattedQuery = String.format(query, gameSessionId);

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "Bet365_Games_Logical_V3", formattedQuery).trim();
		return Integer.parseInt(output);
	}

	/**
	 * Executes stored procedure in HLSDBUAT28U that adds user to free spin promotion
	 * @param promotionID
	 * @param userName
	 * @param token
	 * @param claimed
	 * @param remainingSpins
	 */
	public static void freeSpinAddUserToPromotion(int promotionID, int userID, UUID token, int claimed, int remainingSpins) {
		String databaseServer = "HLSDBUAT28U";
		String databaseName = "Bet365_Games_Logical_V3";

		String addPromotion = "EXEC dbo.TEST_Promotion_FreeSpin_AddUserToPromotion @PromotionId = '%s', @UserId = '%s', @Token = '%s', @Claimed = '%s', @RemainingSpins = '%s';";

		String formattedQuery = String.format(addPromotion, promotionID, userID, token, claimed, remainingSpins);

		SqlQueries.executeAQuery(databaseServer, databaseName, formattedQuery);
	}
	
	public static String getGamingIdFromUserIdentityTable(Integer userId) {
		String query = "SELECT GamingId "
				+ "FROM [UserIdentity] WITH (NOLOCK) "
				+ "WHERE userId = %s";
		
		String formattedQuery = String.format(query, userId);
		
		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "Bet365_Games_Base", formattedQuery).trim();
		return output;
	}

	/**
	 * Executes stored procedure for setting the WithHoldTaxes
	 * @param userId
	 * @param sessionId
	 */
	public static void setWithHoldTaxes(Integer userId, String sessionId, String currentNetWin) {

		String query = "EXEC [dbo].[Test_UpdateOrCreate_WithheldTaxBucketSession]"
				+ " @UserID = " + userId + ","
				+ " @TaxSessionId = '" + sessionId + "',"
				+ " @CurrentNetWin = "+ currentNetWin +"";

		String formattedQuery = String.format(query, userId, sessionId);

		SqlQueries.executeAQuery("MN2GAMSQL0001U0", "Bet365_Games_Logical_V3", formattedQuery);
	}

	public static String createGreeceToken(Integer userId, String sessionId, int regulatedGameId) {

		String query = "EXEC dbo.PlaytechPAS_SessionToken_Insert"
				+ " @UserId = "+ userId + ","
				+ " @SessionID = '" + sessionId + "',"
				+ " @RegulatedGameId = " + regulatedGameId + ","
				+ " @ProductId = 3";

		String formattedQuery = String.format(query, userId, sessionId, regulatedGameId);

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "Bet365_Games_Logical_V3", formattedQuery).trim();
		return output;
	}

}
