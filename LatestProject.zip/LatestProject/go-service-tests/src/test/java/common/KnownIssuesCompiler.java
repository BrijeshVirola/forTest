package common;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class KnownIssuesCompiler {

	/**
	 * Returns a collection of KnownIssue. The instances of KnownIssue are compiled by
	 * scanning the codebase's class files for applications of the EXPECTEDFAILURE annotation.
	 */
	public static List<KnownIssue> getKnownIssues() {
		
		List<KnownIssue> knownIssues = new ArrayList<KnownIssue>();  		
		
		String rootDir = getClassFileRootDir();
		Stream<Path> stream = getAllClassFiles(rootDir);
		stream.forEach(path -> {
			String classFileAsString = path.toString();
			String className = getClassName(rootDir, classFileAsString);
			
			File file = new File(classFileAsString);
			ClassLoader classLoader = null;
			try {
				URL classUrl = file.toURI().toURL();
				URL[] classUrls = new URL[] { classUrl };

				classLoader = new URLClassLoader(classUrls);

				Class<?> currentClass = classLoader.loadClass(className);
				
				List<Method> methods = getAnnotatedMethods(currentClass);

				methods.forEach(method ->{

					ExpectedFailure annotation = method.getAnnotation(ExpectedFailure.class);
					
					String test = className + "." + method.getName();
					String action = annotation.action();
					String jiraRef = annotation.jiraRef();
					
					String jiraLink = formatJiraLink(jiraRef);
					
					knownIssues.add(new KnownIssue(test, jiraLink, action));
				});
			} catch (MalformedURLException e) {
				System.out.println(e);
			} catch (ClassNotFoundException e) {
				System.out.println(e);
			}
		});
		
		return knownIssues;
	}

	private static String formatJiraLink(String jiraRef) {
		if( jiraRef.startsWith("http")) {
			jiraRef = jiraRef.substring(jiraRef.lastIndexOf("/") + 1);
		}
		String jiraUrl = "https://jira/browse/" + jiraRef;
		
		return "<a href=\"" + jiraUrl + "\">" + jiraRef + "</a>";
	}

	private static Stream<Path> getAllClassFiles(String basedir) {
		Stream<Path> stream = null;
		try {
			stream = Files.find(Paths.get(basedir), 100, (path, basicFileAttributes) -> {
				File file = path.toFile();
				return !file.isDirectory() && file.getName().endsWith(".class");
			});
		} catch (IOException e) {
			e.printStackTrace();
		}

		return stream;
	}
	
	private static String getClassName(String classFileRoot, String classFile){
		String className = null;
		
		String trailing = classFile.replace(classFileRoot, "");
		
		className = trailing.replace(File.separator, ".");
		
		String extension = ".class";
		String result = className.substring(0, className.length()-extension.length());
		
		return result;
	}
	
	private static String getClassFileRootDir() {
		String workingDir = System.getProperty("user.dir");
		String classFileRoot =  workingDir + File.separator +  "target" + File.separator + "test-classes" + File.separator;

		return classFileRoot;
	}
	
	private static List<Method> getAnnotatedMethods(final Class<?> type) {
	    final List<Method> methods = new ArrayList<Method>();
	    Class<?> classInfo = type;
	    while (classInfo != null && classInfo != Object.class) { // need to iterated thought hierarchy in order to retrieve methods from above the current instance
	        for (final Method method : classInfo.getDeclaredMethods()) {
	            if (method.isAnnotationPresent(ExpectedFailure.class)) {
                    methods.add(method);
	            }
	        }
	        // move to the upper class in the hierarchy in search for more methods
	        classInfo = classInfo.getSuperclass();
	    }
	    return methods;
	}	
}
