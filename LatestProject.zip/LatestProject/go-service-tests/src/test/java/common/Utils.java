package common;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.testng.Reporter;

import com.google.gson.Gson;

import common.enumsconstants.Authorization;
import common.enumsconstants.BaseUri;
import common.enumsconstants.ProductId;
import common.testtoken.enums.SessionEndpoints;
import common.testtoken.request.CreateSlotsSessionTestReq;
import common.testtoken.request.CreateUserSessionTestReq;
import common.testtoken.request.TerminateUserSessionTestReq;
import common.testtoken.response.CreateSlotsSessionTestResp;
import common.testtoken.response.CreateUserSessionTestResp;
import domain.BaseRequest;
import io.restassured.RestAssured;
import io.restassured.filter.Filter;
import io.restassured.internal.support.Prettifier;
import io.restassured.parsing.Parser;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;
import tests.balanceservice.enums.BalanceEndpoints;
import tests.balanceservice.request.AdjustBalanceReq;
import tests.common.response.ResultOKResp;
import tests.gamelaunchtokenservice.enums.GameLaunchTokenEndpoints;
import tests.gamelaunchtokenservice.request.GenerateGameLaunchUrlReq;
import tests.gamelaunchtokenservice.response.GenerateGameLaunchUrlResp;
import tests.slotsservice.request.GetActiveGameSessionReq;
import tests.slotsservice.response.GameSessionResp;
import tests.tokenservice.request.CreatePublicTokenReq;
import tests.tokenservice.request.PrivateToPublicToken;
import tests.tokenservice.requestobjects.CreatePrivateTokenParams;
import tests.tokenservice.requestobjects.CreatePublicTokenParams;
import tests.tokenservice.response.CreatePublicTokenResp;
import tests.tokenservice.response.TokenResp;

public class Utils {

	private static SecureRandom randomMessageId = null;
	private static Filter requestFilter;
	public static boolean printconsoleoutput = false;

	static {
		requestFilter = (req, response, ctx) -> {
			preformattedMessage("<b>Request method:</b> " + req.getMethod() + "\n<b>Request URI:</b> " + req.getURI()); 
			preformattedMessage("<b>Request headers:</b>\n" + req.getHeaders()); 
			if (req.getBody() != null) {
				prettyBodyMessageRequest(req.getBody());
			}
			return ctx.next(req, response); 
		};

		try {
			randomMessageId = SecureRandom.getInstance("SHA1PRNG");
		} catch (NoSuchAlgorithmException e) {
			System.out.println("Cannot create randomMessageId object: " + e.getMessage());
		}
	}

	public static void prettyBodyMessageRequest(String xmlBody) {

		Prettifier prettifier = new Prettifier();
		String prettyBody = prettifier.prettify(xmlBody, Parser.JSON);
		preformattedMessage("<b>Request body:</b>\n" + prettyBody);

	}

	public static void preformattedMessage(String description) {

		Reporter.log("<pre>" + description + "</pre>");

		if (printconsoleoutput)
			System.out.println(description.replace("&emsp;", "\t"));

	}

	public static CreatePublicTokenResp createNewPublicToken(int userId) {

		String publicToken = UUID.randomUUID().toString();

		CreatePublicTokenReq publicRequest = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.userId(userId)
						.publicToken(publicToken)
						.build())
				.build();

		CreatePublicTokenResp actualCreateResponse =  BaseRequest.post(publicRequest, SessionEndpoints.createPublicTokenSuccess);
		CreatePublicTokenResp expectedCreateResponse = new CreatePublicTokenResp.Builder()
				.id(null)
				.defaults()
				.sno(actualCreateResponse.sno())
				.publicToken(publicToken)
				.build();

		Assert.assertEquals(expectedCreateResponse.publicToken(),actualCreateResponse.publicToken());
		Assert.assertTrue(actualCreateResponse.sno() > 0);

		return actualCreateResponse;
	}

	public static TokenResp createNewPrivateToken(String publicToken) {
		PrivateToPublicToken request = new PrivateToPublicToken
				.Builder()
				.defaults()
				.params(new CreatePrivateTokenParams
						.Builder()
						.defaults()
						.token(publicToken)
						.build())
				.build();
		TokenResp actualResponse =  BaseRequest.post(request, SessionEndpoints.createPrivateTokenSuccess);
		return actualResponse;
	}

	public static String createNewSlotsSession(String username, BigDecimal slotsSessionBalance) {

		CreateSlotsSessionTestReq publicRequest = new CreateSlotsSessionTestReq
				.Builder()
				.defaults()
				.username(username)
				.slotsSessionBalance(slotsSessionBalance)
				.build();

		CreateSlotsSessionTestResp token = BaseRequest.post(publicRequest, SessionEndpoints.createSlotsSessionTokenSuccess, BaseURI.CREATE_USER_SESSION);
		return token.getTestToken();
	}

	public static String getSlotsGameSessionId(int userId) {

		GetActiveGameSessionReq request = new GetActiveGameSessionReq.Builder()
				.defaults()
				.userId(userId)
				.build();

		GameSessionResp actResponse =  BaseRequest.post(request, SessionEndpoints.getActiveGameSessionSuccess);

		return actResponse.getGameSessionId();
	}

	public static CreateUserSessionTestResp createSession(String username) {

		CreateUserSessionTestReq createUserSessionTestRequest = new CreateUserSessionTestReq.Builder()
				.defaults()
				.username(username)
				.build();

		CreateUserSessionTestResp sessionResponse = BaseRequest.post(createUserSessionTestRequest, SessionEndpoints.createUserSessionTestSuccess, BaseURI.CREATE_USER_SESSION);

		return sessionResponse;
	}

	public static CreateUserSessionTestResp createSession(Integer intervalInMinutes, Integer triggerNextRealityCheckInSeconds) {

		CreateUserSessionTestReq createUserSessionTestRequest = new CreateUserSessionTestReq.Builder()
				.defaults()
				.realityCheckInterval(intervalInMinutes)
				.realityCheckSecondsUntil(triggerNextRealityCheckInSeconds)
				.build();

		CreateUserSessionTestResp sessionResponse = BaseRequest.post(createUserSessionTestRequest, SessionEndpoints.createUserSessionTestSuccess, BaseURI.CREATE_USER_SESSION);

		return sessionResponse;
	}

	public static ResultOKResp terminateSessionBySessionId(String sessionId) {

		TerminateUserSessionTestReq terminateUserSessionTestRequest = new TerminateUserSessionTestReq.Builder()
				.defaults()
				.sessionId(sessionId)
				.build();

		ResultOKResp sessionResponse = BaseRequest.post(terminateUserSessionTestRequest, SessionEndpoints.terminateUserSessionTestSuccess, BaseURI.CREATE_USER_SESSION);

		return sessionResponse;
	}

	/**
	 * Insert transaction in tbl bet365GamesTransactions
	 * @param type - Transaction Type
	 * @param userId
	 * @param stakeAmount
	 */
	public static void createTransaction(TransactionType type, int userId, String amount) {
		int regulatedGameId = 6403;
		int cmscoreGameId = ThreadLocalRandom.current().nextInt(0, 100000);
		int partnerId = ThreadLocalRandom.current().nextInt(0, 100000);
		int providerRegionId = 5678;		
		long gameRoundId = ThreadLocalRandom.current().nextLong(0, 100000000);
		long bet365TransactionId = ThreadLocalRandom.current().nextLong(0, 100000000);
		long flakeId = ThreadLocalRandom.current().nextLong(0, 100000000);

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.id(UUID.randomUUID().toString())
				.flakeId(flakeId)
				.transactionType(type)
				.regulatedGameId(regulatedGameId)
				.cmscoreGameId(cmscoreGameId)
				.realAmount(amount)
				.totalAmount(amount)
				.gameRoundId(gameRoundId)
				.userId(userId)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.bet365TransactionId(bet365TransactionId)
				.sourceBet365GamesTransactionIid(bet365TransactionId)
				.partnerTimestampUtc(Instant.now().toString())
				.partnerTransactionId(UUID.randomUUID().toString())
				.build();

		BaseRequest.post(adjBalanceReq, BalanceEndpoints.adjustBalance, "http://mn2gampsr0002u0:18050/api/");
	}

	/**
	 * Create new game launch token for a valid login session for a specific game
	 * @param sessionId
	 * @return the glt
	 */
	public static String createGlt(String sessionId) {

		RequestSpecification request = RestAssured.given().baseUri("https://games571.b365uat.com/Play/MadameWisdom")
				.cookie("gstk", sessionId);
		Response response = request.get();

		String respBody = response.getBody().asString();
		// Extract the glt from the response body html
		String glt =  StringUtils.substringBetween(respBody, "GamingLaunch/en-GB/", "\"");
		System.out.println("The Game Launch Token is: " + glt);
		return glt;
	}

	/**
	 * Convert Json string to Java class object
	 * @param <T>
	 * @param jsonString
	 * @param respClass
	 * @return
	 */
	public static <T> T convertJsonStringToObject(String jsonString, Class<T> respClass) {
		Gson gson = new Gson();
		return gson.fromJson(jsonString, respClass);
	}

	/**
	 * Get the last message from a List with slight delay
	 * @param List of messages
	 * @return
	 * @throws InterruptedException 
	 */
	public static String getLastMessage(List<String> messages) throws InterruptedException {
		Thread.sleep(500);
		return messages.get(messages.size() - 1);
	}

	/**
	 * @return formatted date/time in UTC format yyyy-MM-dd'T'HH:mm:ss.SSSSSSS'Z'
	 */
	public static String dateTimeUtc() {
		Date currentDate = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSS'Z'");
		return simpleDateFormat.format(currentDate);
	}

	public static ArrayList<Integer> generateRandomUserIdList(int size) {
		int range = 999999;		

		ArrayList<Integer> set = new ArrayList<>();

		while(set.size()< size) {
			Random rnd = new Random();
			int number = rnd.nextInt(range);
			set.add(number);

		}  

		return set;
	}

	public static String generateGltToken(String languageCode, Integer countryId, String association, String sessionId) {

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.association(association)
				.sessionId(sessionId)
				.countryId(countryId)
				.languageCode(languageCode)
				.build();

		GenerateGameLaunchUrlResp response =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlSuccess, BaseURI.GAME_LAUNCH_TOKEN_SERVICE);
		return response.result.get("token").toString();

	}

	public static String generateGltTokenForGame(String languageCode, Integer countryId, String association, String sessionId, Integer regulatedGameId) {

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.association(association)
				.sessionId(sessionId)
				.countryId(countryId)
				.languageCode(languageCode)
				.regulatedGameId(regulatedGameId)
				.build();

		GenerateGameLaunchUrlResp response =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlSuccess, BaseURI.GAME_LAUNCH_TOKEN_SERVICE);
		return response.result.get("token").toString();

	}

	/**
	 * Method to credit Non Deposit matched bonuses
	 * @param userID
	 * @param bonusTemplateID
	 * @param amount
	 * @return 'OK' response if request was successful
	 */
	public static Response creditUserBonus(int userID, int bonusTemplateID, double amount) {

		Map<String, Object> jsonParamsMap = new HashMap<>();
		jsonParamsMap.put("user_id", userID);
		jsonParamsMap.put("bonustemplate_id", bonusTemplateID);
		jsonParamsMap.put("amount", amount);
		jsonParamsMap.put("creditedBy", "Test Automation Sofia");

		Map<String, Object> jsonMap = new HashMap<>();
		jsonMap.put("Method", "addcrediteduser");
		jsonMap.put("ID", "12345678");
		jsonMap.put("Params", jsonParamsMap);

		JSONObject requestParams = new JSONObject(jsonMap);

		RequestSpecification request = BaseRequest.createRequest(requestParams);
		Response response = request.when().post("http://gaminginternalsvc.uat.lb.local/gamingbonusapiv1/API/addcrediteduser");

		return response;
	}

	/**
	 * Method to cancel active user bonus by admin, using userbonusID
	 * @param userID
	 * @param userBonusID
	 * @param admin
	 * @return 'OK' response if request was successful
	 */
	private static Response postCancelActiveBonus(int userID, int userBonusID, String admin) {

		Map<String, Object> jsonParamsMap = new HashMap<>();
		jsonParamsMap.put("user_id", userID);
		jsonParamsMap.put("userbonus_id", userBonusID);
		jsonParamsMap.put("admin", admin);

		Map<String, Object> jsonMap = new HashMap<>();
		jsonMap.put("Method", "specificbonuscancelbyadmincommand");
		jsonMap.put("ID", "123456789");
		jsonMap.put("Params", jsonParamsMap);

		JSONObject requestParams = new JSONObject(jsonMap);

		RequestSpecification request = BaseRequest.createRequest(requestParams);
		Response response = request.when().post("http://gaminginternalsvc.uat.lb.local/gam-bonus-admin-svcv1/api/specificbonuscancelbyadmincommand");

		return response;
	}

	/**
	 * Method to cancel user bonus using activeBonusQuerry to obtain userBonusID and cancelActiveBonus to cancel the specific bonus
	 * @param userID 
	 * @param productID   
	 */
	public static void cancelUserActiveBonus(int userID, int productID) {

		try {
			int userBonusID = activeBonusQuerry(productID, userID).then().statusCode(200).extract().path("result[0].userbonus_id");
			postCancelActiveBonus(userID, userBonusID, "Automation");
		} catch (NullPointerException e) {
			Reporter.log("Bonus was not cancelled. Possible reason - no active bonus.");
		}
	}

	/**
	 * Method to return user active bonuses
	 * @param productID
	 * @param userID
	 * @return values of bonustemplate_id, bonustype_id, userbonus_id, is_claimed, is_expired, is_redeemed, expiry, amount_pence, ringfencedamount_pence, progressamount_pence,
	 * 		completion_percentage, currency, priority, moregamesavailable, notinterested, gameinpromotion, depositmatched, userbonusstatus_id, templatename,
	 * 			minimumtransaction, maximumbonus, rolloverrequirement, rolloverrequirement_pence, wageringamount_pence, dateadded, acknowledged, rewardcash, 
	 * 				eligiblegames, gametoken_id, gametoken_id, subsequentbonusamount_pence, subsequentbonustype.
	 */
	private static Response activeBonusQuerry(int productID, int userID) {

		Map<String, Object> jsonParamsMap = new HashMap<>();
		jsonParamsMap.put("product_id", productID);
		jsonParamsMap.put("user_id", userID);

		Map<String, Object> jsonMap = new HashMap<>();
		jsonMap.put("Method", "ActiveBonusQuery");
		jsonMap.put("ID", "7454555412");
		jsonMap.put("Params", jsonParamsMap);

		JSONObject requestParams = new JSONObject(jsonMap);

		RequestSpecification request = BaseRequest.createRequest(requestParams);
		Response response = request.when().post("http://gaminginternalsvc.uat.lb.local/gamingbonusapiv1/API/activebonusquery");

		return response;
	}

	public static Integer getActiveUserBonusId(int userID, int productID) {

		Integer userBonusID = activeBonusQuerry(productID, userID).then().statusCode(200).extract().path("result[0].userbonus_id");

		return userBonusID;
	}

	/**
	 * Method to claim Deposit matched bonus
	 * @param userID
	 * @param productID
	 * @param admin
	 * @return 'OK' response if request was successful
	 */
	public static Response claimUserBonus(int userID, int productID, int userBonusID) {

		Map<String, Object> jsonParamsMap = new HashMap<>();
		jsonParamsMap.put("userbonus_id", userBonusID);
		jsonParamsMap.put("user_id", userID);
		jsonParamsMap.put("admin", "Sofia Automation");

		Map<String, Object> jsonMap = new HashMap<>();
		jsonMap.put("Method", "bonusclaimbyadmincommand");
		jsonMap.put("ID", "12345678");
		jsonMap.put("Params", jsonParamsMap);

		JSONObject requestParams = new JSONObject(jsonMap);

		RequestSpecification request = BaseRequest.createRequest(requestParams);
		Response response = request.when().post("http://gaminginternalsvc.uat.lb.local/gam-bonus-admin-svcv1/api/bonusClaimByAdminCommand");

		return response;
	}

	/**
	 * Set user balance from CBS(Single balance)
	 * @param username
	 * @param gamingBalance
	 * @param sportsBalance
	 */
	public static void setSingleBalanceCBS(String username, BigDecimal gamingBalance, 
			BigDecimal sportsBalance) {

		String balanceEndPoint = "http://uat-gam-cbs.lb.local:7100/cbs/gaming/test/initialise_balance";
		int userId = DatabaseQueries.getUserIdFromUserTable(username);

		Map<String, Object> params = new LinkedHashMap<>();
		params.put("user_id", userId);
		params.put("new_gaming_withdrawable", gamingBalance);
		params.put("new_sports_withdrawable", sportsBalance);

		Map<String, Object> jsonMap = new LinkedHashMap<>();
		jsonMap.put("Method", "initialisebalance");
		jsonMap.put("Params", params);

		RequestSpecification request = BaseRequest.createRequest(jsonMap);
		request.when().post(balanceEndPoint);
	}

	public static String generateRandomString() {

		String SALTCHARS = "abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < 20) { // length of the random string.
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();
		return saltStr;

	}

	public static String getTimeStamp() {

		String timeDate = getZoneLocalDateFormat("UTC", DateTimeFormatter.ISO_LOCAL_DATE_TIME).replace("T", " ").replace("-", "/");
		int lenght = timeDate.length();

		switch (lenght) {
		case 22:
			return timeDate.substring(0, lenght - 2) + "0" + timeDate.substring(lenght - 2, lenght);
		case 21:
			return timeDate.substring(0, lenght - 1) + "00" + timeDate.substring(lenght - 1, lenght);
		default:
			return timeDate;
		}

	}

	public static String getZoneLocalDateFormat(String zoneID, DateTimeFormatter formatter) {

		try {
			ZonedDateTime currentZone = ZonedDateTime.of(LocalDateTime.now(), ZoneId.of("Europe/Sofia"));
			ZoneId newZone = ZoneId.of(zoneID);
			ZonedDateTime newZoned = currentZone.withZoneSameInstant(newZone);
			LocalDateTime newLocal = newZoned.toLocalDateTime();	
			DateTimeFormatter dateTimeFormatter = formatter;
			String formattedDateTime = dateTimeFormatter.format(newLocal);

			return formattedDateTime;
		} catch (DateTimeException e) {
			throw new DateTimeException("Provided time zone: " + zoneID + " is invalid");
		}

	}

	public static String getBaseUri (String userName) {

		String userCountry = DatabaseQueries.getUserCountryFromUserTable(userName);

		if (userCountry.equals("UK")) {
			return BaseUri.UK.getBaseUri();
		}
		if (userCountry.equals("Denmark")) {
			return BaseUri.DK.getBaseUri();
		}
		if (userCountry.equals("Spain")) {
			return BaseUri.ES.getBaseUri();
		}
		if (userCountry.equals("Netherlands")) {
			return BaseUri.NL.getBaseUri();
		}
		if (userCountry.equals("Mexico")) {
			return BaseUri.MX.getBaseUri();
		}
		if (userCountry.equals("Sweden")) {
			return BaseUri.SE.getBaseUri();
		}
		if (userCountry.equals("BAC")) {
			return BaseUri.BAC.getBaseUri();
		}
		if (userCountry.equals("BAP")) {
			return BaseUri.BAP.getBaseUri();
		}
		if (userCountry.equals("Ontario")) {
			return BaseUri.ONT.getBaseUri();
		}
		if (userCountry.equals("Greece")) {
			return BaseUri.GR.getBaseUri();
		} else {return null;}
	}

	public static String getAuthorisation (String userName) {

		String userCountry = DatabaseQueries.getUserCountryFromUserTable(userName);

		if (userCountry.equals("UK")) {
			return Authorization.UK.getAuthorization();
		}
		if (userCountry.equals("Denmark")) {
			return Authorization.DK.getAuthorization();
		}
		if (userCountry.equals("Spain")) {
			return Authorization.ES.getAuthorization();
		}
		if (userCountry.equals("Netherlands")) {
			return Authorization.NL.getAuthorization();
		}
		if (userCountry.equals("Mexico")) {
			return Authorization.MX.getAuthorization();
		}
		if (userCountry.equals("Sweden")) {
			return Authorization.SE.getAuthorization();
		}
		if (userCountry.equals("BAC")) {
			return Authorization.BAC.getAuthorization();
		}
		if (userCountry.equals("BAP")) {
			return Authorization.BAP.getAuthorization();
		}
		if (userCountry.equals("Ontario")) {
			return Authorization.ONT.getAuthorization();
		}
		if (userCountry.equals("Greece")) {
			return Authorization.GR.getAuthorization();
		} else {return null;}
	}


	public static String getPublicToken(String userName, int gameId, ProductId productId) {

		String publicToken = XmlUtils.createTestToken(userName, gameId, productId);
		return publicToken;

	}

	public static int getRandomMessageId() {
		return randomMessageId.nextInt() & Integer.MAX_VALUE;
	}

	public static String randomMessageIdString() {
		int id = randomMessageId.nextInt() & Integer.MAX_VALUE;
		return String.valueOf(id);
	}

	public static Filter getRequestFilter() {

		return requestFilter;

	}

	public static void prettyBodyMessage(Response response, String requestApi) {

		Prettifier prettifier = new Prettifier();
		String prettyBody = prettifier.getPrettifiedBodyIfPossible(response, response.getBody());
		int statusCode = response.statusCode();
		preformattedMessage("<b>Response status:</b> " + statusCode);
		preformattedMessage("<b>Response body</b> of " + requestApi + " :\n" + prettyBody);

	}

	public static Response loginPost(String userName, String publicToken) {

		String loginEndPoint = "Login";

		Date currentDate = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSS'Z'");
		String utcTimeStamp = simpleDateFormat.format(currentDate);
		int messageId = getRandomMessageId();

		String requestBody = "{\r\n"
				+ "    \"utcTimeStamp\": \""+utcTimeStamp+"\",\r\n"
				+ "    \"PublicToken\": \""+publicToken+"\",\r\n"
				+ "    \"MessageID\": "+messageId+"\r\n"
				+ "}";

		System.out.println("\n------Login request------");
		System.out.println(requestBody); 

		RequestSpecification request = RestAssured.given()
				.baseUri(getBaseUri(userName))
				.headers("Accept", "*/*", "api-version","3.0", "Authorization", getAuthorisation(userName))
				.contentType("application/json").body(requestBody).filter(getRequestFilter());
		Response response = request.when().post(loginEndPoint);

		prettyBodyMessage(response, loginEndPoint);

		System.out.println("------Login response------");
		response.prettyPrint();

		return response;

	}

	public static Response gameRoundPost(String userName, String privateToken, String gameCode) {

		String gameRoundEndPoint = "GameRound";

		String utcTimeStamp = dateTimeUtc();
		String startDateTime = dateTimeUtc();
		String methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
		String externalGameRoundId = methodName + System.currentTimeMillis();

		int messageId = getRandomMessageId();

		String requestBody = "{\r\n"
				+ "    \"jackpotDetails\": null,\r\n"
				+ "    \"utcTimeStamp\": \""+utcTimeStamp+"\",\r\n"
				+ "    \"messageID\": "+messageId+",\r\n"
				+ "    \"privateToken\": \""+privateToken+"\",\r\n"
				+ "    \"gameCode\": \""+gameCode+"\",\r\n"
				+ "    \"externalGameRoundId\": \""+externalGameRoundId+"\",\r\n"
				+ "    \"channelId\": 10002,\r\n"
				+ "    \"startTimeUTC\": \""+startDateTime+"\"\r\n"
				+ "}";

		System.out.println("\n------GameRound request------");
		System.out.println(requestBody); 

		RequestSpecification request = RestAssured.given()
				.baseUri(getBaseUri(userName))
				.headers("Accept", "*/*", "api-version","3.0", "Authorization", getAuthorisation(userName))
				.contentType("application/json").body(requestBody).filter(getRequestFilter());
		Response response = request.when().post(gameRoundEndPoint);

		prettyBodyMessage(response, gameRoundEndPoint);

		System.out.println("------GameRound response------");
		response.prettyPrint();

		return response;

	}

	public static Response transactionPost(String userName, String privateToken, int betAmount, String gameRoundId) {

		String transactionEndPoint = "Transaction";

		String userCurrency = DatabaseQueries.getUserCurrencyFromUserTable(userName);

		String utcTimeStamp = dateTimeUtc();
		String externalTransactionId = "VZZ" + System.currentTimeMillis();

		int messageId = getRandomMessageId();

		String requestBody = "{\r\n"
				+ "    \"transactionType\": \"Stake\",\r\n"
				+ "    \"jackpotDetails\": null,\r\n"
				+ "    \"actionType\": \"Standard\",\r\n"
				+ "    \"utcTimeStamp\": \""+utcTimeStamp+"\",\r\n"
				+ "    \"amount\": "+betAmount+",\r\n"
				+ "    \"messageID\": "+messageId+",\r\n"
				+ "    \"gameRoundId\": \""+gameRoundId+"\",\r\n"
				+ "    \"privateToken\": \""+privateToken+"\",\r\n"
				+ "    \"externalTransactionId\": \""+externalTransactionId+"\",\r\n"
				+ "    \"currencyCode\": \""+userCurrency+"\"\r\n"
				+ "}";

		System.out.println("\n------Transaction request------");
		System.out.println(requestBody); 

		RequestSpecification request = RestAssured.given()
				.baseUri(getBaseUri(userName))
				.headers("Accept", "*/*", "api-version","3.0", "Authorization", getAuthorisation(userName))
				.contentType("application/json").body(requestBody).filter(getRequestFilter());
		Response response = request.when().post(transactionEndPoint);

		prettyBodyMessage(response, transactionEndPoint);

		System.out.println("------Transaction response------");
		response.prettyPrint();

		return response;

	}

	public static void makeASpinCogena(String userName, int regulatedGameId, String gameCode, int betAmount, String token) {

		Response loginResponse = loginPost(userName, token);

		JsonPath jsonPath = loginResponse.jsonPath();
		String privateToken = jsonPath.getString("PrivateToken");

		Response gameRoundResponse = gameRoundPost(userName, privateToken, gameCode);

		jsonPath = gameRoundResponse.jsonPath();
		String gameRoundId = jsonPath.getString("GameRoundID");

		transactionPost(userName, privateToken, betAmount, gameRoundId);
	}
}
