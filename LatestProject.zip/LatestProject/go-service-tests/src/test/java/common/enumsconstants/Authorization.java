package common.enumsconstants;

public enum Authorization {

	NOT_PROPER("Basic R2VuZXJpY0NvbToyajJLS3cyV3o"),
	//Those are for Cogena authorization
	UK("Basic R2VuZXJpY0NvbToyajJLS3cyV3oz"),
	IT("Basic R2VuZXJpY0l0YWx5OnZwM3ExMnIwZHB0dQ=="),
	BG("Basic R2VuZXJpY0J1bGdhcmlhOmVUTkQzaGxQZHZhNDZoSA=="),
	SE("Basic R2VuZXJpY1N3ZWRlbjp3M1JOd2hKN0h6c1ZWSFd4"),
	ES("Basic R2VuZXJpY1NwYWluOjkzeTkzbnhoSGtKTEdWYTI="),
	DK("Basic R2VuZXJpY0Rlbm1hcms6ZmdyMjQzSGpSM2thQw=="),
	GR("Basic R2VuZXJpY0dyZWVjZTptdEQ8QnIoaEtIN1laXDdi"),
	NL("Basic T25zZW9OTFVzZXI6cGxDb2xxUnVPZ2hFTk1KVg=="),
	MX("Basic R2VuZXJpY01leGljbzpUditzXzdDS0l6eiZRU2JE"),
	BAC("Basic Q29nZW5hV2hpdGVMYWJlbEJBQ1VzZXI6ZjJhKzVjQzMxLUJD"),
	BAP("Basic Q29nZW5hV2hpdGVMYWJlbEJBUFVzZXI6Sm5fMTdlYTA0LUF3Jjkx"),
	ONT("Basic Q29nZW5hV2hpdGVMYWJlbE9OVFVzZXI6MmoyS0t3Mld6Mw=="),
	//Those are for Incentive authorization
	ROW_INCENTIVE("Basic SW5jZW50aXZlUk9XVXNlcjo8e0FxUDJTKitHaSQrN0xf"),
	//Those are for Evolution authorization
	ROW_EVOLUTION("RXZvbHV0aW9uUk9XVXNlcjp2UFNmN0p6eHZUdm0zOGVQ"),
	NJ_EVOLUTION("QXV0aFRva2VuOmN3Nm53V1Y1N2tyYnczMGZkZjNh");

	private String authorization;

	private Authorization(String authorization) {
		this.authorization = authorization;
	}

	public String getAuthorization() {
		return authorization;
	}
}
