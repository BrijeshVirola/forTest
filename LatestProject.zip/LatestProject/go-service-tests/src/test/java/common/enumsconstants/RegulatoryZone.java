package common.enumsconstants;

public enum RegulatoryZone {
	
	UK,
	ROW,
	SE,
	ES,
	DK,
	BG,
	GR,
	NL,
	MX,
	BAC,
	BAP,
	ONT;	
}

