package common.enumsconstants;

public enum BaseUri {
	
	BAC("http://mn2gampsr0001u0:8047/API/BAC/"),
	BAP("http://mn2gampsr0001u0:8047/API/BAP/"),
	DK("http://mn2gampsr0002u0:8045/API/DK/"),
	EE("http://mn2gampsr0002u0:8045/API/EE/"),
	ES("http://mn2gampsr0002u0:8045/API/ES/"),
	GR("http://mn2gampsr0001u0:8097/API/GR/"),
	MX("http://mn2gampsr0002u0:8045/API/MX/"),
	NL("http://mn2gampsr0002u0:8045/API/NL/"),
	ONT("http://mn2gampsr0002u0:8045/API/ONT/"),
	SE("http://mn2gampsr0002u0:8045/API/SE/"),
	UK("http://mn2gampsr0002u0:8045/API/UK/");
	
	private String baseUri;
	
	private BaseUri(String baseUri) {
		this.baseUri = baseUri;
	}
	
	public String getBaseUri() {
		return baseUri;
	}

}