package common.enumsconstants;

public enum ApiVersion {
	
	V1("1.0"),
	V2("2.0"),
	V3("3.0"),
	EMPTY("");
	
	private String version;
	
	private ApiVersion(String version) {
		this.version = version;
	}
	
	public String getVersion() {
		return version;
	}

}