package common.enumsconstants;

public class UsersId {

	public final static int NOT_EXISTING = 999999900;//Not Existing User id
	public final static int GO_SVC_TESTS = 4599708;//GBP
	public final static int GOSERVICE1 = 4600928;//GBP zero balance all products
	public final static int GOSERVICE2 = 4600995;//GBP gaming balance 80, games bonus balance 56
	public final static int GOSERVICE3 = 4601064;//GBP gaming balance 100, casino bonus 30
	public final static int GO_SVC_TESTS01 = 4601289;//GBP gaming balance 70, casino ring fenced and bonus = 30
	public final static int GO_SVC_TESTS02 = 4601572;//EUR gaming balance 85.36
	public final static int GO_SVC_TESTS03 = 4603164;//GBP 
	public final static int GO_SVC_TESTS04 = 4606275;//GBP 
	public final static int GO_SVC_TESTS05 = 4607384;//GBP

	public final static int GO_SVC_TESTS25 = 4641947;//GBP 

	public final static int GO_SVC_TESTS28 = 4646540;//GBP 
	public final static int GO_SVC_TESTS29 = 4646964;//GBP 
	public final static int GO_SVC_TESTS30 = 4647575;//GBP 
	public final static int GO_SVC_TESTS31 = 4648034;//GBP 

	public final static int GO_SVC_TEST137 = 4809979;//GBP
	public final static int GO_SVC_TEST138 = 4810006;//Denmark

	public final static int GO_SVC_TEST145 = 4832335;//GBP
	public final static int GO_SVC_TEST146 = 4832397;//GBP

}
