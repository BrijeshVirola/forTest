package common.enumsconstants;

public enum LoginGGI {
	
	LOGIN_UK("GGiUser", "_TbY7NsWp9%_fwBx"),
	LOGIN_DK("GGiDkUser", "J6T6mXs-Lh$k2twz"),
	LOGIN_ES("GGiEsUser", "qw8x9om83Hd"),
	LOGIN_NL("GGiNLUser", "87D6TSTAXY5NACNj"),
	LOGIN_MX("GGiMXUATUser", "BQCAA421QGEIKBW5"),
	LOGIN_SE("GGiSEUser", "8qsWtvSS2vNjAd7R"),
	LOGIN_BAC("GGiBACUser", "fuH2gp4LB7dZ4C2D"),
	LOGIN_BAP("GGiBAPUser", "P7UrZWxkeCrdskjJ"),
	LOGIN_ONT("GGiONTUser", "HVRFhCHaxrF3rMqW"),
	LOGIN_GR("GGiGRUser", "qIJ6dohbx3WE45S7");
	
	private String username;
	private String password;
	
	private LoginGGI(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}
	
}
