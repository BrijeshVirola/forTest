package common.testtoken.response;

import java.util.HashMap;
import java.util.Map;

public class CreateUserSessionTestResp {

	private String id;
	private Map<String, Object> result = new HashMap<>();

	public CreateUserSessionTestResp() {
	}
	
	private CreateUserSessionTestResp(Builder builder) {
		this.id = builder.id;
		this.result.put("session_id", builder.session_id);
	}
	
	public String getSessionId() {
		return this.result.get("session_id").toString();
	}
	
	public String getId() {
		return id;
	}
	
	public Map<String, Object> getResult() {
		return result;
	}

	public static class Builder {
		private String id, session_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.session_id = "";
			return this;
		}

		public CreateUserSessionTestResp build() {
			return new CreateUserSessionTestResp(this);
		}
	}
}


