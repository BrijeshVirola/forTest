package common.testtoken.request;


import java.util.HashMap;
import java.util.Map;

public class TerminateUserSessionTestReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private TerminateUserSessionTestReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("session_id", builder.session_id);
	}

	public static class Builder {
		private String id, method, session_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder defaults() {
			this.method = "terminateusersessionbysession-test";
			this.id = "1";
			this.session_id = "";
			return this;
		}

		public TerminateUserSessionTestReq build() {
			return new TerminateUserSessionTestReq(this);
		}
	}
}

