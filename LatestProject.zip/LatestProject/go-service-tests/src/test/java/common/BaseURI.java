package common;

public class BaseURI {

	private static final String SERVER_URL = "http://mn2gampsr0002u0";
	private static final String SERVER_URL2 = "http://mn2gampsr0002u0";
	
	public static final String CREATE_USER_SESSION = SERVER_URL + ":18380/api/"; // Also used for creating Slots session 
	public static final String GAME_ROUND_SERVICE = SERVER_URL + ":18060/api/";
	public static final String GAMING_BONUS_ADMIN_SERVICE = "http://gaminginternalsvc.uat.lb.local/gam-bonus-admin-svcv1/api/";
	
	public static final String CLIENT_RESP_GAMBLING_LIMIT_SERVICE_BING0 = "https://bingo571.b365uat.com/gamingservices/gam-client-responsible-gambling-limit-svcv1/api/";
	public static final String CLIENT_RESP_GAMBLING_LIMIT_SERVICE_GAMES = "https://games571.b365uat.com/gamingservices/gam-client-responsible-gambling-limit-svcv1/api/";
	public static final String CLIENT_RESP_GAMBLING_LIMIT_SERVICE_CASINO = "https://casino571.b365uat.com/gamingservices/gam-client-responsible-gambling-limit-svcv1/api/";
	public static final String CLIENT_RESP_GAMBLING_LIMIT_SERVICE_POKER = "https://poker571.b365uat.com/gamingservices/gam-client-responsible-gambling-limit-svcv1/api/";

	public static final String GAME_LAUNCH_TOKEN_SERVICE = SERVER_URL + ":18260/api/";
	public static final String GAME_ELK_ASSET_SERVICE = SERVER_URL2 + ":18390/";
	public static final String GAME_THUNDERKICK_ASSET_SERVICE = SERVER_URL2 + ":18102/";
	public static final String GAME_NO_CITY_LIMIT_ASSET_SERVICE = SERVER_URL2 + ":18025/";
	
	public static final String tokenURI = "http://mn2gampsr0002u0:18380";
	public static final String loginURI = "http://mn2gampsr0001u0:8250/GGI/ROW/WcfServices";
	
	public static final String GET_TOKEN_BY_TOKEN = SERVER_URL + ":18020/api/";
}


