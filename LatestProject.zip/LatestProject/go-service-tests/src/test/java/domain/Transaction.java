package domain;

import java.util.Objects;

import io.restassured.response.Response;

public class Transaction {

	public Transaction(Response response) {
	    bet365_games_transaction_id  = response.path("result.bet365_games_transaction_id", (String[]) null);
	    transaction_type_id = response.path("result.transaction_type_id", (String[]) null);
	    action_type_id = response.path("result.action_type_id", (String[]) null);
	    partner_transaction_id = response.path("result.partner_transaction_id", (String[]) null);
	    real_amount = response.path("result.real_amount", (String[]) null);
	    ring_fenced_amount = response.path("result.ring_fenced_amount", (String[]) null);
	    bonus_amount = response.path("result.bonus_amount", (String[]) null);
	    total_amount = response.path("result.total_amount", (String[]) null);
	    total_amount_gbp = response.path("result.total_amount_gbp", (String[]) null);
	    currency_code = response.path("result.currency_code", (String[]) null);
	    partner_timestamp_utc = response.path("result.partner_timestamp_utc", (String[]) null);
	    game_round_id = response.path("result.game_round_id", (String[]) null);
	    bet365_transaction_id = response.path("result.bet365_transaction_id", (String[]) null);
		provider_region_id = response.path("result.provider_region_id", (String[]) null);
	    is_new = response.path("result.is_new", (String[]) null);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(action_type_id, bet365_games_transaction_id, bet365_transaction_id, bonus_amount,
				currency_code, game_round_id, is_new, partner_timestamp_utc, partner_transaction_id, provider_region_id,
				real_amount, ring_fenced_amount, total_amount, total_amount_gbp, transaction_type_id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		return action_type_id == other.action_type_id
				&& bet365_games_transaction_id == other.bet365_games_transaction_id
				&& bet365_transaction_id == other.bet365_transaction_id
				&& Objects.equals(bonus_amount, other.bonus_amount)
				&& Objects.equals(currency_code, other.currency_code)
				&& game_round_id == other.game_round_id
				&& Objects.equals(partner_timestamp_utc, other.partner_timestamp_utc)
				&& Objects.equals(partner_transaction_id, other.partner_transaction_id)
				&& provider_region_id == other.provider_region_id
				&& Objects.equals(real_amount, other.real_amount)
				&& Objects.equals(ring_fenced_amount, other.ring_fenced_amount)
				&& Objects.equals(total_amount, other.total_amount)
				&& Objects.equals(total_amount_gbp, other.total_amount_gbp)
				&& transaction_type_id == other.transaction_type_id;
	}

	//TODO note:
	//	examples on the web indicate that naming the fields in line with the json fields
	//	will result in the object being mapped automatically.
	//	this doesn't seem to be working for me though but I'm leaving the fields named
	//	this way so it can be investigated further
	//	The alternative would be to configure RestAssured to use gson's mapping but
	//	I've yet to get this to work either
    public long bet365_games_transaction_id;
    public int transaction_type_id;
    public int action_type_id;
    public String partner_transaction_id;
    public String real_amount;
    public String ring_fenced_amount;
    public String bonus_amount;
    public String total_amount;
    public String total_amount_gbp;
    public String currency_code;
    public String partner_timestamp_utc;
    public int game_round_id;
    public int bet365_transaction_id;
    public int provider_region_id;
    public boolean is_new;
}
