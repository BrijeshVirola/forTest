package domain;

import common.enumsconstants.Errors;

public class ErrorResponse {
	
	private ErrorObject error;
	private String id;
	
	public ErrorResponse() {
	}

	public ErrorResponse(Errors error) {
		this.error = new ErrorObject(error);
	}

	public ErrorObject getError() {
		return error;
	}
	
	public String getId() {
		return id;
	}
	
}
