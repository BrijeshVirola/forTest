package domain;

import java.util.Collections;
import java.util.Map;

import org.json.simple.JSONObject;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;

import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import logging.LoggingRequestFilter;

public class BaseRequest {

	private static LoggingRequestFilter filter = new LoggingRequestFilter();
	private static JsonObject body = new JsonObject();

	public static RequestSpecification createRequest(JsonObject jsonBody) {
		return createRequest(jsonBody, true, true);
	}

	public static RequestSpecification createRequest(Object pojo) {
		return createRequest(pojo, true, true);
	}

	private static RequestSpecification createRequest(JsonObject jsonBody, boolean shouldSetAcceptHeader,
			boolean shouldSetContentTypeHeader) {
		RequestSpecification request = RestAssured.given().filter(filter);

		setAcceptAndContentType(shouldSetAcceptHeader, shouldSetContentTypeHeader, request);

		request.body(jsonBody.toString());

		return request;
	}

	@SuppressWarnings("unchecked")
	private static RequestSpecification createRequest(Object pojo, boolean shouldSetAcceptHeader,
			boolean shouldSetContentTypeHeader) {

		ObjectMapper obm = new ObjectMapper().setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		RequestSpecification request = RestAssured.given().filter(filter);
		setAcceptAndContentType(shouldSetAcceptHeader, shouldSetContentTypeHeader, request);
		request.body(new JSONObject(removeParamsNullValueKeys(obm.convertValue(pojo, Map.class))));

		return request;
	}
	
	@SuppressWarnings("unchecked")
	private static Map<String, Object> removeParamsNullValueKeys(Map<String, Object> map) {
		
		Map<String, Object> paramsMap = null;

	    for (Map.Entry<String, Object> entry : map.entrySet()) {    	
	    	// If Map has a key value of a Map
	    	if (entry.getValue() != null && entry.getValue() instanceof Map) {		
	    		// Assign the Map to a Set variable to iterate, and remmove any null value keys
	    		paramsMap = (Map<String, Object>) entry.getValue();
	    		paramsMap.values().removeAll(Collections.singleton(null));
	    		// Replace the the old Map key with the filtered one
	    		map.replace(entry.getKey(), paramsMap);
	    	}
	    	else if (entry.getValue() == null && entry.getKey().equalsIgnoreCase("params")) {
	    		map.remove(entry.getKey());
	    	}
	    }
	    
	    return map;
	}

	@SafeVarargs
	public static RequestSpecification createRequest(Object pojo, Map<String, Object>... headers) {

		RequestSpecification request = RestAssured.given().filter(filter);
		ObjectMapper obm = new ObjectMapper().setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		if (headers.length > 0) {
			request.headers(headers[0]);
		}		request.body(new JSONObject(obm.convertValue(pojo, Map.class)));
		setAcceptAndContentType(true, true, request);
		return request;
	}
	
	@SafeVarargs
	public static RequestSpecification createRequestWithUri(Object pojo, String baseUri, Map<String, Object>... headers) {

		RequestSpecification request = RestAssured.given().baseUri(baseUri).filter(filter);
		ObjectMapper obm = new ObjectMapper().setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		if (headers.length > 0) {
			request.headers(headers[0]);
		}		request.body(new JSONObject(obm.convertValue(pojo, Map.class)));
		setAcceptAndContentType(true, true, request);
		return request;
	}

	@SafeVarargs
	public static RequestSpecification getRequest(Map<String, Object> queryParams, Map<String, Object>... headers) {
		RequestSpecification request = RestAssured.given().filter(filter);

		if (headers.length > 0) {
			request.headers(headers[0]).queryParams(queryParams);
		} else {
			request.queryParams(queryParams);
		}

		setAcceptAndContentType(true, true, request);
		return request;
	}
	
	@SafeVarargs
	public static RequestSpecification getRequestWithUri(Map<String, Object> queryParams, String baseUri, Map<String, Object>... headers) {
		RequestSpecification request = RestAssured.given().baseUri(baseUri).filter(filter);

		if (headers.length > 0) {
			request.headers(headers[0]).queryParams(queryParams);
		} else {
			request.queryParams(queryParams);
		}

		setAcceptAndContentType(true, true, request);
		return request;
	}

	public static Response callWrongMethodNameRequest(String endPoint, boolean post) {

		JsonObject body = new JsonObject();
		body.addProperty("Method", "invalid_method");

		RequestSpecification request = createRequest(body);
		Response response = post ? request.post(endPoint) : request.get(endPoint);
		response.then().statusCode(200);
		return response;
	}

	/**
	 * 
	 * @param endPoint
	 * @param shouldSetAcceptHeader
	 * @param shouldSetContentTypeHeader
	 * @param post                       if true will call POST request, otherwise
	 *                                   GET
	 * @return
	 */
	public static Response callEmptyBodyRequest(String endPoint, boolean shouldSetAcceptHeader,
			boolean shouldSetContentTypeHeader, boolean post) {

		RequestSpecification request = createRequest(body, shouldSetAcceptHeader, shouldSetContentTypeHeader);
		Response response = post ? request.post(endPoint) : request.get(endPoint);
		response.then().statusCode(200);
		return response;
	}

	public static Response callNoJsonRequest(String endPoint, boolean shouldSetAcceptHeader,
			boolean shouldSetContentTypeHeader, boolean post) {
		RequestSpecification request = RestAssured.given().filter(filter);
		setAcceptAndContentType(shouldSetAcceptHeader, shouldSetContentTypeHeader, request);
		request.body("");

		Response response = post ? request.post(endPoint) : request.get(endPoint);
		response.then().statusCode(200);
		return response;
	}

	private static void setAcceptAndContentType(boolean shouldSetAcceptHeader, boolean shouldSetContentTypeHeader,
			RequestSpecification request) {
		if (shouldSetAcceptHeader) {
			request.header("Accept", "application/json");
		}
		if (shouldSetContentTypeHeader) {
			request.header("Content-Type", "application/json");
		}
	}

	public static <T> T post(Object reqObject, ResponseEndpoints endpoint) {

		RequestSpecification request = createRequest(reqObject);
		Response response = request.post(endpoint.getEndPoint());
		response.then().statusCode(200);

		T resp = response.as(endpoint.getRespClass());

		return resp;
	}
	
	/**
	 * @param reqObject
	 * @param endpoint
	 * @return Response without class serialization
	 */
	public static Response post(Object reqObject, String endpoint) {

		RequestSpecification request = createRequest(reqObject);
		Response response = request.post(endpoint);
		response.then().statusCode(200);

		return response;
	}

	/**
	 * 
	 * @param <T>
	 * @param reqObject
	 * @param endpoint
	 * @param baseUri
	 * @return
	 */
	public static <T> T post(Object reqObject, ResponseEndpoints endpoint, String baseUri) {

		RequestSpecification request = RestAssured.given().baseUri(baseUri).filter(filter);
		ObjectMapper obm = new ObjectMapper().setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		setAcceptAndContentType(true, true, request);
		request.body(new JSONObject(obm.convertValue(reqObject, Map.class)));

		Response response = request.post(endpoint.getEndPoint());
		response.then().statusCode(200);

		T resp = response.as(endpoint.getRespClass());

		return resp;
	}
	
	@SafeVarargs
	public static <T> T post(Object reqObject, ResponseEndpoints endpoint, String baseUri, int statusCode, Map<String, Object>... headers) {

		RequestSpecification request = createRequestWithUri(reqObject, baseUri, headers);
		Response response = request.post(endpoint.getEndPoint());
		response.then().statusCode(statusCode);	
		
		T resp = !response.asString().isEmpty() ? response.as(endpoint.getRespClass()) : null;
		return resp;
	}
	

	@SafeVarargs
	public static <T> T post(Object reqObject,ResponseEndpoints endpoint, int statusCode, Map<String, Object>... headers) {
		RequestSpecification request = createRequest(reqObject, headers);
		Response response = request.post(endpoint.getEndPoint());
		response.then().statusCode(statusCode);	

		T resp = response.as(endpoint.getRespClass());	
		return resp;
	}
	
	@SafeVarargs
	public static <T> T get(Map<String, Object> queryParams, ResponseEndpoints endpoint, Map<String, Object>... headers) {
		RequestSpecification request = getRequest(queryParams, headers);
		Response response = request.get(endpoint.getEndPoint());
		response.then().statusCode(200);

		T resp = response.as(endpoint.getRespClass());
		return resp;
	}

	@SafeVarargs
	public static <T> T get(Map<String, Object> queryParams, ResponseEndpoints endpoint, int statusCode, Map<String, Object>... headers) {
		RequestSpecification request = getRequest(queryParams, headers);
		Response response = request.get(endpoint.getEndPoint());
		response.then().statusCode(statusCode);
		
		T resp = !response.asString().isEmpty() ? response.as(endpoint.getRespClass()) : null;		
		return resp;
	}

	/**
	 * Send get request to an endpoint which responds with jsonString response body
	 * Convert this jsonString response body to a specific Java object
	 * @param <T>
	 * @param queryParams
	 * @param endpoint
	 * @param headers - optional parameter
	 * @return
	 */
	@SafeVarargs
	public static <T> T sendGet(Map<String, Object> queryParams, ResponseEndpoints endpoint, Map<String, Object>... headers) {
		RequestSpecification request = getRequest(queryParams, headers);
		Response response = request.get(endpoint.getEndPoint());
		response.then().statusCode(200);

		T resp = Utils.convertJsonStringToObject(response.getBody().asString(), endpoint.getRespClass());
		return resp;

}
	@SafeVarargs
	public static <T> T get(Map<String, Object> queryParams, ResponseEndpoints endpoint, String baseUri, Map<String, Object>... headers) {
		RequestSpecification request = getRequestWithUri(queryParams, baseUri, headers);
		Response response = request.get(endpoint.getEndPoint());
		response.then().statusCode(200);

		T resp = response.as(endpoint.getRespClass());
		return resp;
	}
	
	@SafeVarargs
	public static <T> T sendGet(Map<String, Object> queryParams, ResponseEndpoints endpoint, int statusCode, Map<String, Object>... headers) {
		RequestSpecification request = getRequest(queryParams, headers);
		Response response = request.get(endpoint.getEndPoint());
		response.then().statusCode(statusCode);

		T resp = Utils.convertJsonStringToObject(response.getBody().asString(), endpoint.getRespClass());
		return resp;
	}
	
	@SafeVarargs
	public static <T> T get(Map<String, Object> queryParams, ResponseEndpoints endpoint, int statusCode, String baseUri, Map<String, Object>... headers) {
		RequestSpecification request = getRequestWithUri(queryParams, baseUri, headers);
		Response response = request.get(endpoint.getEndPoint());
		response.then().statusCode(statusCode);

		T resp = !response.asString().isEmpty() ? response.as(endpoint.getRespClass()) : null;
		return resp;
	}
	
	public static <T> T get(ResponseEndpoints endpoint, int statusCode, String baseUri) {
		RequestSpecification request = RestAssured.given().baseUri(baseUri).filter(filter);
		Response response = request.get(endpoint.getEndPoint());
		response.then().statusCode(statusCode);
		T resp = response.as(endpoint.getRespClass());
		return resp;
		}
	
	public static Response getTextResponse(ResponseEndpoints endpoint, int statusCode, String baseUri) {
		RequestSpecification request = RestAssured.given().baseUri(baseUri).filter(filter);
		Response response = request.get(endpoint.getEndPoint());
		response.then().statusCode(statusCode);
		return response;
		}
	
}
