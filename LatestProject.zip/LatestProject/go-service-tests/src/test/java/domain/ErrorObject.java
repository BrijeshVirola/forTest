package domain;

import common.enumsconstants.Errors;

public class ErrorObject {
	
	private int code;
	private String message;

	public ErrorObject() {
	}
	
	public ErrorObject(Errors error) {
		this.code = error.getCode();
		this.message = error.getMessage();
	}

	public int getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}
	
}
