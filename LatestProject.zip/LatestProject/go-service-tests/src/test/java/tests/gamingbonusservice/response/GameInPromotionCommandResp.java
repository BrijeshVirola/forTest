package tests.gamingbonusservice.response;

public class GameInPromotionCommandResp {
	
	private String id;
	private Boolean result;
	
	public GameInPromotionCommandResp() {
	}
	
	private GameInPromotionCommandResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public Boolean getResult() {
		return result;
	}

	public String getId() {
		return id;
	}

	public static class Builder {
		private String id;
		private Boolean result;
		
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder result(Boolean result) {
			this.result = result;
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.result = true;
			return this;
		}
		
		public GameInPromotionCommandResp build() {
			return new GameInPromotionCommandResp(this);
		}	
	}
}

