package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.enums.GamingBonusServiceUsers;
import tests.gamingbonusservice.request.ActiveBonusQueryReq;
import tests.gamingbonusservice.response.ActiveBonusResult;

public class ActiveBonusQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to ActiveBonusQuery. Positive scenario Casino.")
	public void activeBonusQuery_Positive_Scenario_Casino() throws InterruptedException {

		Integer userId =  GamingBonusServiceUsers.ACTIVE_CASH_BONUS_POS1.getUserId();
		Integer bonusTemplateId = 528;
		Integer productId = 2;
		Double amount = 0.01;

		ActiveBonusResult expectedActiveBonusResult = new ActiveBonusResult.Builder()
				.defaults()
				.bonusTemplateId(bonusTemplateId)
				.userBonusStatusId(1)
				.maximumBonus(0)
				.templateName("TestAutomationCredit")
				.isClaimed(false)
				.isRedeemed(false)
				.gameInPromotion(true)
				.acknowledged(true)
				.bonusproductId(2)
				.build();

		Utils.createActiveBonusAndVerifyThenReturnBonusDetails(userId, bonusTemplateId, productId, expectedActiveBonusResult, amount);

	}

	@Test(description = "Make a request to ActiveBonusQuery. Positive scenario Games.")
	public void activeBonusQuery_Positive_Scenario_Games() throws InterruptedException {

		Integer bonusTemplateId = 1850;
		Integer productId = 4;
		Double amount = 0.01;

		ActiveBonusResult expectedActiveBonusResult = new ActiveBonusResult.Builder()
				.defaults()
				.bonusTemplateId(bonusTemplateId)
				.userBonusStatusId(1)
				.maximumBonus(0)
				.templateName("TestAutomationCredit Games")
				.isClaimed(false)
				.isRedeemed(false)
				.gameInPromotion(true)
				.acknowledged(true)
				.bonusproductId(productId)
				.build();

		Utils.createActiveBonusAndVerifyThenReturnBonusDetails(GamingBonusServiceUsers.ACTIVE_CASH_BONUS_POS2.getUserId(), 
				bonusTemplateId, productId, expectedActiveBonusResult, amount);

	}

	@Test(description = "Make a request to activeBonusQuery. Missing user_id parameter.")
	public void activeBonusQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ActiveBonusQueryReq request = new ActiveBonusQueryReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.activeBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to activeBonusQuery. Missing product_id parameter.")
	public void activeBonusQuery_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ActiveBonusQueryReq request = new ActiveBonusQueryReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.ACTIVE_CASH_BONUS_NEG.getUserId())
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.activeBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to activeBonusQuery. Wrong method.")
	public void activeBonusQuery_Wrong_Method() {

		ActiveBonusQueryReq request = new ActiveBonusQueryReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.activeBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}

