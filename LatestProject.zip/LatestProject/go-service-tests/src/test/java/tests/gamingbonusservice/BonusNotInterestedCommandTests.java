package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.enums.GamingBonusServiceUsers;
import tests.gamingbonusservice.request.BonusNotInterestedCommandReq;
import tests.gamingbonusservice.response.BonusResult;

public class BonusNotInterestedCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to BonusNotInterestedCommand. Positive scenario.")
	public void bonusNotInterested_Positive_Scenario() throws InterruptedException {

		Integer testUserId = GamingBonusServiceUsers.BONUS_NOT_INTERESTED_POS1.getUserId();
		Integer productId = 4;
		Double amount = 0.01;

		BonusResult expectedBonusResult = new BonusResult.Builder()
				.defaults()
				.build();

		BonusResult actualNewlyCreatedUserBonus = Utils.createBonusAndVerifyThenReturnBonusDetails(testUserId,  expectedBonusResult.bonustemplate_id, productId, expectedBonusResult, amount);

		String idForBonusNotInterested = UUID.randomUUID().toString();

		BonusNotInterestedCommandReq requestBonusNotInterested = new BonusNotInterestedCommandReq.Builder()
				.defaults()
				.userId(testUserId)
				.userBonusId(actualNewlyCreatedUserBonus.userbonus_id)
				.id(idForBonusNotInterested)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(requestBonusNotInterested, GamingBonusEndpoints.bonusNotInterestedCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForBonusNotInterested)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		BonusResult actualUpdatedBonus = Utils.getBonusByDateAdded(testUserId, actualNewlyCreatedUserBonus.dateadded);

		BonusResult expectedUpdatedBonus = actualNewlyCreatedUserBonus;
		expectedUpdatedBonus.notinterested = true;
		expectedUpdatedBonus.statusname = "NotInterested";
		expectedUpdatedBonus.userbonusstatus_id = 13;

		assertReflectionEquals(expectedUpdatedBonus, actualUpdatedBonus);

	}

	@Test(description = "Make a request to bonusNotInterested. Missing user_id parameter.")
	public void bonusNotInterested_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusNotInterestedCommandReq request = new BonusNotInterestedCommandReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusNotInterestedCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusNotInterested. Missing userbonus_id parameter.")
	public void bonusNotInterested_MissingUserBonusId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusNotInterestedCommandReq request = new BonusNotInterestedCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.BONUS_NOT_INTERESTED_NEG.getUserId())
				.userBonusId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusNotInterestedCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: userbonus_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusNotInterested. Wrong method.")
	public void bonusNotInterested_Wrong_Method() {

		BonusNotInterestedCommandReq request = new BonusNotInterestedCommandReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusNotInterestedCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}

