package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.enums.GamingBonusServiceUsers;
import tests.gamingbonusservice.request.BonusClaimCommandReq;
import tests.gamingbonusservice.response.BonusResult;

public class BonusClaimCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to BonusClaimCommand. Positive scenario.")
	public void bonusClaimCommand_Positive_Scenario() throws InterruptedException {

		Integer testUserId = GamingBonusServiceUsers.BONUS_CLAIM_COMMAND_POS1.getUserId();
		Integer productId = 4;
		Double amount = 0.01;

		BonusResult expectedBonusResult = new BonusResult.Builder()
				.defaults()
				.build();

		BonusResult actualNewlyCreatedUserBonus = Utils.createBonusAndVerifyThenReturnBonusDetails(testUserId, expectedBonusResult.bonustemplate_id, productId, expectedBonusResult, amount);

		String idForBonusClaimCommand = UUID.randomUUID().toString();

		BonusClaimCommandReq requestBonusClaimCommand = new BonusClaimCommandReq.Builder()
				.defaults()
				.userId(testUserId)
				.userBonusId(actualNewlyCreatedUserBonus.userbonus_id)
				.id(idForBonusClaimCommand)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(requestBonusClaimCommand, GamingBonusEndpoints.bonusClaimCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForBonusClaimCommand)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		BonusResult actualUpdatedBonus = Utils.getBonusByDateAdded(testUserId, actualNewlyCreatedUserBonus.dateadded);

		BonusResult expectedUpdatedBonus = actualNewlyCreatedUserBonus;
		expectedUpdatedBonus.is_claimed = true;
		expectedUpdatedBonus.statusname = "Accepted";
		expectedUpdatedBonus.userbonusstatus_id = 2;
		expectedUpdatedBonus.rolloverrequirement = "0.05";
		Duration threeHundredDays = Duration.ofDays(300);

		//expiry is set at runtime so can differ by a couple of seconds from the previous time plus 300 days so I've set these to null for the assertReflectionEqual test
		//and test individually below
		Instant dateAdded = Instant.parse(actualNewlyCreatedUserBonus.dateadded);
		Instant expectedExpiry = dateAdded.plus(threeHundredDays);
		Instant actualExpiry = Instant.parse(actualNewlyCreatedUserBonus.expiry);

		expectedUpdatedBonus.expiry = null;
		actualUpdatedBonus.expiry = null;

		Long timeDifference = Duration.between(expectedExpiry, actualExpiry).toMillis();
		System.out.println(timeDifference);
		Assert.assertTrue(timeDifference < 3000);

		assertReflectionEquals(expectedUpdatedBonus, actualUpdatedBonus);

	}

	@Test(description = "Make a request to bonusClaimCommand. Missing user_id parameter.")
	public void bonusClaimCommand_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusClaimCommandReq request = new BonusClaimCommandReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusClaimCommand. Missing userbonus_id parameter.")
	public void bonusClaimCommand_MissingUserBonusId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusClaimCommandReq request = new BonusClaimCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.BONUS_CLAIM_COMMAND_NEG.getUserId())
				.userBonusId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: userbonus_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusClaimCommand. Wrong method.")
	public void bonusClaimCommand_Wrong_Method() {

		BonusClaimCommandReq request = new BonusClaimCommandReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}

