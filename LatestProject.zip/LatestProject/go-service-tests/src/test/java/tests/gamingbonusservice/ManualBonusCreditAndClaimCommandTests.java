package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.enums.GamingBonusServiceUsers;
import tests.gamingbonusservice.request.BonusCancelByUserCommandReq;
import tests.gamingbonusservice.request.ManualBonusCreditAndClaimCommandReq;
import tests.gamingbonusservice.response.ActiveBonusResult;
import tests.gamingbonusservice.response.EligibleGame;

public class ManualBonusCreditAndClaimCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to ManualBonusCreditAndClaimCommand. Positive scenario.")
	public void manualBonusCreditAndClaimCommand_Positive_Scenario() throws InterruptedException {

		Integer testUserId = GamingBonusServiceUsers.MANUAL_BONUS_CREDIT_POS1.getUserId();
		Integer productId = 4;
		Integer bonusTemplateId = 1575;
		Double amount = 0.0;
		
		common.Utils.cancelUserActiveBonus(testUserId, productId);

		ActiveBonusResult expectedBonusResult = new ActiveBonusResult.Builder()
				.defaults()
				.bonusTemplateId(bonusTemplateId)
				.templateName("UkComDepositPreWager01_automation")
				.bonusTypeId(5)
				.amountPence(0)
				.userBonusStatusId(15)
				.maximumBonus(0)
				.currency("GBP")
				.isClaimed(false)
				.addEligibleGame(new EligibleGame.Builder().gametokenId(11813).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(15826).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(10601).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(10892).build())
				.isRedeemed(false)
				.depositMatched(true)
				.bonusproductId(productId)
				.moreGamesAvailable(true)
				.acknowledged(true)
				.build();

		ActiveBonusResult actualNewlyCreatedUserBonus = Utils.createActiveBonusAndVerifyThenReturnBonusDetails(testUserId, expectedBonusResult.bonustemplate_id, productId, expectedBonusResult, amount);

		String idForManualBonusCreditAndClaimCommand = UUID.randomUUID().toString();

		ManualBonusCreditAndClaimCommandReq requestManualBonusCreditAndClaimCommand = new ManualBonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.bonusTemplateId(bonusTemplateId)
				.userId(testUserId)
				.id(idForManualBonusCreditAndClaimCommand)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(requestManualBonusCreditAndClaimCommand, GamingBonusEndpoints.manualBonusCreditAndClaimCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForManualBonusCreditAndClaimCommand)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		String idForBonusCancelByUserCommand = UUID.randomUUID().toString();

		BonusCancelByUserCommandReq requestBonusCancelByUserCommand = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userId(testUserId)
				.sportsProductId(null)
				.userBonusId(actualNewlyCreatedUserBonus.userbonus_id)
				.id(idForBonusCancelByUserCommand)
				.build();

		ResultOKResp actualBonusCancelByUserCommandResponse =  BaseRequest.post(requestBonusCancelByUserCommand, GamingBonusEndpoints.bonusCancelByUserCommandSuccess);

		ResultOKResp expectedBonusCancelByUserCommandResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForBonusCancelByUserCommand)
				.build();

		assertReflectionEquals(expectedBonusCancelByUserCommandResponse, actualBonusCancelByUserCommandResponse);	
	}

	@Test(description = "Make a request to ManualBonusCreditAndClaimCommand without the optional parameter"
			+ " transaction_date. Positive scenario.")
	public void manualBonusCreditAndClaimCommand_Positive_Scenario_Without_Transaction_Date() throws InterruptedException {

		Integer testUserId = GamingBonusServiceUsers.MANUAL_BONUS_CREDIT_POS2.getUserId();
		Integer productId = 4;
		Integer bonusTemplateId = 1575;
		Double amount = 0.0;
		
		common.Utils.cancelUserActiveBonus(testUserId, productId);

		ActiveBonusResult expectedBonusResult = new ActiveBonusResult.Builder()
				.defaults()
				.bonusTemplateId(bonusTemplateId)
				.templateName("UkComDepositPreWager01_automation")
				.bonusTypeId(5)
				.amountPence(0)
				.userBonusStatusId(15)
				.maximumBonus(0)
				.currency("GBP")
				.isClaimed(false)
				.addEligibleGame(new EligibleGame.Builder().gametokenId(11813).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(15826).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(10601).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(10892).build())
				.bonusproductId(productId)
				.isRedeemed(false)
				.depositMatched(true)
				.moreGamesAvailable(true)
				.acknowledged(true)
				.build();

		ActiveBonusResult actualNewlyCreatedUserBonus = Utils.createActiveBonusAndVerifyThenReturnBonusDetails(testUserId, expectedBonusResult.bonustemplate_id, productId, expectedBonusResult, amount);

		String idForManualBonusCreditAndClaimCommand = UUID.randomUUID().toString();

		ManualBonusCreditAndClaimCommandReq requestManualBonusCreditAndClaimCommand = new ManualBonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.userId(testUserId)
				.transactionDate(null)
				.bonusTemplateId(bonusTemplateId)
				.id(idForManualBonusCreditAndClaimCommand)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(requestManualBonusCreditAndClaimCommand, GamingBonusEndpoints.manualBonusCreditAndClaimCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForManualBonusCreditAndClaimCommand)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		String idForBonusCancelByUserCommand = UUID.randomUUID().toString();

		BonusCancelByUserCommandReq requestBonusCancelByUserCommand = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userId(testUserId)
				.sportsProductId(null)
				.userBonusId(actualNewlyCreatedUserBonus.userbonus_id)
				.id(idForBonusCancelByUserCommand)
				.build();

		ResultOKResp actualBonusCancelByUserCommandResponse =  BaseRequest.post(requestBonusCancelByUserCommand, GamingBonusEndpoints.bonusCancelByUserCommandSuccess);

		ResultOKResp expectedBonusCancelByUserCommandResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForBonusCancelByUserCommand)
				.build();

		assertReflectionEquals(expectedBonusCancelByUserCommandResponse, actualBonusCancelByUserCommandResponse);	
	}

	@Test(description = "Make a request to manualBonusCreditAndClaimCommand. Unsupported bonus.")
	public void manualBonusCreditAndClaimCommand_UnsupportedBonus() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ManualBonusCreditAndClaimCommandReq request = new ManualBonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.MANUAL_BONUS_CREDIT_NEG.getUserId())
				.productId(1)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.manualBonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Unsupported bonus implementation")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to manualBonusCreditAndClaimCommand. Missing user_id parameter.")
	public void manualBonusCreditAndClaimCommand_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ManualBonusCreditAndClaimCommandReq request = new ManualBonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.manualBonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to manualBonusCreditAndClaimCommand. Missing product_id parameter.")
	public void manualBonusCreditAndClaimCommand_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ManualBonusCreditAndClaimCommandReq request = new ManualBonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.MANUAL_BONUS_CREDIT_NEG.getUserId())
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.manualBonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to manualBonusCreditAndClaimCommand. Missing amount parameter.")
	public void manualBonusCreditAndClaimCommand_MissingAmount_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ManualBonusCreditAndClaimCommandReq request = new ManualBonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.MANUAL_BONUS_CREDIT_NEG.getUserId())
				.amount(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.manualBonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: amount")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to manualBonusCreditAndClaimCommand. Missing bonustemplate_id parameter.")
	public void manualBonusCreditAndClaimCommand_MissingBonusTemplateId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ManualBonusCreditAndClaimCommandReq request = new ManualBonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.MANUAL_BONUS_CREDIT_NEG.getUserId())
				.bonusTemplateId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.manualBonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1001)
				.message("Could not retrieve DepositBonus - doesn't exist")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to manualBonusCreditAndClaimCommand. Missing admin parameter.")
	public void manualBonusCreditAndClaimCommand_MissingBonusAdmin_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ManualBonusCreditAndClaimCommandReq request = new ManualBonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.MANUAL_BONUS_CREDIT_NEG.getUserId())
				.admin(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.manualBonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: admin")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}


	@Test(description = "Make a request to manualBonusCreditAndClaimCommand. Wrong method.")
	public void manualBonusCreditAndClaimCommand_Wrong_Method() {

		ManualBonusCreditAndClaimCommandReq request = new ManualBonusCreditAndClaimCommandReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.manualBonusCreditAndClaimCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}
