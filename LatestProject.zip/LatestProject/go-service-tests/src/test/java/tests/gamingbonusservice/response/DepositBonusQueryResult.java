package tests.gamingbonusservice.response;

public class DepositBonusQueryResult {	
	
	public String title, description, button_text, footer_text, terms_conditions_link_text, terms_conditions_link_token, offer_code;
	public Integer max_amount, bonus_percentage, bonus_id, bonus_implementation, min_amount;
	
	public DepositBonusQueryResult() {
	}
	
	private DepositBonusQueryResult(Builder builder) {
		
		this.title = builder.title;
		this.description = builder.description;
		this.button_text = builder.button_text;
		this.footer_text = builder.footer_text;
		this.terms_conditions_link_text = builder.terms_conditions_link_text;
		this.terms_conditions_link_token = builder.terms_conditions_link_token;
		this.offer_code = builder.offer_code;
		this.max_amount = builder.max_amount;
		this.min_amount = builder.min_amount;
		this.bonus_percentage = builder.bonus_percentage;
		this.bonus_id = builder.bonus_id;
		this.bonus_implementation = builder.bonus_implementation;
	}

	public static class Builder {
		private String title, description, button_text, footer_text, terms_conditions_link_text, terms_conditions_link_token, offer_code;
		private Integer max_amount, bonus_percentage, bonus_id, bonus_implementation, min_amount;
		
		public Builder title(String title) {
			this.title = title;
			return this;
		}
		
		public Builder bonusId(Integer bonus_id) {
			this.bonus_id = bonus_id;
			return this;
		}
		
		public Builder description(String description) {
			this.description = description;
			return this;
		}
		
		public Builder buttonText(String button_text) {
			this.button_text = button_text;
			return this;
		}
		
		public Builder footerText(String footer_text) {
			this.footer_text = footer_text;
			return this;
		}
		
		public Builder termsConditionsLinkText(String terms_conditions_link_text) {
			this.terms_conditions_link_text = terms_conditions_link_text;
			return this;
		}
		
		public Builder termsConditionsLinkToken(String terms_conditions_link_token) {
			this.terms_conditions_link_token = terms_conditions_link_token;
			return this;
		}
		
		public Builder offerCode(String offer_code) {
			this.offer_code = offer_code;
			return this;
		}
		
		public Builder maxAmount(Integer max_amount) {
			this.max_amount = max_amount;
			return this;
		}
		
		public Builder minAmount(Integer min_amount) {
			this.min_amount = min_amount;
			return this;
		}
		
		public Builder bonusPercentage(Integer bonus_percentage) {
			this.bonus_percentage = bonus_percentage;
			return this;
		}
		
		public Builder defaults() {
			this.title = "NPB Deposit Bonus";
			this.description = "This is a Casino NPB bonus";
			this.button_text = "Claim {Amount} from a GBT bonus";
			this.footer_text = "Footer text";
			this.terms_conditions_link_text = "T&C Link";
			this.terms_conditions_link_token = "live-roulette-challenges";
			this.offer_code = "";
			this.max_amount = 100;
			this.bonus_percentage = 100;
			this.bonus_id = 1714;
			this.bonus_implementation = 2;
			this.min_amount = 10;
			
			return this;
		}

		public DepositBonusQueryResult build() {
			return new DepositBonusQueryResult(this);
		}
	}
}
