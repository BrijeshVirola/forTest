package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.testng.Reporter;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.BaseURI;
import common.CustomErrorResponse;
import common.DatabaseQueries;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.request.SpecificBonusRedeemByAdminCommandReq;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.enums.GamingBonusServiceUsers;
import tests.gamingbonusservice.request.AddCreditedUserReq;
import tests.gamingbonusservice.request.BonusClaimCommandReq;

public class AddCreditedUserTests extends BaseClassSetup {

	@Test(description = "Credit, claim and redeem bonus. Golden chips are credited to the user.")
	public void creditRedeemGoldenChipsAwarderded() throws Exception {

		String id = UUID.randomUUID().toString();
		int userId = GamingBonusServiceUsers.ADD_CREDITED_USER_POS2.getUserId();
		int bonusTemplateId = 1605;
		int subsequentBonusTemplateId = 31651;
		Integer lastUserbonus_id =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		int newUserbonus_id;
		BigDecimal gbpValue = new BigDecimal("1.00");
		int quantity = 2;

		Reporter.log("Precondition: Remove user from the promotion id for the subsequent bonus of golden chips" + subsequentBonusTemplateId);
		DatabaseQueries.removeUserFromPromotionById(userId, subsequentBonusTemplateId);

		Reporter.log("01. Credit the user using addCreditedUser");
		AddCreditedUserReq addCreditedUserReq = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(userId)
				.bonusTemplateId(bonusTemplateId)
				.amount(10d)
				.id(id)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(addCreditedUserReq, GamingBonusEndpoints.addCreditedUserSuccess);
		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

		newUserbonus_id =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		Reporter.log("02. Check that new user bonus id " + newUserbonus_id 
				+ " is different then previous " + lastUserbonus_id);
		if (lastUserbonus_id == newUserbonus_id) {
			throw new Exception("User is not credited with new bonus.");
		}

		Reporter.log("03. Claim the bonus using bonusClaimCommand");
		BonusClaimCommandReq requestBonusClaimCommand = new BonusClaimCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(newUserbonus_id)
				.id(id)
				.build();

		actualResponse =  BaseRequest.post(requestBonusClaimCommand, GamingBonusEndpoints.bonusClaimCommandSuccess);
		expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		Reporter.log("04. Redeem the bonus using getusersforbonusactionscommand");
		SpecificBonusRedeemByAdminCommandReq specificBonusRedeemByAdminCommandReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(newUserbonus_id)
				.build();

		ResultOKResp actRedeemResp =  BaseRequest.post(specificBonusRedeemByAdminCommandReq, 
				GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandSuccess, BaseURI.GAMING_BONUS_ADMIN_SERVICE);
		ResultOKResp expRedeemResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expRedeemResp, actRedeemResp);

		Reporter.log("05. Verify last golden chip promotion history that the golden chip promotion is actually awarded.");
		TimeUnit.SECONDS.sleep(5);
		Utils.verifyLastGoldenChipPromotionHistory(userId, gbpValue, quantity);
	}

	@Test(description = "Credit, claim and redeem bonus. Golden chips are credited to the user.")
	public void creditClaimRedeemGoldenChipsAwarderded() throws Exception {

		String id = UUID.randomUUID().toString();
		int userId = GamingBonusServiceUsers.ADD_CREDITED_USER_POS3.getUserId();
		int bonusTemplateId = 1605;
		int subsequentBonusTemplateId = 31651;
		Integer lastUserbonus_id =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		int newUserbonus_id;
		BigDecimal gbpValue = new BigDecimal("1.00");
		int quantity = 2;

		Reporter.log("Precondition: Remove user from the promotion id for the subsequent bonus of golden chips" + subsequentBonusTemplateId);
		DatabaseQueries.removeUserFromPromotionById(userId, subsequentBonusTemplateId);

		Reporter.log("01. Credit the user using addCreditedUser");
		AddCreditedUserReq addCreditedUserReq = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(userId)
				.bonusTemplateId(bonusTemplateId)
				.amount(10d)
				.id(id)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(addCreditedUserReq, GamingBonusEndpoints.addCreditedUserSuccess);
		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

		newUserbonus_id =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		Reporter.log("02. Check that new user bonus id " + newUserbonus_id 
				+ " is different then previous " + lastUserbonus_id);
		if (newUserbonus_id == lastUserbonus_id) {
			throw new Exception("User is not credited with new bonus.");
		}

		Reporter.log("03. Claim the bonus using bonusClaimCommand");
		BonusClaimCommandReq requestBonusClaimCommand = new BonusClaimCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(newUserbonus_id)
				.id(id)
				.build();

		actualResponse =  BaseRequest.post(requestBonusClaimCommand, GamingBonusEndpoints.bonusClaimCommandSuccess);
		expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		Reporter.log("04. Redeem the bonus using getusersforbonusactionscommand");
		SpecificBonusRedeemByAdminCommandReq specificBonusRedeemByAdminCommandReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(newUserbonus_id)
				.build();

		ResultOKResp actRedeemResp =  BaseRequest.post(specificBonusRedeemByAdminCommandReq, 
				GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandSuccess, BaseURI.GAMING_BONUS_ADMIN_SERVICE);
		ResultOKResp expRedeemResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expRedeemResp, actRedeemResp);

		Reporter.log("05. Verify last golden chip promotion history that the golden chip promotion is actually awarded.");
		TimeUnit.SECONDS.sleep(5);
		Utils.verifyLastGoldenChipPromotionHistory(userId, gbpValue, quantity);
	}

	@Test(description = "Credid and redeem bonus. Free spins are credited to the user.")
	public void creditRedeemFreeSpinsAwarderded() throws Exception {

		String id = UUID.randomUUID().toString();
		int userId = GamingBonusServiceUsers.ADD_CREDITED_USER_POS4.getUserId();
		int bonusTemplateId = 1600;
		int subsequentBonusTemplateId = 31647;
		Integer lastUserbonus_id =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		int newUserbonus_id;
		int remainingSpins = 2;
		int awarderSpins = 2;

		Reporter.log("Precondition: Remove user from the promotion id for the subsequent bonus of free spins" + subsequentBonusTemplateId);
		DatabaseQueries.removeUserFromPromotionById(userId, subsequentBonusTemplateId);

		Reporter.log("01. Credit the user using addCreditedUser");
		AddCreditedUserReq addCreditedUserReq = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(userId)
				.bonusTemplateId(bonusTemplateId)
				.amount(10d)
				.id(id)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(addCreditedUserReq, GamingBonusEndpoints.addCreditedUserSuccess);
		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

		newUserbonus_id =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		Reporter.log("02. Check that new user bonus id " + newUserbonus_id 
				+ " is different then previous " + lastUserbonus_id);
		if (newUserbonus_id == lastUserbonus_id) {
			throw new Exception("User is not credited with new bonus.");
		}

		Reporter.log("03. Redeem the bonus using getusersforbonusactionscommand");
		SpecificBonusRedeemByAdminCommandReq specificBonusRedeemByAdminCommandReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(newUserbonus_id)
				.build();

		ResultOKResp actRedeemResp =  BaseRequest.post(specificBonusRedeemByAdminCommandReq, 
				GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandSuccess, BaseURI.GAMING_BONUS_ADMIN_SERVICE);
		ResultOKResp expRedeemResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expRedeemResp, actRedeemResp);

		Reporter.log("04. Verify last free spin promotion history that the free spins promotion is actually awarded.");
		TimeUnit.SECONDS.sleep(5);
		Utils.verifyLastFreeSpinPromotionHistory(userId, remainingSpins, awarderSpins);
	}

	@Test(description = "Credit, claim and redeem bonus. Free spins are credited to the user.")
	public void creditClaimRedeemFreeSpinsAwarderded() throws Exception {

		String id = UUID.randomUUID().toString();
		int userId = GamingBonusServiceUsers.ADD_CREDITED_USER_POS5.getUserId();
		int bonusTemplateId = 1600;
		int subsequentBonusTemplateId = 31647;
		Integer lastUserbonus_id =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		int newUserbonus_id;
		int remainingSpins = 2;
		int awarderSpins = 2;

		Reporter.log("Precondition: Remove user from the promotion id for the subsequent bonus of free spins" + subsequentBonusTemplateId);
		DatabaseQueries.removeUserFromPromotionById(userId, subsequentBonusTemplateId);

		Reporter.log("01. Credit the user using addCreditedUser");
		AddCreditedUserReq addCreditedUserReq = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(userId)
				.bonusTemplateId(bonusTemplateId)
				.amount(10d)
				.id(id)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(addCreditedUserReq, GamingBonusEndpoints.addCreditedUserSuccess);
		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

		newUserbonus_id =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		Reporter.log("02. Check that new user bonus id " + newUserbonus_id 
				+ " is different then previous " + lastUserbonus_id);
		if (newUserbonus_id == lastUserbonus_id) {
			throw new Exception("User is not credited with new bonus.");
		}

		Reporter.log("03. Claim the bonus using bonusClaimCommand");
		BonusClaimCommandReq requestBonusClaimCommand = new BonusClaimCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(newUserbonus_id)
				.id(id)
				.build();

		actualResponse =  BaseRequest.post(requestBonusClaimCommand, GamingBonusEndpoints.bonusClaimCommandSuccess);
		expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		Reporter.log("04. Redeem the bonus using getusersforbonusactionscommand");
		SpecificBonusRedeemByAdminCommandReq specificBonusRedeemByAdminCommandReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(newUserbonus_id)
				.build();

		ResultOKResp actRedeemResp =  BaseRequest.post(specificBonusRedeemByAdminCommandReq, 
				GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandSuccess, BaseURI.GAMING_BONUS_ADMIN_SERVICE);
		ResultOKResp expRedeemResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expRedeemResp, actRedeemResp);

		Reporter.log("05. Verify last free spin promotion history that the free spins promotion is actually awarded.");
		TimeUnit.SECONDS.sleep(5);
		Utils.verifyLastFreeSpinPromotionHistory(userId, remainingSpins, awarderSpins);
	}


	@Test(description = "Make a request to AddCreditedUser. Positive scenario.")
	public void addCreditedUser_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.ADD_CREDITED_USER_POS1.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.addCreditedUserSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to addCreditedUser. Unknown user_id parameter.")
	public void addCreditedUser_UnknownUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(999999999)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.addCreditedUserError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Could not retrieve UserData")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to addCreditedUser. Missing user_id parameter.")
	public void addCreditedUser_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.addCreditedUserError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to addCreditedUser. Missing bonustemplate_id parameter.")
	public void addCreditedUser_MissingBonusTemplateId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.ADD_CREDITED_USER_NEG.getUserId())
				.bonusTemplateId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.addCreditedUserError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: bonustemplate_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to addCreditedUser. Missing amount parameter.")
	public void addCreditedUser_MissingAmount_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.ADD_CREDITED_USER_NEG.getUserId())
				.amount(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.addCreditedUserError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: amount")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to addCreditedUser. Missing creditedby parameter.")
	public void addCreditedUser_MissingCreditedBy_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.ADD_CREDITED_USER_NEG.getUserId())
				.creditedBy(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.addCreditedUserError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: creditedby")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to addCreditedUser. bonus template does not support users country parameter.")
	public void addCreditedUser_CountryBonusemplateMismatch_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.ADD_CREDITED_USER_NEG.getUserId())
				.bonusTemplateId(124)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.addCreditedUserError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("The user's country is not supported for this bonus template")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to addCreditedUser. Wrong method.")
	public void addCreditedUser_Wrong_Method() {

		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.addCreditedUserError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}