package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.request.BonusTypeQueryReq;
import tests.gamingbonusservice.response.BonusType;
import tests.gamingbonusservice.response.BonusTypeQueryResp;

public class BonusTypeQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to BonusTypeQueryCommand. Positive scenario.")
	public void bonusTypeQueryCommand_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusTypeQueryReq request = new BonusTypeQueryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		BonusType bonusType1 = new BonusType.Builder()
				.bonusName("Cash")
				.bonusTypeId(3)
				.build();

		BonusType bonusType2 = new BonusType.Builder()
				.bonusName("After-Wager")
				.bonusTypeId(4)
				.build();

		BonusType bonusType3 = new BonusType.Builder()
				.bonusName("Pre-Wager")
				.bonusTypeId(5)
				.build();

		BonusTypeQueryResp expectedResponse = new BonusTypeQueryResp.Builder()
				.defaults()
				.addResult(bonusType1)
				.addResult(bonusType2)
				.addResult(bonusType3)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		BonusTypeQueryResp actualResponse = BaseRequest.post(request, GamingBonusEndpoints.bonusTypeQuerySuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusTypeQueryCommand. Wrong method.")
	public void bonusTypeQueryCommand_Wrong_Method() {

		BonusTypeQueryReq request = new BonusTypeQueryReq.Builder().defaults().id(null).method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, GamingBonusEndpoints.bonusTypeQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder().code(6)
				.message("Incorrect method in request").id(null).build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}