package tests.gamingbonusservice.response;

import java.util.List;

public class ActiveBonusResult {	
	
	public Integer bonustemplate_id, bonustype_id, userbonus_id, amount_pence, ringfencedamount_pence, progressamount_pence, completion_percentage, userbonusstatus_id, minimumtransaction, maximumbonus;
	public Integer priority, rolloverrequirement_pence, wageringamount_pence, subsequentbonusamount_pence, subsequentbonustype, bonusproduct_id;
	public String bonustype, expiry, currency, statusname, templatename, rolloverrequirement, createdby, dateadded;
	public Boolean is_claimed, is_expired, is_redeemed, notinterested, depositmatched, moregamesavailable, gameinpromotion, acknowledged, rewardcash, requireacceptance;;
	public List<EligibleGame> eligiblegames= new java.util.ArrayList<>();

	public ActiveBonusResult() {
	}
	
	private ActiveBonusResult(Builder builder) {
		
		this.bonustemplate_id = builder.bonustemplate_id;
		this.bonustype_id = builder.bonustype_id;
		this.userbonus_id = builder.userbonus_id;
		this.amount_pence = builder.amount_pence;
		this.ringfencedamount_pence = builder.ringfencedamount_pence;
		this.progressamount_pence = builder.progressamount_pence;
		this.completion_percentage = builder.completion_percentage;
		this.userbonusstatus_id = builder.userbonusstatus_id;
		this.minimumtransaction = builder.minimumtransaction;
		this.maximumbonus = builder.maximumbonus;
		
		this.bonustype = builder.bonustype;
		this.expiry = builder.expiry;
		this.currency = builder.currency;
		this.statusname = builder.statusname;
		this.templatename = builder.templatename;
		this.rolloverrequirement = builder.rolloverrequirement;
		this.createdby = builder.createdby;
		this.dateadded = builder.dateadded;
		
		this.is_claimed = builder.is_claimed;
		this.is_expired = builder.is_expired;
		this.is_redeemed = builder.is_redeemed;
		this.notinterested = builder.notinterested;
		this.depositmatched = builder.depositmatched;
		this.priority = builder.priority;
		this.moregamesavailable = builder.moregamesavailable;
		this.gameinpromotion = builder.gameinpromotion;
		this.rolloverrequirement_pence = builder.rolloverrequirement_pence;
		this.wageringamount_pence = builder.wageringamount_pence;
		this.dateadded = builder.dateadded;
		this.acknowledged = builder.acknowledged;
		this.rewardcash = builder.rewardcash;
		this.eligiblegames = builder.eligiblegames;
		this.subsequentbonusamount_pence = builder.subsequentbonusamount_pence;
		this.subsequentbonustype = builder.subsequentbonustype;
		this.bonusproduct_id = builder.bonusproduct_id;
	}

	public static class Builder {
		private Integer bonustemplate_id, bonustype_id, userbonus_id, amount_pence, ringfencedamount_pence, progressamount_pence, completion_percentage, userbonusstatus_id, minimumtransaction, maximumbonus;
		private Integer priority, rolloverrequirement_pence, wageringamount_pence, subsequentbonusamount_pence, subsequentbonustype, bonusproduct_id;
		private String bonustype, expiry, currency, statusname, templatename, rolloverrequirement, createdby, dateadded;
		private Boolean is_claimed, is_expired, is_redeemed, notinterested, depositmatched, moregamesavailable, gameinpromotion, acknowledged, rewardcash;
		private List<EligibleGame> eligiblegames= new java.util.ArrayList<>();
		
		public Builder bonusTemplateId(Integer bonustemplate_id) {
			this.bonustemplate_id = bonustemplate_id;
			return this;
		}
		
		public Builder bonusTypeId(Integer bonustype_id) {
			this.bonustype_id = bonustype_id;
			return this;
		}
		
		public Builder bonusproductId(Integer bonusproduct_id) {
			this.bonusproduct_id = bonusproduct_id;
			return this;
		}
		
		public Builder userBonusId(Integer userbonus_id) {
			this.userbonus_id = userbonus_id;
			return this;
		}
		
		public Builder amountPence(Integer amount_pence) {
			this.amount_pence = amount_pence;
			return this;
		}
		
		public Builder ringFencedAmountPence(Integer ringfencedamount_pence) {
			this.ringfencedamount_pence = ringfencedamount_pence;
			return this;
		}
		
		public Builder progressAmountPence(Integer progressamount_pence) {
			this.progressamount_pence = progressamount_pence;
			return this;
		}
		
		public Builder completionPercentage(Integer completion_percentage) {
			this.completion_percentage = completion_percentage;
			return this;
		}
		
		public Builder userBonusStatusId(Integer userbonusstatus_id) {
			this.userbonusstatus_id = userbonusstatus_id;
			return this;
		}
		
		public Builder minimumTransaction(Integer minimumtransaction) {
			this.minimumtransaction = minimumtransaction;
			return this;
		}
		
		public Builder maximumBonus(Integer maximumbonus) {
			this.maximumbonus = maximumbonus;
			return this;
		}
		
		public Builder priority(Integer priority) {
			this.priority = priority;
			return this;
		}
		
		public Builder rolloverRequirementPence(Integer rolloverrequirement_pence) {
			this.rolloverrequirement_pence = rolloverrequirement_pence;
			return this;
		}
		
		public Builder wageringAmountPence(Integer wageringamount_pence) {
			this.wageringamount_pence = wageringamount_pence;
			return this;
		}
		
		public Builder subsequentBonusAmountPence(Integer subsequentbonusamount_pence) {
			this.subsequentbonusamount_pence = subsequentbonusamount_pence;
			return this;
		}
		
		public Builder addEligibleGame(EligibleGame eligibleGame) {
			this.eligiblegames.add(eligibleGame);
			return this;
		}
		
		public Builder bonusType(String bonustype) {
			this.bonustype = bonustype;
			return this;
		}
		
		public Builder expiry(String expiry) {
			this.expiry = expiry;
			return this;
		}
		
		public Builder currency(String currency) {
			this.currency = currency;
			return this;
		}
		
		public Builder statusName(String statusname) {
			this.statusname = statusname;
			return this;
		}
		
		public Builder templateName(String templatename) {
			this.templatename = templatename;
			return this;
		}
		
		public Builder rolloverRequirement(String rolloverrequirement) {
			this.rolloverrequirement = rolloverrequirement;
			return this;
		}
		
		public Builder createdBy(String createdby) {
			this.createdby = createdby;
			return this;
		}
		
		public Builder dateAdded(String dateadded) {
			this.dateadded = dateadded;
			return this;
		}
		
		public Builder isClaimed(Boolean is_claimed) {
			this.is_claimed = is_claimed;
			return this;
		}
		
		public Builder isExpired(Boolean is_expired) {
			this.is_expired = is_expired;
			return this;
		}
		
		public Builder isRedeemed(Boolean is_redeemed) {
			this.is_redeemed = is_redeemed;
			return this;
		}
		
		public Builder notInterested(Boolean notinterested) {
			this.notinterested = notinterested;
			return this;
		}
		
		public Builder depositMatched(Boolean depositmatched) {
			this.depositmatched = depositmatched;
			return this;
		}
		
		public Builder moreGamesAvailable(Boolean moregamesavailable) {
			this.moregamesavailable = moregamesavailable;
			return this;
		}
		
		public Builder gameInPromotion(Boolean gameinpromotion) {
			this.gameinpromotion = gameinpromotion;
			return this;
		}
		
		public Builder acknowledged(Boolean acknowledged) {
			this.acknowledged = acknowledged;
			return this;
		}
		
		public Builder rewardCash(Boolean rewardcash) {
			this.rewardcash = rewardcash;
			return this;
		}
		
		public Builder defaults() {
			this.priority = 0;
			this.moregamesavailable = false;
			this.gameinpromotion = false;
			this.depositmatched = false;
			this.rolloverrequirement_pence = 0;
			this.wageringamount_pence = 0;
			this.acknowledged = false;
			this.rewardcash = false;
			this.eligiblegames = new java.util.ArrayList<>();
			this.subsequentbonusamount_pence = 0;
			this.subsequentbonustype = 0;
	         
			this.bonustemplate_id = 305;
			this.bonustype_id = 3;
			this.userbonus_id = null;
			this.amount_pence = 1;
			this.ringfencedamount_pence = 0;
			this.progressamount_pence = 0;
			this.completion_percentage = 0;
			this.userbonusstatus_id = 10;
			this.minimumtransaction = 0;
			this.maximumbonus = 100;
			
			this.bonustype = null;
			this.expiry = "0001-01-01T00:00:00Z";
			this.currency = "GBP";
			this.statusname = null;
			this.templatename = "PnnTestCash";
			this.rolloverrequirement = "0";
			this.createdby = null;
			this.dateadded = null;
			
			this.is_claimed = true;
			this.is_expired = false;
			this.is_redeemed = true;
			this.notinterested = false;
			this.depositmatched = false;
			this.bonusproduct_id = 2;
			
			return this;
		}

		public ActiveBonusResult build() {
			return new ActiveBonusResult(this);
		}
	}
}
