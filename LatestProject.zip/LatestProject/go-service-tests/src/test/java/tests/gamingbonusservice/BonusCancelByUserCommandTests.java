package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.enums.GamingBonusServiceUsers;
import tests.gamingbonusservice.request.BonusCancelByUserCommandReq;
import tests.gamingbonusservice.response.BonusResult;

public class BonusCancelByUserCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to BonusCancelByUserCommand. Positive scenario.")
	public void bonusCancelByUserCommand_Positive_Scenario() throws InterruptedException {

		Integer testUserId = GamingBonusServiceUsers.BONUS_CANCEL_BY_USER_POS1.getUserId();
		Integer productId = 4;
		Double amount = 0.01;

		BonusResult expectedBonusResult = new BonusResult.Builder()
				.defaults()
				.build();

		BonusResult actualNewlyCreatedUserBonus = Utils.createBonusAndVerifyThenReturnBonusDetails(testUserId, expectedBonusResult.bonustemplate_id, productId, expectedBonusResult, amount);

		String idForBonusCancelByUserCommand = UUID.randomUUID().toString();

		BonusCancelByUserCommandReq requestBonusCancelByUserCommand = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userId(testUserId)
				.userBonusId(actualNewlyCreatedUserBonus.userbonus_id)
				.id(idForBonusCancelByUserCommand)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(requestBonusCancelByUserCommand, GamingBonusEndpoints.bonusCancelByUserCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForBonusCancelByUserCommand)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		BonusResult actualUpdatedBonus = Utils.getBonusByDateAdded(testUserId, actualNewlyCreatedUserBonus.dateadded);

		BonusResult expectedUpdatedBonus = actualNewlyCreatedUserBonus;
		expectedUpdatedBonus.is_cancellable = false;
		expectedUpdatedBonus.statusname = "CancelledByWithdrawal";
		expectedUpdatedBonus.userbonusstatus_id = 9;

		assertReflectionEquals(expectedUpdatedBonus, actualUpdatedBonus);


	}

	@Test(description = "Make a request to bonusCancelByUserCommand. Missing user_id parameter.")
	public void bonusCancelByUserCommand_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusCancelByUserCommandReq request = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCancelByUserCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusCancelByUserCommand. Missing userbonus_id parameter.")
	public void bonusCancelByUserCommand_MissingUserBonusId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusCancelByUserCommandReq request = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.BONUS_CANCEL_BY_USER_NEG.getUserId())
				.userBonusId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCancelByUserCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: userbonus_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusCancelByUserCommand. Missing sportsProduct_id parameter.")
	public void bonusCancelByUserCommand_MissingSportsProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusCancelByUserCommandReq request = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.BONUS_CANCEL_BY_USER_NEG.getUserId())
				.sportsProductId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCancelByUserCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Bonus not cancelled")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusCancelByUserCommand. Missing isCancelledByWithdrawal parameter.")
	public void bonusCancelByUserCommand_MissingIsCancelledByWithdrawal_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusCancelByUserCommandReq request = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.BONUS_CANCEL_BY_USER_NEG.getUserId())
				.isCancelledByWithdrawal(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCancelByUserCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Bonus not cancelled")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusCancelByUserCommand. Unknown bonus.")
	public void bonusCancelByUserCommand_UnknownBonus() {

		Integer unknownUserBonusId = 99999;
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusCancelByUserCommandReq request = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userBonusId(unknownUserBonusId)
				.userId(GamingBonusServiceUsers.BONUS_CANCEL_BY_USER_NEG2.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCancelByUserCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Bonus not cancelled, bonus does not exist")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusCancelByUserCommand. Missing bonus_implementation parameter.")
	public void bonusCancelByUserCommand_MissingBonus_implementation_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusCancelByUserCommandReq request = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.BONUS_CANCEL_BY_USER_NEG.getUserId())
				.bonusImplementation(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCancelByUserCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Unsupported bonus implementation")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusCancelByUserCommand. Wrong method.")
	public void bonusCancelByUserCommand_Wrong_Method() {

		BonusCancelByUserCommandReq request = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusCancelByUserCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	
}
