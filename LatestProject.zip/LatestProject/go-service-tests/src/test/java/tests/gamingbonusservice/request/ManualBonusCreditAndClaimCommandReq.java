package tests.gamingbonusservice.request;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class ManualBonusCreditAndClaimCommandReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private ManualBonusCreditAndClaimCommandReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("bonustemplate_id", builder.bonustemplate_id);
		this.params.put("amount", builder.amount);
		this.params.put("product_id", builder.product_id);
		this.params.put("admin", builder.admin);
		this.params.put("transaction_date", builder.transaction_date);
	}

	public static class Builder {
		private String method, id, admin, transaction_date; //transaction_date is optional
		private Integer user_id, bonustemplate_id, amount, product_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder amount(Integer amount) {
			this.amount = amount;
			return this;
		}
		
		public Builder bonusTemplateId(Integer bonustemplate_id) {
			this.bonustemplate_id = bonustemplate_id;
			return this;
		}
		
		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}
		
		public Builder admin(String admin) {
			this.admin = admin;
			return this;
		}
		
		public Builder transactionDate(String transaction_date) {
			this.transaction_date = transaction_date;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "manualbonuscreditandclaimcommand";
			transaction_date = Instant.now().toString();
			this.amount = 10;
			this.product_id = 4;
			this.bonustemplate_id = 137;
			this.admin = "api automation test gaming bonus service";
			return this;
		}

		public ManualBonusCreditAndClaimCommandReq build() {
			return new ManualBonusCreditAndClaimCommandReq(this);
		}
	}
}
