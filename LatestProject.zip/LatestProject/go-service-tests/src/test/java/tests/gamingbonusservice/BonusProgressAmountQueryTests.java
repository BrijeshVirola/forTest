package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.enums.GamingBonusServiceUsers;
import tests.gamingbonusservice.request.BonusProgressAmountQueryReq;
import tests.gamingbonusservice.response.BonusProgressAmountQueryResp;
import tests.gamingbonusservice.response.BonusProgressAmountQueryResult;

public class BonusProgressAmountQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to BonusProgressAmountQuery. Positive scenario.")
	public void bonusProgressAmountQuery_Positive_Scenario() throws InterruptedException {

		String idForBonusProgressAmountQuery = UUID.randomUUID().toString();

		BonusProgressAmountQueryReq requestBonusProgressAmountQuery = new BonusProgressAmountQueryReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.BONUS_PROG_AMOUNT_POS1.getUserId())
				.id(idForBonusProgressAmountQuery)
				.build();

		BonusProgressAmountQueryResp actualResponse =  BaseRequest.post(requestBonusProgressAmountQuery, GamingBonusEndpoints.bonusProgressAmountQuerySuccess);

		BonusProgressAmountQueryResult bonusProgressAmountQueryResult = new BonusProgressAmountQueryResult.Builder()
				.defaults()
				.build();

		BonusProgressAmountQueryResp expectedResponse = new BonusProgressAmountQueryResp.Builder()
				.defaults()
				.addResult(bonusProgressAmountQueryResult)
				.id(idForBonusProgressAmountQuery)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to bonusProgressAmountQuery. Missing user_id parameter.")
	public void bonusProgressAmountQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusProgressAmountQueryReq request = new BonusProgressAmountQueryReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusProgressAmountQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusProgressAmountQuery. Missing userbonus_id parameter.")
	public void bonusProgressAmountQuery_MissingUserBonusId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BonusProgressAmountQueryReq request = new BonusProgressAmountQueryReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.BONUS_PROG_AMOUNT_NEG.getUserId())
				.userBonusId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusProgressAmountQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: userbonus_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to bonusProgressAmountQuery. Wrong method.")
	public void bonusProgressAmountQuery_Wrong_Method() {

		BonusProgressAmountQueryReq request = new BonusProgressAmountQueryReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.bonusProgressAmountQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}

