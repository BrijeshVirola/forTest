package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.Reporter;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamingbonusservice.enums.GamingBonusEndpoints;
import tests.gamingbonusservice.enums.GamingBonusServiceUsers;
import tests.gamingbonusservice.request.DepositBonusQueryReq;
import tests.gamingbonusservice.response.DepositBonusQueryResp;
import tests.gamingbonusservice.response.DepositBonusQueryResult;

public class DepositBonusQueryTests extends BaseClassSetup {

	@Test(description = "Make a request to DepositBonusQuery. Positive scenario.")
	public void DepositBonusQuery_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.DEPOSIT_BONUS_QUERY_POS1.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		DepositBonusQueryResp actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQuerySuccess);

		DepositBonusQueryResult result = new DepositBonusQueryResult.Builder()
				.defaults()
				.maxAmount(50)
				.build();

		DepositBonusQueryResp expectedResponse = new DepositBonusQueryResp.Builder()
				.defaults()
				.addResult(result)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to DepositBonusQuery with visible promotion to UK and hidden to BG.")
	public void DepositBonusQuery_Hidden_Visible_Different_Regulations() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		Reporter.log("01. Make request to deposit bonus query with UK user"
				+ " for which the deposit promotion is not hidden");
		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.DEPOSIT_BONUS_QUERY_POS2.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		DepositBonusQueryResp actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQuerySuccess);

		DepositBonusQueryResult result = new DepositBonusQueryResult.Builder()
				.defaults()
				.title("NPB Deposit Bonus BG Test Ontario")
				.bonusId(1806)
				.maxAmount(100)
				.termsConditionsLinkToken("live-roulette-challenges-automation")
				.build();

		DepositBonusQueryResp expectedResponse = new DepositBonusQueryResp.Builder()
				.defaults()
				.addResult(result)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		Reporter.log("02. Make request to deposit bonus query with Bulgarian user"
				+ " for which the deposit promotion is hidden");
		request = new DepositBonusQueryReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.DEPOSIT_BONUS_QUERY_POS3.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQuerySuccess);

		result = new DepositBonusQueryResult.Builder()
				.build();

		expectedResponse = new DepositBonusQueryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to DepositBonusQuery. Unknown user_id parameter.")
	public void DepositBonusQuery_UnknownUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.userId(999999999)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Error received while fetching deposit bonus. Could not retrieve UserData")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to DepositBonusQuery. Missing user_id parameter.")
	public void DepositBonusQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to DepositBonusQuery. Missing sports_product_id parameter.")
	public void DepositBonusQuery_MissingSportsProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.userId(GamingBonusServiceUsers.DEPOSIT_BONUS_QUERY_NEG.getUserId())
				.sportsProductId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: sports_product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to DepositBonusQuery. Wrong method.")
	public void DepositBonusQuery_Wrong_Method() {

		DepositBonusQueryReq request = new DepositBonusQueryReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusEndpoints.depositBonusQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}