package tests.gamingbonusservice.response;

public class BonusProgressAmountQueryResult {	
	
	public Long transaction_id;
	public Double bonusprogressamountadded;
	public Integer bonusprogressamount;
	public String processedtime;
	
	public BonusProgressAmountQueryResult() {
	}
	
	private BonusProgressAmountQueryResult(Builder builder) {
		this.transaction_id = builder.transaction_id;
		this.bonusprogressamountadded = builder.bonusprogressamountadded;
		this.bonusprogressamount = builder.bonusprogressamount;
		this.processedtime = builder.processedtime;
	}

	public static class Builder {
		private Long transaction_id;
		private Double bonusprogressamountadded;
		private Integer bonusprogressamount;
		private String processedtime;

		public Builder transactionId(Long transaction_id) {
			this.transaction_id = transaction_id;
			return this;
		}
		
		public Builder bonusProgressAmountAdded(Double bonusprogressamountadded) {
			this.bonusprogressamountadded = bonusprogressamountadded;
			return this;
		}
		
		public Builder bonusProgressAmount(Integer bonusprogressamount) {
			this.bonusprogressamount = bonusprogressamount;
			return this;
		}
		
		public Builder processedTime(String processedtime) {
			this.processedtime = processedtime;
			return this;
		}
		
		public Builder defaults() {
			this.transaction_id = 2156054197L;
			this.bonusprogressamountadded = 10.00;
			this.bonusprogressamount = 0;
			this.processedtime = "2021-03-09T13:20:16Z";
			return this;
		}

		public BonusProgressAmountQueryResult build() {
			return new BonusProgressAmountQueryResult(this);
		}
	}
}
