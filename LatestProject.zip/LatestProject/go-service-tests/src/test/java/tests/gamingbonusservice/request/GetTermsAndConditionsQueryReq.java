package tests.gamingbonusservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetTermsAndConditionsQueryReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private GetTermsAndConditionsQueryReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("bonustemplate_id", builder.bonustemplate_id);
	}

	public static class Builder {
		private String method, id;
		private Integer user_id, bonustemplate_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder bonusTemplateId(Integer bonustemplate_id) {
			this.bonustemplate_id = bonustemplate_id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "gettermsandconditionsquery";
			this.bonustemplate_id = 132;
			return this;
		}

		public GetTermsAndConditionsQueryReq build() {
			return new GetTermsAndConditionsQueryReq(this);
		}
	}
}

