package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.greeceresponsiblegamblingservice.enums.GRRespGamblingServiceUsers;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.EndGameRoundSessionTimeDeductionReq;
import tests.greeceresponsiblegamblingservice.response.AllSessionTimeDeductionResp;
public class EndGameRoundSessionDeductionTests extends BaseClassSetup {

	//TODO: Temporary disable this test in order to use the rests of tests for a release.
	@Test(enabled = false, description = "Make a request to calculate the participation time since the game round started. Positive scenario.")
	public void endgameroundsessiontimededuction_Positive_Scenario() {

		String id = UUID.randomUUID().toString();
		EndGameRoundSessionTimeDeductionReq request = new EndGameRoundSessionTimeDeductionReq.Builder()
				.defaults()
				.id(id)
				.build();

		AllSessionTimeDeductionResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.endgameroundsessiontimedeductionSuccess);

		AllSessionTimeDeductionResp expectedResponse =  new AllSessionTimeDeductionResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to calculate the participation time since the game round started. Could not end game round session.")
	public void endgameroundsessiontimededuction_Couldnot_end_session() {

		String id = UUID.randomUUID().toString();
		EndGameRoundSessionTimeDeductionReq request = new EndGameRoundSessionTimeDeductionReq.Builder()
				.defaults()
				.id(id)
				.userId(GRRespGamblingServiceUsers.END_GAME_ROUND_POS1.getUserId())
				.build();

		AllSessionTimeDeductionResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.endgameroundsessiontimedeductionSuccess);

		AllSessionTimeDeductionResp expectedResponse =  new AllSessionTimeDeductionResp.Builder()
				.defaults()
				.breach(false)
				.breachCode(null)
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to calculate the participation time since the game round started. Missing parameter userID.")
	public void endgameroundsessiontimededuction_Missing_Parameter_user_id() {


		EndGameRoundSessionTimeDeductionReq request = new EndGameRoundSessionTimeDeductionReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.endgameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to calculate the participation time since the game round started. Missing parameter sessionID.")
	public void endgameroundsessiontimededuction_Missing_Parameter_session_id() {


		EndGameRoundSessionTimeDeductionReq request = new EndGameRoundSessionTimeDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.END_GAME_ROUND_NEG.getUserId())
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.endgameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: session_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to calculate the participation time since the game round started. Missing parameter sessionID.")
	public void endgameroundsessiontimededuction_Missing_Parameter_game_round_id() {


		EndGameRoundSessionTimeDeductionReq request = new EndGameRoundSessionTimeDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.END_GAME_ROUND_NEG.getUserId())
				.partnerGameRoundId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.endgameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_game_round_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to calculate the participation time since the game round started. Missing parameter sessionID.")
	public void endgameroundsessiontimededuction_Missing_Parameter_partner_id() {


		EndGameRoundSessionTimeDeductionReq request = new EndGameRoundSessionTimeDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.END_GAME_ROUND_NEG.getUserId())
				.partnerId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.endgameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to calculate the participation time since the game round started. Wrong method.")
	public void endgameroundsessiontimededuction_Wrong_Method() {

		EndGameRoundSessionTimeDeductionReq request = new EndGameRoundSessionTimeDeductionReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.endgameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
