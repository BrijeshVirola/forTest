package tests.greeceresponsiblegamblingservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetWithhodTaxesResp {

	private String id;
	private Map<String, Object> result = new HashMap<>();

	public GetWithhodTaxesResp() {
	}

	public Map<String, Object> getResult() {
		return result;
	}

	private GetWithhodTaxesResp(Builder builder) {
		this.id = builder.id;
		this.result.put("current_withheld_tax", builder.current_withheld_tax);
		this.result.put("poker_current_withheld_tax", builder.poker_current_withheld_tax);
		this.result.put("poker_tournaments_current_withheld_tax", builder.poker_tournaments_current_withheld_tax);
	}

	public String getId() {
		return id;
	}

	public static class Builder {
		private String id;
		private String current_withheld_tax;
		private String poker_current_withheld_tax;
		private String poker_tournaments_current_withheld_tax;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder currentWithHoldTax(String currentWithHoldTax) {
			this.current_withheld_tax = currentWithHoldTax;
			return this;
		}


		public Builder pokerCurrentWithheldTax(String pokerCurrentWithheldTax) {
			this.poker_current_withheld_tax = pokerCurrentWithheldTax;
			return this;
		}
		
		public Builder pokerTournamentscurrentWithheldTax(String pokerCurrentWithheldTax) {
			this.poker_tournaments_current_withheld_tax = pokerCurrentWithheldTax;
			return this;
		}

		public Builder defaults() {
			this.id = null;
			this.current_withheld_tax = "0";
			this.poker_current_withheld_tax = "0";
			this.poker_tournaments_current_withheld_tax = "0";
			return this;
		}

		public GetWithhodTaxesResp build() {
			return new GetWithhodTaxesResp(this);
		}	
	}
}
