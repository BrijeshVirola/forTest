package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.greeceresponsiblegamblingservice.enums.GRRespGamblingServiceUsers;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.UserHasZeroLimitSetReq;
import tests.greeceresponsiblegamblingservice.response.UserHasZeroLimitSetResp;
public class UserHasZeroLimitsetTests extends BaseClassSetup {

	@Test(description = "Make a request to set the user's loss limit to zero. Positive scenario.")
	public void userhaszerolimitset_Positive_Scenario() {

		UserHasZeroLimitSetReq request = new UserHasZeroLimitSetReq.Builder()
				.defaults()
				.userID(GRRespGamblingServiceUsers.USER_HAS_ZERO_LIMIT_POS1.getUserId())
				.build();

		UserHasZeroLimitSetResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.userHasZeroLimitSetSuccess);

		UserHasZeroLimitSetResp expectedResponse =  new UserHasZeroLimitSetResp.Builder()
				.defaults()
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to set the user's loss limit to zero. Missing parameter.")
	public void userhaszerolimitset_Missing_Parameter() {

		UserHasZeroLimitSetReq request = new UserHasZeroLimitSetReq.Builder()
				.defaults()
				.userID(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.userHasZeroLimitSetError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to set the user's loss limit to zero. Wrong method.")
	public void userhaszerolimitset_Wrong_Method() {

		UserHasZeroLimitSetReq request = new UserHasZeroLimitSetReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.userHasZeroLimitSetError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
