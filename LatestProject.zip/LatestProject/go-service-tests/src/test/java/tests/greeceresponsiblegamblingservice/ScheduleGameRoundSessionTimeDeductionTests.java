package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.greeceresponsiblegamblingservice.enums.GRRespGamblingServiceUsers;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.ScheduleGameRoundSessionDeductionReq;
import tests.greeceresponsiblegamblingservice.response.AllSessionTimeDeductionResp;
public class ScheduleGameRoundSessionTimeDeductionTests extends BaseClassSetup {

	//TODO: Implement stored procs to have user session before executing the test
	@Test(enabled=false, description = "Make a request to Schedule a delayed session time deduction after a fixed amount of time. Positive scenario.")
	public void schedulegameroundsessiontimededuction_Positive_Scenario() {

		ScheduleGameRoundSessionDeductionReq request = new ScheduleGameRoundSessionDeductionReq.Builder()
				.defaults()
				.build();

		AllSessionTimeDeductionResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulegameroundsessiontimedeductionSuccess);

		AllSessionTimeDeductionResp expectedResponse =  new AllSessionTimeDeductionResp.Builder()
				.defaults()
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to Schedule a delayed session time deduction after a fixed amount of time. Missing parameter.")
	public void schedulegameroundsessiontimededuction_Missing_Parameter() {

		ScheduleGameRoundSessionDeductionReq request = new ScheduleGameRoundSessionDeductionReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulegameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Schedule a delayed session time deduction after a fixed amount of time. Missing parameter.")
	public void schedulegameroundsessiontimededuction_Missing_Paramete_session_id() {

		ScheduleGameRoundSessionDeductionReq request = new ScheduleGameRoundSessionDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.SCHEDULE_GAME_ROUND_NEG.getUserId())
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulegameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: session_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Schedule a delayed session time deduction after a fixed amount of time. Missing parameter.")
	public void schedulegameroundsessiontimededuction_Missing_Paramete_partner_game_round_id() {

		ScheduleGameRoundSessionDeductionReq request = new ScheduleGameRoundSessionDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.SCHEDULE_GAME_ROUND_NEG.getUserId())
				.partnerGameRoundId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulegameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_game_round_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Schedule a delayed session time deduction after a fixed amount of time. Missing parameter.")
	public void schedulegameroundsessiontimededuction_Missing_Parameter_partner_id() {

		ScheduleGameRoundSessionDeductionReq request = new ScheduleGameRoundSessionDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.SCHEDULE_GAME_ROUND_NEG.getUserId())
				.partnerId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulegameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Schedule a delayed session time deduction after a fixed amount of time. Missing parameter.")
	public void schedulegameroundsessiontimededuction_Missing_Parameter_product_id() {

		ScheduleGameRoundSessionDeductionReq request = new ScheduleGameRoundSessionDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.SCHEDULE_GAME_ROUND_NEG.getUserId())
				.productId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulegameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Schedule a delayed session time deduction after a fixed amount of time. Missing parameter.")
	public void schedulegameroundsessiontimededuction_participation_duration() {

		ScheduleGameRoundSessionDeductionReq request = new ScheduleGameRoundSessionDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.SCHEDULE_GAME_ROUND_NEG.getUserId())
				.participantDuration(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulegameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: participation_duration")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Schedule a delayed session time deduction after a fixed amount of time. Missing parameter.")
	public void schedulegameroundsessiontimededuction_participation_datetime_utc() {

		ScheduleGameRoundSessionDeductionReq request = new ScheduleGameRoundSessionDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.SCHEDULE_GAME_ROUND_NEG.getUserId())
				.participationDateTime(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulegameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: participation_datetime_utc")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Schedule a delayed session time deduction after a fixed amount of time. Wrong method.")
	public void schedulegameroundsessiontimededuction_Wrong_Method() {

		ScheduleGameRoundSessionDeductionReq request = new ScheduleGameRoundSessionDeductionReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulegameroundsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
