package tests.greeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetWithHoldTaxesReq {

	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private GetWithHoldTaxesReq(Builder builder) {
		this.method = builder.method;
		this.params.put("session_id", builder.session_id);
	}

	public static class Builder {
		private String method;
		private String session_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder defaults() {
			this.method = "getwithholdtaxes";
			this.session_id = "251882F6CA7A49F6869F275327BB8CD2000004";
			return this;
		}

		public GetWithHoldTaxesReq build() {
			return new GetWithHoldTaxesReq(this);
		}
	}
}
