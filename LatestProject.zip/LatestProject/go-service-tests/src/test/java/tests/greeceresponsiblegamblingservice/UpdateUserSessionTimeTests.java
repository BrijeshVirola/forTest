package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.Utils;
import domain.BaseRequest;
import tests.greeceresponsiblegamblingservice.enums.GRRespGamblingServiceUsers;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.UpdateUserSessionTimeReq;
import tests.greeceresponsiblegamblingservice.response.AllSessionTimeDeductionResp;
public class UpdateUserSessionTimeTests extends BaseClassSetup {

	//update as the part of the https://jira/browse/PRJGREG-2744
	@Test(description = "Make a request to Update the buckets with the participation time. Positive scenario.")
	public void updateusersessiontime_Positive_Scenario() {

		String username = GRRespGamblingServiceUsers.UPDATE_USER_SESSION_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.UPDATE_USER_SESSION_POS1.getUserId())
				.sessionId(sessionId)
				.build();

		AllSessionTimeDeductionResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeSuccess);

		AllSessionTimeDeductionResp expectedResponse =  new AllSessionTimeDeductionResp.Builder()
				.defaults()
				.id(null)
				.breach(false)
				.breachCode(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to Update the buckets with the participation time. Missing parameter userID.")
	public void updateusersessiontime_Missing_Parameter_user_id() {


		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Update the buckets with the participation time. Missing parameter sessionID.")
	public void updateusersessiontime_Missing_Parameter_session_id() {


		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.UPDATE_USER_SESSION_NEG.getUserId())
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: session_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Update the buckets with the participation time.Missing parameter productId.")
	public void updateusersessiontime_Missing_Parameter_product_id() {


		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.UPDATE_USER_SESSION_NEG.getUserId())
				.productId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Update the buckets with the participation time. Missing parameter partcipantDuration defaults to 0 and record breach.")
	public void updateusersessiontime_Missing_Parameter_participation_duration() {

		String username = GRRespGamblingServiceUsers.UPDATE_USER_SESSION_POS2.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.UPDATE_USER_SESSION_POS2.getUserId())
				.sessionId(sessionId)
				.participantDuration(null)
				.build();

		AllSessionTimeDeductionResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeSuccess);

		AllSessionTimeDeductionResp expectedResponse = new AllSessionTimeDeductionResp.Builder()
				.defaults()
				.id(null)
				.breach(false)
				.breachCode(null)
				.build();						

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Update the buckets with the participation time.Missing parameter partcipantDateTime.")
	public void updateusersessiontime_Missing_Parameter_participation_dateTime() {

		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.UPDATE_USER_SESSION_NEG.getUserId())
				.participationDateTime(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: participation_datetime_utc")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Update the buckets with the participation time.Wrong method.")
	public void updateusersessiontime_Wrong_Method() {

		UpdateUserSessionTimeReq request = new UpdateUserSessionTimeReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateusersessiontimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
