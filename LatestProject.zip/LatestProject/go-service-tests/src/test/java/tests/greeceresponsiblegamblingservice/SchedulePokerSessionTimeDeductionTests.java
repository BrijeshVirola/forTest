package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.greeceresponsiblegamblingservice.enums.GRRespGamblingServiceUsers;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.SchedulePokerSessionTimeDeductionReq;
import tests.greeceresponsiblegamblingservice.response.AllSessionTimeDeductionResp;
public class SchedulePokerSessionTimeDeductionTests extends BaseClassSetup {

	//TODO: Temporary disable this test in order to use the rests of tests for a release.
	@Test(enabled = false, description = "Make a request to Schedule a delayed session time deduction after the remaining time to breach a limit. Positive scenario.")
	public void schedulepokersessiontimededuction_Positive_Scenario() {

		SchedulePokerSessionTimeDeductionReq request = new SchedulePokerSessionTimeDeductionReq.Builder()
				.defaults()
				.build();

		AllSessionTimeDeductionResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulePokerSessionTimeDeductionSuccess);

		AllSessionTimeDeductionResp expectedResponse =  new AllSessionTimeDeductionResp.Builder()
				.defaults()
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to Schedule a delayed session time deduction after the remaining time to breach a limit. Missing parameter userID.")
	public void schedulepokersessiontimededuction_Missing_Parameter_user_id() {


		SchedulePokerSessionTimeDeductionReq request = new SchedulePokerSessionTimeDeductionReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulePokerSessionTimeDeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Schedule a delayed session time deduction after the remaining time to breach a limit. Missing parameter sessionID.")
	public void schedulepokersessiontimededuction_Missing_Parameter_session_id() {


		SchedulePokerSessionTimeDeductionReq request = new SchedulePokerSessionTimeDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.SCHEDULE_POKER_SESSION_NEG.getUserId())
				.SessionId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulePokerSessionTimeDeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: session_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to Schedule a delayed session time deduction after the remaining time to breach a limit. Wrong method.")
	public void schedulepokersessiontimededuction_Wrong_Method() {

		SchedulePokerSessionTimeDeductionReq request = new SchedulePokerSessionTimeDeductionReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.schedulePokerSessionTimeDeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
