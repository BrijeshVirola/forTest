package tests.greeceresponsiblegamblingservice.enums;

import common.DatabaseQueries;

public enum GRRespGamblingServiceUsers {

	END_GAME_ROUND_POS1("KrisiTestGR1"),
	END_GAME_ROUND_NEG("OnseoUATGr1"),
	GET_WITH_HOLD_TAXES_POS1("GOSVCGRUSER63"),
	GET_WITH_HOLD_TAXES_POS2("GO_SVC_GR_02"),
	GET_WITH_HOLD_TAXES_POS3("GO_SVC_GR_03"),
	GET_WITH_HOLD_TAXES_POS4("GO_SVC_GR_04"),
	GET_WITH_HOLD_TAXES_POS5("GO_SVC_GR_05"),
	GET_WITH_HOLD_TAXES_POS6("GO_SVC_GR_06"),
	GET_WITH_HOLD_TAXES_POS7("GO_SVC_GR_07"),
	GET_WITH_HOLD_TAXES_POS8("GO_SVC_GR_08"),
	GET_WITH_HOLD_TAXES_POS9("GO_SVC_GR_09"),
	GET_WITH_HOLD_TAXES_POS10("GO_SVC_GR_10"),
	POKER_LOGOUT_SESSION_POS1("ArLV7362171328"),
	POKER_LOGOUT_SESSION_NEG("JH02031009"),
	SCHEDULE_GAME_ROUND_NEG("JH02031009"),
	SCHEDULE_POKER_SESSION_NEG("OnseoUATGr3"),
	SESSION_NOTIFICATION_NEG("GO_SVC_SLOTSGR"),
	SET_USER_LOSS_POS1("GO_SVC_SLOTSGR"),
	SET_USER_LOSS_NEG("wintestSW3"),
	UPDATE_USER_SESSION_POS1("GOSVCGRUSER8"),
	UPDATE_USER_SESSION_POS2("GO_SVC_SLOTSGR"),
	UPDATE_USER_SESSION_NEG("KrisiTestGR1"),
	UPDATE_WIN_BET_BUCKET_POS1("KrisiTestGR1"),
	UPDATE_WIN_BET_BUCKET_NEG("GOSVCGRUSER70"),
	USER_HAS_ZERO_LIMIT_POS1("OnseoUATGr3");

	private String username;

	private GRRespGamblingServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}