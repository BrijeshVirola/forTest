package tests.greeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class SetUserLossLimitReq {

	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private SetUserLossLimitReq(Builder builder) {
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("daily_loss_limit_amount", builder.daily_loss_limit_amount);
		this.params.put("weekly_loss_limit_amount", builder.weekly_loss_limit_amount);
		this.params.put("monthly_loss_limit_amount", builder.monthly_loss_limit_amount);
	}

	public static class Builder {
		private String method, daily_loss_limit_amount, weekly_loss_limit_amount, monthly_loss_limit_amount;
		private Integer user_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder dailyLossLimitAmount(String daily_loss_limit_amount) {
			this.daily_loss_limit_amount = daily_loss_limit_amount;
			return this;
		}

		public Builder weeklyLossLimitAmount(String weekly_loss_limit_amount) {
			this.weekly_loss_limit_amount = weekly_loss_limit_amount;
			return this;
		}

		public Builder monthlyLossLimitAmount(String monthly_loss_limit_amount) {
			this.monthly_loss_limit_amount = monthly_loss_limit_amount;
			return this;
		}

		public Builder defaults() {
			this.method = "setuserlosslimit";
			this.daily_loss_limit_amount="100.50";
			this.weekly_loss_limit_amount="500.00";
			this.monthly_loss_limit_amount="1000.00";			
			return this;
		}

		public SetUserLossLimitReq build() {
			return new SetUserLossLimitReq(this);
		}
	}
}
