package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.BaseURI;
import common.CustomErrorResponse;
import common.DatabaseQueries;
import common.Utils;
import common.XmlUtils;
import common.enumsconstants.ProductId;
import domain.BaseRequest;
import tests.greeceresponsiblegamblingservice.enums.GRRespGamblingServiceUsers;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.GetWithHoldTaxesReq;
import tests.greeceresponsiblegamblingservice.response.GetWithhodTaxesResp;
import tests.tokenservice.enums.TokenEndpoints;
import tests.tokenservice.request.GetTokenByTokenReq;
import tests.tokenservice.requestobjects.GetTokenByTokenParams;
import tests.tokenservice.response.TokenResp;
public class GetWithHoldTaxesTests extends BaseClassSetup {

	@Test(description = "Make a request to get withhold taxes - without tax value. Positive scenario.")
	public void getWithholdTaxes_withoutTax_Positive_Scenario() {

		String username = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(sessionId)
				.build();

		GetWithhodTaxesResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesSuccess);

		GetWithhodTaxesResp expectedResponse =  new GetWithhodTaxesResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to get withhold taxes - currentWithHoldTax value is calculated. Positive scenario.")
	public void getWithholdTaxes_withCurrentTWithHeldax_Positive_Scenario() {

		String userName = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS2.getUsername();
		int userId = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS2.getUserId();

		String token = XmlUtils.createTestToken(userName, 49871, ProductId.GAMES);

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 

		TokenResp actualGetResponse =  BaseRequest.post(getRequest, TokenEndpoints.getTokenByTokenSuccess, BaseURI.GET_TOKEN_BY_TOKEN);

		DatabaseQueries.setWithHoldTaxes(userId, actualGetResponse.getResult().getSessionId(), "700.00");

		// Make a spin
		Utils.makeASpinCogena(userName, 49871, "CogenaWhiteLabelGMGreeceTestGame", 1, token);

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(actualGetResponse.getResult().getSessionId())
				.build();

		GetWithhodTaxesResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesSuccess);

		GetWithhodTaxesResp expectedResponse =  new GetWithhodTaxesResp.Builder()
				.defaults()
				.currentWithHoldTax("39.8")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to get withhold taxes - currentWithHoldTax value is NOT calculated with the boundary value. Positive scenario.")
	public void getWithholdTaxes_withCurrentTWithHeldax_Boundary_Value_Scenario1() {

		String userName = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS3.getUsername();
		int userId = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS3.getUserId();

		String token = XmlUtils.createTestToken(userName, 49871, ProductId.GAMES);

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 

		TokenResp actualGetResponse =  BaseRequest.post(getRequest, TokenEndpoints.getTokenByTokenSuccess, BaseURI.GET_TOKEN_BY_TOKEN);

		DatabaseQueries.setWithHoldTaxes(userId, actualGetResponse.getResult().getSessionId(), "501.00");

		// Make a spin
		Utils.makeASpinCogena(userName, 49871, "CogenaWhiteLabelGMGreeceTestGame", 1, token);

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(actualGetResponse.getResult().getSessionId())
				.build();

		GetWithhodTaxesResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesSuccess);

		GetWithhodTaxesResp expectedResponse =  new GetWithhodTaxesResp.Builder()
				.defaults()
				.currentWithHoldTax("0")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}

	@Test(description = "Make a request to get withhold taxes - currentWithHoldTax value is calculated with the boundary value. Positive scenario.")
	public void getWithholdTaxes_withCurrentTWithHeldax_Boundary_Value_Scenario2() {

		String userName = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS4.getUsername();
		int userId = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS4.getUserId();

		String token = XmlUtils.createTestToken(userName, 49871, ProductId.GAMES);

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 

		TokenResp actualGetResponse =  BaseRequest.post(getRequest, TokenEndpoints.getTokenByTokenSuccess, BaseURI.GET_TOKEN_BY_TOKEN);

		DatabaseQueries.setWithHoldTaxes(userId, actualGetResponse.getResult().getSessionId(), "501.01");

		// Make a spin
		Utils.makeASpinCogena(userName, 49871, "CogenaWhiteLabelGMGreeceTestGame", 1, token);

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(actualGetResponse.getResult().getSessionId())
				.build();

		GetWithhodTaxesResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesSuccess);

		GetWithhodTaxesResp expectedResponse =  new GetWithhodTaxesResp.Builder()
				.defaults()
				.currentWithHoldTax("0.002")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}	

	@Test(description = "Make a request to get withhold taxes - pokerCurrentWithheldTax value is calculated. Positive scenario.")
	public void getWithholdTaxes_withPokerCurrentTWithHeldax_Positive_Scenario() {

		String userName = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS5.getUsername();
		String sessionId = Utils.createSession(userName).getSessionId();
		int userId = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS5.getUserId();
		String token = DatabaseQueries.createGreeceToken(userId, sessionId, 31288);

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 

		TokenResp actualGetResponse =  BaseRequest.post(getRequest, TokenEndpoints.getTokenByTokenSuccess, BaseURI.GET_TOKEN_BY_TOKEN);

		// Make a transaction
		XmlUtils.PTEWSpinAndWin(userName, new BigDecimal("-10.00"), new BigDecimal("600.00"), token, false);

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(actualGetResponse.getResult().getSessionId())
				.build();

		GetWithhodTaxesResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesSuccess);

		GetWithhodTaxesResp expectedResponse =  new GetWithhodTaxesResp.Builder()
				.defaults()
				.pokerCurrentWithheldTax("78")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to get withhold taxes - pokerCurrentWithheldTax value is NOT calculated with the boundary value. Positive scenario.")
	public void getWithholdTaxes_withPokerCurrentTWithHeldax_Boundary_Value_Scenario1() {

		String userName = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS6.getUsername();
		String sessionId = Utils.createSession(userName).getSessionId();
		int userId = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS6.getUserId();
		String token = DatabaseQueries.createGreeceToken(userId, sessionId, 31288);

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 

		TokenResp actualGetResponse =  BaseRequest.post(getRequest, TokenEndpoints.getTokenByTokenSuccess, BaseURI.GET_TOKEN_BY_TOKEN);

		// Make a transaction
		XmlUtils.PTEWSpinAndWin(userName, new BigDecimal("-10.00"), new BigDecimal("110.03"), token, false);

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(actualGetResponse.getResult().getSessionId())
				.build();

		GetWithhodTaxesResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesSuccess);

		GetWithhodTaxesResp expectedResponse =  new GetWithhodTaxesResp.Builder()
				.defaults()
				.pokerCurrentWithheldTax("0")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to get withhold taxes - pokerCurrentWithheldTax value is calculated with the boundary value. Positive scenario.")
	public void getWithholdTaxes_withPokerCurrentTWithHeldax_Boundary_Value_Scenario2() {

		String userName = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS7.getUsername();
		String sessionId = Utils.createSession(userName).getSessionId();
		int userId = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS7.getUserId();
		String token = DatabaseQueries.createGreeceToken(userId, sessionId, 31288);

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 

		TokenResp actualGetResponse =  BaseRequest.post(getRequest, TokenEndpoints.getTokenByTokenSuccess, BaseURI.GET_TOKEN_BY_TOKEN);

		// Make a transaction
		XmlUtils.PTEWSpinAndWin(userName, new BigDecimal("-10.00"), new BigDecimal("110.04"), token, false);

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(actualGetResponse.getResult().getSessionId())
				.build();

		GetWithhodTaxesResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesSuccess);

		GetWithhodTaxesResp expectedResponse =  new GetWithhodTaxesResp.Builder()
				.defaults()
				.pokerCurrentWithheldTax("0.006")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to get withhold taxes - pokerTournamentscurrentWithheldTax value is calculated. Positive scenario.")
	public void getWithholdTaxes_withPokerTournamentCurrentTWithHeldax_Positive_Scenario() {

		String userName = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS8.getUsername();
		String sessionId = Utils.createSession(userName).getSessionId();
		int userId = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS8.getUserId();
		String token = DatabaseQueries.createGreeceToken(userId, sessionId, 31288);

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 

		TokenResp actualGetResponse =  BaseRequest.post(getRequest, TokenEndpoints.getTokenByTokenSuccess, BaseURI.GET_TOKEN_BY_TOKEN);

		// Make a transaction
		XmlUtils.PTEWSpinAndWin(userName, new BigDecimal("-10.00"), new BigDecimal("600.00"), token, true);

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(actualGetResponse.getResult().getSessionId())
				.build();

		GetWithhodTaxesResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesSuccess);

		GetWithhodTaxesResp expectedResponse =  new GetWithhodTaxesResp.Builder()
				.defaults()
				.pokerTournamentscurrentWithheldTax("78")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}	

	@Test(description = "Make a request to get withhold taxes - pokerTournamentscurrentWithheldTax value is NOT calculated with the boundary value. Positive scenario.")
	public void getWithholdTaxes_withPokerTournamentCurrentTWithHeldax_Boundary_Value_Scenario1() {

		String userName = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS9.getUsername();
		String sessionId = Utils.createSession(userName).getSessionId();
		int userId = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS9.getUserId();
		String token = DatabaseQueries.createGreeceToken(userId, sessionId, 31288);

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 

		TokenResp actualGetResponse =  BaseRequest.post(getRequest, TokenEndpoints.getTokenByTokenSuccess, BaseURI.GET_TOKEN_BY_TOKEN);

		// Make a transaction
		XmlUtils.PTEWSpinAndWin(userName, new BigDecimal("-10.00"), new BigDecimal("110.03"), token, true);

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(actualGetResponse.getResult().getSessionId())
				.build();

		GetWithhodTaxesResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesSuccess);

		GetWithhodTaxesResp expectedResponse =  new GetWithhodTaxesResp.Builder()
				.defaults()
				.pokerTournamentscurrentWithheldTax("0")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}	

	@Test(description = "Make a request to get withhold taxes - pokerTournamentscurrentWithheldTax value is calculated with the boundary value. Positive scenario.")
	public void getWithholdTaxes_withPokerTournamentCurrentTWithHeldax_Boundary_Value_Scenario2() {

		String userName = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS10.getUsername();
		String sessionId = Utils.createSession(userName).getSessionId();
		int userId = GRRespGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS10.getUserId();
		String token = DatabaseQueries.createGreeceToken(userId, sessionId, 31288);

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 

		TokenResp actualGetResponse =  BaseRequest.post(getRequest, TokenEndpoints.getTokenByTokenSuccess, BaseURI.GET_TOKEN_BY_TOKEN);

		// Make a transaction
		XmlUtils.PTEWSpinAndWin(userName, new BigDecimal("-10.00"), new BigDecimal("110.04"), token, true);

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(actualGetResponse.getResult().getSessionId())
				.build();

		GetWithhodTaxesResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesSuccess);

		GetWithhodTaxesResp expectedResponse =  new GetWithhodTaxesResp.Builder()
				.defaults()
				.pokerTournamentscurrentWithheldTax("0.006")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

	}	

	@Test(description = "Make a request to set the user's loss limit to zero. Missing parameter. Negative Scenario.")
	public void userhaszerolimitset_Missing_Parameter() {

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.getwithholdtaxesError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: session_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to set the user's loss limit to zero. Wrong method. Negative Scenario.")
	public void userhaszerolimitset_Wrong_Method() {

		GetWithHoldTaxesReq request = new GetWithHoldTaxesReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.userHasZeroLimitSetError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}
