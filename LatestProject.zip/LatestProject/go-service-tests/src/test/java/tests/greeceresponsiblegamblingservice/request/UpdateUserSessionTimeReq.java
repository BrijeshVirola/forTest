package tests.greeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class UpdateUserSessionTimeReq {

	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private UpdateUserSessionTimeReq(Builder builder) {
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("session_id", builder.session_id);
		this.params.put("product_id", builder.product_id);
		this.params.put("participation_duration", builder.participation_duration);	
		this.params.put("participation_datetime_utc", builder.participation_datetime_utc);
	}

	public static class Builder {
		private String method, session_id, participation_datetime_utc;
		private Integer user_id, product_id, participation_duration;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public Builder participationDateTime(String participation_datetime_utc) {
			this.participation_datetime_utc = participation_datetime_utc;
			return this;
		}

		public Builder participantDuration(Integer participation_duration) {
			this.participation_duration = participation_duration;
			return this;
		}


		public Builder defaults() {
			this.method = "updateusersessiontime";
			this.session_id="0FC994B2B1094D818A1988EB09E371000084";
			this.product_id=4;
			this.participation_duration=190;
			this.participation_datetime_utc="2022-01-05T13:41:25.125Z";
			return this;
		}

		public UpdateUserSessionTimeReq build() {
			return new UpdateUserSessionTimeReq(this);
		}
	}
}
