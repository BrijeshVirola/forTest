package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.greeceresponsiblegamblingservice.enums.GRRespGamblingServiceUsers;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.UpdateWinBetBucketAmountReq;
import tests.greeceresponsiblegamblingservice.response.UpdateWinBetBucketAmountResp;
public class UpdateWinBetBucketAmountTests extends BaseClassSetup {

	//TODO: Implement stored procs to have user session before executing the test. JIRA Issue ID: PRJSAK-2663
	@Test(enabled =false, description = "Make a request to updateWinBetBucketAmount.  Daily/monthly/weekly limit not breached. Positive scenario.")
	public void updateBetBucketAmount_Positive_Scenario() {


		UpdateWinBetBucketAmountReq request = new UpdateWinBetBucketAmountReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.UPDATE_WIN_BET_BUCKET_POS1.getUserId())
				.build();

		UpdateWinBetBucketAmountResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateWinBetBucketAmountSuccess);

		UpdateWinBetBucketAmountResp expectedResponse =  new UpdateWinBetBucketAmountResp.Builder()
				.defaults()		        
				.id(null)
				.limitBreached(false)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	//TODO: Implement stored procs to have user session before executing the test. JIRA Issue ID: PRJSAK-2663
	@Test(enabled = false, description = "Make a request to UpdateBetBucketAmount. Daily/monthly/weekly limit breached. Positive Scenario")
	public void updateBetBucketAmount_DailyBetLimitExceeded() {


		UpdateWinBetBucketAmountReq request = new UpdateWinBetBucketAmountReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.UPDATE_WIN_BET_BUCKET_POS1.getUserId())
				.build();

		UpdateWinBetBucketAmountResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateWinBetBucketAmountSuccess);

		UpdateWinBetBucketAmountResp expectedResponse =  new UpdateWinBetBucketAmountResp.Builder()
				.defaults()
				.id(null)
				.limitBreached(false)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}


	@Test(description = "Make a request to UpdateWinBetBucketAmount. Missing userId parameter.")
	public void updateBetBucketAmount_Missing_Parameter() {


		UpdateWinBetBucketAmountReq request = new UpdateWinBetBucketAmountReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateWinBetBucketAmountError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to UpdateWinBetBucketAmount. Missing productId parameter.")
	public void updateBetBucketAmount_Missing_Parameter_product_id() {


		UpdateWinBetBucketAmountReq request = new UpdateWinBetBucketAmountReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.UPDATE_WIN_BET_BUCKET_NEG.getUserId())
				.productId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateWinBetBucketAmountError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	
	@Test(description = "Make a request to UpdateWinBetBucketAmount. Missing winAmount parameter.")
	public void updateBetBucketAmount_Missing_Parameter_winAmount() {

		UpdateWinBetBucketAmountReq request = new UpdateWinBetBucketAmountReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.UPDATE_WIN_BET_BUCKET_NEG.getUserId())
				.winAmount(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateWinBetBucketAmountError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1004)
				.message("Session was not found for the user")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to UpdateWinBetBucketAmount. Missing betAmount parameter.")
	public void updateBetBucketAmount_Missing_Parameter_betAmount() {

		
		UpdateWinBetBucketAmountReq request = new UpdateWinBetBucketAmountReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.UPDATE_WIN_BET_BUCKET_NEG.getUserId())
				.betAmount(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateWinBetBucketAmountError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1004)
				.message("Session was not found for the user")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to UpdateBetBucketAmount. Wrong method.")
	public void updateBetBucketAmount_Wrong_Method() {

		UpdateWinBetBucketAmountReq request = new UpdateWinBetBucketAmountReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.updateWinBetBucketAmountError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
