package tests.greeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.greeceresponsiblegamblingservice.enums.GRRespGamblingServiceUsers;
import tests.greeceresponsiblegamblingservice.enums.GrRespGamblingEndpoints;
import tests.greeceresponsiblegamblingservice.request.PokerLogoutSessionTimeDeductionReq;
import tests.greeceresponsiblegamblingservice.response.AllSessionTimeDeductionResp;
public class PokerLogoutSessionTimeDeductionTests extends BaseClassSetup {

	//TODO: Implement stored procs to have user session before executing the test
	@Test(enabled=false, description = "Make a request to calculate the participation time since login. Positive scenario.")
	public void pokerlogoutsessiontimededuction_Positive_Scenario() {

		PokerLogoutSessionTimeDeductionReq request = new PokerLogoutSessionTimeDeductionReq.Builder()
				.defaults()
				.build();

		AllSessionTimeDeductionResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.pokerlogoutsessiontimedeductionSuccess);

		AllSessionTimeDeductionResp expectedResponse =  new AllSessionTimeDeductionResp.Builder()
				.defaults()
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	

	@Test(description = "Make a request to calculate the participation time since login. Could not end poker session.")
	public void pokerlogoutsessiontimededuction_Couldnot_end_session() {

		String id = UUID.randomUUID().toString();

		PokerLogoutSessionTimeDeductionReq request = new PokerLogoutSessionTimeDeductionReq.Builder()
				.defaults()
				.id(id)
				.userId(GRRespGamblingServiceUsers.POKER_LOGOUT_SESSION_POS1.getUserId())
				.build();

		AllSessionTimeDeductionResp actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.pokerlogoutsessiontimedeductionSuccess);

		AllSessionTimeDeductionResp expectedResponse =  new AllSessionTimeDeductionResp.Builder()
				.defaults()
				.breachCode(null)
				.breach(false)
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to calculate the participation time since login. Missing parameter userID.")
	public void pokerlogoutsessiontimededuction_Missing_Parameter_user_id() {


		PokerLogoutSessionTimeDeductionReq request = new PokerLogoutSessionTimeDeductionReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.pokerlogoutsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to calculate the participation time since login. Missing parameter sessionID.")
	public void pokerlogoutsessiontimededuction_Missing_Parameter_session_id() {


		PokerLogoutSessionTimeDeductionReq request = new PokerLogoutSessionTimeDeductionReq.Builder()
				.defaults()
				.userId(GRRespGamblingServiceUsers.POKER_LOGOUT_SESSION_NEG.getUserId())
				.SessionId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.pokerlogoutsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: session_id")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to calculate the participation time since login. Wrong method.")
	public void pokerlogoutsessiontimededuction_Wrong_Method() {

		PokerLogoutSessionTimeDeductionReq request = new PokerLogoutSessionTimeDeductionReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GrRespGamblingEndpoints.pokerlogoutsessiontimedeductionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
