package tests.greeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class UpdateWinBetBucketAmountReq {

	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private UpdateWinBetBucketAmountReq(Builder builder) {
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("win_amount", builder.win_amount);
		this.params.put("bet_amount", builder.bet_amount);
		this.params.put("product_id", builder.product_id);
		this.params.put("server_local_date", builder.server_local_date);
	}

	public static class Builder {
		private String method, win_amount, bet_amount, server_local_date;
		private Integer user_id, product_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder winAmount(String win_amount) {
			this.win_amount = win_amount;
			return this;
		}

		public Builder betAmount(String bet_amount) {
			this.bet_amount = bet_amount;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public Builder serverLocalDate(String server_local_date) {
			this.server_local_date = server_local_date;
			return this;
		}

		public Builder defaults() {
			this.method = "updatewinbetbucketamount";
			this.win_amount="0.0";
			this.bet_amount="-2.0";
			this.product_id=4;
			this.server_local_date="2022-01-13T00:00:00Z";			
			return this;
		}

		public UpdateWinBetBucketAmountReq build() {
			return new UpdateWinBetBucketAmountReq(this);
		}
	}
}
