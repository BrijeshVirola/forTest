package tests.greeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class UserHasZeroLimitSetReq {

	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private UserHasZeroLimitSetReq(Builder builder) {
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
	}

	public static class Builder {
		private String method;
		private Integer user_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userID(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder defaults() {
			this.method = "userhaszerolimitset";
			return this;
		}

		public UserHasZeroLimitSetReq build() {
			return new UserHasZeroLimitSetReq(this);
		}
	}
}
