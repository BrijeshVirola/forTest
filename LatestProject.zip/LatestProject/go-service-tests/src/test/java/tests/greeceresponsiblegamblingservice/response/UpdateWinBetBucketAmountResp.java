package tests.greeceresponsiblegamblingservice.response;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class UpdateWinBetBucketAmountResp {

	private String id;
	private Map<String, Object> result = new HashMap<>();

	public UpdateWinBetBucketAmountResp() {
	}

	public Map<String, Object> getResult() {
		return result;
	}

	private UpdateWinBetBucketAmountResp(Builder builder) {
		this.id = builder.id;
		this.result.put("LimitBreached", builder.LimitBreached);
		this.result.put("ServerLocalDate", builder.ServerLocalDate);
	}

	public String getId() {
		return id;
	}

	public Instant getServerLocalDate() {
		return Instant.parse(result.get("ServerLocalDate").toString());
	}

	public static class Builder {
		private String id;
		private Boolean LimitBreached;
		private String ServerLocalDate;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder limitBreached(Boolean LimitBreached) {
			this.LimitBreached = LimitBreached;
			return this;
		}


		public Builder serverLocalDate(String ServerLocalDate) {
			this.ServerLocalDate = ServerLocalDate;
			return this;
		}

		public Builder defaults() {
			this.id = "2";
			this.LimitBreached = true;
			this.ServerLocalDate = "2022-01-13T00:00:00Z";
			return this;
		}

		public UpdateWinBetBucketAmountResp build() {
			return new UpdateWinBetBucketAmountResp(this);
		}	
	}
}
