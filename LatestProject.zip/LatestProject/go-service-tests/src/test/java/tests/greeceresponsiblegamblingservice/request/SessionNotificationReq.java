package tests.greeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class SessionNotificationReq {

	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private SessionNotificationReq(Builder builder) {
		this.method = builder.method;
		this.params.put("session_id", builder.session_id);
		this.params.put("display_notification", builder.display_notification);
		this.params.put("breach_type", builder.breach_type);
		this.params.put("user_breach_information_id", builder.user_breach_information_id);
	}

	public static class Builder {
		private String method, session_id;
		private Integer breach_type, user_breach_information_id;
		private Boolean display_notification;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder displayNotification(Boolean display_notification) {
			this.display_notification = display_notification;
			return this;
		}

		public Builder breachType(Integer breach_type) {
			this.breach_type = breach_type;
			return this;
		}

		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder userBreachInformationId(Integer user_breach_information_id) {
			this.user_breach_information_id = user_breach_information_id;
			return this;
		}

		public Builder defaults() {
			this.method = "sessionnotification";
			this.session_id = "C48171EE19834F879DB846ED0FC65B4A020004";
			this.display_notification=true;
			this.breach_type=13;
			this.user_breach_information_id=20697;			
			return this;
		}

		public SessionNotificationReq build() {
			return new SessionNotificationReq(this);
		}
	}
}
