package tests.greeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class PokerLogoutSessionTimeDeductionReq {

	@SuppressWarnings("unused")
	private String method, id;

	private Map<String, Object> params = new HashMap<>();

	private PokerLogoutSessionTimeDeductionReq(Builder builder) {
		this.method = builder.method;
		this.id = builder.id;
		this.params.put("user_id", builder.user_id);
		this.params.put("session_id", builder.session_id);
	}

	public static class Builder {
		private String method, id, session_id;
		private Integer user_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder SessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder defaults() {
			this.method = "pokerlogoutsessiontimededuction";
			this.session_id="4D29A8B9397546AD82F987F02194AD76000004";		
			return this;
		}

		public PokerLogoutSessionTimeDeductionReq build() {
			return new PokerLogoutSessionTimeDeductionReq(this);
		}
	}
}
