package tests.gahoosearchservice.enums;

import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.gahoosearchservice.response.GahooSearchResp;
import tests.gahoosearchservice.response.GahooSearchNullResp;

public enum GahooSearchEndpoints implements ResponseEndpoints {

	gahooSearchSuccess(GahooSearchResp.class, "search"),
	gahooSearchNullSuccess(GahooSearchNullResp.class, "search"),
	gahooSearchError(CustomErrorResponse.class, "search");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GahooSearchEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
