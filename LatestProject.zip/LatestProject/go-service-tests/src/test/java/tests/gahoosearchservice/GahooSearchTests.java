package tests.gahoosearchservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.gahoosearchservice.enums.GahooSearchEndpoints;
import tests.gahoosearchservice.request.GahooSearchReq;
import tests.gahoosearchservice.response.GahooSearchNullResp;
import tests.gahoosearchservice.response.GahooSearchResp;

public class GahooSearchTests extends BaseClassSetup {

	@DataProvider(name = "liveCasinoBaseUri")
	public Object[][] liveCasinoBaseUri() {
		return new Object[][] {
			{"https://livecasino571.b365uat.com/gamingservices/gam-gahoo-svcv1/api/"}	
		};
	}

	@Test(description = "Make a request to Gahoo Search. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Exact_Match_Search_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("WildCrusade")
				.p(4)
				.c(36)
				.cs(72)
				.l(1)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.uv(true)
				.cp(true)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expWildCrusade(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Exact Match - Estonia Country, Estonia Language. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Exact_Match_Estonia_Country_Estonia_Language_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("robocop")
				.p(2)
				.cs(0)
				.cc("EUR")
				.l(29)
				.tn("2")
				.pt(1)
				.dg(1)
				.uv(true)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expEstoniaCountryEstoniaLanguage(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Optional parameter: cs.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void createGameRound_Missing_cs_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("Majority Rules Speed")
				.p(45)
				.c(197)
				.cs(null)
				.l(1)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.uv(true)
				.cp(false)
				.build();
		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expMajorityRulesSpeedBlackjack(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Optional uv. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Optinal_UV_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("Money Drop")
				.p(45)
				.c(197)
				.cs(0)
				.l(1)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.uv(null)
				.cp(false)
				.build();
		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expMoneyDrop(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Cross Product Set to false. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Cross_Product_False_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("Gods Bonus")
				.p(45)
				.c(197)
				.cs(0)
				.l(1)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.uv(true)
				.cp(false)
				.build();
		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expAgeoftheGodsBonusRoulette(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Country - Denmark and Language - English Search. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Denmark_Country_English_Language_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("MedusasGoldenGaze")
				.p(4)
				.c(54)
				.cs(72)
				.l(1)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expMedusasGoldenGaze(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Search by a word - Card Search. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Search_By_Word_CARD_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("Card")
				.p(4)
				.c(54)
				.cs(72)
				.l(1)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.uv(true)
				.cp(true)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expThreeCardBragHG(actualResponse.getResult().get(0)))
				.addUserSearchDetails(Utils.expThreeCardBrag(actualResponse.getResult().get(1)))
				.addUserSearchDetails(Utils.expLive3CardBrag(actualResponse.getResult().get(2)))
				.build();

		Utils.sortById(expResponse);
		Utils.sortById(actualResponse);
		
		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Bulgarian Language. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Bulgarian_Language_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("Бакара")
				.p(2)
				.c(31)
				.cs(0)
				.l(19)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("EUR")
				.uv(true)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expBulLiveBaccarat(actualResponse.getResult().get(0)))
				.addUserSearchDetails(Utils.expBulLiveBaccarat7Seat(actualResponse.getResult().get(1)))
				.build();

		Utils.sortById(expResponse);
		Utils.sortById(actualResponse);

		assertReflectionEquals(expResponse, actualResponse);
	}
	
	@Test(description = "Make a request to Gahoo Search - Country Italy, Italian Language. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Country_Italy_Italian_Language_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("leggende alfa più meno")
				.p(4)
				.c(97)
				.cs(0)
				.l(6)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("EUR")
				.uv(true)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expItalianLittleGreenMenNovaWildss(actualResponse.getResult().get(0)))
				.addUserSearchDetails(Utils.expItalianChamberOfAlchemy(actualResponse.getResult().get(1)))
				.build();

		Utils.sortById(expResponse);
		Utils.sortById(actualResponse);

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Country Spain, Spanish Language. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Country_Spain_Spanish_Language_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("blackjack")
				.p(2)
				.c(171)
				.cs(0)
				.l(3)
				.tn("1")
				.pt(1)
				.dg(1)
				.cc("EUR")
				.uv(true)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expSpanishBlackjackMultihand(actualResponse.getResult().get(0)))
				.addUserSearchDetails(Utils.expSpanishBlackjackSuper21(actualResponse.getResult().get(1)))
				.addUserSearchDetails(Utils.expSpanishAmericanBlackjack(actualResponse.getResult().get(2)))
				.build();

		Utils.sortById(expResponse);
		Utils.sortById(actualResponse);

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Country China, Chinese Language. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Country_China_Chinese_Language_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("黑骑士II")
				.p(4)
				.c(42)
				.cs(0)
				.l(2)
				.tn("1,2")
				.pt(1)
				.dg(1)
				.cc("CNY")
				.uv(true)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expChinaBlackKnightIISG(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Country Malta, English Language. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Country_Malta_English_Language_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("SaharaNights")
				.p(4)
				.c(120)
				.cs(0)
				.l(1)
				.tn("1,2")
				.pt(1)
				.dg(1)
				.cc("EUR")
				.uv(true)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expMaltaSaharaNights(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}
	
	@Test(description = "Make a request to Gahoo Search - Country Sweden, Swedish Language. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Country_Sweden_Swedish_Language_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("delfin")
				.p(4)
				.c(181)
				.cs(0)
				.l(8)
				.tn("1,2")
				.pt(1)
				.dg(1)
				.cc("EUR")
				.uv(true)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expSwedenDolphinGold(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Country Bulgaria, German Language. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Country_Bulgaria_German_Language_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("gold")
				.p(2)
				.c(31)
				.cs(0)
				.l(5)
				.tn("1")
				.pt(1)
				.dg(1)
				.cc("EUR")
				.uv(true)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expGermanAgeOfTheGods(actualResponse.getResult().get(0)))
				.addUserSearchDetails(Utils.expGermanGoddessofWisdom(actualResponse.getResult().get(1)))
				.addUserSearchDetails(Utils.expGermanAgeoftheGodsFuriousFour(actualResponse.getResult().get(2)))
				.addUserSearchDetails(Utils.expGermanAgeoftheGodsKingofOlympus(actualResponse.getResult().get(3)))
				.addUserSearchDetails(Utils.expGermanLiveAgeoftheGodsRoulette(actualResponse.getResult().get(4)))
				.addUserSearchDetails(Utils.expGermanCasinoHoldEm(actualResponse.getResult().get(5)))
				.build();

		Utils.sortById(expResponse);
		Utils.sortById(actualResponse);

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - User is Age Verified. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Search_User_Age_Verified_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("Abracardabra")
				.p(4)
				.c(197)
				.cs(0)
				.l(1)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.uv(true)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expAgeVerified(actualResponse.getResult().get(0)))
				.addUserSearchDetails(Utils.expAgeAbraCatDabra(actualResponse.getResult().get(1)))
				.build();

		Utils.sortById(expResponse);
		Utils.sortById(actualResponse);
		
		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Technology Search - 1 and 2. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Search_By_Technology_Id_1_2_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("SpaceHunter")
				.tn("1,2")
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expSpaceHunter(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search. Cross Product - true. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Cross_Product_Set_True_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.cp(true)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expSearchDetailsBeetlejuice(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search. Partial Match. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Partial_Match_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("west")
				.p(4)
				.c(54)
				.cs(72)
				.l(1)
				.tn("1,2")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.uv(true)
				.cp(true)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);
		
		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expWildWest(actualResponse.getResult().get(0)))
				.addUserSearchDetails(Utils.expWildWildWest(actualResponse.getResult().get(1)))
				.addUserSearchDetails(Utils.expKingOfTheWest(actualResponse.getResult().get(2)))
				.addUserSearchDetails(Utils.expEastSeaDragonKing(actualResponse.getResult().get(3)))
				.build();

		Utils.sortById(actualResponse);
		Utils.sortById(expResponse);

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search. Device Group - 2. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Device_Group_2_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("BeastsOfFire")
				.dg(2)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expBeastsOfFire(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search. Platform Type - 2. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Platform_Type_2_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("FireGoddess")
				.pt(2)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expFireGoddessINS(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Country - Germany - English Search. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Country_Germany_Language_English_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("FreeSpinsReturn")
				.p(4)
				.c(54)
				.cs(75)
				.l(1)
				.tn("1")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expFreeSpinsReturn(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Search by a word - Live. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Search_By_Word_Live_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("live")
				.p(4)
				.c(54)
				.cs(75)
				.l(1)
				.tn("1")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.uv(true)
				.cp(true)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expTheFinerReelsofLife(actualResponse.getResult().get(0)))
				.addUserSearchDetails(Utils.expLifeOfRiches(actualResponse.getResult().get(1)))
				.addUserSearchDetails(Utils.expLiveDragonTiger(actualResponse.getResult().get(2)))
				.addUserSearchDetails(Utils.expLiveCasinoHoldem(actualResponse.getResult().get(3)))
				.build();

		Utils.sortById(expResponse);
		Utils.sortById(actualResponse);

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Game Search - Live on Live Casino. Positive scenario.", dataProvider = "liveCasinoBaseUri")
	public void getGahooSearch_Game_Search_On_Live_Casino_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("DealorNoDealTheBigDraw")
				.p(45)
				.c(197)
				.cs(0)
				.l(1)
				.tn("2")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.uv(true)
				.cp(false)
				.build();

		GahooSearchResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchSuccess, baseUri);

		GahooSearchResp expResponse = new GahooSearchResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserSearchDetails(Utils.expDealorNoDealTheBigDraw(actualResponse.getResult().get(0)))
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Search by a word - Live on Live Casino. Positive scenario.", dataProvider = "liveCasinoBaseUri")
	public void getGahooSearch_Search_By_Word_Live_On_Live_Casino_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("live")
				.p(45)
				.c(54)
				.cs(75)
				.l(1)
				.tn("1")
				.pt(1)
				.dg(1)
				.cc("GBP")
				.uv(true)
				.cp(false)
				.build();

		GahooSearchNullResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchNullSuccess, baseUri);

		GahooSearchNullResp expResponse = new GahooSearchNullResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.result(null)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to Gahoo Search. Platform Type - 3. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Platform_Type_3_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.pt(3)
				.build();

		GahooSearchNullResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchNullSuccess, baseUri);

		GahooSearchNullResp expResponse = new GahooSearchNullResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.result(null)
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - Null result. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Null_Result_Search_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("abcdfefijfiejifjeijfie")
				.build();

		GahooSearchNullResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchNullSuccess, baseUri);

		GahooSearchNullResp expResponse = new GahooSearchNullResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.result(null)
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to Gahoo Search - One Char Search - Null result. Negative scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_One_Char_Null_Result_Search_Negative_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("a")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: t")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Wrong method.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Wrong_Method(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(4)
				.message("Invalid request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: t.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Missing_t_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: t")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: p.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Missing_p_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.p(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: p")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: c.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Missing_c_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.c(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: c")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: tn.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Missing_tn_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.tn(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: tn")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: pt.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Missing_pt_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.pt(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: pt")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to gahooSearch. Missing parameter: dg.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Missing_dg_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.dg(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: dg")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to gahooSearch. Missing parameter: cc.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Missing_cc_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.cc(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: cc")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}	
	
	@Test(description = "Make a request to gahooSearch. Missing parameter: l.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch_Missing_l_Parameter(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.l(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchError, baseUri);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: l")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to Gahoo Search - Age Not Verified - uv. Positive scenario.", dataProvider = "baseUri", dataProviderClass = DataProviders.class)
	public void getGahooSearch__Age_Not_Verified_Positive_Scenario(String baseUri) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GahooSearchReq request = new GahooSearchReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.t("Abracardabra")
				.uv(false)
				.build();

		GahooSearchNullResp actualResponse =  BaseRequest.post(request, GahooSearchEndpoints.gahooSearchNullSuccess, baseUri);

		GahooSearchNullResp expResponse = new GahooSearchNullResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.result(null)
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}
}
