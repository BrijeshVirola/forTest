package tests.gahoosearchservice;

import tests.gahoosearchservice.response.GahooSearchResp;
import tests.gahoosearchservice.responseobjects.DebugInfo;
import tests.gahoosearchservice.responseobjects.UserSearchDetails;

public class Utils {

	public static UserSearchDetails expSearchDetailsBeetlejuice(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(17355)
				.why("Starts with match on beetlejuice")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(9646)
				.gt("Beetlejuice Megaways")
				.tkn("BeetlejuiceMegaways")
				.p(4)
				.ibn("BeetlejuiceMegaways2")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expSearchDetailsDealOrNoDeal(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(20212)
				.why("Key word matches on [game]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(10719)
				.gt("Deal or No Deal: The Golden Game")
				.tkn("DONDTheGoldenGame")
				.p(4)
				.ibn("DealOrNoDealTheGoldenGame2")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expSearchDetailsMedusaGoldenGaze(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(11385)
				.why("Edit distance match on gae (gaze)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7518)
				.gt("Medusa's Golden Gaze")
				.tkn("MedusasGoldenGaze")
				.p(4)
				.ibn("MedusasGoldenGaze")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expSearchDetailsFurysGate(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(11593)
				.why("Edit distance match on gae (gate)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7608)
				.gt("Fury’s Gate")
				.tkn("FurysGate")
				.ipei("games/SGP/GamePod/OriginalsIcon.svg")
				.p(4)
				.ibn("FurysGate")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expSearchDetailsLiveGameShows(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(10389)
				.why("Key word matches on [game]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7053)
				.gt("Live Game Shows Lobby")
				.tkn("LiveAotGRouletteTest")
				.p(2)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expEstoniaCountryEstoniaLanguage(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(8114)
				.why("Full name match on robocop")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(5739)
				.gt("Robocop")
				.tkn("Robocop")
				.p(2)
				.ibn("RoboCop2")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expThreeCardBragHG(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(11012)
				.why("Key word matches on [card]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7322)
				.gt("3 Card Brag")
				.tkn("ThreeCardBragHG")
				.p(4)
				.ibn("3CardBrag-HillsideGames")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expThreeCardBrag(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(12465)
				.why("Key word matches on [card]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(8033)
				.gt("3 Card Brag")
				.tkn("ThreeCardBrag")
				.p(2)
				.ibn("3CardBrag")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expLive3CardBrag(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(8223)
				.why("Key word matches on [card]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(6073)
				.gt("Live 3 Card Brag")
				.tkn("Live3CardBrag")
				.p(2)
				.ibn("Live3CardBrag")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expAgeVerified(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(9399)
				.why("Full name match on abracardabra")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(6598)
				.gt("Abracardabra")
				.tkn("Abracardabra")
				.p(4)
				.ibn("Abracardabra")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expAgeAbraCatDabra(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(24657)
				.why("Edit distance match on abracadabra (abracatdabra)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(12551)
				.gt("AbraCatDabra")
				.tkn("abraCatDabra")
				.p(4)
				.ibn(null)
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}
	
	public static UserSearchDetails expWildWest(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(2835)
				.why("Key word matches on [west]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(2789)
				.gt("Wild West HTML5")
				.tkn("WildWest")
				.p(4)
				.ibn("WildWest")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expWildWildWest(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(14162)
				.why("Key word matches on [west]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(3261)
				.gt("Wild Wild West")
				.tkn("WildWildWest")
				.p(4)
				.ibn("WildWildWest")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expKingOfTheWest(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(20946)
				.why("Key word matches on [west]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(11047)
				.gt("King of the West")
				.tkn("KingOfTheWest")
				.p(4)
				.ibn("KingOfTheWest")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expEastSeaDragonKing(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(16235)
				.why("Edit distance match on est (east)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(9491)
				.gt("East Sea Dragon King")
				.tkn("EastSeaDragonKing")
				.p(4)
				.ibn("EastSeaDragonKing")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expEuropeanRouletteGold(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(1596)
				.why("Key word matches on [roulette]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(1566)
				.gt("European Roulette Gold")
				.tkn("EuropeanRouletteGold")
				.p(4)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expPremierR(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(10777)
				.why("Key word matches on [roulette]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7245)
				.gt("Premier Roulette")
				.tkn("PremierR")
				.p(4)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expRoulettePro(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(5003)
				.why("Starts with match on roulette")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(3489)
				.gt("Roulette Pro")
				.tkn("RoulettePro")
				.p(2)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expPremiumEuropeanRoulette(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(4806)
				.why("Starts with match on roulette")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(582)
				.gt("Premium European Roulette")
				.tkn("PremiumEuropeanRoulette")
				.p(2)
				.ibn("PremiumEuropeanRoulette")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expPremiumFrenchRoulette(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(4949)
				.why("Starts with match on roulette")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(3429)
				.gt("Premium French Roulette")
				.tkn("PremiumFrenchRoulette")
				.p(2)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expSlingshotRoulette(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(8814)
				.why("Key word matches on [roulette]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(6480)
				.gt("Slingshot Roulette")
				.tkn("SlingshotRoulette")
				.p(2)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expMultiplayerEuropeanRoulette(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(5173)
				.why("Key word matches on [roulette]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(4218)
				.gt("Multiplayer European Roulette")
				.tkn("MultiplayerEuropeanRoulette")
				.p(2)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expAgeoftheGodsRoulette(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(4896)
				.why("Key word matches on [roulette]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(3376)
				.gt("Age of the Gods: Roulette")
				.tkn("AgeoftheGodsRoulette")
				.p(2)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expTheFinerReelsofLife(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(203)
				.why("Edit distance match on lie (life)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(191)
				.gt("The Finer Reels of Life")
				.tkn("TheFinerReelsofLife")
				.p(4)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expLifeOfRiches(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(2841)
				.why("Edit distance match on lie (life)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(2795)
				.gt("Life of Riches")
				.tkn("LifeOfRiches")
				.p(4)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expLiveDragonTiger(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(8186)
				.why("Starts with match on live")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(5604)
				.gt("Live Dragon Tiger")
				.tkn("LiveDragonTiger")
				.p(2)
				.ibn("LiveDragonTiger")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expLiveCasinoHoldem(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(4850)
				.why("Starts with match on live")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(1612)
				.gt("Live Casino Hold'em")
				.tkn("LiveCasinoHoldem")
				.p(2)
				.ibn("LiveCasinoHoldem")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expLiveBaccarat(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(21009)
				.why("Full name match on baccarat")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(6215)
				.gt("Baccarat")
				.tkn("LiveBaccarat")
				.p(45)
				.ibn("LiveBaccarat")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expMontezumaMegaways(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(15215)
				.why("Starts with match on montezumamegaways")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(9113)
				.gt("Montezuma Megaways")
				.tkn("MontezumaMegaways")
				.p(4)
				.ibn("MontezumaMegaways")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expFreeSpinsReturn(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(16305)
				.why("Starts with match on freespinsreturn")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(3083)
				.gt("Free Spins Return")
				.tkn("FreeSpinsReturn")
				.p(4)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expBeastsOfFire(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(23161)
				.why("Starts with match on beastsoffire")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(11788)
				.gt("Beasts of Fire")
				.tkn("beastsoffire")
				.p(4)
				.ibn("BeastsOfFire")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expMedusasGoldenGaze(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(11385)
				.why("Starts with match on medusasgoldengaze")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7518)
				.gt("Medusa's Golden Gaze")
				.tkn("MedusasGoldenGaze")
				.p(4)
				.ibn("MedusasGoldenGaze")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expFireToad(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(20295)
				.why("Starts with match on firetoad")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(10748)
				.gt("Fire Toad")
				.tkn("firetoad")
				.p(4)
				.ibn("firetoad")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expBulLiveBaccarat7Seat(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(11071)
				.why("Starts with match on бакара")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7342)
				.gt("Бакара На Живо")
				.tkn("LiveBaccarat7Seat")
				.p(2)
				.ibn("Live7SeatBaccarat")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expBulLiveBaccarat(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(8386)
				.why("Starts with match on бакара")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(6215)
				.gt("Бакара На Живо")
				.tkn("LiveBaccarat")
				.p(2)
				.ibn("LiveBaccarat")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expItalianLittleGreenMenNovaWildss(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(17213)
				.why("Edit distance match on men (men)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(9586)
				.gt("Little Green Men Nova Wilds")
				.tkn("LittleGreenMenNovaWildss")
				.p(4)
				.ibn("LittleGreenMenNovaWilds")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expItalianChamberOfAlchemy(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(9803)
				.why("Edit distance match on ala (sala)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(6828)
				.gt("Chamber of Alchemy")
				.tkn("ChamberOfAlchemy")
				.ipei("games/SGP/GamePod/OriginalsIcon.svg")
				.p(4)
				.ibn("ChamberOfAlchemy")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expSpanishBlackjackMultihand(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(4829)
				.why("Full name match on blackjack")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(922)
				.gt("Blackjack - Multi-mano")
				.tkn("BlackjackMultihand")
				.p(2)
				.ibn("BlackjackMultihand")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expSpanishBlackjackSuper21(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(8649)
				.why("Starts with match on blackjack")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(6389)
				.gt("Blackjack Super 21")
				.tkn("BlackjackSuper21")
				.p(2)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expSpanishAmericanBlackjack(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(8648)
				.why("Key word matches on [blackjack]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(6388)
				.gt("American Blackjack")
				.tkn("AmericanBlackjack")
				.p(2)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expChinaBlackKnightIISG(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(9962)
				.why("Full name match on 黑骑士ii")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(6883)
				.gt("黑骑士II")
				.tkn("BlackKnightIISG")
				.p(4)
				.ibn("BlackKnight2")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expMaltaSaharaNights(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(14998)
				.why("Starts with match on saharanights")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(8794)
				.gt("Sahara Nights")
				.tkn("SaharaNights")
				.p(4)
				.ibn("SaharaNights")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expSwedenDolphinGold(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(15647)
				.why("Key word matches on [delfin]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(9355)
				.gt("Dolphin Gold")
				.tkn("DolphinGold")
				.p(4)
				.ibn("DolphinGold")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expGermanAgeOfTheGods(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(4897)
				.why("Edit distance match on god (gods)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(3377)
				.gt("Age of the Gods")
				.tkn("AgeOfTheGods")
				.p(2)
				.ibn("AgeOfTheGods")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expGermanGoddessofWisdom(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(4914)
				.why("Edit distance match on god (gods)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(3394)
				.gt("Age of the Gods: Goddess of Wisdom")
				.tkn("GoddessofWisdom")
				.p(2)
				.ibn("AgeOfTheGodsGoddessOfWisdom")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expGermanAgeoftheGodsFuriousFour(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(4951)
				.why("Edit distance match on god (gods)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(3431)
				.gt("Age of the Gods: Furious 4")
				.tkn("AgeoftheGodsFuriousFour")
				.p(2)
				.ibn(null)
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expGermanAgeoftheGodsKingofOlympus(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(6450)
				.why("Edit distance match on god (gods)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(2216)
				.gt("Age of the Gods: King of Olympus")
				.tkn("AgeoftheGodsKingofOlympus")
				.p(2)
				.ibn("AgeoftheGodsKingofOlympus")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expGermanLiveAgeoftheGodsRoulette(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(8200)
				.why("Edit distance match on god (gods)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(6057)
				.gt("Live Age of the Gods: Roulette")
				.tkn("LiveAgeoftheGodsRoulette")
				.p(2)
				.ibn("LiveAgeoftheGodsRoulette")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expGermanCasinoHoldEm(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(4855)
				.why("Edit distance match on old (hold)")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(1806)
				.gt("Casino Hold 'Em")
				.tkn("CasinoHoldEm")
				.p(2)
				.ibn("CasinoHoldem-Playtech")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}

	public static UserSearchDetails expFireGoddessINS(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(11831)
				.why("Starts with match on firegoddess")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(7745)
				.gt("Fire Goddess")
				.tkn("FireGoddessINS")
				.p(4)
				.ibn("FireGoddess")
				.hci(true)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}
	
	public static UserSearchDetails expSpaceHunter(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(20605)
				.why("Starts with match on spacehunter")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(10901)
				.gt("Space Hunter: Shoot for Cash")
				.tkn("SpaceHunter")
				.p(2)
				.ibn("SpaceHunter")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}
	
	public static UserSearchDetails expDealorNoDealTheBigDraw(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(24786)
				.why("Starts with match on dealornodealthebigdraw")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(12603)
				.gt("Deal or No Deal: The Big Draw")
				.tkn("DealorNoDealTheBigDraw")
				.p(45)
				.ibn("DealOrNoDealTheBigDraw")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}
	
	public static UserSearchDetails expMajorityRulesSpeedBlackjack(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(24792)
				.why("Starts with match on majority rules speed")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(12609)
				.gt("Majority Rules Speed Blackjack")
				.tkn("MajorityRulesSpeedBlackjack")
				.p(45)
				.ibn("LiveMajorityRulesSpeedBlackjck")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}
	
	public static UserSearchDetails expAgeoftheGodsBonusRoulette(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(24777)
				.why("Key word matches on [gods bonus]")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(12594)
				.gt("Age of the Gods Bonus Roulette")
				.tkn("AgeoftheGodsBonusRoulette")
				.p(45)
				.ibn("LiveAgeOfGodsBonusRoulette")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}
	
	public static UserSearchDetails expWildCrusade(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(21700)
				.why("Starts with match on wildcrusade")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(11435)
				.gt("Wild Crusade")
				.tkn("WildCrusade")
				.p(2)
				.ibn("WildCrusade")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}
	
	public static UserSearchDetails expMoneyDrop(UserSearchDetails details) {

		DebugInfo expectedDebugInfo = new DebugInfo.Builder().defaults()
				.indexPriority(details.getDebugInfo().getIndexPriority())
				.indexRanking(details.getDebugInfo().getIndexRanking())
				.productGameId(24794)
				.why("Full name match on money drop")
				.build();

		return new UserSearchDetails.Builder()
				.defaults()
				.id(12611)
				.gt("Money Drop")
				.tkn("MoneyDrop")
				.p(45)
				.ibn("TheMoneyDropLive")
				.hci(null)
				.addDebugInfo(expectedDebugInfo)
				.build();
	}
	
	public static void sortById(GahooSearchResp resp) {

		resp.getResult().sort((a, b) -> a.getId().compareTo(b.getId()));
	}
}
