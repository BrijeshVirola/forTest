package tests.gahoosearchservice.responseobjects;

public class UserSearchDetails {

	protected Integer id;
	protected String gt;
	protected String tkn;
	protected Integer p;
	protected String ibn;
	protected Boolean hci;
	protected String ipei;
	protected DebugInfo debugInfo;

	public UserSearchDetails() {
	}
	
	private UserSearchDetails(Builder builder) {
		this.id = builder.id;
		this.gt = builder.gt;
		this.tkn = builder.tkn;
		this.p = builder.p;
		this.ibn = builder.ibn;
		this.hci = builder.hci;
		this.ipei = builder.ipei;
		this.debugInfo = builder.debugInfo;
	}

	public DebugInfo getDebugInfo(){
		return debugInfo;
	}

	public Integer getId() {
		return id;
	}

	public String getGt() {
		return gt;
	}
	
	public String getTkn() {
		return tkn;
	}
	
	public Integer getP() {
		return p;
	}
	
	public String getIbn() {
		return ibn;
	}
	
	public Boolean getHci() {
		return hci;
	}
	
	public String getIpei() {
		return ipei;
	}

	public static class Builder {
		public Boolean hci;
		public String ibn;
		public Integer p;
		public String tkn;
		public String gt;
		public Integer id;
		public String ipei;
		private DebugInfo debugInfo;

		public Builder id(Integer id) {
			this.id = id;
			return this;
		}

		public Builder ibn(String ibn) {
			this.ibn = ibn;
			return this;
		}

		public Builder p(Integer p) {
			this.p = p;
			return this;
		}

		public Builder tkn(String tkn) {
			this.tkn = tkn;
			return this;
		}

		public Builder gt(String gt) {
			this.gt = gt;
			return this;
		}
		
		public Builder ipei(String ipei) {
			this.ipei = ipei;
			return this;
		}

		public Builder hci(Boolean hci) {
			this.hci = hci;
			return this;
		}
		
      public Builder addDebugInfo(DebugInfo debugInfo) { 
			  this.debugInfo = debugInfo;
			  return this; 
	   }
		 
		public Builder defaults() {
			this.id = 10415;
			this.gt = "games test";		
			this.tkn = "gamestest";	
			this.p = 4;
			this.ibn = "WildWildWest";
			this.hci = true;
			this.debugInfo = new DebugInfo.Builder().defaults().build();
			return this;
		}

		public UserSearchDetails build() {
			UserSearchDetails result = new UserSearchDetails(this);
			return result;
		}
	}
}
