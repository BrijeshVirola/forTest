package tests.gahoosearchservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.enumsconstants.ServiceErrors;
import domain.BaseRequest;
import domain.ErrorResponse;
import io.restassured.response.Response;

public class CommonErrorsAllEndpointsTests extends BaseClassSetup {

	@DataProvider(name = "getEndpoints")
	private Object[] getEndpoints() {
		return new Object[] {"search"};
	}

	@Test(description = "Make a request with GET instead of POST method - Error code 1", dataProvider = "getEndpoints")
	public void get_Method_Instead_Of_Post(String method) {

		Response response = BaseRequest.callEmptyBodyRequest(method , true,
				true, false);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.NOT_HTTP_POST);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with no content type header - Error code 2", dataProvider = "getEndpoints")
	public void header_Content_Type_Not_Set(String method) {

		Response response = BaseRequest.callEmptyBodyRequest(method, true,
				false, true);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.THE_CONTENT_TYPE_HEADER_WAS_MISSING_OR_INVALID);

		assertReflectionEquals(expError, actError);
	}
}
