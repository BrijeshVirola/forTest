package tests.clientresponsiblegamblinglimitservice.enums;

import common.DatabaseQueries;

public enum ClientRespGamblingLimitServiceGRUsers {

	GET_LIMIT_BREACH_POS1("GOSVCGRUSER16"),
	GET_LIMIT_BREACH_POS2("GOSVCGRUSER17"),
	GET_LIMIT_BREACH_POS3("GOSVCGRUSER4"),
	GET_LOGIN_BREACH_POS1("GOSVCGRUSER18"),
	GET_LOGIN_BREACH_POS2("GOSVCGRUSER19"),
	GET_LOGIN_BREACH_POS3("GOSVCARGUSER20"),
	GET_USER_LIMIT_POS1("GOSVCGRUSER3"),
	GET_USER_LIMIT_POS2("GOSVCGRUSER21"),
	GET_USER_LIMIT_POS3("GO_SVC_GR_LIM"),
	GET_USER_LIMIT_POS4("GO_SVC_NL"),
	GET_USER_LIMIT_POS5("GOSVCGRUSER3"),
	HAS_ZERO_LIMIT_POS1("GOSVCGRUSER6"),
	MARK_LBN_SEEN_POS1("GOSVCGRUSER7"),
	MARK_LBN_SEEN_POS2("GOSVCGRUSER25"),
	MARK_LBN_COMPLETE_POS1("GOSVCGRUSER26"),
	MARK_LBN_COMPLETE_POS2("GOSVCGRUSER27"),
	NOTIFY_LOGIN_BREACH_POS1("GOSVCGRUSER8"),
	NOTIFY_LOGIN_BREACH_POS2("GOSVCGRUSER29");

	private String username;

	private ClientRespGamblingLimitServiceGRUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}