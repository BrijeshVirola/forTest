package tests.clientresponsiblegamblinglimitservice.argentinausertests;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.DataProviders;
import common.ExpectedFailure;
import common.Utils;
import domain.BaseRequest;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitEndpoints;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitServiceARGUsers;
import tests.clientresponsiblegamblinglimitservice.request.ClientRespHeaders;
import tests.clientresponsiblegamblinglimitservice.request.GetLimitsReq;
import tests.clientresponsiblegamblinglimitservice.response.ClientRespSvcResp;

public class NotifyLoginBreachTests extends BaseClassSetup {	

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2910")
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to NotifyLoginBreach with glt parameter. Positive scenario.")
	public void NotifyLoginBreach_ARG_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.NOTIFY_LOGIN_BREACH_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("es-AR",10,"011", sessionId);

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		ClientRespSvcResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.notifyloginbreachSuccess, 204,baseUri, headers.getHeaders());

		assertReflectionEquals(actualResponse, null);		
		
		Utils.terminateSessionBySessionId(sessionId);
		
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2910")
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to NotifyLoginBreach without glt parameter. Positive scenario.")
	public void NotifyLoginBreach_without_glt_ARG_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.NOTIFY_LOGIN_BREACH_POS2.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		ClientRespSvcResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.notifyloginbreachSuccess, 204,baseUri, headers.getHeaders());

		assertReflectionEquals(actualResponse, null);		
		
		Utils.terminateSessionBySessionId(sessionId);
		
	}


	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to NotifyLoginBreach without gstk parameter and invalid glt.")
	public void NotifyLoginBreach_ARG_without_gstkCookie(String baseUri) {

		String gltId = UUID.randomUUID().toString();
		
		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		ClientRespSvcResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.notifyloginbreachSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}

	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to NotifyLoginBreach without gstk and glt parameter. Negative scenario.")
	public void NotifyLoginBreach_ARG_without_gstkCookie_glt(String baseUri) {

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		ClientRespSvcResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.notifyloginbreachSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}


}
