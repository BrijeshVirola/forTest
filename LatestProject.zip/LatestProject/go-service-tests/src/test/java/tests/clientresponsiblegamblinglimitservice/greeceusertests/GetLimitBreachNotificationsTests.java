package tests.clientresponsiblegamblinglimitservice.greeceusertests;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.DataProviders;
import common.ExpectedFailure;
import common.Utils;
import domain.BaseRequest;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitEndpoints;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitServiceGRUsers;
import tests.clientresponsiblegamblinglimitservice.request.ClientRespHeaders;
import tests.clientresponsiblegamblinglimitservice.request.GetLimitsReq;
import tests.clientresponsiblegamblinglimitservice.response.BreachLimits;
import tests.clientresponsiblegamblinglimitservice.response.GetLimitBreachNotifResp;

public class GetLimitBreachNotificationsTests extends BaseClassSetup {	

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2910")
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to GetLimitBreachNotifications with glt parameter. Positive scenario.")
	public void GetLimitBreachNotifications_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceGRUsers.GET_LIMIT_BREACH_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("gre",78,"011", sessionId);

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetLimitBreachNotifResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getlimitbreachnotificationsSuccess, baseUri,  headers.getHeaders());

		BreachLimits limit = new BreachLimits.Builder()
				.defaults()
				.build();

		GetLimitBreachNotifResp expectedResponse = new GetLimitBreachNotifResp.Builder()	
				.defaults()
				.addBreach(limit)
				.build();

		assertReflectionEquals(actualResponse, expectedResponse);	

		Utils.terminateSessionBySessionId(sessionId);

	}

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2910")
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to GetLimitBreachNotifications without glt parameter. Positive scenario.")
	public void GetLimitBreachNotifications_without_glt_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceGRUsers.GET_LIMIT_BREACH_POS2.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		GetLimitBreachNotifResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getlimitbreachnotificationsSuccess, baseUri,  headers.getHeaders());

		BreachLimits limit = new BreachLimits.Builder()
				.defaults()
				.build();

		GetLimitBreachNotifResp expectedResponse = new GetLimitBreachNotifResp.Builder()	
				.defaults()
				.addBreach(limit)
				.build();

		assertReflectionEquals(actualResponse, expectedResponse);	

		Utils.terminateSessionBySessionId(sessionId);

	}


	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to GetLimitBreachNotifications without gstk parameter. Negative scenario.")
	public void GetLimitBreachNotifications_without_gstkCookie(String baseUri) {

		String username = ClientRespGamblingLimitServiceGRUsers.GET_LIMIT_BREACH_POS3.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("gre",78,"011", sessionId);

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetLimitBreachNotifResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getlimitbreachnotificationsSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}


	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to GetLimitBreachNotifications without gstk parameter. Negative scenario.")
	public void GetLimitBreachNotifications_without_gstkCookie_glt(String baseUri) {

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		GetLimitBreachNotifResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getlimitbreachnotificationsSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}



}
