package tests.clientresponsiblegamblinglimitservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetUserLimitsResp {
	
	private Integer mb;
	private Map<String, Object> dl = new HashMap<>();
	private Map<String, Object> ll = new HashMap<>();

	public GetUserLimitsResp() {
	}
	
	private GetUserLimitsResp(Builder builder) {
		this.mb = builder.mb;
		this.dl.put("d", builder.d);
		this.dl.put("w", builder.w);
		this.dl.put("m", builder.m);
		this.ll.put("d", builder.dL);
		this.ll.put("w", builder.wL);
		this.ll.put("m", builder.mL);
	}	

	public Integer getMb() {
		return mb;
	}
	
	public Map<String, Object> getDl() {
		return dl;
	}
	
	public Map<String, Object> getLl() {
		return ll;
	}

	public static class Builder {
		private Integer mb, d, w, m, dL, mL, wL;

		public Builder mb(Integer mb) {
			this.mb = mb;
			return this;
		}
		
		public Builder d(Integer d) {
			this.d = d;
			return this;
		}


		public Builder w(Integer w) {
			this.w = w;
			return this;
		}

		public Builder m(Integer m) {
			this.m = m;
			return this;
		}
		public Builder dL(Integer dL) {
			this.dL = dL;
			return this;
		}
		public Builder wL(Integer wL) {
			this.wL = wL;
			return this;
		}
		public Builder mL(Integer mL) {
			this.mL = mL;
			return this;
		}

		public Builder defaults() {
			this.mb = 0;
			this.d = 2500;
			this.w = null;
			this.m = null;
			this.dL = null;
			this.wL = null;
			this.mL = null;
			return this;
		}

		public GetUserLimitsResp build() {
			return new GetUserLimitsResp(this);
		}
	}
}
