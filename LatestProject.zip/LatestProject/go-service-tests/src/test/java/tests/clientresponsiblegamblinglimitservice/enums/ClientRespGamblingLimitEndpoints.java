package tests.clientresponsiblegamblinglimitservice.enums;

import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.clientresponsiblegamblinglimitservice.response.ClientRespSvcResp;
import tests.clientresponsiblegamblinglimitservice.response.GetUserLimitsResp;
import tests.clientresponsiblegamblinglimitservice.response.HasZeroLimitsResponse;

public enum ClientRespGamblingLimitEndpoints implements ResponseEndpoints {

	haszerolimitSuccess(HasZeroLimitsResponse.class, "haszerolimit"),
	haszerolimitError(CustomErrorResponse.class, "haszerolimit"),
	marklimitbreachnotificationsascompleteSuccess(ClientRespSvcResp.class, "marklimitbreachnotificationsascomplete"),
	marklimitbreachnotificationsascompleteError(CustomErrorResponse.class, "marklimitbreachnotificationsascomplete"),
	marklimitbreachnotificationAsSeenSuccess(ClientRespSvcResp.class, "marklimitbreachnotificationsasseen"),
	marklimitbreachnotificationAsSeenError(CustomErrorResponse.class, "marklimitbreachnotificationsasseen"),
	getuserlimitsSuccess(GetUserLimitsResp.class, "getuserlimits"),
	getuserlimitsError(CustomErrorResponse.class, "getuserlimits"),
	notifyloginbreachSuccess(ClientRespSvcResp.class, "notifyloginbreach"),
	notifyloginbreachError(CustomErrorResponse.class, "notifyloginbreach"),
	getloginbreachdetailsSuccess(ClientRespSvcResp.class, "getloginbreachdetails"),
	getloginbreachdetailsError(CustomErrorResponse.class, "getloginbreachdetails"),
	getlimitbreachnotificationsSuccess(ClientRespSvcResp.class, "getlimitbreachnotifications"),
	getlimitbreachnotificationsError(CustomErrorResponse.class, "getlimitbreachnotifications");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> ClientRespGamblingLimitEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
