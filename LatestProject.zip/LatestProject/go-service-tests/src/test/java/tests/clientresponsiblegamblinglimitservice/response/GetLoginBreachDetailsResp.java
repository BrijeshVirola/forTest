package tests.clientresponsiblegamblinglimitservice.response;


public class GetLoginBreachDetailsResp {
	
	private Integer bi;
	private String bt;
	
	public GetLoginBreachDetailsResp() {
	}
	
	private GetLoginBreachDetailsResp(Builder builder) {
		this.bi = builder.bi;
		this.bt = builder.bt;
	}	

	public Integer getBi() {
		return bi;
	}

	public String getBt() {
		return bt;
	}

	public static class Builder {
		private Integer bi;
		private String bt;

		public Builder bi(Integer bi) {
			this.bi = bi;
			return this;
		}
		
		public Builder bt(String bt) {
			this.bt = bt;
			return this;
		}

		public Builder defaults() {
			this.bi = 123000;
			this.bt = "DepositLimitsEightyPercentWeekly";
			return this;
		}

		public GetLoginBreachDetailsResp build() {
			return new GetLoginBreachDetailsResp(this);
		}
	}
}
