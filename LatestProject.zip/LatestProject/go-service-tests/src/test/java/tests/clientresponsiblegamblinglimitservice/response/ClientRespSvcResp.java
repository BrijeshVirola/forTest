package tests.clientresponsiblegamblinglimitservice.response;

public class ClientRespSvcResp {

	public ClientRespSvcResp() {
	}
	
	private ClientRespSvcResp(Builder builder) {
	}

	public static class Builder {
		public ClientRespSvcResp build() {
			return new ClientRespSvcResp(this);
		}
	}
}
