package tests.clientresponsiblegamblinglimitservice.response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class GetLimitBreachNotifResp {
	
	private Integer cs;
	private String t;	
	private String cit;
	private Map<String, ArrayList<BreachLimits>> b = new HashMap<>();
	
	public GetLimitBreachNotifResp() {
	}
	
	private GetLimitBreachNotifResp(Builder builder) {
		this.t = builder.t;
		this.cit = builder.cit;
		this.cs = builder.cs;
		this.b.put("b", builder.b);		

	}	

	public Integer getCs() {
		return cs;
	}

	public String getT() {
		return t;
	}

	public String getCit() {
		return cit;
	}
	
	public Map<String, ArrayList<BreachLimits>> getB() {
		return b;
	}

	public static class Builder {
		private Integer cs;
		private String t, cit;
		private ArrayList<BreachLimits> b;


		public Builder bi(Integer cs) {
			this.cs = cs;
			return this;
		}
		
		public Builder bt(String t) {
			this.t = t;
			return this;
		}

		public Builder cit(String cit) {
			this.cit = cit;
			return this;
		}
		
		public Builder addBreach(BreachLimits bl) {
			b.add(bl);
			return this;
		}

		public Builder defaults() {
			this.t = "Important information about your limits";
			this.cit = "Closing in {0}s";
			this.cs = 15;
			this.b = new ArrayList<BreachLimits>();

			return this;
		}

		public GetLimitBreachNotifResp build() {
			return new GetLimitBreachNotifResp(this);
		}
	}
}
