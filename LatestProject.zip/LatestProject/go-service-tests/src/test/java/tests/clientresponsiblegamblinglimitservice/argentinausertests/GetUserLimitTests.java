package tests.clientresponsiblegamblinglimitservice.argentinausertests;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.DataProviders;
import common.Utils;
import domain.BaseRequest;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitEndpoints;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitServiceARGUsers;
import tests.clientresponsiblegamblinglimitservice.request.ClientRespHeaders;
import tests.clientresponsiblegamblinglimitservice.request.GetLimitsReq;
import tests.clientresponsiblegamblinglimitservice.response.GetUserLimitsResp;

public class GetUserLimitTests extends BaseClassSetup {	

	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to GetUserLimit with glt parameter. Positive scenario.")
	public void GetUserLimit_ARG_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_USER_LIMIT_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("es-AR",10,"011", sessionId);

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetUserLimitsResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getuserlimitsSuccess, baseUri,  headers.getHeaders());

		GetUserLimitsResp expectedResponse =  new GetUserLimitsResp.Builder()
				.defaults()
				.d(500000).m(null)
				.dL(null).wL(6000).mL(null)//pre-defined limit values
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);		
		
		Utils.terminateSessionBySessionId(sessionId);

	}
	
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to GetUserLimit without glt parameter. Positive scenario.")
	public void GetUserLimit_ARG_without_glt_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_USER_LIMIT_POS2.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		GetUserLimitsResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getuserlimitsSuccess, baseUri,  headers.getHeaders());

		GetUserLimitsResp expectedResponse =  new GetUserLimitsResp.Builder()
				.defaults()
				.d(10000).m(null)
				.dL(null).wL(6000).mL(null)//pre-defined limit values
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);		
		
		Utils.terminateSessionBySessionId(sessionId);

	}
	
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to GetUserLimit with glt parameter for user with 0 gaming loss limit. Positive scenario.")
	public void GetUserLimit_Zero_Gaming_ARG_Limit_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_USER_LIMIT_POS3.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("es-AR",10,"011", sessionId);


		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetUserLimitsResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getuserlimitsSuccess, baseUri, headers.getHeaders());

		GetUserLimitsResp expectedResponse =  new GetUserLimitsResp.Builder()
				.mb(0)
				.d(5) // Predefined Deposit limit values
				.dL(null).wL(null).mL(null) // Predefined Login limit values
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);		
		
		Utils.terminateSessionBySessionId(sessionId);

	}

	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to GetUserLimit with glt parameter for NL User. Positive scenario.")
	public void GetUserLimit_NL_User_ARGPositive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_USER_LIMIT_POS4.getUsername(); // NL user with predefined deposit and login limit values
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("es-AR",10,"089", sessionId);

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetUserLimitsResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getuserlimitsSuccess, headers.getHeaders());

		GetUserLimitsResp expectedResponse =  new GetUserLimitsResp.Builder()
				.defaults()
				.mb(100)
				.d(500).w(1000).m(2000) // Predefined Deposit limit values
				.dL(2).wL(10080).mL(44640) // Predefined Login limit values
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);		
		
		Utils.terminateSessionBySessionId(sessionId);

	}


	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to GetUserLimit without gstk parameter and valid glt. Positive scenario.")
	public void GetUserLimit_ARG_without_gstkCookie(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_USER_LIMIT_POS5.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("es-AR",10,"011", sessionId);
		
		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetUserLimitsResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getuserlimitsSuccess, baseUri);

		GetUserLimitsResp expectedResponse =  new GetUserLimitsResp.Builder()
				.defaults()
				.d(10000).m(null)
				.dL(null).wL(6000).mL(null)//pre-defined limit values
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);		
		
		Utils.terminateSessionBySessionId(sessionId);	
	}
	
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to GetUserLimit without gstk parameter and invalid glt. Negative scenario.")
	public void GetUserLimit_ARG_without_gstkCookie_invalid_glt(String baseUri) {

		String gltId = UUID.randomUUID().toString();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetUserLimitsResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getuserlimitsSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}


	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to GetUserLimit without gstk parameter. Negative scenario.")
	public void GetUserLimit_ARG_without_gstkCookie_glt(String baseUri) {


		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		GetUserLimitsResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getuserlimitsSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}

}
