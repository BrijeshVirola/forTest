package tests.clientresponsiblegamblinglimitservice.greeceusertests;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.DataProviders;
import common.Utils;
import domain.BaseRequest;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitEndpoints;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitServiceGRUsers;
import tests.clientresponsiblegamblinglimitservice.request.ClientRespHeaders;
import tests.clientresponsiblegamblinglimitservice.request.GetLimitsReq;
import tests.clientresponsiblegamblinglimitservice.response.HasZeroLimitsResponse;

public class HasZeroLimitTests extends BaseClassSetup {	

	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to HasZeroLimits with glt parameter. Positive scenario.")
	public void HasZeroLimits_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceGRUsers.HAS_ZERO_LIMIT_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("gre",78,"011", sessionId);

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		HasZeroLimitsResponse actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.haszerolimitSuccess, 200, baseUri, headers.getHeaders());

		HasZeroLimitsResponse expectedResponse =  new HasZeroLimitsResponse.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
		
		Utils.terminateSessionBySessionId(sessionId);

	}
	
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to HasZeroLimits without glt parameter. Positive scenario.")
	public void HasZeroLimits_without_glt_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceGRUsers.HAS_ZERO_LIMIT_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		HasZeroLimitsResponse actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.haszerolimitSuccess, 200, baseUri, headers.getHeaders());

		HasZeroLimitsResponse expectedResponse =  new HasZeroLimitsResponse.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
		
		Utils.terminateSessionBySessionId(sessionId);

	}

	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to HasZeroLimits without gstk parameter and valid glt. Positive scenario.")
	public void HasZeroLimits_without_gstkCookie_valid_glt(String baseUri) {

		String username = ClientRespGamblingLimitServiceGRUsers.HAS_ZERO_LIMIT_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("gre",78,"011", sessionId);
		
		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();
		
		HasZeroLimitsResponse actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.haszerolimitSuccess, baseUri);

		HasZeroLimitsResponse expectedResponse =  new HasZeroLimitsResponse.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
		
		Utils.terminateSessionBySessionId(sessionId);

	}

	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to HasZeroLimits existing_session. Negative scenario.")
	public void HasZeroLimits_existing_session(String baseUri) {
		
		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.build();

		HasZeroLimitsResponse actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.haszerolimitSuccess, 401, baseUri, headers.getHeaders());

		Assert.assertEquals(actualResponse, null);	
	}
	
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to HasZeroLimits without gstk parameter and invalid glt. Negative scenario.")
	public void HasZeroLimits_without_gstkCookie_invalid_glt(String baseUri) {
	
		String gltId = UUID.randomUUID().toString();
		
		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		HasZeroLimitsResponse actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.haszerolimitSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}
	
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to HasZeroLimits without gstk parameter and glt. Negative scenario.")
	public void HasZeroLimits_without_gstkCookie_glt(String baseUri) {
	
		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		HasZeroLimitsResponse actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.haszerolimitSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}

}
