package tests.clientresponsiblegamblinglimitservice.request;

import java.util.ArrayList;
import java.util.List;

public class MarkLimitBreachNotificationReq {

	private List<Integer> ubiid;


	private MarkLimitBreachNotificationReq(Builder builder) {
		this.ubiid = builder.ubiid;
	}

	public List<Integer> getUbiid() {
		return ubiid;
	}
	
	public static class Builder {
		private List<Integer> ubiid;

		public Builder addUbiid(Integer ubiid) {
			this.ubiid.add(ubiid);
			return this;
		}
		
		public Builder defaults() {
			this.ubiid = new ArrayList<Integer>();
			return this;
		}
		
		public MarkLimitBreachNotificationReq build() {
			return new MarkLimitBreachNotificationReq(this);
		}
	}
}
