package tests.clientresponsiblegamblinglimitservice.argentinausertests;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.DataProviders;
import common.Utils;
import domain.BaseRequest;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitEndpoints;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitServiceARGUsers;
import tests.clientresponsiblegamblinglimitservice.request.ClientRespHeaders;
import tests.clientresponsiblegamblinglimitservice.request.MarkLimitBreachNotificationReq;
import tests.clientresponsiblegamblinglimitservice.response.ClientRespSvcResp;

public class MarkLimitBreachNotificationCompleteTests extends BaseClassSetup {	

	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to MarkLimitBreachNotificationComplete  with glt parameter. Positive scenario.")
	public void MarkLimitBreachNotificationComplete_ARG__Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.MARK_LBN_COMPLETE_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		MarkLimitBreachNotificationReq request = new MarkLimitBreachNotificationReq.Builder()
				.defaults()
				.addUbiid(1051)
				.addUbiid(1052)
				.build();

		ClientRespSvcResp actualResponse =  BaseRequest.post(request, ClientRespGamblingLimitEndpoints.marklimitbreachnotificationsascompleteSuccess, baseUri, 204, headers.getHeaders());

		assertReflectionEquals(actualResponse, null);		
		
		Utils.terminateSessionBySessionId(sessionId);

	}


	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to MarkLimitBreachNotificationComplete without gstk parameter. Negative scenario.")
	public void MarkLimitBreachNotificationComplete_ARG__without_gstkCookie(String baseUri) {

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(null)
				.build();

		MarkLimitBreachNotificationReq request = new MarkLimitBreachNotificationReq.Builder()
				.defaults()
				.addUbiid(1051)
				.addUbiid(1052)
				.build();

		ClientRespSvcResp actualResponse =  BaseRequest.post(request, ClientRespGamblingLimitEndpoints.marklimitbreachnotificationsascompleteSuccess, baseUri, 400, headers.getHeaders());

		assertReflectionEquals(actualResponse, null);	
	}

	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, description = "Make a request to MarkLimitBreachNotificationCompleteTests without ubiid - defaults to 0.")
	public void MarkLimitBreachNotificationComplete_ARG_without_ubiid(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.MARK_LBN_COMPLETE_POS2.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		MarkLimitBreachNotificationReq request = new MarkLimitBreachNotificationReq.Builder()
				.defaults()
				.addUbiid(null)
				.build();

		ClientRespSvcResp actualResponse =  BaseRequest.post(request, ClientRespGamblingLimitEndpoints.marklimitbreachnotificationsascompleteSuccess, baseUri, 204, headers.getHeaders());

		assertReflectionEquals(actualResponse, null);	
		
		Utils.terminateSessionBySessionId(sessionId);

	}

}
