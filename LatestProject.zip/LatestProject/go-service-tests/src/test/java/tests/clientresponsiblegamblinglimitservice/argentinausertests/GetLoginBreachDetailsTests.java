package tests.clientresponsiblegamblinglimitservice.argentinausertests;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.DataProviders;
import common.Utils;
import domain.BaseRequest;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitEndpoints;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitServiceARGUsers;
import tests.clientresponsiblegamblinglimitservice.request.ClientRespHeaders;
import tests.clientresponsiblegamblinglimitservice.request.GetLimitsReq;
import tests.clientresponsiblegamblinglimitservice.response.ClientRespSvcResp;
import tests.clientresponsiblegamblinglimitservice.response.GetLoginBreachDetailsResp;

public class GetLoginBreachDetailsTests extends BaseClassSetup {	

	//Endpoint not developed

	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to NotifyLoginBreach with glt parameter. Positive scenario.")
	public void GetLoginBreachDetails_ARG_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_LOGIN_BREACH_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("es-AR",10,"011", sessionId);


		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetLoginBreachDetailsResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getloginbreachdetailsSuccess, 204, baseUri, headers.getHeaders());

		assertReflectionEquals(actualResponse, null);	
		
		Utils.terminateSessionBySessionId(sessionId);

	}
	
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to NotifyLoginBreach without glt parameter. Positive scenario.")
	public void GetLoginBreachDetails_ARG_without_glt_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_LOGIN_BREACH_POS2.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();


		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		GetLoginBreachDetailsResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getloginbreachdetailsSuccess, 204, baseUri, headers.getHeaders());

		assertReflectionEquals(actualResponse, null);	
		
		Utils.terminateSessionBySessionId(sessionId);

	}


	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to NotifyLoginBreach without gstk parameter Valid Glt. Negative scenario.")
	public void GetLoginBreachDetails_ARG_without_gstkCookie(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_LOGIN_BREACH_POS3.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("es-AR",10,"011", sessionId);	

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		ClientRespSvcResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getloginbreachdetailsSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}
	
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to NotifyLoginBreach without gstk parameter and Glt. Negative scenario.")
	public void GetLoginBreachDetails_ARG_without_gstkCookie_glt(String baseUri) {

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		ClientRespSvcResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getloginbreachdetailsSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}



}
