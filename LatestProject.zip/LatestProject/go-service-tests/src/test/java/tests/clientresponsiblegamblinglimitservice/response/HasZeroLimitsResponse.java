package tests.clientresponsiblegamblinglimitservice.response;


public class HasZeroLimitsResponse {
	
	private Boolean r;
	
	public HasZeroLimitsResponse() {
	}
	
	private HasZeroLimitsResponse(Builder builder) {
		this.r = builder.r;
	}	

	public Boolean getR() {
		return r;
	}

	public static class Builder {
		private Boolean r;

		public Builder r(Boolean r) {
			this.r = r;
			return this;
		}

		public Builder defaults() {
			this.r = true;
			return this;
		}

		public HasZeroLimitsResponse build() {
			return new HasZeroLimitsResponse(this);
		}
	}
}
