package tests.clientresponsiblegamblinglimitservice.argentinausertests;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.DataProviders;
import common.ExpectedFailure;
import common.Utils;
import domain.BaseRequest;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitEndpoints;
import tests.clientresponsiblegamblinglimitservice.enums.ClientRespGamblingLimitServiceARGUsers;
import tests.clientresponsiblegamblinglimitservice.request.ClientRespHeaders;
import tests.clientresponsiblegamblinglimitservice.request.GetLimitsReq;
import tests.clientresponsiblegamblinglimitservice.response.BreachLimits;
import tests.clientresponsiblegamblinglimitservice.response.GetLimitBreachNotifResp;

public class GetLimitBreachNotificationsTests extends BaseClassSetup {	

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2910")
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to GetLimitBreachNotifications with glt parameter. Positive scenario.")
	public void GetLimitBreachNotifications_ARG_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_LIMIT_BREACH_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("es-AR",10,"011", sessionId);


		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetLimitBreachNotifResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getlimitbreachnotificationsSuccess, baseUri,  headers.getHeaders());

		BreachLimits limit = new BreachLimits.Builder()
				.defaults()
				.build();

		GetLimitBreachNotifResp expectedResponse = new GetLimitBreachNotifResp.Builder()	
				.defaults()
				.addBreach(limit)
				.build();

		assertReflectionEquals(actualResponse, expectedResponse);
		
		Utils.terminateSessionBySessionId(sessionId);

	}

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2910")
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to GetLimitBreachNotifications with glt parameter. Positive scenario.")
	public void GetLimitBreachNotifications_ARG_Without_glt_Positive_Scenario(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_LIMIT_BREACH_POS2.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();


		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		GetLimitBreachNotifResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getlimitbreachnotificationsSuccess, baseUri,  headers.getHeaders());

		BreachLimits limit = new BreachLimits.Builder()
				.defaults()
				.build();

		GetLimitBreachNotifResp expectedResponse = new GetLimitBreachNotifResp.Builder()	
				.defaults()
				.addBreach(limit)
				.build();

		assertReflectionEquals(actualResponse, expectedResponse);
		
		Utils.terminateSessionBySessionId(sessionId);

	}

	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to GetLimitBreachNotifications without gstk parameter and valid glt. Positive scenario.")
	public void GetLimitBreachNotifications_ARG_without_gstkCookie_valid_glt(String baseUri) {

		String username = ClientRespGamblingLimitServiceARGUsers.GET_LIMIT_BREACH_POS3.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltToken("es-AR",10,"011", sessionId);
		
		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetLimitBreachNotifResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getlimitbreachnotificationsSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}
	
	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to GetLimitBreachNotifications without gstk parameter and valid glt. Negative scenario.")
	public void GetLimitBreachNotifications_ARG_without_gstkCookie_invalid_glt(String baseUri) {

	    String gltId = UUID.randomUUID().toString();
		
		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(gltId)
				.build();

		GetLimitBreachNotifResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getlimitbreachnotificationsSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}


	@Test(dataProvider = "getClientRespLimitSvcBAseUri", dataProviderClass = DataProviders.class, enabled=false, description = "Make a request to GetLimitBreachNotifications without gstk and glt parameter. Negative scenario.")
	public void GetLimitBreachNotifications_ARG_without_gstkCookie_glt(String baseUri) {

		GetLimitsReq request = new GetLimitsReq.Builder()
				.defaults()
				.glt(null)
				.build();

		GetLimitBreachNotifResp actualResponse =  BaseRequest.get(request.getParameters(), ClientRespGamblingLimitEndpoints.getlimitbreachnotificationsSuccess, 400, baseUri);

		Assert.assertEquals(actualResponse, null);		
	}


}
