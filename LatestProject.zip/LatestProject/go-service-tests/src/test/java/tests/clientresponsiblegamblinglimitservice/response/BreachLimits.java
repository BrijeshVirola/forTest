package tests.clientresponsiblegamblinglimitservice.response;

public class BreachLimits {

	private String bt;
	private String bdt;
	private String bt1;
	private String bt2;
	private Integer ubiid;
	private String bs;
	
	public BreachLimits() {
	}

	private BreachLimits(Builder builder) {
		this.bt = builder.bt;
		this.bdt = builder.bdt;
		this.bt1 = builder.bt1;
		this.bt2 = builder.bt2;
		this.ubiid = builder.ubiid;
		this.bs = builder.bs;
	}	

	public String getBt() {
		return bt;
	}

	public String getBdt() {
		return bdt;
	}

	public String getBt1() {
		return bt1;
	}

	public String getBt2() {
		return bt2;
	}

	public Integer getUbiid() {
		return ubiid;
	}

	public String getBs() {
		return bs;
	}

	public static class Builder {

		private String bt, bdt, bt1, bt2, bs;
		private Integer ubiid;

		public Builder bt(String bt) {
			this.bt = bt;
			return this;
		}

		public Builder bdt(String bdt) {
			this.bdt = bdt;
			return this;
		}

		public Builder bt1(String bt1) {
			this.bt1 = bt1;
			return this;
		}

		public Builder bt2(String bt2) {
			this.bt2 = bt2;
			return this;
		}

		public Builder productId(Integer ubiid) {
			this.ubiid = ubiid;
			return this;
		}

		public Builder bs(String bs) {
			this.bs = bs;
			return this;
		}


		public Builder defaults() {
			this.bt = "LossLimitsGamingEightyPercentMonthly";
			this.bdt = "2021-11-11T16:55:01.33473";
			this.bt1 = "Approaching monthly Gaming loss limit of �5.00";
			this.bt2 = "Currently �4.00";
			this.ubiid = 19425;
			this.bs = "NotSeen";

			return this;
		}

		public BreachLimits build() {
			BreachLimits b = new BreachLimits(this);
			return b;
		}
	}
}

