package tests.gamenocitylimitlaunchservice.response;

public class GetApiAssetResp {	

}

