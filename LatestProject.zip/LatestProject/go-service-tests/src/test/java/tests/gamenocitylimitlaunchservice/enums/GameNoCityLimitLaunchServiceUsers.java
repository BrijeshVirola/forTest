package tests.gamenocitylimitlaunchservice.enums;

import common.DatabaseQueries;

public enum GameNoCityLimitLaunchServiceUsers {

	POST_HTML_POS1("GAMENCL01"),
	POST_HTML_NEG("GAMENCL99");

	private String username;

	private GameNoCityLimitLaunchServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}