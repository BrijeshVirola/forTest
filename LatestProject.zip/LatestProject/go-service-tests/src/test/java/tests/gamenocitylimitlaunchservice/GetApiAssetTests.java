package tests.gamenocitylimitlaunchservice;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import common.BaseURI;
import domain.BaseRequest;
import io.restassured.response.Response;
import tests.gamenocitylimitlaunchservice.enums.GameNoCityLimitLaunchEndpoints;

public class GetApiAssetTests extends BaseURI {

	@Test(description = "Make a CSS get request. Positive scenario.")
	public void cssRequestPositiveScenario() {

		Response response  = BaseRequest.getTextResponse(GameNoCityLimitLaunchEndpoints.assetCssSuccess, 200, GAME_NO_CITY_LIMIT_ASSET_SERVICE);

		assertEquals(response.headers().get("Content-Type").toString(), ("Content-Type=text/css; charset=utf-8"));

		assertEquals(response.getBody().asString().substring(0, 4), "body");

	}

	@Test(description = "Make a JS get request. Positive scenario.")
	public void jsRequestPositiveScenario() {

		Response response = BaseRequest.getTextResponse(GameNoCityLimitLaunchEndpoints.assetJsSuccess, 200, GAME_NO_CITY_LIMIT_ASSET_SERVICE);

		assertEquals(response.headers().get("Content-Type").toString(), ("Content-Type=text/javascript; charset=utf-8"));

		assertEquals(response.getBody().asString().substring(0, 3), "var");

	}

	@Test(description = "Make a get request with missing endpoint. Negative scenario.")
	public void requestNegativeScenarioMissingEndPoint() {

		Response response = BaseRequest.getTextResponse(GameNoCityLimitLaunchEndpoints.assetJsError, 404, GAME_NO_CITY_LIMIT_ASSET_SERVICE);

		assertEquals(response.headers().get("Content-Type").toString(), ("Content-Type=text/plain; charset=utf-8"));

		assertThat(response.getBody().asString(), containsString("404 page not found"));

	}

	@Test(description = "Make a get request with invalid endpoint. Negative scenario.")
	public void requestNegativeScenarioInvalidEndPoint() {

		Response response = BaseRequest.getTextResponse(GameNoCityLimitLaunchEndpoints.assetCssError, 404, GAME_NO_CITY_LIMIT_ASSET_SERVICE);

		assertEquals(response.headers().get("Content-Type"), null);

		assertEquals(response.getBody().asString(), "");

	}

}
