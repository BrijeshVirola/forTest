package tests.gbtenabledservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.gbtenabledservice.response.GbtEnabledProductsPerCountryResp;
import tests.gbtenabledservice.response.IsGbtEnabledResp;

public enum GbtEnabledEndpoints implements ResponseEndpoints {

	postIsEnabledSuccess(IsGbtEnabledResp.class, "isGbtEnabled"),
	postGbtEnabledProductsPerCountrySuccess(GbtEnabledProductsPerCountryResp.class, "GbtEnabledProductsPerCountry"),
	gbtEnabledProductsPerCountryQueryError(CustomErrorResponse.class, "GbtEnabledProductsPerCountry"),
	gbtEnabledRequestError(CustomErrorResponse.class, "isGbtEnabled");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GbtEnabledEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
