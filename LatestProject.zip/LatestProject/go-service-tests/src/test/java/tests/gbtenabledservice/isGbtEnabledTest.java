package tests.gbtenabledservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gbtenabledservice.enums.GbtEnabledEndpoints;
import tests.gbtenabledservice.enums.GbtEnabledServiceUsers;
import tests.gbtenabledservice.request.GbtEnabledDetailsReq;
import tests.gbtenabledservice.response.IsGbtEnabledResp;


public class isGbtEnabledTest extends BaseClassSetup {

	@Test(description = "Make a request to post GBT Enabled Method. Positive scenario.")

	public void postGbtEnabled_Positive_Scenario() {

		GbtEnabledDetailsReq gbtEnabledRequest = new GbtEnabledDetailsReq.Builder()
				.defaults()
				.id(GbtEnabledServiceUsers.IS_GBT_ENABLED_POS.getUserId())
				.build();

		IsGbtEnabledResp actualGbtEnabledResponse =  BaseRequest.post(gbtEnabledRequest, GbtEnabledEndpoints.postIsEnabledSuccess);

		IsGbtEnabledResp expectedGbtEnabledResponse =  new IsGbtEnabledResp.Builder()
				.defaults()
				.id(GbtEnabledServiceUsers.IS_GBT_ENABLED_POS.getUserId())
				.build();

		assertReflectionEquals(expectedGbtEnabledResponse, actualGbtEnabledResponse);
	}

	@Test(description = "Make a request to isGbtEnabled. Wrong method.")
	public void isGbtEnabled_Wrong_Method() {

		GbtEnabledDetailsReq request = new GbtEnabledDetailsReq.Builder()
				.defaults()
				.id(GbtEnabledServiceUsers.IS_GBT_ENABLED_NEG.getUserId())
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GbtEnabledEndpoints.gbtEnabledRequestError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to isGbtEnabled. Missing parameter: product_id.")
	public void isGbtEnabled_MissingProductId_Parameter() {

		GbtEnabledDetailsReq request = new GbtEnabledDetailsReq.Builder()
				.defaults()
				.productId(null)
				.id(GbtEnabledServiceUsers.IS_GBT_ENABLED_NEG.getUserId())
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GbtEnabledEndpoints.gbtEnabledRequestError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: product_id")
				.id(GbtEnabledServiceUsers.IS_GBT_ENABLED_NEG.getUserId())
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to isGbtEnabled. Missing parameter: country_id.")
	public void isGbtEnabled_MissingCountryId_Parameter() {

		GbtEnabledDetailsReq request = new GbtEnabledDetailsReq.Builder()
				.defaults()
				.countryId(null)
				.id(GbtEnabledServiceUsers.IS_GBT_ENABLED_NEG.getUserId())
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GbtEnabledEndpoints.gbtEnabledRequestError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: country_id")
				.id(GbtEnabledServiceUsers.IS_GBT_ENABLED_NEG.getUserId())
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}

