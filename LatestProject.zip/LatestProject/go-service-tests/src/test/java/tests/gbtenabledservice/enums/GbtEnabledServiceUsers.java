package tests.gbtenabledservice.enums;

import common.DatabaseQueries;

public enum GbtEnabledServiceUsers {
	
	GBT_ENABLED_PRODUCTS_POS("GO_GBT_ENAB1"),
	GBT_ENABLED_PRODUCTS_NEG("GO_GBT_ENAB2"),
	IS_GBT_ENABLED_POS("GO_GBT_ENAB3"),
	IS_GBT_ENABLED_NEG("GO_GBT_ENAB4");

	private String username;

	private GbtEnabledServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public String getUserId() {
		return String.valueOf(DatabaseQueries.getUserIdFromUserTable(getUsername()));
	}
}