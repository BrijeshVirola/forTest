package tests.gbtenabledservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gbtenabledservice.enums.GbtEnabledEndpoints;
import tests.gbtenabledservice.enums.GbtEnabledServiceUsers;
import tests.gbtenabledservice.request.GbtEnabledProductsPerCountryReq;
import tests.gbtenabledservice.response.GbtEnabledProductsPerCountryResp;

public class GbtEnabledProductsPerCountryTest extends BaseClassSetup {


	@Test(description = "Make a request to post GBT Enabled Products Per Country Method. Positive scenario.")

	public void postGbtEnabledProductsPerCountry_Positive_Scenario() {

		GbtEnabledProductsPerCountryReq gbtEnabledProductsPerCountryRequest = new GbtEnabledProductsPerCountryReq.Builder()
				.defaults()
				.id(GbtEnabledServiceUsers.GBT_ENABLED_PRODUCTS_POS.getUserId())
				.build();

		GbtEnabledProductsPerCountryResp actualGbtEnabledProductsPerCountryResponse =  BaseRequest.post(gbtEnabledProductsPerCountryRequest, GbtEnabledEndpoints.postGbtEnabledProductsPerCountrySuccess);

		GbtEnabledProductsPerCountryResp expectedGbtEnabledProductsPerCountryResponse =  new GbtEnabledProductsPerCountryResp.Builder()
				.defaults()
				.addProduct(2)
				.addProduct(4)
				.id(GbtEnabledServiceUsers.GBT_ENABLED_PRODUCTS_POS.getUserId())
				.build();

		assertReflectionEquals(expectedGbtEnabledProductsPerCountryResponse, actualGbtEnabledProductsPerCountryResponse);
	}


	@Test(description = "Make a request to GbtEnabledProductsPerCountry. Wrong method.")
	public void GbtEnabledProductsPerCountry_Wrong_Method() {

		GbtEnabledProductsPerCountryReq request = new GbtEnabledProductsPerCountryReq.Builder()
				.defaults()
				.id(GbtEnabledServiceUsers.GBT_ENABLED_PRODUCTS_NEG.getUserId())
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GbtEnabledEndpoints.gbtEnabledProductsPerCountryQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GbtEnabledProductsPerCountry. Missing parameter: country_id.")
	public void GbtEnabledProductsPerCountry_MissingCountryId_Parameter() {

		GbtEnabledProductsPerCountryReq request = new GbtEnabledProductsPerCountryReq.Builder()
				.defaults()
				.countryId(null)
				.id(GbtEnabledServiceUsers.GBT_ENABLED_PRODUCTS_NEG.getUserId())
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GbtEnabledEndpoints.gbtEnabledProductsPerCountryQueryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: country_id")
				.id(GbtEnabledServiceUsers.GBT_ENABLED_PRODUCTS_NEG.getUserId())
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
