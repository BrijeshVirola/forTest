package tests.gameelklaunchservice.response;

public class GetApiAssetResp {	

}

