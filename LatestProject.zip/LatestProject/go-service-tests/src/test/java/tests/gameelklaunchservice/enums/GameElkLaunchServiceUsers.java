package tests.gameelklaunchservice.enums;

import common.DatabaseQueries;

public enum GameElkLaunchServiceUsers {

	POST_HTML_POS1("GAMELKLNCH01"),
	POST_HTML_NEG("GAMELKLNCH02");

	private String username;

	private GameElkLaunchServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}