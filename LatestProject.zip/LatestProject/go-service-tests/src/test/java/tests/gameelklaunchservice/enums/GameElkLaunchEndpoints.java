package tests.gameelklaunchservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.gameelklaunchservice.response.GetApiAssetResp;
import tests.gameelklaunchservice.response.PostApiHtmlResp;

public enum GameElkLaunchEndpoints implements ResponseEndpoints {

	htmlError(CustomErrorResponse.class, "api/html"),
	htmlSuccess(PostApiHtmlResp.class, "api/html"),
	assetJsError(CustomErrorResponse.class, ""),
	assetJsSuccess(GetApiAssetResp.class, "asset/js"),
	assetCssError(CustomErrorResponse.class, "asset/cssx"),
	assetCssSuccess(GetApiAssetResp.class, "asset/css");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GameElkLaunchEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
