package tests.gamesservice.responseobjects;

public class RegulatedGame {
	
	private Integer regulated_game_id;
	private Integer game_id;
	private Integer regulated_zone_id;
	private String provider_game_reference;
	private String private_partner_game_id;
	private String regulatory_game_reference;
	private Integer provider_region_id;
	private Integer product_id;
	private Integer platform_type_id;
	private Integer cms_core_game_id;
	private Integer partner_id;
	private Integer game_play_technology_id;
	private Integer provider_id;
	private String game_name;
	private Boolean is_multistage;
	private String bonus_game_type;
	private Integer return_delay_in_seconds;
	private Boolean is_visible;
	private Integer provider_implementation_id;
	private Integer game_round_duration_seconds;
	private Integer game_type_id;

	public RegulatedGame() {
	}
	
	private RegulatedGame(Builder builder) {
		this.regulated_game_id = builder.regulated_game_id;
		this.game_id = builder.game_id;
		this.regulated_zone_id = builder.regulated_zone_id;
		this.provider_game_reference = builder.provider_game_reference;
		this.private_partner_game_id = builder.private_partner_game_id;
		this.regulatory_game_reference = builder.regulatory_game_reference;
		this.provider_region_id = builder.provider_region_id;
		this.product_id = builder.product_id;
		this.platform_type_id = builder.platform_type_id;
		this.cms_core_game_id = builder.cms_core_game_id;
		this.partner_id = builder.partner_id;
		this.game_play_technology_id = builder.game_play_technology_id;
		this.provider_id = builder.provider_id;
		this.game_name = builder.game_name;
		this.is_multistage = builder.is_multistage;
		this.bonus_game_type = builder.bonus_game_type;
		this.return_delay_in_seconds = builder.return_delay_in_seconds;
		this.is_visible = builder.is_visible;
		this.provider_implementation_id = builder.provider_implementation_id;
		this.game_round_duration_seconds = builder.game_round_duration_seconds;
		this.game_type_id = builder.game_type_id;
	}
	
	public Integer getRegulated_game_id() {
		return regulated_game_id;
	}

	public Integer getGame_id() {
		return game_id;
	}

	public Integer getRegulated_zone_id() {
		return regulated_zone_id;
	}

	public String getProvider_game_reference() {
		return provider_game_reference;
	}

	public String getPrivate_partner_game_id() {
		return private_partner_game_id;
	}

	public String getRegulatory_game_reference() {
		return regulatory_game_reference;
	}

	public Integer getProvider_region_id() {
		return provider_region_id;
	}

	public Integer getProduct_id() {
		return product_id;
	}

	public Integer getPlatform_type_id() {
		return platform_type_id;
	}

	public Integer getCms_core_game_id() {
		return cms_core_game_id;
	}

	public Integer getPartner_id() {
		return partner_id;
	}

	public Integer getGame_play_technology_id() {
		return game_play_technology_id;
	}

	public Integer getProvider_id() {
		return provider_id;
	}

	public String getGame_name() {
		return game_name;
	}

	public Boolean getIs_multistage() {
		return is_multistage;
	}

	public String getBonus_game_type() {
		return bonus_game_type;
	}

	public Integer getReturn_delay_in_seconds() {
		return return_delay_in_seconds;
	}

	public Boolean getIs_visible() {
		return is_visible;
	}

	public Integer getProvider_implementation_id() {
		return provider_implementation_id;
	}

	public Integer getGame_round_duration_seconds() {
		return game_round_duration_seconds;
	}

	public Integer getGame_type_id() {
		return game_type_id;
	}

	public static class Builder {
		private Integer regulated_game_id;
		private Integer game_id;
		private Integer regulated_zone_id;
		private String provider_game_reference;
		private String private_partner_game_id;
		private String regulatory_game_reference;
		private Integer provider_region_id;
		private Integer product_id;
		private Integer platform_type_id;
		private Integer cms_core_game_id;
		private Integer partner_id;
		private Integer game_play_technology_id;
		private Integer provider_id;
		private String game_name;
		private Boolean is_multistage;
		private String bonus_game_type;
		private Integer return_delay_in_seconds;
		private Boolean is_visible;
		private Integer provider_implementation_id;
		private Integer game_round_duration_seconds;
		private Integer game_type_id;

		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}

		public Builder gameId(Integer game_id) {
			this.game_id = game_id;
			return this;
		}

		public Builder regulatedZoneId(Integer regulated_zone_id) {
			this.regulated_zone_id = regulated_zone_id;
			return this;
		}

		public Builder providerGameReference(String provider_game_reference) {
			this.provider_game_reference = provider_game_reference;
			return this;
		}

		public Builder privateParterGameId(String private_partner_game_id) {
			this.private_partner_game_id = private_partner_game_id;
			return this;
		}

		public Builder regulatoryGameReference(String regulatory_game_reference) {
			this.regulatory_game_reference = regulatory_game_reference;
			return this;
		}

		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public Builder platformTypeId(Integer platform_type_id) {
			this.platform_type_id = platform_type_id;
			return this;
		}

		public Builder cmsCoreGameId(Integer cms_core_game_id) {
			this.cms_core_game_id = cms_core_game_id;
			return this;
		}

		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}

		public Builder gamePlayTechnologyId(Integer game_play_technology_id) {
			this.game_play_technology_id = game_play_technology_id;
			return this;
		}
		
		public Builder providerId(Integer provider_id) {
			this.provider_id = provider_id;
			return this;
		}

		public Builder gameName(String game_name) {
			this.game_name = game_name;
			return this;
		}

		public Builder isMultistage(Boolean is_multistage) {
			this.is_multistage = is_multistage;
			return this;
		}

		public Builder bonusGameType(String bonus_game_type) {
			this.bonus_game_type = bonus_game_type;
			return this;
		}

		public Builder returnDelayInSeconds(Integer return_delay_in_seconds) {
			this.return_delay_in_seconds = return_delay_in_seconds;
			return this;
		}

		public Builder isVisible(Boolean is_visible) {
			this.is_visible = is_visible;
			return this;
		}

		public Builder providerImplementationId(Integer provider_implementation_id) {
			this.provider_implementation_id = provider_implementation_id;
			return this;
		}
		
		public Builder gameRoundDurationSeconds(Integer game_round_duration_seconds) {
			this.game_round_duration_seconds = game_round_duration_seconds;
			return this;
		}
		
		public Builder gameTypeId(Integer game_type_id) {
			this.game_type_id = game_type_id;
			return this;
		}
		
		public Builder defaults() {
			this.bonus_game_type = "C";
			this.regulated_game_id = 95678;
			this.game_id = 10107;
			this.regulated_zone_id = 1;
			this.provider_game_reference = "gpas_gogold_pop";
			this.private_partner_game_id = "gpas_gogold_pop";
			this.regulatory_game_reference = "";
			this.provider_region_id = 3;
			this.product_id	= 22;
			this.platform_type_id = 4;
			this.cms_core_game_id = 33396;
			this.game_play_technology_id = 2;
			this.provider_id = 3;
			this.game_name = "Age of the Gods Norse: Book of Dwarves";
			this.is_multistage = false;
			this.return_delay_in_seconds = 0;
			this.is_visible = true;
			this.provider_implementation_id = 81;
			this.partner_id = 8;
			this.game_round_duration_seconds = 0;
			this.game_type_id = 1;
			return this;
		}

		public RegulatedGame build() {
			RegulatedGame result = new RegulatedGame(this);
			return result;
		}
	}
}

