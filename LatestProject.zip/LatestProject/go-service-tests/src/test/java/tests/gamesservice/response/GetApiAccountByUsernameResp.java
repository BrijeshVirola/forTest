package tests.gamesservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetApiAccountByUsernameResp {
	
	private String id = null;
	private Map<String, Object> result = new HashMap<>();
	
	public GetApiAccountByUsernameResp() {
	}
	
	private GetApiAccountByUsernameResp(Builder builder) {
		this.id = builder.idInMainBodySection;
		this.result.put("id", builder.idInResultSection);
		this.result.put("username", builder.username);
		this.result.put("password", builder.password);
		this.result.put("regulatory_zone_id", builder.regulatoryZoneId);
		this.result.put("game_reference_type_id", builder.gameReferenceTypeId);
		this.result.put("provider_implementation_group_id", builder.providerGroupImplementationId);
		this.result.put("provider_implementation_ids", builder.providerImplementationIds);
	}
	
	public String getId() {
		return id;
	}
	
	public Map<String, Object> getResult() {
		return result;
	}
	
	public static class Builder {
		private String idInMainBodySection;
		private Integer idInResultSection;
		private String username;
		private String password;
		private Integer regulatoryZoneId;
		private Integer gameReferenceTypeId;
		private Integer providerGroupImplementationId;
		private Integer [] providerImplementationIds;
		
		public Builder idInMainBodySection(String id) {
			this.idInMainBodySection = id;
			return this;
		}
		
		public Builder idInResultSection(Integer id) {
			this.idInResultSection = id;
			return this;
		}
		
		public Builder username(String username) {
			this.username = username;
			return this;
		}
		
		public Builder password(String password) {
			this.password = password;
			return this;
		}
		
		public Builder regulatoryZoneId(Integer regulatoryZoneId) {
			this.regulatoryZoneId = regulatoryZoneId;
			return this;
		}
		
		public Builder gameReferenceTypeId(Integer gameReferenceTypeId) {
			this.gameReferenceTypeId = gameReferenceTypeId;
			return this;
		}
		
		public Builder providerGroupImplementationId(Integer providerGroupImplementationId) {
			this.providerGroupImplementationId = providerGroupImplementationId;
			return this;
		}
		
		public Builder providerImplementationIds(Integer[] providerImplementationIds) {
			this.providerImplementationIds = providerImplementationIds;
			return this;
		}
		
		public Builder defaults() {
			this.idInMainBodySection = null;
			this.idInResultSection = 26;
			this.username = "OnseoUser";
			this.password = "ae836617e46c132ed2af599fd4ce3c251e4097edf4642dd46852d95601b7d3a8";
			this.regulatoryZoneId = 1;
			this.gameReferenceTypeId = 1;
			this.providerGroupImplementationId = 27;
			this.providerImplementationIds = new Integer[] {145};
			return this;
		}
		
		public GetApiAccountByUsernameResp build() {
			return new GetApiAccountByUsernameResp(this);
		}	
	}
}