package tests.gamesservice.response;

public class GetIgpReportingGamesDataResp {

	private String id;
	Result result;

	public GetIgpReportingGamesDataResp() {
	}
	
	private GetIgpReportingGamesDataResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public int getRegulatedGameId() {
		return result.regulated_game_id;
	}
	
	public int getRegulatedGameType() {
		return result.regulated_game_type;
	}
	
	public int getCertifiedSoftwareVersion() {
		return result.certified_software_version;
	}
	
	public int getProviderId() {
		return result.provider_id;
	} 
	public String getRegulatoryGameReference() {
		return result.regulatory_game_reference;
	}
	
	public String getId() {
		return id;
	}
	
	public Result getResult() {
		return result;
	}

	public static class Builder {
		private String id;
		private String regulatory_game_reference;
		private int regulated_game_id, regulated_game_type, certified_software_version, provider_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder regulatedGameId(int regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}

		public Builder regulatedGameType(int regulated_game_type) {
			this.regulated_game_type = regulated_game_type;
			return this;
		}

		public Builder certifiedSoftwareVersion(int certified_software_version) {
			this.certified_software_version = certified_software_version;
			return this;
		}
		
		public Builder providerId(int provider_id) {
			this.provider_id = provider_id;
			return this;
		}

		public Builder regulatoryGameReference(String regulatory_game_reference) {
			this.regulatory_game_reference = regulatory_game_reference;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.regulated_game_id = 7687;
			this.regulated_game_type = 2;
			this.certified_software_version = 0;
			this.regulatory_game_reference = "CogenaWhiteLabelGMItalyTestGameA";
			this.provider_id = 101;
			return this;
		}

		public GetIgpReportingGamesDataResp build() {
			return new GetIgpReportingGamesDataResp(this);
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		public Result() {
		}

		public int regulated_game_id;
		public int regulated_game_type;
		public int certified_software_version;
		public int provider_id;
		public String regulatory_game_reference;
		
		public Result(Builder builder) {
			
			this.regulated_game_id = builder.regulated_game_id;
			this.regulated_game_type = builder.regulated_game_type;
			this.certified_software_version = builder.certified_software_version;
			this.regulatory_game_reference = builder.regulatory_game_reference;		
			this.provider_id = builder.provider_id;
		}

		@SuppressWarnings("unused")
		public int getRegulated_game_id() {
			return regulated_game_id;
		}

		@SuppressWarnings("unused")
		public int getRegulated_game_type() {
			return regulated_game_type;
		}

		@SuppressWarnings("unused")
		public int getCertified_software_version() {
			return certified_software_version;
		}

		@SuppressWarnings("unused")
		public String getRegulatory_game_reference() {
			return regulatory_game_reference;
		}
		
		@SuppressWarnings("unused")
		public int getRegulatory_provider_id() {
			return provider_id;
		}		
	}
}
