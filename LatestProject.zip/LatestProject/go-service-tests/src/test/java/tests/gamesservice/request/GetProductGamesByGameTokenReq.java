package tests.gamesservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetProductGamesByGameTokenReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	
	private Map<String, Object> params = new HashMap<>();

	private GetProductGamesByGameTokenReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("game_token", builder.game_token);
		this.params.put("product_id", builder.product_id);
		this.params.put("technology_ids", builder.technology_ids);
	}

	public static class Builder {
		private String id;
		private String method;
		private String game_token;
		private Integer product_id;
		private Integer[] technology_ids;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder gameToken(String game_token) {
			this.game_token = game_token;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public Builder technologyIds(Integer[] technology_ids) {
			this.technology_ids = technology_ids;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.method = "getproductgamesbygametoken";
			this.game_token = "3HandBlackjack";
			this.product_id = 1;
			this.technology_ids = new Integer[] { 1, 2 };
			return this;
		}

		public GetProductGamesByGameTokenReq build() {
			return new GetProductGamesByGameTokenReq(this);
		}
	}
}
