package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamesservice.enums.GameEndpoints;
import tests.gamesservice.request.GetProductGamesByGameTokenReq;
import tests.gamesservice.response.GetProductGamesByGameTokenResp;
import tests.gamesservice.responseobjects.GetProductGamesByGameTokenGame;

public class GetProductGamesByGameTokenTests extends BaseClassSetup {

	@Test(description = "Make a valid request to GetProductGamesByGameToken with known details")
	public void GivenValidRequestForKnownDetails_WhenGetProductGamesByGameToken_ThenASuccessResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetProductGamesByGameTokenReq requestBody = new GetProductGamesByGameTokenReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetProductGamesByGameTokenGame game = new GetProductGamesByGameTokenGame.Builder()
				.defaults()
				.build();

		GetProductGamesByGameTokenResp expectedResponse = new GetProductGamesByGameTokenResp.Builder()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addGame(game)
				.build();

		GetProductGamesByGameTokenResp actualResponse = BaseRequest.post(requestBody,
				GameEndpoints.getProductGamesByGameTokenSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a valid request to GetProductGamesByGameToken with unknown details")
	public void GivenValidRequestForUnknownDetails_WhenGetProductGamesByGameToken_ThenAnEmptySuccessResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetProductGamesByGameTokenReq requestBody = new GetProductGamesByGameTokenReq.Builder()
				.defaults()
				.gameToken("UNKNOWN")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetProductGamesByGameTokenResp expectedResponse = new GetProductGamesByGameTokenResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetProductGamesByGameTokenResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getProductGamesByGameTokenSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "A request with a field too long in GetProductGamesByGameToken - Error code 1009")
	public void GetProductGamesByGameTokenOfInvalidLength_WhenGetProductGamesByGameToken_ThenAnErrorResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetProductGamesByGameTokenReq requestBody = new GetProductGamesByGameTokenReq.Builder()
				.defaults()
				.gameToken("THIS_SENTENCE_IN_TOTAL_IS_ONE_CHARACTER_LONGER_THAN_THE_MAXIMUM_ALLOWABLE_FIELD_LENGTH_OF_ONE_HUNDRED")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody,
				GameEndpoints.getProductGamesByGameTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1009)
				.message("Invalid parameter: game_token must be between 1 and 100 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "A request with a missing field in GetProductGamesByGameToken - Error code 1009")
	public void GetProductGamesByGameTokenWithMissingField_WhenGetProductGamesByGameToken_ThenAnErrorResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetProductGamesByGameTokenReq requestBody = new GetProductGamesByGameTokenReq.Builder().defaults()
				.gameToken(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, GameEndpoints.getProductGamesByGameTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: game_token")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "A request with a missing field in GetProductGamesByGameToken - Error code 7")
	public void GetProductGamesByGameTokenWithMissingFieldproductId_WhenGetProductGamesByGameToken_ThenAnErrorResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetProductGamesByGameTokenReq requestBody = new GetProductGamesByGameTokenReq.Builder().defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, GameEndpoints.getProductGamesByGameTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "A request with a missing field in GetProductGamesByGameToken - Error code 7")
	public void GetProductGamesByGameTokenWithMissingFieldtechnologyIds_WhenGetProductGamesByGameToken_ThenAnErrorResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetProductGamesByGameTokenReq requestBody = new GetProductGamesByGameTokenReq.Builder().defaults()
				.technologyIds(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, GameEndpoints.getProductGamesByGameTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: technology_ids")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}
