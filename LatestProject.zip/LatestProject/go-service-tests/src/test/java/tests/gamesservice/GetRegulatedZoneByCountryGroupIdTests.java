package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamesservice.enums.GameEndpoints;
import tests.gamesservice.request.GetRegulatedZoneByCountryGroupIdReq;
import tests.gamesservice.response.GetRegulatedZoneByCountryGroupIdResp;

public class GetRegulatedZoneByCountryGroupIdTests extends BaseClassSetup {
	@DataProvider(name = "getRegulatedZoneByCountryGroupId")
	//country_group_id; id; name
	private Object[][] getRegulatedZoneByCountryGroupId() {
		return new Object[][] {{ 11, 1, "UK"}, { 12, 5, "COM"}, { 39, 2, "Italy"}, { 31, 3, "Spain"}};
	}

	@Test(description = "Make a request to GetRegulatedZoneByCountryGroupId. Positive scenario.", dataProvider = "getRegulatedZoneByCountryGroupId")
	public void getRegulatedZoneByCountryGroupId_Positive_Scenario(Integer countryGroupId, Integer expId, String exName) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedZoneByCountryGroupIdReq request = new GetRegulatedZoneByCountryGroupIdReq.Builder()
				.defaults()
				.countryGroupId(countryGroupId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetRegulatedZoneByCountryGroupIdResp actResponse =  BaseRequest.post(request, GameEndpoints.getRegulatedZoneByCountryGroupIdSuccess);
		GetRegulatedZoneByCountryGroupIdResp expResponse =  new GetRegulatedZoneByCountryGroupIdResp.Builder()
				.idInBody(idForRequestToBeEchoedBackInResponseId)
				.idInResult(expId)
				.name(exName)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to getRegulatedZoneByCountryGroupId. Missing parameter.")
	public void getRegulatedZoneByCountryGroupId_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedZoneByCountryGroupIdReq request = new GetRegulatedZoneByCountryGroupIdReq.Builder()
				.defaults()
				.countryGroupId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(request, GameEndpoints.getRegulatedZoneByCountryGroupIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: country_group_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to getRegulatedZoneByCountryGroupId. Wrong method.")
	public void getRegulatedZoneByCountryGroupId_Wrong_Method() {

		GetRegulatedZoneByCountryGroupIdReq request = new GetRegulatedZoneByCountryGroupIdReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(null)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(request, GameEndpoints.getRegulatedZoneByCountryGroupIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
	
	@Test(description = "Make a request to getRegulatedZoneByCountryGroupId. Failed to get regulated zone.")
	public void getRegulatedZoneByCountryGroupId_No_regulated_zone() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedZoneByCountryGroupIdReq request = new GetRegulatedZoneByCountryGroupIdReq.Builder()
				.defaults()
				.countryGroupId(110)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(request, GameEndpoints.getRegulatedZoneByCountryGroupIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(1010)
				.message("Failed to get regulated zone")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
}
