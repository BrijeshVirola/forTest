package tests.gamesservice.requestobjects;

public class GetRegulatedGamesByProviderGameReferenceParams {
	private String provider_game_reference;
	private Integer provider_id;
	private Integer provider_region_id;
	private Integer product_id;
	private Integer regulated_zone_id;
	
	private GetRegulatedGamesByProviderGameReferenceParams(ParamsBuilder builder) {
		this.regulated_zone_id = builder.regulated_zone_id;
		this.provider_game_reference = builder.provider_game_reference;
		this.provider_region_id = builder.provider_region_id;
		this.product_id = builder.product_id;
		this.provider_id = builder.provider_id;
	}

	public Integer getRegulatedZoneId() {
		return regulated_zone_id;
	};

	public String getProviderGameReference() {
		return provider_game_reference;
	};

	public Integer getProviderRegionId() {
		return provider_region_id;
	};

	public Integer getProductId() {
		return product_id;
	};

	public Integer getProviderId() {
		return provider_id;
	};

	public static class ParamsBuilder {
		private String provider_game_reference;
		private Integer provider_id;
		private Integer provider_region_id;
		private Integer product_id;
		private Integer regulated_zone_id;

		public ParamsBuilder regulatedZoneId(Integer regulated_zone_id) {
			this.regulated_zone_id = regulated_zone_id;
			return this;
		}

		public ParamsBuilder providerGameReference(String provider_game_reference) {
			this.provider_game_reference = provider_game_reference;
			return this;
		}

		public ParamsBuilder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}

		public ParamsBuilder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public ParamsBuilder providerId(Integer provider_id) {
			this.provider_id = provider_id;
			return this;
		}
		
		public ParamsBuilder defaults() {
			this.regulated_zone_id = 1;
			this.provider_game_reference = "gpas_gogold_pop";
			this.provider_region_id = 3;
			this.product_id	= 22;
			this.provider_id = 3;
			return this;
		}

		public GetRegulatedGamesByProviderGameReferenceParams build() {
			GetRegulatedGamesByProviderGameReferenceParams params = new GetRegulatedGamesByProviderGameReferenceParams(this);
			return params;
		}
	}
}