package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamesservice.enums.GameEndpoints;
import tests.gamesservice.request.GetRegulatedGamesByGameIdReq;
import tests.gamesservice.response.GetRegulatedGamesByGameIdResp;
import tests.gamesservice.responseobjects.RegulatedGame;

public class GetRegulatedGamesByGameIdTests extends BaseClassSetup {


	@Test(description = "Make a valid request to get GetRegulatedGamesByGameId")
	public void GivenValidRequestForAKnownGetRegulatedGamesByGameId_WhenGetRegulatedGameByGameId_ThenASuccessResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)			
				.build();

		RegulatedGame regulatedGame = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(59)
				.gameId(28)
				.regulatedZoneId(1)
				.providerGameReference("eas")
				.privateParterGameId("eas")
				.regulatoryGameReference("0")
				.providerRegionId(3)
				.productId(4)
				.platformTypeId(1)
				.cmsCoreGameId(2014)
				.partnerId(28)
				.gamePlayTechnologyId(1)
				.providerId(3)
				.gameName("Easter Surprise")
				.isMultistage(false)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(72)
				.gameRoundDurationSeconds(0)
				.gameTypeId(1)
				.build();

		GetRegulatedGamesByGameIdResp expectedResponse = new GetRegulatedGamesByGameIdResp.Builder()
				.defaults()
				.addGame(regulatedGame)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetRegulatedGamesByGameIdResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a valid request to get GetRegulatedGamesByGameId with game_round_duration_seconds")
	public void GivenValidRequestForAKnownGetRegulatedGamesByGameId_Game_Round_Duration_Seconds_Not_Zero() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.gameId(4392)
				.regulatedZoneId(8)
				.productId(45)
				.id(idForRequestToBeEchoedBackInResponseId)			
				.build();

		RegulatedGame regulatedGame1 = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(105409)
				.gameId(28)
				.regulatedZoneId(8)
				.providerGameReference("bjl")
				.privateParterGameId("bjl")
				.regulatoryGameReference("")
				.providerRegionId(3)
				.gameId(4392)
				.productId(45)
				.platformTypeId(1)
				.cmsCoreGameId(35714)
				.partnerId(135)
				.gamePlayTechnologyId(2)
				.providerId(3)
				.gameName("Live Blackjack")
				.isMultistage(true)
				.bonusGameType("C")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(141)
				.gameRoundDurationSeconds(10)
				.gameTypeId(2)
				.build();
		
		RegulatedGame regulatedGame2 = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(105410)
				.gameId(28)
				.regulatedZoneId(8)
				.providerGameReference("bjl")
				.privateParterGameId("bjl")
				.regulatoryGameReference("")
				.providerRegionId(3)
				.gameId(4392)
				.productId(45)
				.platformTypeId(2)
				.cmsCoreGameId(35715)
				.partnerId(135)
				.gamePlayTechnologyId(2)
				.providerId(3)
				.gameName("Live Blackjack")
				.isMultistage(true)
				.bonusGameType("C")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(141)
				.gameRoundDurationSeconds(0)
				.gameTypeId(2)
				.build();

		GetRegulatedGamesByGameIdResp expectedResponse = new GetRegulatedGamesByGameIdResp.Builder()
				.defaults()
				.addGame(regulatedGame1)
				.addGame(regulatedGame2)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetRegulatedGamesByGameIdResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a valid request to get GetRegulatedGamesByGameId with game_type_id - 0.")
	public void GivenValidRequestForAKnownGetRegulatedGamesByGameId_Game_Type_Id_Returned_0() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerRegionId(3)
				.productId(4)
				.providerId(3)
				.regulatedZoneId(1)
				.gameId(7718)
				.build();

		RegulatedGame regulatedGame = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(49099)
				.gameId(7718)
				.regulatedZoneId(1)
				.providerGameReference("evjj")
				.privateParterGameId("")
				.regulatoryGameReference("")
				.providerRegionId(3)
				.productId(4)
				.platformTypeId(1)
				.cmsCoreGameId(21848)
				.partnerId(28)
				.gamePlayTechnologyId(1)
				.providerId(3)
				.gameName("Everybody's Jackpot sub game")
				.isMultistage(false)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(72)
				.gameRoundDurationSeconds(0)
				.gameTypeId(0)
				.build();

		GetRegulatedGamesByGameIdResp expectedResponse = new GetRegulatedGamesByGameIdResp.Builder()
				.defaults()
				.addGame(regulatedGame)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetRegulatedGamesByGameIdResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a valid request to get GetRegulatedGamesByGameId with game_type_id - 1.")
	public void GivenValidRequestForAKnownGetRegulatedGamesByGameId_Game_Type_Id_Returned_1() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerRegionId(6)
				.productId(4)
				.providerId(6)
				.regulatedZoneId(10)
				.gameId(614)
				.build();

		RegulatedGame regulatedGame = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(24692)
				.gameId(614)
				.regulatedZoneId(10)
				.providerGameReference("rgl_365_snapshot_m")
				.privateParterGameId("")
				.regulatoryGameReference("0")
				.providerRegionId(6)
				.productId(4)
				.platformTypeId(2)
				.cmsCoreGameId(3455)
				.partnerId(12)
				.gamePlayTechnologyId(3)
				.providerId(6)
				.gameName("Snapshot")
				.isMultistage(false)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(61)
				.gameRoundDurationSeconds(0)
				.gameTypeId(1)
				.build();
		
		GetRegulatedGamesByGameIdResp expectedResponse = new GetRegulatedGamesByGameIdResp.Builder()
				.defaults()
				.addGame(regulatedGame)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetRegulatedGamesByGameIdResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a valid request to get GetRegulatedGamesByGameId with game_type_id - 2.")
	public void GivenValidRequestForAKnownGetRegulatedGamesByGameId_Game_Type_Id_Returned_2() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerRegionId(3)
				.productId(5)
				.providerId(3)
				.regulatedZoneId(1)
				.gameId(6106)
				.build();

		RegulatedGame regulatedGame1 = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(48709)
				.gameId(6106)
				.regulatedZoneId(1)
				.providerGameReference("dtl")
				.privateParterGameId("dtl")
				.regulatoryGameReference("")
				.providerRegionId(3)
				.productId(5)
				.platformTypeId(2)
				.cmsCoreGameId(21767)
				.partnerId(135)
				.gamePlayTechnologyId(2)
				.providerId(3)
				.gameName("Live Dragon Tiger")
				.isMultistage(true)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(141)
				.gameRoundDurationSeconds(0)
				.gameTypeId(2)
				.build();

		RegulatedGame regulatedGame2 = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(48711)
				.gameId(6106)
				.regulatedZoneId(1)
				.providerGameReference("dtl")
				.privateParterGameId("dtl")
				.regulatoryGameReference("")
				.providerRegionId(3)
				.productId(5)
				.platformTypeId(3)
				.cmsCoreGameId(21767)
				.partnerId(135)
				.gamePlayTechnologyId(2)
				.providerId(3)
				.gameName("Live Dragon Tiger")
				.isMultistage(true)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(141)
				.gameRoundDurationSeconds(0)
				.gameTypeId(2)
				.build();
		
		RegulatedGame regulatedGame3 = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(48713)
				.gameId(6106)
				.regulatedZoneId(1)
				.providerGameReference("dtl")
				.privateParterGameId("dtl")
				.regulatoryGameReference("")
				.providerRegionId(3)
				.productId(5)
				.platformTypeId(4)
				.cmsCoreGameId(21767)
				.partnerId(135)
				.gamePlayTechnologyId(2)
				.providerId(3)
				.gameName("Live Dragon Tiger")
				.isMultistage(true)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(141)
				.gameRoundDurationSeconds(0)
				.gameTypeId(2)
				.build();
		
		RegulatedGame regulatedGame4 = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(48715)
				.gameId(6106)
				.regulatedZoneId(1)
				.providerGameReference("dtl")
				.privateParterGameId("dtl")
				.regulatoryGameReference("")
				.providerRegionId(3)
				.productId(5)
				.platformTypeId(5)
				.cmsCoreGameId(21767)
				.partnerId(135)
				.gamePlayTechnologyId(2)
				.providerId(3)
				.gameName("Live Dragon Tiger")
				.isMultistage(true)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(141)
				.gameRoundDurationSeconds(0)
				.gameTypeId(2)
				.build();
		
		GetRegulatedGamesByGameIdResp expectedResponse = new GetRegulatedGamesByGameIdResp.Builder()
				.defaults()
				.addGame(regulatedGame1)
				.addGame(regulatedGame2)
				.addGame(regulatedGame3)
				.addGame(regulatedGame4)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetRegulatedGamesByGameIdResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request with wrong method in the body for GetRegulatedGamesByGameId - Error code 6")
	public void GetRegulatedGamesByGameId_Wrong_Method() {

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD")
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

	@Test(description = "Make a request with missing parameter from params object for GetRegulatedGamesByGameId - Error code 7")
	public void GetRegulatedGamesByGameId_Missing_Param_providerId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: provider_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

	
	
	@Test(description = "Make a request with missing parameter from params object for GetRegulatedGamesByGameId - Error code 7")
	public void GetRegulatedGamesByGameId_Missing_Param_providerRegionId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerRegionId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: provider_region_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

	@Test(description = "Make a request with missing parameter from params object for GetRegulatedGamesByGameId - Error code 7")
	public void GetRegulatedGamesByGameId_Missing_Param_productId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.productId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}


	@Test(description = "Make a request with missing parameter from params object for GetRegulatedGamesByGameId - Error code 7")
	public void GetRegulatedGamesByGameId_Missing_Param_regulatedZoneId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGamesByGameIdReq requestBody = new GetRegulatedGamesByGameIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.regulatedZoneId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: regulated_zone_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

}
