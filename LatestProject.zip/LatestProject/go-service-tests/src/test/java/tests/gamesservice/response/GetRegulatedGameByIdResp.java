package tests.gamesservice.response;

import tests.gamesservice.responseobjects.RegulatedGame;

public class GetRegulatedGameByIdResp {

	private String id;
	private RegulatedGame result;
	
	public GetRegulatedGameByIdResp() {
	}

	private GetRegulatedGameByIdResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.regulatedGame;	
	}

	public String getId() {
		return id;
	}

	public RegulatedGame getResult() {
		return result;
	}

	public static class Builder {
		private String id;
		private RegulatedGame regulatedGame;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addGame(RegulatedGame regulatedGame) {
			this.regulatedGame = regulatedGame;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public GetRegulatedGameByIdResp build() {
			GetRegulatedGameByIdResp result = new GetRegulatedGameByIdResp(this);
			return result;
		}
	}
}
