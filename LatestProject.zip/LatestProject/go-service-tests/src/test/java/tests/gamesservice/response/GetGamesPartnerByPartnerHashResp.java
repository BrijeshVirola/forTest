package tests.gamesservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetGamesPartnerByPartnerHashResp {

	private Map<String, Object> result = new HashMap<>();
	private String id;
	
	public GetGamesPartnerByPartnerHashResp() {
	}

	private GetGamesPartnerByPartnerHashResp(Builder builder) {
		this.id = builder.id;
		this.result.put("partner_id", builder.partner_id);
		this.result.put("partner_name", builder.partner_name);
	}
	
	public String getId() {
		return id;
	}
	
	public Map<String, Object> getResult() {
		return result;
	}

	public static class Builder {
		private String id;
		private Integer partner_id;
		private String partner_name;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}

		public Builder partnerName(String partner_name) {
			this.partner_name = partner_name;
			return this;
		}

		public Builder defaults() {
			this.partner_id = 139;
			this.partner_name = "HillsideGamesCogena";
			return this;
		}

		public GetGamesPartnerByPartnerHashResp build() {
			return new GetGamesPartnerByPartnerHashResp(this);
		}
	}
}
