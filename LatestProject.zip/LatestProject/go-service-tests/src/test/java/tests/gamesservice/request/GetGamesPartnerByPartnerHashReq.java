package tests.gamesservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetGamesPartnerByPartnerHashReq {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;
	private Map<String, Object> params = new HashMap<>();
	
	private GetGamesPartnerByPartnerHashReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("partner_hash", builder.partner_hash);
	}
	
	public static class Builder {
		private String id;
		private String method;
		private String partner_hash;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder partnerHash(String partnerHash) {
			this.partner_hash = partnerHash;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "getgamespartnerbypartnerhash";
			this.partner_hash = "HillsideGamesCogenaHash";
			return this;
		}
		
		public GetGamesPartnerByPartnerHashReq build() {
			return new GetGamesPartnerByPartnerHashReq(this);
		}
	}
}