package tests.gamesservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetRegulatedZoneByCountryGroupIdResp {
	
	private String id = null;
	private Map<String, Object> result = new HashMap<>();
	
	public GetRegulatedZoneByCountryGroupIdResp() {
	}
	
	private GetRegulatedZoneByCountryGroupIdResp(Builder builder) {
		this.id = builder.idInBody;
		this.result.put("id", builder.idInResult);
		this.result.put("name", builder.name);
	}
	
	public String getId() {
		return id;
	}
	
	public Map<String, Object> getResult() {
		return result;
	}
	
	public static class Builder {
		private String idInBody, name;
		private Integer idInResult;
		
		public Builder idInBody(String idInBody) {
			this.idInBody = idInBody;
			return this;
		}
		
		public Builder idInResult(Integer idInResult) {
			this.idInResult = idInResult;
			return this;
		}
		
		public Builder name(String name) {
			this.name = name;
			return this;
		}
		
		public Builder defaults() {
			this.idInBody = "1";
			this.idInResult = 1;
			this.name = "UK";
			return this;
		}
		
		public GetRegulatedZoneByCountryGroupIdResp build() {
			return new GetRegulatedZoneByCountryGroupIdResp(this);
		}	
	}
}

