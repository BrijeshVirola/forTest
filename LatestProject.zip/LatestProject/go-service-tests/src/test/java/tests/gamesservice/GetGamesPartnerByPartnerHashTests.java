package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamesservice.enums.GameEndpoints;
import tests.gamesservice.request.GetGamesPartnerByPartnerHashReq;
import tests.gamesservice.response.GetGamesPartnerByPartnerHashResp;

public class GetGamesPartnerByPartnerHashTests extends BaseClassSetup {

	@Test(description = "Make a valid request to get GetGamesPartnerByPartnerHash with a known partner hash")
	public void GivenValidRequestForAKnownPartnerHash_WhenGetGamesPartnerByPartnerHash_ThenASuccessResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		String knownValidPartnerHash = "HillsideGamesCogenaHash";
		GetGamesPartnerByPartnerHashReq requestBody = new GetGamesPartnerByPartnerHashReq.Builder()
				.defaults()
				.partnerHash(knownValidPartnerHash)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetGamesPartnerByPartnerHashResp expectedResponce = new GetGamesPartnerByPartnerHashResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetGamesPartnerByPartnerHashResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getGamesPartnerByPartnerHashSuccess);

		assertReflectionEquals(expectedResponce, actualResponse);
	}

	@Test(description = "Make a request with a partner hash which is unknown for GetGamesPartnerByPartnerHash - Error code 1006")
	public void GivenValidRequestForAnUnknownPartnerHash_WhenGetGamesPartnerByPartnerHash_ThenAnErrorResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGamesPartnerByPartnerHashReq request = new GetGamesPartnerByPartnerHashReq.Builder()
				.defaults()
				.partnerHash("UNKNOWN_PARTNER_HASH")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(request, GameEndpoints.getGamesPartnerByPartnerHashError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1005)
				.message("Partner was not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}

	@Test(description = "Make a request with a partner hash which exceeds max permitted length of 50 in GetGamesPartnerByPartnerHash - Error code 1006")
	public void GivenRequestWithAPartnerHashGreaterThanLength50_WhenGetGamesPartnerByPartnerHash_ThenAnErrorResponseIsReceived() {

		String tooLongPartnerHash = "ONE_CHAR_LONGER_THAN_THE_MAX_PERMITTED_LENGTH_OF_50";
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGamesPartnerByPartnerHashReq request = new GetGamesPartnerByPartnerHashReq.Builder()
				.defaults()
				.partnerHash(tooLongPartnerHash)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(request, GameEndpoints.getGamesPartnerByPartnerHashError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1004)
				.message("Supplied partner hash is too long (50 chars max)")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError); 
	}
	
	@Test(description = "Make a request with missing parameter partner_hash from GivenRequestWithAPartnerHash")
	public void GivenRequestWithAPartnerHash_Missing_partner_hash() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetGamesPartnerByPartnerHashReq request = new GetGamesPartnerByPartnerHashReq.Builder()
				.defaults()
				.partnerHash(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actError =  BaseRequest.post(request, GameEndpoints.getGamesPartnerByPartnerHashError);

		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_hash")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expError, actError);
	}

}
