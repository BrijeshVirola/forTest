package tests.gamesservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetRegulatedGameIdsByPropertyValueResp {

	private String id;
	private Map<String, Integer[]> result = new HashMap<>();

	public GetRegulatedGameIdsByPropertyValueResp() {
	}
	
	private GetRegulatedGameIdsByPropertyValueResp(Builder builder) {
		this.id = builder.id;
		this.result.put("regulated_game_ids", builder.regulated_game_ids);
	}

	public String getId() {
		return id;
	}
	
	public Map<String, Integer[]> getResult() {
		return result;
	}

	public static class Builder {
		private String id;
		private Integer[] regulated_game_ids;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder regulatedGameIds(Integer[] regulated_game_ids) {
			this.regulated_game_ids = regulated_game_ids;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.regulated_game_ids = new Integer[] {};
			return this;
		}
	
		public GetRegulatedGameIdsByPropertyValueResp build() {
			return new GetRegulatedGameIdsByPropertyValueResp(this);
		}
	}
}
