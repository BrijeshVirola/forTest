package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamesservice.enums.GameEndpoints;
import tests.gamesservice.request.GetRegulatedGamesByProviderGameReferenceReq;
import tests.gamesservice.response.ListOfRegulatedGamesResp;
import tests.gamesservice.responseobjects.RegulatedGame;

public class GetRegulatedGamesByProviderGameReferenceTests extends BaseClassSetup {

	@Test(description = "Make a valid request to get GetRegulatedGamesByProviderGameReference with known provider details")
	public void GivenValidRequestForKnownProviderDetails_WhenGetRegulatedGamesByProviderGameReference_ThenASuccessResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		RegulatedGame game1 = new RegulatedGame.Builder().defaults()
				.platformTypeId(3)
				.regulatedGameId(95681)
				.build();

		RegulatedGame game2 = new RegulatedGame.Builder().defaults().build();

		RegulatedGame game3 = new RegulatedGame.Builder().defaults()
				.platformTypeId(6)
				.regulatedGameId(97998)
				.build();

		ListOfRegulatedGamesResp expectedResponse = new ListOfRegulatedGamesResp.Builder()
				.defaults()
				.addGame(game1)
				.addGame(game2)
				.addGame(game3)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ListOfRegulatedGamesResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a valid request to get GetRegulatedGamesByProviderGameReference with known provider details with game_round_duration_seconds not zero")
	public void GivenValidRequestForKnownProviderDetails_WhenGetRegulatedGamesByProviderGameReference_game_round_duration_seconds_Not_Zero() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.providerRegionId(3)
				.providerGameReference("bjl")
				.productId(45)
				.providerId(3)
				.regulatedZoneId(8)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		RegulatedGame regulatedGame1 = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(105409)
				.gameId(28)
				.regulatedZoneId(8)
				.providerGameReference("bjl")
				.privateParterGameId("bjl")
				.regulatoryGameReference("")
				.providerRegionId(3)
				.gameId(4392)
				.productId(45)
				.platformTypeId(1)
				.cmsCoreGameId(35714)
				.partnerId(135)
				.gamePlayTechnologyId(2)
				.providerId(3)
				.gameName("Live Blackjack")
				.isMultistage(true)
				.bonusGameType("C")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(141)
				.gameRoundDurationSeconds(10)
				.gameTypeId(2)
				.build();
		
		RegulatedGame regulatedGame2 = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(105410)
				.gameId(28)
				.regulatedZoneId(8)
				.providerGameReference("bjl")
				.privateParterGameId("bjl")
				.regulatoryGameReference("")
				.providerRegionId(3)
				.gameId(4392)
				.productId(45)
				.platformTypeId(2)
				.cmsCoreGameId(35715)
				.partnerId(135)
				.gamePlayTechnologyId(2)
				.providerId(3)
				.gameName("Live Blackjack")
				.isMultistage(true)
				.bonusGameType("C")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(141)
				.gameRoundDurationSeconds(0)
				.gameTypeId(2)
				.build();

		ListOfRegulatedGamesResp expectedResponse = new ListOfRegulatedGamesResp.Builder()
				.defaults()
				.addGame(regulatedGame1)
				.addGame(regulatedGame2)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ListOfRegulatedGamesResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a valid request to get GetRegulatedGamesByProviderGameReference with known provider details with game_type_id zero")
	public void GivenValidRequestForKnownProviderDetails_WhenGetRegulatedGamesByProviderGameReference_Game_Type_Id_Zero() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.providerRegionId(2)
				.providerGameReference("LOTRTheFellowship")
				.productId(1)
				.providerId(2)
				.regulatedZoneId(5)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		RegulatedGame regulatedGame = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(1650)
				.gameId(820)
				.regulatedZoneId(5)
				.providerGameReference("LOTRTheFellowship")
				.privateParterGameId("")
				.regulatoryGameReference("0")
				.providerRegionId(2)
				.productId(1)
				.platformTypeId(1)
				.cmsCoreGameId(2777)
				.partnerId(2)
				.gamePlayTechnologyId(1)
				.providerId(2)
				.gameName("The Lord of the Rings")
				.isMultistage(false)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(20)
				.gameRoundDurationSeconds(0)
				.gameTypeId(0)
				.build();
		
		ListOfRegulatedGamesResp expectedResponse = new ListOfRegulatedGamesResp.Builder()
				.defaults()
				.addGame(regulatedGame)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ListOfRegulatedGamesResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a valid request to get GetRegulatedGamesByProviderGameReference with known provider details with game_type_id one")
	public void GivenValidRequestForKnownProviderDetails_WhenGetRegulatedGamesByProviderGameReference_Game_Type_Id_One() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.providerRegionId(1)
				.providerGameReference("AMAZONWILD")
				.productId(1)
				.providerId(1)
				.regulatedZoneId(5)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		RegulatedGame regulatedGame = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(909)
				.gameId(452)
				.regulatedZoneId(5)
				.providerGameReference("AMAZONWILD")
				.privateParterGameId("")
				.regulatoryGameReference("0")
				.providerRegionId(1)
				.productId(1)
				.platformTypeId(1)
				.cmsCoreGameId(3431)
				.partnerId(1)
				.gamePlayTechnologyId(1)
				.providerId(1)
				.gameName("Amazon Wild")
				.isMultistage(false)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(10)
				.gameRoundDurationSeconds(0)
				.gameTypeId(1)
				.build();
		
		ListOfRegulatedGamesResp expectedResponse = new ListOfRegulatedGamesResp.Builder()
				.defaults()
				.addGame(regulatedGame)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ListOfRegulatedGamesResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a valid request to get GetRegulatedGamesByProviderGameReference with known provider details with game_type_id two")
	public void GivenValidRequestForKnownProviderDetails_WhenGetRegulatedGamesByProviderGameReference_Game_Type_Id_Two() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.providerRegionId(2)
				.providerGameReference("Jackspwrpoker")
				.productId(4)
				.providerId(2)
				.regulatedZoneId(2)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		RegulatedGame regulatedGame = new RegulatedGame.Builder()
				.defaults()
				.regulatedGameId(1115)
				.gameId(567)
				.regulatedZoneId(2)
				.providerGameReference("Jackspwrpoker")
				.privateParterGameId("MGS_Jacks_Or_Better_MH")
				.regulatoryGameReference("7270")
				.providerRegionId(2)
				.productId(4)
				.platformTypeId(1)
				.cmsCoreGameId(3390)
				.partnerId(17)
				.gamePlayTechnologyId(1)
				.providerId(2)
				.gameName("Jacks or Better Power Poker")
				.isMultistage(true)
				.bonusGameType("G")
				.returnDelayInSeconds(0)
				.isVisible(true)
				.providerImplementationId(22)
				.gameRoundDurationSeconds(0)
				.gameTypeId(2)
				.build();
		
		ListOfRegulatedGamesResp expectedResponse = new ListOfRegulatedGamesResp.Builder()
				.defaults()
				.addGame(regulatedGame)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ListOfRegulatedGamesResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a valid request to get GetRegulatedGamesByProviderGameReference which has no matching results")
	public void GivenValidRequestWithNoMatchingGames_WhenGetRegulatedGamesByProviderGameReference_ThenAnEmptySuccessResponseIsReceived() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.providerGameReference("UNKNOWN")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ListOfRegulatedGamesResp expectedResponse = new ListOfRegulatedGamesResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ListOfRegulatedGamesResp actualResponse = BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@DataProvider(name = "getRegulatedGamesByProviderGameReferenceInvalidFieldLengths")
	private Object[] getRegulatedGamesByProviderGameReferenceInvalidFieldLengths() {
		return new Object[] { "THIS_SENTENCE_IN_TOTAL_IS_ONE_CHARACTER_LONGER_THAN_THE_MAXIMUM_ALLOWABLE_FIELD_LENGTH_OF_ONE_HUNDRED", ""};
	}


	@Test(description = "A request with a field too long/short in GetRegulatedGamesByProviderGameReference - Error code 1006", dataProvider = "getRegulatedGamesByProviderGameReferenceInvalidFieldLengths")
	public void GivenRequestWithAProviderGameReferenceOfInvalidLength_WhenGetRegulatedGamesByProviderGameReference_ThenAnErrorResponseIsReceived(String invalidTestData) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.providerGameReference(invalidTestData)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1009)
				.message("Invalid parameter: provider_game_reference must be between 1 and 100 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "A request with no provider_id in GetRegulatedGamesByProviderGameReference - Error code 7")
	public void GivenRequestWithAProviderGameReference_missingProviderId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.providerId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: provider_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "A request with no providerRegionId in GetRegulatedGamesByProviderGameReference - Error code 7")
	public void GivenRequestWithAProviderGameReference_missingProviderRegionId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.providerRegionId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: provider_region_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "A request with no productId in GetRegulatedGamesByProviderGameReference - Error code 7")
	public void GivenRequestWithAProviderGameReference_missingProductId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "A request with no regulatedZoneId in GetRegulatedGamesByProviderGameReference - Error code 7")
	public void GivenRequestWithAProviderGameReference_regulatedZoneId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
				.defaults()
				.regulatedZoneId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, GameEndpoints.getRegulatedGamesByProviderGameReferenceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: regulated_zone_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

}
