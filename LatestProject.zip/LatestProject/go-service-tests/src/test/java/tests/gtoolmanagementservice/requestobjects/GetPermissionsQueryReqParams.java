package tests.gtoolmanagementservice.requestobjects;

public class GetPermissionsQueryReqParams {
	
	@SuppressWarnings("unused")
	private String pluginname;
	
	private GetPermissionsQueryReqParams(Builder builder) {
		this.pluginname = builder.pluginName;
	}
	
	public static class Builder {

		private String pluginName;
		
		public Builder pluginName(String pluginName) {
			this.pluginName = pluginName;
			return this;
		}
		
		public Builder defaults() {
			this.pluginName = "Bonus tool";
			return this;
		}
		
		public GetPermissionsQueryReqParams build() {
			return new GetPermissionsQueryReqParams(this);
		}
		
	}

}
