package tests.gtoolmanagementservice.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import tests.gtoolmanagementservice.responseobjects.GetPermissionsQueryRespResultObject;

public class GetPermissionsQueryResp {

	@JsonProperty("id")
	private String id;
	@JsonProperty("result")
	private List<GetPermissionsQueryRespResultObject> result;

	public GetPermissionsQueryResp() {
	}

	public String getId() {
		return id;
	}
	
	public List<GetPermissionsQueryRespResultObject> getResult() {
		return result;
	}

	private GetPermissionsQueryResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}

	public static class Builder {

		private String id;
		private List<GetPermissionsQueryRespResultObject> result;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addResult(GetPermissionsQueryRespResultObject resultObject) {
			this.result.add(resultObject);
			return this;
		}

		public Builder defaults() {
			id = "1";
			result = new ArrayList<>();
			return this;
		}

		public GetPermissionsQueryResp build() {
			return new GetPermissionsQueryResp(this);
		}

	}

}