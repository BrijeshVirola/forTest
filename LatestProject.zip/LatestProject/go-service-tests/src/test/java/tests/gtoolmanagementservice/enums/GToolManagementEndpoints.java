package tests.gtoolmanagementservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.gtoolmanagementservice.response.GetPermissionsQueryResp;

public enum GToolManagementEndpoints implements ResponseEndpoints {

	getPermissionsQuerySuccess(GetPermissionsQueryResp.class, "getpermissionsquery"),
	getPermissionsQueryError(CustomErrorResponse.class, "getpermissionsquery");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GToolManagementEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
