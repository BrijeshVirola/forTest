package tests.gtoolmanagementservice.enums;

import common.DatabaseQueries;

public enum GtoolManagementServiceUsers {
	
	GET_PERMISSIONS_QUERRY_POS("GO_GTOOL1"),
	GET_PERMISSIONS_QUERRY_NEG("GO_GTOOL2");

	private String username;

	private GtoolManagementServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public String getUserId() {
		return String.valueOf(DatabaseQueries.getUserIdFromUserTable(getUsername()));
	}
}