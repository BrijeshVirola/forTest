package tests.gtoolmanagementservice.responseobjects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GetPermissionsQueryRespResultObject {

	@JsonProperty("Read")
	private Boolean Read;
	@JsonProperty("Write")
	private Boolean Write;
	@JsonProperty("IsGroup")
	private Boolean IsGroup;
	@JsonProperty("UserAndGroupName")
	private String UserAndGroupName;
	@JsonProperty("FeatureName")
	private String FeatureName;
	@JsonProperty("FeatureID")
	private Integer FeatureID;

	public GetPermissionsQueryRespResultObject() {
	}

	public Boolean getRead() {
		return Read;
	}

	public Boolean getWrite() {
		return Write;
	}

	public Boolean getIsGroup() {
		return IsGroup;
	}

	public String getUserAndGroupName() {
		return UserAndGroupName;
	}

	public String getFeatureName() {
		return FeatureName;
	}

	public Integer getFeatureID() {
		return FeatureID;
	}

	private GetPermissionsQueryRespResultObject(Builder builder) {
		this.Read = builder.read;
		this.Write = builder.write;
		this.IsGroup = builder.isGroup;
		this.UserAndGroupName = builder.userAndGroupName;
		this.FeatureName = builder.featureName;
		this.FeatureID = builder.featureId;		
	}

	public static class Builder {
		private Boolean read;
		private Boolean write;
		private Boolean isGroup;
		private String userAndGroupName;
		private String featureName;
		private Integer featureId;

		public Builder read(Boolean read) {
			this.read = read;
			return this;
		}

		public Builder write(Boolean write) {
			this.write = write;
			return this;
		}

		public Builder isGroup(Boolean isGroup) {
			this.isGroup = isGroup;
			return this;
		}

		public Builder userAndGroupName(String userAndGroupName) {
			this.userAndGroupName = userAndGroupName;
			return this;
		}

		public Builder featureName(String featureName) {
			this.featureName = featureName;
			return this;
		}

		public Builder featureId(Integer featureId) {
			this.featureId = featureId;
			return this;
		}

		public Builder defaults() {
			this.read = true;
			this.write = true;
			this.isGroup = true;
			this.userAndGroupName = "Domain Users";
			this.featureName = "";
			this.featureId = 0;			
			return this;
		}

		public GetPermissionsQueryRespResultObject build() {
			return new GetPermissionsQueryRespResultObject(this);
		}

	}

}