package tests.cbsbalanceservice.request;

import java.util.HashMap;
import java.util.Map;

import tests.cbsbalanceservice.enums.CbsBalanceServiceUsers;

public class GetLatestTransactionByTransactionTypeIdReq {
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Integer user_id;
	@SuppressWarnings("unused")
	private Integer product_id;
	private Map<String, Object> params = new HashMap<>();

	private GetLatestTransactionByTransactionTypeIdReq(Builder builder) {
		this.method = builder.method;
		this.id = builder.id;
		this.params.put("user_id", builder.user_id);
		this.params.put("provider_region_id", builder.provider_region_id);
		this.params.put("partner_id", builder.partner_id);
		this.params.put("transaction_type_id", builder.transaction_type_id);
	}

	public static class Builder {
		private String method, id;
		private Integer provider_region_id, user_id, partner_id, transaction_type_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}

		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}

		public Builder transactionTypeId(Integer transaction_type_id) {
			this.transaction_type_id = transaction_type_id;
			return this;
		}

		public Builder defaults() {
			this.method  = "GetLatestTransactionByTransactionTypeId";
			this.id = "1";
			this.user_id = CbsBalanceServiceUsers.GET_LATEST_TRANSACTION_REQ.getUserId();
			this.provider_region_id = 20;
			this.partner_id = 100;
			this.transaction_type_id = 227;
			return this;
		}

		public GetLatestTransactionByTransactionTypeIdReq build() {
			return new GetLatestTransactionByTransactionTypeIdReq(this);
		}
	}
}
