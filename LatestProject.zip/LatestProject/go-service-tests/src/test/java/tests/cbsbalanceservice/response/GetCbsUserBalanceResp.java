package tests.cbsbalanceservice.response;

public class GetCbsUserBalanceResp {

	private String id;
	private Result result;

	public GetCbsUserBalanceResp() {
	}
	
	private GetCbsUserBalanceResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public String getId() {
		return id;
	}

	public Result getResult() {
		return result;
	}

	public static class Builder {
		String id;
		Integer user_id;
		String balance;
		String bonus;
		String ring_fenced;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder balance(String balance) {
			this.balance = balance;
			return this;
		}

		public Builder bonus(String bonus) {
			this.bonus = bonus;
			return this;
		}

		public Builder ringFenced(String ring_fenced) {
			this.ring_fenced = ring_fenced;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.user_id = 2001;
			this.balance = "940.83";
			this.bonus = "0";
			this.ring_fenced = "0";
			return this;
		}

		public GetCbsUserBalanceResp build() {
			return new GetCbsUserBalanceResp(this);
		}
	}

	private class Result {

		Integer user_id;
		String balance;
		String bonus;
		String ring_fenced;

		@SuppressWarnings("unused")
		public Result() {
		}
		
		public Result(Builder builder) {
			this.user_id = builder.user_id;
			this.balance = builder.balance;
			this.bonus = builder.bonus;
			this.ring_fenced = builder.ring_fenced;
		}

		@SuppressWarnings("unused")
		public Integer getUser_id() {
			return user_id;
		}

		@SuppressWarnings("unused")
		public String getBalance() {
			return balance;
		}

		@SuppressWarnings("unused")
		public String getBonus() {
			return bonus;
		}

		@SuppressWarnings("unused")
		public String getRing_fenced() {
			return ring_fenced;
		}
	}
}