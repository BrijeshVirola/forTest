package tests.cbsbalanceservice.response;

import java.util.ArrayList;
import java.util.List;

public class GetCbsTransactionsResp {

	private String id;
	private List<InsertTransaction> result;

	public GetCbsTransactionsResp() {
	}
	
	private GetCbsTransactionsResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.insertTransaction;
	}

	public String getId() {
		return id;
	}

	public List<InsertTransaction> getResult() {
		return result;
	}

	public static class Builder {
		private String id;
		private List<InsertTransaction> insertTransaction;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addTransaction(InsertTransaction insertTransaction) {
			this.insertTransaction.add(insertTransaction);
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.insertTransaction = new ArrayList<InsertTransaction>();
			return this;
		}

		public GetCbsTransactionsResp build() {
			GetCbsTransactionsResp result = new GetCbsTransactionsResp(this);
			return result;
		}
	}
}
