package tests.cbsbalanceservice.response;

public class GetCbsTransactionResp {

	private String id;
	public InsertTransaction result;

	public GetCbsTransactionResp() {
	}
	
	private GetCbsTransactionResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.insertTransaction;
	}
	
	public String getPartnerTimestampUtc() {
		return result.getPartnerTimestampUtc();
	}

	public String getId() {
		return id;
	}
	
	public InsertTransaction getResult() {
		return result;
	}

	public static class Builder {
		private String id;
		private InsertTransaction insertTransaction;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addTransaction(InsertTransaction insertTransaction) {
			this.insertTransaction = insertTransaction;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public GetCbsTransactionResp build() {
			GetCbsTransactionResp result = new GetCbsTransactionResp(this);
			return result;
		}
	}
}
