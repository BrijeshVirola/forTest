package tests.cbsbalanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.cbsbalanceservice.enums.CbsBalanceEndpoints;
import tests.cbsbalanceservice.request.GetLatestTransactionByTransactionTypeIdReq;
import tests.cbsbalanceservice.response.GetCbsTransactionResp;
import tests.cbsbalanceservice.response.InsertTransaction;

public class GetLatestTransactionByTransactionTypeIdTests extends BaseClassSetup {

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId. Positive default scenario.")
	public void getLatestTransactionByTransactionTypeId_Positive_Default_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionResp actualResponse = BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdSuccess);

		InsertTransaction insertTransaction = new InsertTransaction.Builder()
				.defaults()
				.transactionTypeId(227)
				.partnerTimestampUtc("2022-04-04T15:02:00.076Z")
				.realAmount("-0.03")
				.totalAmount("-0.03")
				.providerRegionId(20)
				.bet365TransactionId(0L)
				.bet365GamesTransactionId(9079926421282703396L)
				.gameRoundId(383998L)
				.partnerTransactionId("e41ab39b-4c1f-491f-a552-bff5803e7c7f")
				.totalAmountGbp("-0.03")
				.regulatedGameId(-1)
				.action_type_id(actualResponse.getResult().getAction_type_id())
				.flake_id(actualResponse.getResult().getFlake_id())
				.user_token(actualResponse.getResult().getUser_token())
				.actionTypeId(2)
				.build();

		GetCbsTransactionResp expectedResponse = new GetCbsTransactionResp.Builder()
				.defaults()
				.addTransaction(insertTransaction)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();


		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId with invalid method.")
	public void getLatestTransactionByTransactionTypeId_Invalid_Method() {

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId with missing parameter user_id.")
	public void getLatestTransactionByTransactionTypeId_Missing_userId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId with missing parameter provider_region_id.")
	public void getLatestTransactionByTransactionTypeId_Missing_providerRegionId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.providerRegionId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: provider_region_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId with missing parameter partner_id.")
	public void getLatestTransactionByTransactionTypeId_Missing_partnerId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.partnerId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId with missing parameter transaction_type_id.")
	public void getLatestTransactionByTransactionTypeId_Missing_transactionTypeId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.transactionTypeId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: transaction_type_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId unknown user_id.")
	public void getLatestTransactionByTransactionTypeId_Unknown_userId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.userId(999999999)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1010)
				.message("Transaction not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, CbsBalanceEndpoints.getLatestTransactionByTransactionTypeIdError);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
