package tests.cbsbalanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.cbsbalanceservice.enums.CbsBalanceEndpoints;
import tests.cbsbalanceservice.request.GetCbsUserBalanceReq;
import tests.cbsbalanceservice.response.GetCbsUserBalanceResp;

public class GetUserBalanceTests extends BaseClassSetup {

	@Test(description = "Make a request to getUserBalance. Positive default scenario.")
	public void getUserBalance_Positive_Default_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCbsUserBalanceReq requestBody = new GetCbsUserBalanceReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		GetCbsUserBalanceResp expectedResponse = new GetCbsUserBalanceResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsUserBalanceResp actualResponse = BaseRequest.post(requestBody, CbsBalanceEndpoints.getCbsUserBalanceSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getUserBalance with invalid method.")
	public void getUserBalance_Invalid_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCbsUserBalanceReq requestBody = new GetCbsUserBalanceReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, CbsBalanceEndpoints.getCbsUserBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUserBalance with missing parameter user_id.")
	public void getUserBalance_Missing_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCbsUserBalanceReq requestBody = new GetCbsUserBalanceReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, CbsBalanceEndpoints.getCbsUserBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUserBalance with missing parameter product_id.")
	public void getUserBalance_Missing_productId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCbsUserBalanceReq requestBody = new GetCbsUserBalanceReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, CbsBalanceEndpoints.getCbsUserBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUserBalance unknown user_id.")
	public void getUserBalance_Unknown_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCbsUserBalanceReq requestBody = new GetCbsUserBalanceReq.Builder()
				.defaults()
				.userId(999999999)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsUserBalanceResp expectedResponse = new GetCbsUserBalanceResp.Builder()
				.defaults()
				.userId(999999999)
				.balance("0")
				.bonus("0")
				.ringFenced("0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsUserBalanceResp actualResponse = BaseRequest.post(requestBody, CbsBalanceEndpoints.getCbsUserBalanceSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
