package tests.cbsbalanceservice.enums;

import common.DatabaseQueries;

public enum CbsBalanceServiceUsers {

	CBS_ADJUST_BALANCE_REQ("gbt_lachuk4"),
	GET_LATEST_TRANSACTION_REQ("GO_SVC_TEST136"),
	GET_TRANSACTION_BY_PARTNER_REQ("gbt_lachuk4");

	private String username;

	private CbsBalanceServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}