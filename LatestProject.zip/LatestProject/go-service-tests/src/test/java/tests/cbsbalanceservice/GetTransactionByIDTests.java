package tests.cbsbalanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.cbsbalanceservice.enums.CbsBalanceEndpoints;
import tests.cbsbalanceservice.request.GetTransactionByIDReq;
import tests.cbsbalanceservice.response.GetCbsTransactionResp;
import tests.cbsbalanceservice.response.InsertTransaction;

public class GetTransactionByIDTests extends BaseClassSetup {

	@Test(description = "Make a request to getTransactionsById. Positive default scenario.")
	public void getTransactionById_Positive_Default_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTransactionByIDReq requestBody = new GetTransactionByIDReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionResp actualResponse = BaseRequest.post(requestBody, CbsBalanceEndpoints.getCbsTransactionByIdSuccess);
		
		InsertTransaction insertTransaction = new InsertTransaction.Builder()
				.defaults()
				.action_type_id(actualResponse.getResult().getAction_type_id())
				.flake_id(actualResponse.getResult().getFlake_id())
				.user_token(actualResponse.getResult().getUser_token())
				.actionTypeId(1)
				.build();

		GetCbsTransactionResp expectedResponse = new GetCbsTransactionResp.Builder()
				.defaults()
				.addTransaction(insertTransaction)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getTransactionsById with invalid method.")
	public void getTransactionsById_Invalid_Method() {

		GetTransactionByIDReq requestBody = new GetTransactionByIDReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, CbsBalanceEndpoints.getCbsTransactionByIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getTransactionsById with missing parameter id.")
	public void getTransactionsById_Missing_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTransactionByIDReq requestBody = new GetTransactionByIDReq.Builder()
				.defaults()
				.idInParams(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(requestBody, CbsBalanceEndpoints.getCbsTransactionByIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: ID")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getTransactionsById unknown id.")
	public void getTransactionsById_Unknown_Id() {
		Long unknownId = 281474976710656L;
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTransactionByIDReq requestBody = new GetTransactionByIDReq.Builder()
				.defaults()
				.idInParams(unknownId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1010)
				.message("Transaction not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(requestBody, CbsBalanceEndpoints.getCbsTransactionByIdError);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
