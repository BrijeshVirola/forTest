package tests.cbsbalanceservice.request;

import java.time.Instant;
import java.util.Random;
import java.util.UUID;

import common.TransactionType;
import tests.cbsbalanceservice.enums.CbsBalanceServiceUsers;   

public class CbsAdjustBalanceReq {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;
	public Params params;

	private CbsAdjustBalanceReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params = new Params(builder);
	}
	
	public static class Builder {
		String id, method, bonus_game_type, token;
		Long bet365_games_transaction_id, game_round_id, bet365_transaction_id, flake_id, source_bet365_games_transaction_id;
		String partner_transaction_id;
		String real_amount, bonus_amount, total_amount, total_amount_gbp, currency_code, partner_timestamp_utc;
		String ring_fenced_amount;
		Integer provider_region_id, transaction_type_id, user_id, cmscore_game_id, regulated_game_id, partner_id, product_id, currency_id, user_bonus_id, action_type_id;
		Boolean is_new, allow_bonus, allow_ring_fenced;
		ExternalBalanceChange external_balance_change;
		
		Random random = new Random();
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder bet365GamesTransactionId(Long bet365_games_transaction_id) {
			this.bet365_games_transaction_id = bet365_games_transaction_id;
			return this;
		}

		public Builder transactionTypeId(Integer transaction_type_id) {
			this.transaction_type_id = transaction_type_id;
			return this;
		}

		public Builder partnerTransactionId(String partner_transaction_id) {
			this.partner_transaction_id = partner_transaction_id;
			return this;
		}

		public Builder realAmount(String real_amount) {
			this.real_amount = real_amount;
			return this;
		}
		
		public Builder ringFencedAmount(String ring_fenced_amount) {
			this.ring_fenced_amount = ring_fenced_amount;
			return this;
		}
		
		public Builder bonusAmount(String bonus_amount) {
			this.bonus_amount = bonus_amount;
			return this;
		}
		
		public Builder totalAmount(String total_amount) {
			this.total_amount = total_amount;
			return this;
		}
		
		public Builder totalAmountGbp(String total_amount_gbp) {
			this.total_amount_gbp = total_amount_gbp;
			return this;
		}
		
		public Builder currencyCode(String currency_code) {
			this.currency_code = currency_code;
			return this;
		}

		public Builder partnerTimestampUtc(String partner_timestamp_utc) {
			this.partner_timestamp_utc = partner_timestamp_utc;
			return this;
		}
		
		public Builder gameRoundId(Long game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}
		
		public Builder bet365TransactionId(Long bet365_transaction_id) {
			this.bet365_transaction_id = bet365_transaction_id;
			return this;
		}
		
		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}
		
		public Builder bonusGameType(String bonus_game_type) {
			this.bonus_game_type = bonus_game_type;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder cmsCoreGameId(Integer cmscore_game_id) {
			this.cmscore_game_id = cmscore_game_id;
			return this;
		}
		
		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}
		
		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}
		
		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}
		
		public Builder token(String token) {
			this.token = token;
			return this;
		}
		
		public Builder allowBonus(Boolean allow_bonus) {
			this.allow_bonus = allow_bonus;
			return this;
		}
		
		public Builder allowRingFenced(Boolean allow_ring_fenced) {
			this.allow_ring_fenced = allow_ring_fenced;
			return this;
		}
		
		public Builder currencyId(Integer currency_id) {
			this.currency_id = currency_id;
			return this;
		}
		
		public Builder flakeId(Long flake_id) {
			this.flake_id = flake_id;
			return this;
		}
		
		public Builder userBonusId(Integer user_bonus_id) {
			this.user_bonus_id = user_bonus_id;
			return this;
		}
		
		public Builder actionTypeId(Integer action_type_id) {
			this.action_type_id = action_type_id;
			return this;
		}
		
		public Builder addExternalBalanceChange(ExternalBalanceChange external_balance_change) {
			this.external_balance_change = external_balance_change;
			return this;
		}
		
		public Builder sourceBet365GamesTransactionId(Long source_bet365_games_transaction_id) {
			this.source_bet365_games_transaction_id = source_bet365_games_transaction_id;
			return this;
		}
		
		
		public Builder defaults() {
			this.id = "1";
			this.method = "AdjustBalance";
			this.flake_id = UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE;
			this.real_amount = "-0.01";
			this.bonus_amount = "-0.01";
			this.ring_fenced_amount = "-0.01";
			this.total_amount = "-0.03";
			this.bonus_game_type = "G";
			this.user_id = CbsBalanceServiceUsers.CBS_ADJUST_BALANCE_REQ.getUserId();
			this.action_type_id = TransactionType.STAKE.getValue();
			this.cmscore_game_id = 2885;
			this.regulated_game_id = 6403;
			this.transaction_type_id = 2;
			this.partner_transaction_id = UUID.randomUUID().toString();
			this.partner_timestamp_utc = Instant.now().toString();
			this.partner_id = 100;
			this.game_round_id = 383998L;
			this.product_id = 19;
			this.token = "99faa686-3189-4eea-b789-bf828ed78a34";
			this.provider_region_id = 20;
			this.allow_bonus = true;
			this.allow_ring_fenced = true;
			this.currency_id = 1;
			this.bet365_transaction_id = UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE;
			this.user_bonus_id = null;
			this.external_balance_change = null;
			this.source_bet365_games_transaction_id = null;

			return this;
		}

		public CbsAdjustBalanceReq build() {
			return new CbsAdjustBalanceReq(this);
		}
	}

	public class Params {
		public Long flake_id;
		public String real_amount;
		public String bonus_amount;
		public String ring_fenced_amount;
		public String total_amount;
		public String bonus_game_type;
		public Integer user_id;
		public Integer cmscore_game_id;
		public Integer regulated_game_id;
		public String partner_transaction_id;
		public Integer transaction_type_id;
		public String partner_timestamp_utc;
		public Integer partner_id;
		public Long game_round_id;
		public Integer product_id;
		public String token;
		public Integer provider_region_id;
		public Boolean allow_bonus;
		public Boolean allow_ring_fenced;
		public Integer currency_id;
		public Long bet365_transaction_id;
		public Integer user_bonus_id;
		public ExternalBalanceChange external_balance_change;
		public Long source_bet365_games_transaction_id;
		public Integer action_type_id;
		
		public Params(Builder builder) {
			this.flake_id = builder.flake_id;
			this.real_amount = builder.real_amount;
			this.bonus_amount = builder.bonus_amount;
			this.ring_fenced_amount = builder.ring_fenced_amount;
			this.total_amount = builder.total_amount;
			this.bonus_game_type = builder.bonus_game_type;
			this.user_id = builder.user_id;
			this.cmscore_game_id = builder.cmscore_game_id;
			this.regulated_game_id = builder.regulated_game_id;
			this.transaction_type_id = builder.transaction_type_id;
			this.partner_transaction_id = builder.partner_transaction_id;
			this.partner_timestamp_utc = builder.partner_timestamp_utc;
			this.partner_id = builder.partner_id;
			this.game_round_id = builder.game_round_id;
			this.product_id = builder.product_id;
			this.token = builder.token;
			this.action_type_id = builder.action_type_id;
			this.provider_region_id = builder.provider_region_id;
			this.allow_bonus = builder.allow_bonus;
			this.allow_ring_fenced = builder.allow_ring_fenced;
			this.currency_id = builder.currency_id;
			this.bet365_transaction_id = builder.bet365_transaction_id;
			this.user_bonus_id = builder.user_bonus_id;
			this.external_balance_change = builder.external_balance_change;
			this.source_bet365_games_transaction_id = builder.source_bet365_games_transaction_id;
		}
	}
}
