package tests.cbsbalanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import common.FlakeGenerator;
import common.TransactionType;
import common.enumsconstants.Constants;
import domain.BaseRequest;
import tests.balanceservice.enums.BalanceEndpoints;
import tests.cbsbalanceservice.enums.CbsBalanceEndpoints;
import tests.cbsbalanceservice.request.CbsAdjustBalanceReq;
import tests.cbsbalanceservice.request.ExternalBalanceChange;
import tests.cbsbalanceservice.response.GetCbsTransactionResp;
public class AdjustBalanceTests extends BaseClassSetup {

	@DataProvider(name = "group1PlaytechTransactionTypeProvider")
	public Object[][] getGroup1PlaytechTransactionTypes() {
		return new Object[][] {	
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER}
		};
	}

	@Test(description = "Make a request to Adjust balance endpoint. Positive scenario.", dataProvider = "group1PlaytechTransactionTypeProvider")
	public void valid_Group1PlaytechTransactionType_When_AdjustBalance_Then_TheExpectedTransactionIsReturned(TransactionType transactionType) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = transactionType.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.actionTypeId(TransactionType.STAKE.getValue())
				.realAmount(null)
				.bonusAmount(null)
				.ringFencedAmount(null)
				.bet365TransactionId(null)
				.regulatedGameId(-1)
				.cmsCoreGameId(-1)
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals("-0.03", actualResponse.result.real_amount);
		Assert.assertEquals("0", actualResponse.result.ring_fenced_amount);
		Assert.assertEquals("0", actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals("-0.03", actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(actualResponse.result.regulated_game_id, null);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@DataProvider(name = "group1NonPlaytechTransactionTypeProvider")
	public Object[][] getGroup1NonPlaytechTransactionTypes() {
		return new Object[][] {	
			{TransactionType.STAKE},
			{TransactionType.FREE_SPIN_STAKE},
			{TransactionType.GOLDEN_CHIP_STAKE},
			{TransactionType.GAMING_STAKE},
			{TransactionType.POKER_BUY_CHIPS},
			{TransactionType.POKER_TOURNAMENT_ENTRY},
			{TransactionType.POKER_TOURNAMENT_REBUY}
		};
	}
	
	@DataProvider(name = "externalBalanceChange")
	public Object[][] externalBalanceChange() {
		return new Object[][] {	
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER},
			{TransactionType.GAMING_STAKE},
			{TransactionType.POKER_BUY_CHIPS},
			{TransactionType.POKER_TOURNAMENT_ENTRY},
			{TransactionType.POKER_TOURNAMENT_REBUY}
		};
	}

	@Test(description = "Make a request to Adjust balance endpoint. Positive scenario.", dataProvider = "group1NonPlaytechTransactionTypeProvider")
	public void valid_Group1NonPlaytechTransactionType_When_AdjustBalance_Then_TheExpectedTransactionIsReturned(TransactionType transactionType) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = transactionType.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.actionTypeId(TransactionType.GAMING_RETURN.getValue())
				.realAmount(null)
				.bonusAmount(null)
				.ringFencedAmount(null)
				.bet365TransactionId(null)
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals("-0.03", actualResponse.result.real_amount);
		Assert.assertEquals("0", actualResponse.result.ring_fenced_amount);
		Assert.assertEquals("0", actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals("-0.03", actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(actualResponse.result.regulated_game_id, null);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@Test(description = "Make a request to Adjust balance endpoint including optional external balance data. Positive scenario.", dataProvider = "externalBalanceChange")
	public void valid_Group1TransactionType_When_AdjustBalanceWithExternalBalanceChange_Then_TheExpectedTransactionIsReturned(
			TransactionType transactionType) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = transactionType.getValue();

		ExternalBalanceChange external_balance_change = new ExternalBalanceChange.Builder()
				.bonusAmount("-0.03")
				.ringFencedAmount("0")
				.build();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.realAmount("0")
				.bonusAmount(null)
				.ringFencedAmount(null)
				.transactionTypeId(transactionTypeInt)
				.addExternalBalanceChange(external_balance_change)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals("0", actualResponse.result.real_amount);
		Assert.assertEquals("0", actualResponse.result.ring_fenced_amount);
		Assert.assertEquals("0", actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals("-0.03", actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertEquals(request.params.bet365_transaction_id, actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(actualResponse.result.regulated_game_id, null);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@DataProvider(name = "group3TransactionTypeProvider")
	public Object[][] getGroup3TransactionTypes() {
		return new Object[][] {	
			{TransactionType.RETURN},
			{TransactionType.FREE_SPIN_RETURN},
			{TransactionType.GOLDEN_CHIP_RETURN},
			{TransactionType.GAMING_RETURN},
			//{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO},
			//{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO},
			{TransactionType.POKER_SELL_CHIPS},
			{TransactionType.POKER_TOURNAMENT_WIN},
			//{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER}
		};
	}

	@ExpectedFailure(jiraRef = "PRJSAK-2150", action = "unrecognised transaction types removed form data provider.")
	@Test(description = "Make a request to Adjust balance endpoint excluding optional external balance data. Positive scenario.", dataProvider = "group3TransactionTypeProvider")
	public void valid_Group3TransactionType_When_AdjustBalanceWithoutExternalBalanceChange_Then_TheExpectedTransactionIsReturned(
			TransactionType transactionType) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = transactionType.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusGameType(null)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.sourceBet365GamesTransactionId(null)
				.realAmount("0.01")
				.bonusAmount("0.01")
				.ringFencedAmount("0.01")
				.totalAmount("0.03")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);

		Assert.assertEquals("0.02", actualResponse.result.real_amount);
		Assert.assertEquals("0", actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.ring_fenced_amount, actualResponse.result.ring_fenced_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertTrue(actualResponse.result.bet365_games_transaction_id > 0);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(actualResponse.result.regulated_game_id, null);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@Test(description = "Make a request to Adjust balance endpoint for instant games return excluding optional external balance data. Positive scenario.")
	public void valid_Group4TransactionType_When_AdjustBalanceWithoutExternalBalanceChange_Then_TheExpectedTransactionIsReturned() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = TransactionType.INSTANT_GAMES_RETURN.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.userBonusId(null)
				.realAmount("1.01")
				.bonusAmount("1.01")
				.ringFencedAmount("1.01")
				.totalAmount("3.03")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals("2.02", actualResponse.result.real_amount);
		Assert.assertEquals("0", actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.ring_fenced_amount, actualResponse.result.ring_fenced_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertTrue(actualResponse.result.bet365_games_transaction_id > 0);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(actualResponse.result.regulated_game_id, null);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@DataProvider(name = "group5TransactionTypeProvider")
	public Object[][] getGroup5TransactionTypes() {
		return new Object[][] {	
			{TransactionType.VOID_STAKE},
			{TransactionType.VOID_GAMING_STAKE},
			{TransactionType.VOID_POKER_BUY_CHIPS},
			{TransactionType.VOID_POKER_TOURNAMENT_ENTRY},
			{TransactionType.VOID_POKER_TOURNAMENT_REBUY}
		};
	}

	@Test(description = "Make a request to Adjust balance endpoint excluding optional external balance data. Positive scenario.", dataProvider = "group5TransactionTypeProvider")
	public void valid_Group5TransactionType_When_AdjustBalanceWithoutExternalBalanceChange_Then_TheExpectedTransactionIsReturned(
			TransactionType transactionType) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = transactionType.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.allowBonus(null)
				.allowRingFenced(null)
				.realAmount("0.01")
				.bonusAmount("0.01")
				.ringFencedAmount("0.01")
				.totalAmount("0.03")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals(request.params.real_amount, actualResponse.result.real_amount);
		Assert.assertEquals(request.params.bonus_amount, actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.ring_fenced_amount, actualResponse.result.ring_fenced_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertTrue(actualResponse.result.bet365_games_transaction_id > 0);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(actualResponse.result.regulated_game_id, null);
		Assert.assertTrue(actualResponse.result.is_new);
	}

	@Test(description = "Make a request to Adjust balance endpoint for void instant games stake excluding optional external balance data. Positive scenario.")
	public void valid_Group6TransactionType_When_AdjustBalanceWithoutExternalBalanceChange_Then_TheExpectedTransactionIsReturned() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = TransactionType.VOID_INSTANT_GAMES_STAKE.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.allowBonus(null)
				.allowRingFenced(null)
				.userBonusId(null)
				.realAmount("0.01")
				.bonusAmount("0.01")
				.ringFencedAmount("0.01")
				.totalAmount("0.03")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();

		GetCbsTransactionResp actualResponse =  BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceSuccess);

		Assert.assertEquals(transactionTypeInt, actualResponse.result.transaction_type_id);
		Assert.assertEquals(request.params.partner_transaction_id, actualResponse.result.partner_transaction_id);
		Assert.assertEquals(request.params.real_amount, actualResponse.result.real_amount);
		Assert.assertEquals(request.params.bonus_amount, actualResponse.result.bonus_amount);
		Assert.assertEquals(request.params.ring_fenced_amount, actualResponse.result.ring_fenced_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount);
		Assert.assertEquals(request.params.total_amount, actualResponse.result.total_amount_gbp);
		Assert.assertEquals("GBP", actualResponse.result.currency_code);

		String timeStampAdjustedForTrailingZeroRemovalInResponse = request.params.partner_timestamp_utc.replaceAll("0+(?=Z)", "");
		Assert.assertEquals(timeStampAdjustedForTrailingZeroRemovalInResponse, actualResponse.result.partner_timestamp_utc);

		Assert.assertEquals(new Long(0), actualResponse.result.bet365_transaction_id);
		Assert.assertEquals(request.params.game_round_id, actualResponse.result.game_round_id);
		Assert.assertTrue(actualResponse.result.bet365_games_transaction_id > 0);
		Assert.assertEquals(request.params.provider_region_id, actualResponse.result.provider_region_id);
		Assert.assertEquals(actualResponse.result.regulated_game_id, null);
		Assert.assertTrue(actualResponse.result.is_new);
	}
	
	
	@Test(description = "Make a request to Adjust balance endpoint for void instant games stake with negative amount. Negative scenario.")
	public void adjustBalanceRequest_voidInstantGamesStake_NegativeAmount() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer transactionTypeInt = TransactionType.VOID_INSTANT_GAMES_STAKE.getValue();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(transactionTypeInt)
				.id(idForRequestToBeEchoedBackInResponseId)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.allowBonus(null)
				.allowRingFenced(null)
				.userBonusId(null)
				.realAmount("-0.01")
				.bonusAmount("-0.01")
				.ringFencedAmount("-0.02")
				.totalAmount("-0.03")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();
		
		CustomErrorResponse actualError = BaseRequest.post(request, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.id(idForRequestToBeEchoedBackInResponseId)
				.code(1006)
				.message("Void stakes must use a positive real_amount")
				.build();
		assertReflectionEquals(expectedError, actualError);

		
	}
	
	@Test(description = "Make a request to Adjust balance endpoint Instant Games Stake Different Amount . Negative scenario.")
	public void validInstantgamesStake_DifferentAmount_Negative_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(TransactionType.INSTANT_GAMES_STAKE.getValue())
				.id(idForRequestToBeEchoedBackInResponseId)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.allowBonus(null)
				.allowRingFenced(null)
				.realAmount("-1")
				.bonusAmount("0.01")
				.ringFencedAmount("0.01")
				.totalAmount("-31")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();
		
		CustomErrorResponse actualError = BaseRequest.post(request, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.id(idForRequestToBeEchoedBackInResponseId)
				.code(1006)
				.message("TotalAmount is different to RealAmount")
				.build();
		assertReflectionEquals(expectedError, actualError);

	}
	
	@Test(description = "Make a request to Adjust balance endpoint Instant Games Stake. Positive scenario.")
	public void validInstantgamesStake_PositiveAmount_Negative_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(TransactionType.INSTANT_GAMES_STAKE.getValue())
				.id(idForRequestToBeEchoedBackInResponseId)
				.cmsCoreGameId(null)
				.bet365TransactionId(null)
				.allowBonus(null)
				.allowRingFenced(null)
				.realAmount("1")
				.bonusAmount("0.01")
				.ringFencedAmount("0.01")
				.totalAmount("31")
				.sourceBet365GamesTransactionId(FlakeGenerator.nextId(Constants.nodeId)) 
				.build();
		
		CustomErrorResponse actualError = BaseRequest.post(request, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.id(idForRequestToBeEchoedBackInResponseId)
				.code(1006)
				.message("Stakes must use a negative total_amount")
				.build();
		assertReflectionEquals(expectedError, actualError);

	}
	
	@Test(description = "Make a request to Adjust balance endpoint RequestAmountsNotAddUp. Negative scenario.")
	public void adjustBalanceRequest_RequestAmountsNotAddUp_Negative_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.realAmount("0")
				.bonusAmount("0.03")
				.ringFencedAmount("0.5")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.id(idForRequestToBeEchoedBackInResponseId)
				.code(1006)
				.message("Requested transfer amounts do not add up")
				.build();
		assertReflectionEquals(expectedError, actualError);

	}	
	
	@Test(description = "Make a request to Adjust balance endpoint ProductIdRequired. Negative scenario.")
	public void adjustBalanceRequest_ProductIdRequired_Negative_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ExternalBalanceChange external_balance_change = new ExternalBalanceChange.Builder()
                .defaults()
				.build();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(149)
				.productId(null)
				.addExternalBalanceChange(external_balance_change)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		CustomErrorResponse actualError = BaseRequest.post(request, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.id(idForRequestToBeEchoedBackInResponseId)
				.code(1011)
				.message("product_id must be for a Casino or Poker product")
				.build();
		assertReflectionEquals(expectedError, actualError);

	}	
	
	@Test(description = "Make a request to Adjust balance endpoint realAmountRequired. Negative scenario.")
	public void adjustBalanceRequest_RealAmountRequired_Negative_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ExternalBalanceChange external_balance_change = new ExternalBalanceChange.Builder()
                .defaults()
				.build();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.realAmount(null)
				.transactionTypeId(149)
				.addExternalBalanceChange(external_balance_change)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		CustomErrorResponse actualError = BaseRequest.post(request, BalanceEndpoints.adjustBalanceError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.id(idForRequestToBeEchoedBackInResponseId)
				.code(7)
				.message("Missing or invalid parameter: real_amount")
				.build();
		assertReflectionEquals(expectedError, actualError);

	}	
	
	@Test(description = "Make a request to Adjust balance endpoint without Action Type ID. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_Then_TheExpectedTransactionIsReturned_No_Action_Type_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.actionTypeId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1011)
				.message("Missing or invalid parameter: action_type_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to Adjust balance endpoint with action type ID value 0. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_Invalid_Action_Type_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.actionTypeId(0)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1011)
				.message("Missing or invalid parameter: action_type_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to Adjust balance endpoint with negative action type ID . Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_Negative_Action_Type_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.actionTypeId(-1)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1011)
				.message("Missing or invalid parameter: action_type_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to Adjust balance endpoint without Flake ID. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_No_Flake_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.flakeId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: flake_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	
	@Test(description = "Make a request to Adjust balance endpoint without User ID. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_No_User_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to Adjust balance endpoint without Regulated Game ID. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_No_Regulated_Game_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.regulatedGameId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: regulated_game_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	
	@Test(description = "Make a request to Adjust balance endpoint without Partner Transaction ID. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_No_Partner_Transaction_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.partnerTransactionId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: partner_transaction_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to Adjust balance endpoint without Partner Time Stamp. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_Without_Partner_TimeStamp() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.partnerTimestampUtc(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: partner_timestamp_utc")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to Adjust balance endpoint without Partner ID. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_Without_Partner_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.partnerId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: partner_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to Adjust balance endpoint without Game Round ID. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_Without_Game_Round_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.gameRoundId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: game_round_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to Adjust balance endpoint without Transaction Type ID. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_Without_Transaction_Type_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.transactionTypeId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: transaction_type_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to Adjust balance endpoint without Token. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_Without_Token() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.token(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: token")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to Adjust balance endpoint without Token. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_Without_Provider_Region_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.providerRegionId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: provider_region_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	

	@Test(description = "Make a request to Adjust balance endpoint without Source Bet365 Tranaction Id. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_Without_SourceBet365_Transaction_Id() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.sourceBet365GamesTransactionId(null)
				.transactionTypeId(83)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: source_bet365_games_transaction_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to Adjust balance endpoint without gameRoundId. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_No_gameRoundId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.gameRoundId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: game_round_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to Adjust balance endpoint without regulatedGameId. Negative scenario.")
	public void valid_GroupPlaytechTransactionType_When_AdjustBalance_No_regulatedGameId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CbsAdjustBalanceReq request = new CbsAdjustBalanceReq.Builder()
				.defaults()
				.regulatedGameId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.post(request, CbsBalanceEndpoints.cbsAdjustBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing or invalid parameter: regulated_game_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	
	}