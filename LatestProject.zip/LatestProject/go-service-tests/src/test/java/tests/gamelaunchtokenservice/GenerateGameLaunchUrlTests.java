package tests.gamelaunchtokenservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamelaunchtokenservice.enums.GameLaunchTokenEndpoints;
import tests.gamelaunchtokenservice.request.GenerateGameLaunchUrlReq;
import tests.gamelaunchtokenservice.response.GenerateGameLaunchUrlResp;

public class GenerateGameLaunchUrlTests  extends BaseClassSetup{

	@Test(description = "Make a request to GenerateGameLaunchUrl. Positive scenario.")
	public void generateGameLaunchUrl_Positive_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GenerateGameLaunchUrlResp actResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlSuccess);

		GenerateGameLaunchUrlResp expResponse =  new GenerateGameLaunchUrlResp.Builder()
				.defaults()
				.token(actResponse.result.get("token").toString())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(actResponse, expResponse);
	}

	@Test(description = "Make a request to generateGameLaunchUrl. Missing product_id parameter.")
	public void generateGameLaunchUrl_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to generateGameLaunchUrl. Wrong method.")
	public void generateGameLaunchUrl_Wrong_Method() {

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to generateGameLaunchUrl. Missing Language Code.")
	public void generateGameLaunchUrl_Missing_Language_Code() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.languageCode(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: language_code")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to generateGameLaunchUrl. Missing Provider Implementation Id.")
	public void generateGameLaunchUrl_Missing_Provider_ImplementationId() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerImplementationId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: provider_implementation_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to generateGameLaunchUrl. Missing Game Token Id.")
	public void generateGameLaunchUrl_Missing_Game_Token_Id() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.gameTokenId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: game_token_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to generateGameLaunchUrl. Missing Product Id.")
	public void generateGameLaunchUrl_Missing_Product_Id() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.productId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: product_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to generateGameLaunchUrl. Missing Launch host.")
	public void generateGameLaunchUrl_Missing_Launch_Host() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.launchHost(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: launch_host")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to generateGameLaunchUrl. Missing Session Id.")
	public void generateGameLaunchUrl_Missing_Session_Id() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: session_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to generateGameLaunchUrl. Missing Platform Type Id.")
	public void generateGameLaunchUrl_Missing_Platform_Type_Id() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.platformTypeId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: platform_type_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to generateGameLaunchUrl. Missing Country Id")
	public void generateGameLaunchUrl_Missing_Country_Id() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.countryId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: country_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to generateGameLaunchUrl. Missing Regulated Game Id")
	public void generateGameLaunchUrl_Missing_regulated_Game_Id() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.regulatedGameId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: regulated_game_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to generateGameLaunchUrl. Missing association - optional parameter")
	public void generateGameLaunchUrl_Missing_association() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.association(null)
				.build();

		GenerateGameLaunchUrlResp actResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlSuccess);

		GenerateGameLaunchUrlResp expResponse =  new GenerateGameLaunchUrlResp.Builder()
				.defaults()
				.token(actResponse.result.get("token").toString())
				.absoluteUrl("https://www.sagala-uat365.com/GamingLaunch/en-GB/"+actResponse.result.get("token").toString())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(actResponse, expResponse);
	}
	
	@Test(enabled = false, description = "Make a request to generateGameLaunchUrl. Missing Free Play -optional parameter")
	public void generateGameLaunchUrl_Missing_FreePlay() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GenerateGameLaunchUrlReq request = new GenerateGameLaunchUrlReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.freePlay(null)
				.build();

		GenerateGameLaunchUrlResp actResponse =  BaseRequest.post(request, GameLaunchTokenEndpoints.generateGameLaunchUrlSuccess);

		GenerateGameLaunchUrlResp expResponse =  new GenerateGameLaunchUrlResp.Builder()
				.defaults()
				.token(actResponse.result.get("token").toString())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(actResponse, expResponse);
	}
}
