package tests.gamelaunchtokenservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetGameLaunchDetailsReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private GetGameLaunchDetailsReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("token", builder.token);
	}

	public static class Builder {
		private String method, id, token;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder token(String token) {
			this.token = token;
			return this;
		}

		public Builder defaults() {
			this.method = "getgamelaunchdetails";
			this.id = "1";
			this.token = null;
			return this;
		}

		public GetGameLaunchDetailsReq build() {
			return new GetGameLaunchDetailsReq(this);
		}
	}
}
