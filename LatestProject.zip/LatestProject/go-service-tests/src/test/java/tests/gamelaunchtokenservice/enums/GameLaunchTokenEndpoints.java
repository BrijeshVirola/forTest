package tests.gamelaunchtokenservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.gamelaunchtokenservice.response.GenerateGameLaunchUrlResp;
import tests.gamelaunchtokenservice.response.GetGameLaunchDetailsResp;

public enum GameLaunchTokenEndpoints implements ResponseEndpoints {

	generateGameLaunchUrlSuccess(GenerateGameLaunchUrlResp.class, "GenerateGameLaunchUrl"),
	generateGameLaunchUrlError(CustomErrorResponse.class, "GenerateGameLaunchUrl"),
	getGameLaunchDetailsSuccess(GetGameLaunchDetailsResp.class, "GetGameLaunchDetails"),
	getGameLaunchDetailsError(CustomErrorResponse.class, "GetGameLaunchDetails");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GameLaunchTokenEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
