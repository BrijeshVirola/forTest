package tests.gamelaunchtokenservice.response;

import java.util.HashMap;
import java.util.Map;

public class GenerateGameLaunchUrlResp {
	
	public String id = null;
	public Map<String, Object> result = new HashMap<>();
	
	public GenerateGameLaunchUrlResp() {
	}
	
	private GenerateGameLaunchUrlResp(Builder builder) {
		this.id = builder.id;
		this.result.put("absolute_url", builder.absolute_url);
		this.result.put("token", builder.token);
	}
	
	public static class Builder {
		private String id, token, absolute_url;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder absoluteUrl(String absolute_url) {
			this.absolute_url = absolute_url;
			return this;
		}
		
		public Builder token(String token) {
			this.token = token;
			this.absolute_url += token;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.absolute_url = "https://www011.sagala-uat365.com/GamingLaunch/en-GB/";
			this.token = "";
			return this;
		}
		
		public GenerateGameLaunchUrlResp build() {
			return new GenerateGameLaunchUrlResp(this);
		}	
	}
}
