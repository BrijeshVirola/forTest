package tests.gamelaunchtokenservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetGameLaunchDetailsResp {
	
	public String id = null;
	public Map<String, Object> result = new HashMap<>();
	
	private GetGameLaunchDetailsResp(Builder builder) {
		this.id = builder.id;
		this.result.put("active", builder.active);
		this.result.put("product_id", builder.product_id);
		this.result.put("country_id", builder.country_id);
		this.result.put("language_code", builder.language_code);
		this.result.put("session_id", builder.session_id);
		this.result.put("association", builder.association);
		this.result.put("launch_host", builder.launch_host);
		this.result.put("platform_type_id", builder.platform_type_id);
		this.result.put("free_play", builder.free_play);
		this.result.put("regulated_game_id", builder.regulated_game_id);
		this.result.put("game_token_id", builder.game_token_id);
		this.result.put("provider_implementation_id", builder.provider_implementation_id);
	}
	
	public GetGameLaunchDetailsResp() {	
	}
	
	public static class Builder {
		private String id, language_code, session_id, association, launch_host;
		private Integer product_id, platform_type_id, country_id, regulated_game_id, game_token_id, provider_implementation_id;
		private Boolean free_play, active;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder active(Boolean active) {
			this.active = active;
			return this;
		}
		
		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}
		
		public Builder countryId(Integer country_id) {
			this.country_id = country_id;
			return this;
		}
		
		public Builder languageCode(String language_code) {
			this.language_code = language_code;
			return this;
		}

		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}
		
		public Builder association(String association) {
			this.association = association;
			return this;
		}
		
		public Builder launchHost(String launch_host) {
			this.launch_host = launch_host;
			return this;
		}
		
		public Builder platformTypeId(Integer platform_type_id) {
			this.platform_type_id = platform_type_id;
			return this;
		}
		
		public Builder freePlay(Boolean free_play) {
			this.free_play = free_play;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.active = true;
			this.product_id = 4;
			this.country_id = 0;
			this.language_code = "";
			this.session_id = "41D9B93552C54A738B0E4DE0C7B6DB3D000004";
			this.association = "";
			this.launch_host = "https://games011.b365uat.com";
			this.platform_type_id = 1;
			this.free_play = false;
			this.regulated_game_id = 37508;
			this.game_token_id = 7516;
			this.provider_implementation_id = 145;
			return this;
		}
		
		public GetGameLaunchDetailsResp build() {
			return new GetGameLaunchDetailsResp(this);
		}	
	}
}
