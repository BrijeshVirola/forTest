package tests.gamethunderkicklaunchservice.request;

import java.util.HashMap;
import java.util.Map;

public class HtmlReq {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private HtmlReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("game_launch_token", builder.game_launch_token);
		this.params.put("user_id", builder.user_id);
		this.params.put("language_id", builder.language_id);
		this.params.put("environment_id", builder.environment_id);
		this.params.put("sagala_domain", builder.sagala_domain);
		this.params.put("culture", builder.culture);
	}

	public static class Builder {
		private String id, method, game_launch_token, sagala_domain, culture;
		private Integer user_id, language_id, environment_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder game_launch_token(String game_launch_token) {
			this.game_launch_token = game_launch_token;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder language_id(Integer language_id) {
			this.language_id = language_id;
			return this;
		}

		public Builder environment_id(Integer environment_id) {
			this.environment_id = environment_id;
			return this;
		}

		public Builder sagala_domain(String sagala_domain) {
			this.sagala_domain = sagala_domain;
			return this;
		}

		public Builder culture(String culture) {
			this.culture = culture;
			return this;
		}

		public Builder defaults() {
			this.id = "123456789";
			this.method = "html";
			this.game_launch_token = "f3180626-3a2c-4546-b5aa-cbd77158b524";
			this.user_id = 123;
			this.language_id = 2;
			this.environment_id = 1;
			this.sagala_domain = "https://www011.sagala-uat.com";
			this.culture = "en-GB";
			return this;
		}

		public HtmlReq build() {
			return new HtmlReq(this);
		}
	}
}
