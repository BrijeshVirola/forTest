package tests.gamethunderkicklaunchservice.response;

import java.util.HashMap;
import java.util.Map;

public class PostApiHtmlResp {

	private String id;
	private Map<String, Object> result = new HashMap<>();

	public PostApiHtmlResp() {
	}
	
	private PostApiHtmlResp(Builder builder) {
		
		this.id = builder.id;
		this.result.put("html", builder.html);	
	}
	
	public String getId() {
		return this.id;
	}
	
	public Map<String, Object> getResult() {
		return result;
	}

	public static class Builder {
		
		private String id, html;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder html(String html) {
			this.html = html;
			return this;
		}

		public Builder defaults() {
			this.id = "123456789";
			this.html = "some html";
			return this;
		}

		public PostApiHtmlResp build() {
			return new PostApiHtmlResp(this);
		}
		
	}

	@Override
	public String toString() {
		return "PostApiHtmlResp [id=" + id + ", result=" + result + "]";
	}
	
}
