package tests.gamethunderkicklaunchservice.enums;

import common.DatabaseQueries;

public enum GameThunderkickLaunchServiceUsers {

	POST_HTML_POS1("GAMETKI01"),
	POST_HTML_NEG("GAMETKI99");

	private String username;

	private GameThunderkickLaunchServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}