package tests.gamethunderkicklaunchservice.response;

public class GetApiAssetResp {	

}

