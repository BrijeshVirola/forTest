package tests.gamethunderkicklaunchservice;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.matchesPattern;
import static org.testng.Assert.assertEquals;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.RegEx;
import common.Utils;
import domain.BaseRequest;
import tests.gameelklaunchservice.request.HtmlReq;
import tests.gameelklaunchservice.response.PostApiHtmlResp;
import tests.gamethunderkicklaunchservice.enums.GameThunderkickLaunchEndpoints;
import tests.gamethunderkicklaunchservice.enums.GameThunderkickLaunchServiceUsers;

public class PostHtmlTests extends BaseClassSetup {

	@Test(description = "Make a HTML request. Positive scenario.")
	public void htmlRequestPositiveScenario() {

		String username = GameThunderkickLaunchServiceUsers.POST_HTML_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltTokenForGame("uk",197,"011", sessionId, 105688);

		HtmlReq htmlRequest = new HtmlReq.Builder()
				.defaults()
				.userId(4850555)
				.game_launch_token(gltId)
				.build();

		PostApiHtmlResp resp = BaseRequest.post(htmlRequest, GameThunderkickLaunchEndpoints.htmlSuccess);

		String respInString = resp.toString();

		String iFrame = StringUtils.substringBetween(respInString, "<iframe", "iframe>");

		String gameId = StringUtils.substringBetween(iFrame, "gameid=", "\\");
		String token = StringUtils.substringBetween(iFrame, "Token=", "\\");
		
		String lobbyUrl = StringUtils.substringBetween(iFrame, "lobbyUrl=", "/Lobby");

		String gameLaunchOrigin = StringUtils.substringBetween(respInString, "bet365.sagala.Thunderkick.MessageProxyService.init", ";");

		assertThat(resp.toString(), containsString("<iframe id=\"gamecontent\" src=\"https:\\/\\/ext-qa-gameservice.thunderkick.com\\/gamelauncher"));
		assertEquals(gameId, "tk-berzerker-a");
		assertThat(token, matchesPattern(RegEx.GUID));
		assertEquals(lobbyUrl, "https:\\/\\/www011.sagala-uat.com\\");
		assertThat(gameLaunchOrigin, containsString("https:\\/\\/games011.b365uat.com"));


	}

	@Test(description = "Make a HTML request with invalid token. Negative scenario.")
	public void htmlRequestInvalidToken() {

		HtmlReq htmlRequest = new HtmlReq.Builder()
				.defaults()
				.userId(4850563)
				.game_launch_token("c6a96470-4505-4b6e-8b6c-bef97121fb75")
				.build();

		CustomErrorResponse resp = BaseRequest.post(htmlRequest, GameThunderkickLaunchEndpoints.htmlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Unable to get game launch details")
				.id("123456789")
				.build();

		assertReflectionEquals(expectedResponse, resp);

	}

	@Test(description = "Make a HTML request with incorrect method name. Negative scenario.")
	public void htmlRequestInvalidMethod() {

		String username = GameThunderkickLaunchServiceUsers.POST_HTML_NEG.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();
		String gltId = Utils.generateGltTokenForGame("uk",197,"011", sessionId, 105688);

		HtmlReq htmlRequest = new HtmlReq.Builder()
				.defaults()
				.method("XXX")
				.game_launch_token(gltId)
				.build();

		CustomErrorResponse resp = BaseRequest.post(htmlRequest, GameThunderkickLaunchEndpoints.htmlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, resp);

	}

	@Test(description = "Make a HTML request with invalid parameter. Negative scenario.")
	public void htmlRequestInvalidParameter() {

		HtmlReq htmlRequest = new HtmlReq.Builder()
				.defaults()
				.game_launch_token(null)
				.build();

		CustomErrorResponse resp = BaseRequest.post(htmlRequest, GameThunderkickLaunchEndpoints.htmlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1008)
				.message("Invalid parameter: GameLaunchToken")
				.id("123456789")
				.build();

		assertReflectionEquals(expectedResponse, resp);

	}


	@Test(description = "Make a HTML request with invalid environment_id parameter. Negative scenario.")
	public void htmlRequestInvalidEnvironmentIDParameter() {

		HtmlReq htmlRequest = new HtmlReq.Builder()
				.defaults()
				.environment_id(null)
				.build();

		CustomErrorResponse resp = BaseRequest.post(htmlRequest, GameThunderkickLaunchEndpoints.htmlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1008)
				.message("Invalid parameter: EnvironmentId")
				.id("123456789")
				.build();

		assertReflectionEquals(expectedResponse, resp);

	}

	@Test(description = "Make a HTML request with invalid user_id parameter. Negative scenario.")
	public void htmlRequestInvalidUserIDParameter() {

		HtmlReq htmlRequest = new HtmlReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse resp = BaseRequest.post(htmlRequest, GameThunderkickLaunchEndpoints.htmlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1008)
				.message("Invalid parameter: UserId")
				.id("123456789")
				.build();

		assertReflectionEquals(expectedResponse, resp);

	}

	@Test(description = "Make a HTML request with invalid Culture parameter. Negative scenario.")
	public void htmlRequestInvalidCultureParameter() {

		HtmlReq htmlRequest = new HtmlReq.Builder()
				.defaults()
				.culture(null)
				.build();

		CustomErrorResponse resp = BaseRequest.post(htmlRequest, GameThunderkickLaunchEndpoints.htmlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1008)
				.message("Invalid parameter: Culture")
				.id("123456789")
				.build();

		assertReflectionEquals(expectedResponse, resp);

	}

	@Test(description = "Make a HTML request with invalid LanguageId parameter. Negative scenario.")
	public void htmlRequestInvalidLanguageIdParameter() {

		HtmlReq htmlRequest = new HtmlReq.Builder()
				.defaults()
				.language_id(null)
				.build();

		CustomErrorResponse resp = BaseRequest.post(htmlRequest, GameThunderkickLaunchEndpoints.htmlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1008)
				.message("Invalid parameter: LanguageId")
				.id("123456789")
				.build();

		assertReflectionEquals(expectedResponse, resp);

	}

	@Test(description = "Make a HTML request with invalid SagalaDomain parameter. Negative scenario.")
	public void htmlRequestInvalidSagalaDomainParameter() {

		HtmlReq htmlRequest = new HtmlReq.Builder()
				.defaults()
				.sagala_domain(null)
				.build();

		CustomErrorResponse resp = BaseRequest.post(htmlRequest, GameThunderkickLaunchEndpoints.htmlError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1008)
				.message("Invalid parameter: SagalaDomain")
				.id("123456789")
				.build();

		assertReflectionEquals(expectedResponse, resp);

	}

}
