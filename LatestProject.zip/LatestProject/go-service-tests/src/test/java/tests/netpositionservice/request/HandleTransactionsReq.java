package tests.netpositionservice.request;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HandleTransactionsReq {

	@SuppressWarnings("unused")
	private String id, method;
	
	private Map<String, List<TransactionReq>> params = new HashMap<>();

	private HandleTransactionsReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("transactions", builder.transactions);
	}

	public static class Builder {
		private String id, method;
		private List<TransactionReq> transactions;

		public Builder addTransaction(TransactionReq transaction) {
			this.transactions.add(transaction);
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder defaults() {
			this.method = "handletransactions";
			this.transactions = new ArrayList<TransactionReq>();
			return this;
		}

		public HandleTransactionsReq build() {
			return new HandleTransactionsReq(this);
		}
	}
}

