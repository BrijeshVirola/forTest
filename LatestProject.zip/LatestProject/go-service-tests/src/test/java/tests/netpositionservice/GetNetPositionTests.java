package tests.netpositionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.TransactionType;
import common.Utils;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.netpositionservice.enums.NetPositionEndpoints;
import tests.netpositionservice.enums.NetPositionServiceUsers;
import tests.netpositionservice.request.GetNetPositionReq;
import tests.netpositionservice.request.StartSessionReq;
import tests.netpositionservice.response.GetNetPositionResp;
public class GetNetPositionTests extends BaseClassSetup{

	@Test(description = "Make a request to GetNetPosition with stake transaction. Positive scenario.")
	public void getNetPosition_Stake_Positive_Scenario() {
		Instant sessionCreationTime = Instant.now();
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String negativeStake = "-1";
		String positiveStake = "1";

		// 1. Create new session
		StartSessionReq sessionRequest = new StartSessionReq.Builder()
				.defaults()
				.userId(NetPositionServiceUsers.GET_NET_POSITION_POS1.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualSessionResponse =  BaseRequest.post(sessionRequest, NetPositionEndpoints.startSessionSuccess);

		ResultOKResp expectedSessionResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedSessionResponse, actualSessionResponse);	

		String idForRequestToBeEchoedBackInResponseId2 = UUID.randomUUID().toString();

		// 2. Create new stake transaction for the specific userId
		Utils.createTransaction(TransactionType.STAKE, NetPositionServiceUsers.GET_NET_POSITION_POS1.getUserId(), negativeStake);

		// 3. Create netPosition request
		GetNetPositionReq netPositionRequest = new GetNetPositionReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId2)
				.userId(NetPositionServiceUsers.GET_NET_POSITION_POS1.getUserId())
				.build();

		// 4. Send the netPosition request
		GetNetPositionResp actualNetPositionResponse =  BaseRequest.post(netPositionRequest, NetPositionEndpoints.getNetPositionSuccess);

		GetNetPositionResp expNetPositionResponse = new GetNetPositionResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId2)
				.durationInMilliseconds(actualNetPositionResponse.getDurationInMilliseconds())
				.netPositionAmount(negativeStake)
				.betAmount(positiveStake)
				.build();

		// 5. Check the response object with the expected one
		assertReflectionEquals(expNetPositionResponse, actualNetPositionResponse);

		// Make additional checks for the durationbInMiliseconds
		Instant actionsCompleteTime = Instant.now();
		long timeSinceSessionCreated = Duration.between(sessionCreationTime, actionsCompleteTime).toMillis();
		Integer durationInMilliseconds = actualNetPositionResponse.getDurationInMilliseconds(); 
		Assert.assertTrue(durationInMilliseconds >= 0, "secs_since_login was less than zero");
		Assert.assertTrue(durationInMilliseconds <= timeSinceSessionCreated, "secs_since_login exceeded time since session was created");
	}

	@Test(description = "Make a request to GetNetPosition with Return transaction. Positive scenario.")
	public void getNetPosition_Return_Positive_Scenario() {
		Instant sessionCreationTime = Instant.now();
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String returnTransaction = "1";

		// 1. Create new session
		StartSessionReq sessionRequest = new StartSessionReq.Builder()
				.defaults()
				.userId(NetPositionServiceUsers.GET_NET_POSITION_POS2.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualSessionResponse =  BaseRequest.post(sessionRequest, NetPositionEndpoints.startSessionSuccess);

		ResultOKResp expectedSessionResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedSessionResponse, actualSessionResponse);	

		String idForRequestToBeEchoedBackInResponseId2 = UUID.randomUUID().toString();

		// 2. Create new return transaction for the specific userId
		Utils.createTransaction(TransactionType.RETURN, NetPositionServiceUsers.GET_NET_POSITION_POS2.getUserId(), returnTransaction);

		// 3. Create netPosition request
		GetNetPositionReq netPositionRequest = new GetNetPositionReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId2)
				.userId(NetPositionServiceUsers.GET_NET_POSITION_POS2.getUserId())
				.build();

		// 4. Send the netPosition request
		GetNetPositionResp actualNetPositionResponse =  BaseRequest.post(netPositionRequest, NetPositionEndpoints.getNetPositionSuccess);

		GetNetPositionResp expNetPositionResponse = new GetNetPositionResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId2)
				.durationInMilliseconds(actualNetPositionResponse.getDurationInMilliseconds())
				.netPositionAmount(returnTransaction)
				.winAmount(returnTransaction)
				.build();

		// 5. Check the response object with the expected one
		assertReflectionEquals(expNetPositionResponse, actualNetPositionResponse);

		// Make additional checks for the durationbInMiliseconds
		Instant actionsCompleteTime = Instant.now();
		long timeSinceSessionCreated = Duration.between(sessionCreationTime, actionsCompleteTime).toMillis();
		Integer durationInMilliseconds = actualNetPositionResponse.getDurationInMilliseconds(); 
		Assert.assertTrue(durationInMilliseconds >= 0, "secs_since_login was less than zero");
		Assert.assertTrue(durationInMilliseconds <= timeSinceSessionCreated, "secs_since_login exceeded time since session was created");
	}

	@Test(description = "Make a request to GetNetPosition with Stake and Return transactions. Positive scenario.")
	public void getNetPosition_Stake_And_Return_Positive_Scenario() {
		Instant sessionCreationTime = Instant.now();
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String negativeStake = "-1";
		String positiveStake = "1";
		String returnTransaction = "3";

		// 1. Create new session
		StartSessionReq sessionRequest = new StartSessionReq.Builder()
				.defaults()
				.userId(NetPositionServiceUsers.GET_NET_POSITION_POS3.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualSessionResponse =  BaseRequest.post(sessionRequest, NetPositionEndpoints.startSessionSuccess);

		ResultOKResp expectedSessionResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedSessionResponse, actualSessionResponse);	

		String idForRequestToBeEchoedBackInResponseId2 = UUID.randomUUID().toString();

		// 2. Create new stake and return transactions for the specific userId
		Utils.createTransaction(TransactionType.STAKE, NetPositionServiceUsers.GET_NET_POSITION_POS3.getUserId(), negativeStake);
		Utils.createTransaction(TransactionType.RETURN, NetPositionServiceUsers.GET_NET_POSITION_POS3.getUserId(), returnTransaction);

		// 3. Create netPosition request
		GetNetPositionReq netPositionRequest = new GetNetPositionReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId2)
				.userId(NetPositionServiceUsers.GET_NET_POSITION_POS3.getUserId())
				.build();

		// 4. Send the netPosition request
		GetNetPositionResp actualNetPositionResponse =  BaseRequest.post(netPositionRequest, NetPositionEndpoints.getNetPositionSuccess);

		GetNetPositionResp expNetPositionResponse = new GetNetPositionResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId2)
				.durationInMilliseconds(actualNetPositionResponse.getDurationInMilliseconds())
				.netPositionAmount(new BigDecimal(returnTransaction).subtract(new BigDecimal(positiveStake)).toPlainString())
				.betAmount(positiveStake)
				.winAmount(returnTransaction)
				.build();

		// 5. Check the response object with the expected one
		assertReflectionEquals(expNetPositionResponse, actualNetPositionResponse);

		// Make additional checks for the durationbInMiliseconds
		Instant actionsCompleteTime = Instant.now();
		long timeSinceSessionCreated = Duration.between(sessionCreationTime, actionsCompleteTime).toMillis();
		Integer durationInMilliseconds = actualNetPositionResponse.getDurationInMilliseconds(); 
		Assert.assertTrue(durationInMilliseconds >= 0, "secs_since_login was less than zero");
		Assert.assertTrue(durationInMilliseconds <= timeSinceSessionCreated, "secs_since_login exceeded time since session was created");
	}

	@Test(description = "Make a request to GetNetPosition without transaction. Positive scenario.")
	public void getNetPosition_Without_Transaction_Positive_Scenario() {
		Instant sessionCreationTime = Instant.now();
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		// 1. Create new session
		StartSessionReq sessionRequest = new StartSessionReq.Builder()
				.defaults()
				.userId(NetPositionServiceUsers.GET_NET_POSITION_POS4.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualSessionResponse =  BaseRequest.post(sessionRequest, NetPositionEndpoints.startSessionSuccess);

		ResultOKResp expectedSessionResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedSessionResponse, actualSessionResponse);	

		String idForRequestToBeEchoedBackInResponseId2 = UUID.randomUUID().toString();

		// 3. Create netPosition request
		GetNetPositionReq netPositionRequest = new GetNetPositionReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId2)
				.userId(NetPositionServiceUsers.GET_NET_POSITION_POS4.getUserId())
				.build();

		// 4. Send the netPosition request
		GetNetPositionResp actualNetPositionResponse =  BaseRequest.post(netPositionRequest, NetPositionEndpoints.getNetPositionSuccess);

		GetNetPositionResp expNetPositionResponse = new GetNetPositionResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId2)
				.durationInMilliseconds(actualNetPositionResponse.getDurationInMilliseconds())
				.build();

		// 5. Check the response object with the expected one
		assertReflectionEquals(expNetPositionResponse, actualNetPositionResponse);

		// Make additional checks for the durationbInMiliseconds
		Instant actionsCompleteTime = Instant.now();
		long timeSinceSessionCreated = Duration.between(sessionCreationTime, actionsCompleteTime).toMillis();
		Integer durationInMilliseconds = actualNetPositionResponse.getDurationInMilliseconds(); 
		Assert.assertTrue(durationInMilliseconds >= 0, "secs_since_login was less than zero");
		Assert.assertTrue(durationInMilliseconds <= timeSinceSessionCreated, "secs_since_login exceeded time since session was created");
	}

	@Test(description = "Make a request to getNetPosition. Session not created.")
	public void getNetPosition_MissingSessionDetails() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		Integer userWithoutASession = 20972;

		GetNetPositionReq request = new GetNetPositionReq.Builder()
				.defaults()
				.userId(userWithoutASession)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, NetPositionEndpoints.getNetPositionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Session not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getNetPosition. Missing user_id parameter.")
	public void getNetPosition_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetNetPositionReq request = new GetNetPositionReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, NetPositionEndpoints.getNetPositionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getNetPosition. Wrong method.")
	public void getNetPositon_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetNetPositionReq request = new GetNetPositionReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, NetPositionEndpoints.getNetPositionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
