package tests.netpositionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.netpositionservice.enums.NetPositionEndpoints;
import tests.netpositionservice.enums.NetPositionServiceUsers;
import tests.netpositionservice.request.StartSessionReq;
public class StartSessionTests extends BaseClassSetup{

	@Test(description = "Make a request to StartSession. Positive scenario.")
	public void startSession_Positive_Scenario() throws InterruptedException {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		StartSessionReq request = new StartSessionReq.Builder()
				.defaults()
				.userId(NetPositionServiceUsers.START_SESSION_POS1.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, NetPositionEndpoints.startSessionSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to startSession. Missing user_id parameter.")
	public void startSession_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		StartSessionReq request = new StartSessionReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, NetPositionEndpoints.startSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to startSession. Wrong method.")
	public void startSession_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		StartSessionReq request = new StartSessionReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, NetPositionEndpoints.startSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to startSession. Missing regulated_game_id parameter.")
	public void startSession_Missing_Regulated_Game_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		StartSessionReq request = new StartSessionReq.Builder()
				.defaults()
				.userId(NetPositionServiceUsers.START_SESSION_NEG.getUserId())
				.regulatedGameId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, NetPositionEndpoints.startSessionError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.message("Missing parameter: regulated_game_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}
