package tests.netpositionservice.request;

import java.util.concurrent.TimeUnit;

import common.FlakeGenerator;
import common.enumsconstants.Constants;

public class TransactionReq {

	@SuppressWarnings("unused")
	private Long transaction_id;
	@SuppressWarnings("unused")
	private Integer user_id;
	@SuppressWarnings("unused")
	private Integer real_amount;
	@SuppressWarnings("unused")
	private Integer bonus_amount;
	@SuppressWarnings("unused")
	private Integer ringfenced_amount;
	@SuppressWarnings("unused")
	private Integer total_amount;

	private TransactionReq(Builder builder) {
		this.user_id = builder.user_id;
		this.transaction_id = builder.transaction_id;
		this.real_amount = builder.real_amount;
		this.bonus_amount = builder.bonus_amount;
		this.ringfenced_amount = builder.ringfenced_amount;
		this.total_amount = builder.total_amount;
	}

	public static class Builder {
		private Integer user_id, real_amount, bonus_amount, ringfenced_amount, total_amount;
		private Long transaction_id;

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder transactionId(Long transaction_id) {
			this.transaction_id = transaction_id;
			return this;
		}

		public Builder realAmount(Integer real_amount) {
			this.real_amount = real_amount;
			return this;
		}

		public Builder bonusAmount(Integer bonus_amount) {
			this.bonus_amount = bonus_amount;
			return this;
		}

		public Builder ringFencedAmount(Integer ringfenced_amount) {
			this.ringfenced_amount = ringfenced_amount;
			return this;
		}

		public Builder totalAmount(Integer total_amount) {
			this.total_amount = total_amount;
			return this;
		}

		public Builder generateTransactionId() throws InterruptedException {
			TimeUnit.MILLISECONDS.sleep(1);
			this.transaction_id = FlakeGenerator.nextId(Constants.nodeId);
			return this;
		}

		public Builder defaults() {
			this.transaction_id = 1L;
			this.real_amount = 10;
			this.bonus_amount = 10;
			this.ringfenced_amount = 10;
			this.total_amount = 30;
			return this;
		}

		public TransactionReq build() {
			return new TransactionReq(this);
		}
	}
}

