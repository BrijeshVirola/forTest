package tests.netpositionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.netpositionservice.enums.NetPositionEndpoints;
import tests.netpositionservice.enums.NetPositionServiceUsers;
import tests.netpositionservice.request.GetNetPositionReq;
import tests.netpositionservice.request.HandleTransactionsReq;
import tests.netpositionservice.request.StartSessionReq;
import tests.netpositionservice.request.TransactionReq;
import tests.netpositionservice.response.GetNetPositionResp;
public class HandleTransactionsTests extends BaseClassSetup{

	@Test(description = "Make a request to HandleTransactions. Positive scenario.")
	public void handleTransactions_Positive_Scenario() throws InterruptedException {
		Integer testUserId = 1462;

		Instant sessionCreationTime = Instant.now();
		
		String sessionId = UUID.randomUUID().toString();
		
		StartSessionReq sessionRequest = new StartSessionReq.Builder()
				.defaults()
				.userId(testUserId)
				.id(sessionId)
				.build();

		ResultOKResp actualSessionResponse =  BaseRequest.post(sessionRequest, NetPositionEndpoints.startSessionSuccess);

		ResultOKResp expectedSessionResponse = new ResultOKResp.Builder()
				.defaults()
				.id(sessionId)
				.build();

		assertReflectionEquals(expectedSessionResponse, actualSessionResponse);	

		String transactionId = UUID.randomUUID().toString();

		TransactionReq transaction1 = new TransactionReq.Builder()
				.generateTransactionId()
				.bonusAmount(1)
				.realAmount(2)
				.ringFencedAmount(3)
				.totalAmount(6)
				.userId(testUserId)
				.build();

		TransactionReq transaction2 = new TransactionReq.Builder()
				.generateTransactionId()
				.bonusAmount(1)
				.realAmount(2)
				.ringFencedAmount(3)
				.totalAmount(6)
				.userId(testUserId)
				.build();

		TransactionReq transaction3 = new TransactionReq.Builder()
				.generateTransactionId()
				.bonusAmount(1)
				.realAmount(2)
				.ringFencedAmount(3)
				.totalAmount(6)
				.userId(testUserId)
				.build();

		HandleTransactionsReq request = new HandleTransactionsReq.Builder()
				.defaults()
				.addTransaction(transaction1)
				.addTransaction(transaction2)
				.addTransaction(transaction3)
				.id(transactionId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, NetPositionEndpoints.handleTransactionsSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(transactionId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		String netPositionId = UUID.randomUUID().toString();
		
		GetNetPositionReq netPositionRequest = new GetNetPositionReq.Builder()
				.defaults()
				.userId(testUserId)
				.id(netPositionId)
				.build();

		GetNetPositionResp actualNetPositionResponse =  BaseRequest.post(netPositionRequest, NetPositionEndpoints.getNetPositionSuccess);

		Instant actionsCompleteTime = Instant.now();
		
		long timeSinceSessionCreated = Duration.between(sessionCreationTime, actionsCompleteTime).toMillis();

		Integer durationInMilliseconds = actualNetPositionResponse.getDurationInMilliseconds(); 

		Assert.assertTrue(durationInMilliseconds >= 0, "duration_in_milliseconds was less than zero");
		Assert.assertTrue(durationInMilliseconds <= timeSinceSessionCreated, "duration_in_milliseconds exceeded time since session was created");
		Assert.assertEquals(actualNetPositionResponse.getNetPositionAmount(),"18");
		Assert.assertEquals(actualNetPositionResponse.getRegulatedGameId(), 97998);
	}

	@Test(description = "Make a request to handleTransactions. Wrong method.")
	public void handleTransactions_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		HandleTransactionsReq request = new HandleTransactionsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, NetPositionEndpoints.handleTransactionsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to HandleTransactions. Missing parameter user_id. Positive scenario.")
	public void handleTransactions_Missing_User_Id_Positive_Scenario() throws InterruptedException {
		Integer testUserId = NetPositionServiceUsers.HANDLE_TRANSACTION_POS1.getUserId();

		Instant sessionCreationTime = Instant.now();
		
		String sessionId = UUID.randomUUID().toString();
		
		StartSessionReq sessionRequest = new StartSessionReq.Builder()
				.defaults()
				.userId(testUserId)
				.id(sessionId)
				.build();

		ResultOKResp actualSessionResponse =  BaseRequest.post(sessionRequest, NetPositionEndpoints.startSessionSuccess);

		ResultOKResp expectedSessionResponse = new ResultOKResp.Builder()
				.defaults()
				.id(sessionId)
				.build();

		assertReflectionEquals(expectedSessionResponse, actualSessionResponse);	

		String transactionId = UUID.randomUUID().toString();

		TransactionReq transaction1 = new TransactionReq.Builder()
				.generateTransactionId()
				.bonusAmount(1)
				.realAmount(2)
				.ringFencedAmount(3)
				.totalAmount(6)
				.userId(null)
				.build();

		TransactionReq transaction2 = new TransactionReq.Builder()
				.generateTransactionId()
				.bonusAmount(1)
				.realAmount(2)
				.ringFencedAmount(3)
				.totalAmount(6)
				.userId(null)
				.build();

		TransactionReq transaction3 = new TransactionReq.Builder()
				.generateTransactionId()
				.bonusAmount(1)
				.realAmount(2)
				.ringFencedAmount(3)
				.totalAmount(6)
				.userId(null)
				.build();

		HandleTransactionsReq request = new HandleTransactionsReq.Builder()
				.defaults()
				.addTransaction(transaction1)
				.addTransaction(transaction2)
				.addTransaction(transaction3)
				.id(transactionId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, NetPositionEndpoints.handleTransactionsSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(transactionId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		String netPositionId = UUID.randomUUID().toString();
		
		GetNetPositionReq netPositionRequest = new GetNetPositionReq.Builder()
				.defaults()
				.userId(testUserId)
				.id(netPositionId)
				.build();

		GetNetPositionResp actualNetPositionResponse =  BaseRequest.post(netPositionRequest, NetPositionEndpoints.getNetPositionSuccess);

		Instant actionsCompleteTime = Instant.now();
		
		long timeSinceSessionCreated = Duration.between(sessionCreationTime, actionsCompleteTime).toMillis();

		Integer durationInMilliseconds = actualNetPositionResponse.getDurationInMilliseconds(); 

		Assert.assertTrue(durationInMilliseconds >= 0, "duration_in_milliseconds was less than zero");
		Assert.assertTrue(durationInMilliseconds <= timeSinceSessionCreated, "duration_in_milliseconds exceeded time since session was created");
		Assert.assertEquals(actualNetPositionResponse.getNetPositionAmount(),"0");
		Assert.assertEquals(actualNetPositionResponse.getRegulatedGameId(), 97998);
	}

	@Test(description = "Make a request to HandleTransactions. Missing parameter transaction_id. Negative scenario.")
	public void handleTransactions_Missing_Transaction_Id_Negative_Scenario() throws InterruptedException {
		Integer testUserId = 1464;
		String transactionId = UUID.randomUUID().toString();

		TransactionReq transaction1 = new TransactionReq.Builder()
				.transactionId(null)
				.bonusAmount(1)
				.realAmount(2)
				.ringFencedAmount(3)
				.totalAmount(6)
				.userId(testUserId)
				.build();

		HandleTransactionsReq request = new HandleTransactionsReq.Builder()
				.defaults()
				.addTransaction(transaction1)
				.id(transactionId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, NetPositionEndpoints.handleTransactionsSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(transactionId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);			
	}

	@Test(description = "Make a request to HandleTransactions. Single transaction. Positive scenario.")
	public void handleTransactions_Single_Transaction_Positive_Scenario() throws InterruptedException {
		Integer testUserId = 1464;

		Instant sessionCreationTime = Instant.now();
		
		String sessionId = UUID.randomUUID().toString();
		
		StartSessionReq sessionRequest = new StartSessionReq.Builder()
				.defaults()
				.userId(testUserId)
				.id(sessionId)
				.build();

		ResultOKResp actualSessionResponse =  BaseRequest.post(sessionRequest, NetPositionEndpoints.startSessionSuccess);

		ResultOKResp expectedSessionResponse = new ResultOKResp.Builder()
				.defaults()
				.id(sessionId)
				.build();

		assertReflectionEquals(expectedSessionResponse, actualSessionResponse);	

		String transactionId = UUID.randomUUID().toString();

		TransactionReq transaction1 = new TransactionReq.Builder()
				.generateTransactionId()
				.bonusAmount(1)
				.realAmount(2)
				.ringFencedAmount(3)
				.totalAmount(6)
				.userId(testUserId)
				.build();

		HandleTransactionsReq request = new HandleTransactionsReq.Builder()
				.defaults()
				.addTransaction(transaction1)
				.id(transactionId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, NetPositionEndpoints.handleTransactionsSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(transactionId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		String netPositionId = UUID.randomUUID().toString();
		
		GetNetPositionReq netPositionRequest = new GetNetPositionReq.Builder()
				.defaults()
				.userId(testUserId)
				.id(netPositionId)
				.build();

		GetNetPositionResp actualNetPositionResponse =  BaseRequest.post(netPositionRequest, NetPositionEndpoints.getNetPositionSuccess);

		Instant actionsCompleteTime = Instant.now();
		
		long timeSinceSessionCreated = Duration.between(sessionCreationTime, actionsCompleteTime).toMillis();

		Integer durationInMilliseconds = actualNetPositionResponse.getDurationInMilliseconds(); 

		Assert.assertTrue(durationInMilliseconds >= 0, "duration_in_milliseconds was less than zero");
		Assert.assertTrue(durationInMilliseconds <= timeSinceSessionCreated, "duration_in_milliseconds exceeded time since session was created");
		Assert.assertEquals(actualNetPositionResponse.getNetPositionAmount(),"6");
		Assert.assertEquals(actualNetPositionResponse.getRegulatedGameId(), 97998);
	}

}
