package tests.netpositionservice.enums;

import common.DatabaseQueries;

public enum NetPositionServiceUsers {

	GET_NET_POSITION_POS1("GO_SVC_TESTS03"),
	GET_NET_POSITION_POS2("GO_SVC_TESTS04"),
	GET_NET_POSITION_POS3("GO_SVC_TESTS05"),
	GET_NET_POSITION_POS4("GO_SVC_TESTS06"),
	HANDLE_TRANSACTION_POS1("BV1463"),
	START_SESSION_POS1("GO_SVC_STS_01"),
	START_SESSION_NEG("GO_SVC_STS_99");

	private String username;

	private NetPositionServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}