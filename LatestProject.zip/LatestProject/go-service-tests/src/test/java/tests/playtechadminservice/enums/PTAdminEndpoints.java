package tests.playtechadminservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.common.response.ResultOKResp;
import tests.playtechadminservice.response.GetDynamicBalancesResp;
import tests.playtechadminservice.response.SearchCasinoBonusTemplatesResp;
import tests.playtechadminservice.response.SearchPlayerBonusesResp;

public enum PTAdminEndpoints implements ResponseEndpoints {

	searchPlayerBonusesSuccess(SearchPlayerBonusesResp.class, "SearchPlayerBonuses"),
	searchPlayerBonusesError(CustomErrorResponse.class, "SearchPlayerBonuses"),
	getDynamicBalancesSuccess(GetDynamicBalancesResp.class, "GetDynamicBalances"),
	getDynamicBalancesError(CustomErrorResponse.class, "GetDynamicBalances"),
	offerBonusSuccess(ResultOKResp.class, "OfferBonus"),
	offerBonusError(CustomErrorResponse.class, "OfferBonus"),
	removeBonusSuccess(ResultOKResp.class, "RemoveBonus"),
	removeBonusError(CustomErrorResponse.class, "RemoveBonus"),
	sendPlayerMessageSuccess(ResultOKResp.class, "SendPlayerMessage"),
	sendPlayerMessageError(CustomErrorResponse.class, "SendPlayerMessage"),
	searchCasinoBonusTemplatesSuccess(SearchCasinoBonusTemplatesResp.class, "searchCasinoBonusTemplates"),
	searchCasinoBonusTemplatesError(CustomErrorResponse.class, "searchCasinoBonusTemplates");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> PTAdminEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
