package tests.playtechadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.playtechadminservice.enums.PTAServiceUsers;
import tests.playtechadminservice.enums.PTAdminEndpoints;
import tests.playtechadminservice.request.OfferBonusReq;
public class OfferBonusTests extends BaseClassSetup {
	@Test(description = "Make a request to OfferBonus - wagering bonus. Positive scenario.")
	public void offerBonus_WageringBonus_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.userId(PTAServiceUsers.OFFER_BONUS_POS1.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.result("ok")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, PTAdminEndpoints.offerBonusSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to OfferBonus - golden chips. Positive scenario.")
	public void offerBonus_GoldenChips_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.userId(PTAServiceUsers.OFFER_BONUS_POS2.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.description("AddBonus")
				.transactionDate("2020-11-20T13:44:00Z")
				.templateId("38854")
				.goldenChipsCount(1)
				.goldenChipsUnitValue("10")
				.amount(null)
				.build();

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.result("ok")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, PTAdminEndpoints.offerBonusSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to OfferBonus - free spins. Omit currency_code")
	public void offerBonus_Free_Spins_Without_Currency_Code() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.description("AddBonus")
				.templateId("65886")
				.userId(PTAServiceUsers.OFFER_BONUS_POS3.getUserId())
				.bonustypeId(8)
				.currencyCode(null)
				.build();

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.result("ok")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, PTAdminEndpoints.offerBonusSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to OfferBonus - free spins. With currency_code")
	public void offerBonus_Free_Spins_With_Currency_Code() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.description("AddBonus")
				.templateId("65886")
				.userId(PTAServiceUsers.OFFER_BONUS_POS4.getUserId())
				.bonustypeId(8)
				.currencyCode("GBP")
				.build();

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.result("ok")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp actualResponse =  BaseRequest.post(request, PTAdminEndpoints.offerBonusSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to OfferBonus - wagering bonus. Without currency_code.")
	public void offerBonus_WageringBonus_Without_Currency_Code() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.currencyCode(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: currency_code")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to OfferBonus - golden chips without currency_code")
	public void offerBonus_GoldenChips_Without_Currency_Code() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.userId(PTAServiceUsers.OFFER_BONUS_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.description("AddBonus")
				.transactionDate("2020-11-20T13:44:00Z")
				.templateId("38854")
				.goldenChipsCount(1)
				.goldenChipsUnitValue("10")
				.currencyCode(null)
				.amount(null)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: currency_code")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to offerBonus. Missing user_id parameter.")
	public void offerBonus_MissingUserid_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to offerBonus. Missing product_id parameter.")
	public void offerBonus_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.userId(PTAServiceUsers.OFFER_BONUS_NEG.getUserId())
				.productId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to offerBonus. Missing template_id parameter.")
	public void offerBonus_MissingTemplateId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.templateId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: template_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to offerBonus. Missing amount parameter.")
	public void offerBonus_MissingAmount_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.userId(PTAServiceUsers.OFFER_BONUS_NEG.getUserId())
				.amount(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: amount")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to offerBonus. Missing description parameter.")
	public void offerBonus_MissingDescription_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.description(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing parameter: description")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}


	@Test(description = "Make a request to offerBonus. Wrong method.")
	public void offerBonus_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		OfferBonusReq request = new OfferBonusReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(request, PTAdminEndpoints.offerBonusError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
