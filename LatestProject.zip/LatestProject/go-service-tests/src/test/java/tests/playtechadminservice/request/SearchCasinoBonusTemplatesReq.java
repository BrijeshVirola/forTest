package tests.playtechadminservice.request;

import java.util.ArrayList;
import java.util.List;

public class SearchCasinoBonusTemplatesReq {

	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Params params;

	private SearchCasinoBonusTemplatesReq(Builder builder) {
		ID = builder.id;
		Method = builder.method;
		params = new Params(builder);
	}

	public static class Builder {
		private String method, id;
		private Integer product_id;
		private List<Integer> countrygroup_ids;
		private List<String> statuses, playTypes;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public Builder addCountryGroupId(Integer countrygroupId) {
			countrygroup_ids.add(countrygroupId);
			return this;
		}
		
		public Builder addStatus(String status) {
			statuses.add(status);
			return this;
		}
		
		public Builder addPlayType(String playType) {
			playTypes.add(playType);
			return this;
		}

		public Builder defaults() {
			this.id = "123456789";
			this.method = "searchCasinoBonusTemplates";
			this.product_id = 2;
			this.countrygroup_ids = new ArrayList<Integer>();
			this.statuses = new ArrayList<String>();
			this.playTypes = new ArrayList<String>();
			return this;
		}

		public SearchCasinoBonusTemplatesReq build() {
			return new SearchCasinoBonusTemplatesReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		private Integer product_id;
		@SuppressWarnings("unused")
		private List<Integer> countrygroup_ids;
		@SuppressWarnings("unused")
		private List<String> statuses;
		@SuppressWarnings("unused")
		private List<String> playTypes;
		
		public Params(Builder builder) {
			product_id = builder.product_id;
			countrygroup_ids = builder.countrygroup_ids;
			statuses = builder.statuses;
			playTypes = builder.playTypes;
		}
	}
}
