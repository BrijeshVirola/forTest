package tests.playtechadminservice.enums;

import common.DatabaseQueries;

public enum PTAServiceUsers {

	GET_DYNAMIC_BALANCE_POS1("GO_SVC_PTGD_01"),
	GET_DYNAMIC_BALANCE_NEG("GO_SVC_PTGD_99"),
	OFFER_BONUS_POS1("GO_SVC_OB_01"),
	OFFER_BONUS_POS2("GO_SVC_OB_02"),
	OFFER_BONUS_POS3("GO_SVC_TEST130"),
	OFFER_BONUS_POS4("GO_SVC_TEST131"),
	OFFER_BONUS_NEG("GO_SVC_OB_99"),
	REMOVE_BONUS_POS1("apitest2"),
	REMOVE_BONUS_NEG("GO_SVC_RB_99"),
	SEARCH_PLAYER_BONUSES_POS1("apitest"),
	SEARCH_PLAYER_BONUSES_NEG("GO_SVC_SPB_99"),
	SEND_PLAYER_MESSAGE_NEG("GO_SVC_SPM_99");

	private String username;

	private PTAServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}