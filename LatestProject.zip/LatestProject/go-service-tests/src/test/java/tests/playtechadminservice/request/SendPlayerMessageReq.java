package tests.playtechadminservice.request;

import java.util.HashMap;
import java.util.Map;

public class SendPlayerMessageReq {

		@SuppressWarnings("unused")
		private String method, id, message;
		@SuppressWarnings("unused")
		private Integer user_id, product_id;
		private Map<String, Object> params = new HashMap<>();

		private SendPlayerMessageReq(Builder builder) {
			this.id = builder.id;
			this.method = builder.method;
			this.params.put("message", builder.message);
			this.params.put("user_id", builder.user_id);
			this.params.put("product_id", builder.product_id);
		}

		public static class Builder {
			private String method, id, message;
			private Integer user_id, product_id;
			
			public Builder method(String method) {
				this.method = method;
				return this;
			}

			public Builder id(String id) {
				this.id = id;
				return this;
			}

			public Builder userId(Integer user_id) {
				this.user_id = user_id;
				return this;
			}
			
			public Builder productId(Integer product_id) {
				this.product_id = product_id;
				return this;
			}

			public Builder message(String message) {
				this.message = message;
				return this;
			}

			public Builder defaults() {
				this.id = "1";
				this.method = "SendPlayerMessage";
				this.product_id = 2;
				this.message = "You are now playing with bonus funds";
				return this;
			}

			public SendPlayerMessageReq build() {
				return new SendPlayerMessageReq(this);
			}
		}
	}

