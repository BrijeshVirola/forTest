package tests.playtechadminservice.request;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

	public class GetDynamicBalancesReq {

		@SuppressWarnings("unused")
		private String method;
		@SuppressWarnings("unused")
		private String id;

		private Map<String, Object> params = new HashMap<>();

		private GetDynamicBalancesReq(Builder builder) {
			this.id = builder.id;
			this.method = builder.method;
			this.params.put("user_id", builder.user_id);
			this.params.put("product_id", builder.product_id);
			this.params.put("currency_code", builder.currency_code);
			this.params.put("requested_balances", builder.requested_balances);
		}

		public static class Builder {
			private String method, id,currency_code;
			private List<String> requested_balances;
			private Integer user_id, product_id;

			public Builder method(String method) {
				this.method = method;
				return this;
			}

			public Builder id(String id) {
				this.id = id;
				return this;
			}

			public Builder userId(Integer user_id) {
				this.user_id = user_id;
				return this;
			}

			public Builder productId(Integer product_id) {
				this.product_id = product_id;
				return this;
			}
			
			public Builder currencyCode(String currency_code) {
				this.currency_code = currency_code;
				return this;
			}
			
			public Builder addRequestedBalances(String requested_balance) {
				this.requested_balances.add(requested_balance);
				return this;
			}

			public Builder defaults() {
				this.id = "1";
				this.method = "GetDynamicBalances";
				this.product_id = 2;
				this.currency_code = "EUR";
				this.requested_balances = new ArrayList<String>();
				return this;
			}

			public GetDynamicBalancesReq build() {
				return new GetDynamicBalancesReq(this);
			}
		}
	}

