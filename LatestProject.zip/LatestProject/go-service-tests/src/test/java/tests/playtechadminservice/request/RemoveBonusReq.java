package tests.playtechadminservice.request;

import java.util.HashMap;
import java.util.Map;

public class RemoveBonusReq {

		@SuppressWarnings("unused")
		private String method, id, bonus_instance_code, reason;
		@SuppressWarnings("unused")
		private Integer user_id, product_id;
		private Map<String, Object> params = new HashMap<>();

		private RemoveBonusReq(Builder builder) {
			this.id = builder.id;
			this.method = builder.method;
			this.params.put("bonus_instance_code", builder.bonus_instance_code);
			this.params.put("reason", builder.reason);
			this.params.put("user_id", builder.user_id);
			this.params.put("product_id", builder.product_id);
		}

		public static class Builder {
			private String method, id, reason;
			private Integer user_id, product_id, bonus_instance_code;
			
			public Builder method(String method) {
				this.method = method;
				return this;
			}

			public Builder id(String id) {
				this.id = id;
				return this;
			}

			public Builder reason(String reason) {
				this.reason = reason;
				return this;
			}

			public Builder bonusInstanceCode(Integer bonus_instance_code) {
				this.bonus_instance_code = bonus_instance_code;
				return this;
			}

			public Builder userId(Integer user_id) {
				this.user_id = user_id;
				return this;
			}			

			public Builder productId(Integer product_id) {
				this.product_id = product_id;
				return this;
			}

			public Builder defaults() {
				this.id = "1";
				this.method = "RemoveBonus";
				this.bonus_instance_code = 7572527;
				this.product_id = 2;
				this.reason = "CancelByAdmin";
				return this;
			}

			public RemoveBonusReq build() {
				return new RemoveBonusReq(this);
			}
		}
	}

