package tests.playtechadminservice.request;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class OfferBonusReq {

		@SuppressWarnings("unused")
		private String method, id;
		private Map<String, Object> params = new HashMap<>();

		private OfferBonusReq(Builder builder) {
			this.id = builder.id;
			this.method = builder.method;
			this.params.put("template_id", builder.template_id);
			this.params.put("amount", builder.amount);
			this.params.put("currency_code", builder.currency_code);
			this.params.put("description", builder.description);
			this.params.put("remote_ip", builder.remote_ip);
			this.params.put("user_id", builder.user_id);
			this.params.put("product_id", builder.product_id);
			this.params.put("transaction_date", builder.transaction_date);
			this.params.put("golden_chips_unit_value", builder.golden_chips_unit_value);
			this.params.put("golden_chips_count", builder.golden_chips_count);
			this.params.put("bonustype_id", builder.bonustype_id);
		}

		public static class Builder {
			private String method, id, currency_code, template_id, description, remote_ip, transaction_date, amount, golden_chips_unit_value;
			private Integer user_id, product_id, golden_chips_count, bonustype_id;
			
			public Builder method(String method) {
				this.method = method;
				return this;
			}

			public Builder id(String id) {
				this.id = id;
				return this;
			}
			
			public Builder bonustypeId(Integer bonustype_id) {
				this.bonustype_id = bonustype_id;
				return this;
			}

			public Builder goldenChipsUnitValue(String golden_chips_unit_value) {
				this.golden_chips_unit_value = golden_chips_unit_value;
				return this;
			}

			public Builder goldenChipsCount(Integer golden_chips_count) {
				this.golden_chips_count = golden_chips_count;
				return this;
			}

			public Builder templateId(String template_id) {
				this.template_id = template_id;
				return this;
			}

			public Builder amount(String amount) {
				this.amount = amount;
				return this;
			}
			
			public Builder currencyCode(String currency_code) {
				this.currency_code = currency_code;
				return this;
			}
			
			public Builder description(String description) {
				this.description = description;
				return this;
			}
			
			public Builder remoteIp(String remote_ip) {
				this.remote_ip = remote_ip;
				return this;
			}

			public Builder userId(Integer user_id) {
				this.user_id = user_id;
				return this;
			}			

			public Builder productId(Integer product_id) {
				this.product_id = product_id;
				return this;
			}
			
			public Builder transactionDate(String transaction_date) {
				this.transaction_date = transaction_date;
				return this;
			}

			public Builder defaults() {
				this.id = "1";
				this.method = "OfferBonus";
				this.template_id = "63166";
				this.amount = "8";
				this.currency_code = "GBP";
				this.description = "AddBonus - from service";
				this.remote_ip = "172.17.157.1";
				this.product_id = 2;
				this.transaction_date = Instant.now().toString();
				this.golden_chips_unit_value = null;
				this.golden_chips_count = null;
				this.bonustype_id = null;
				return this;
			}

			public OfferBonusReq build() {
				return new OfferBonusReq(this);
			}
		}
	}

