package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.Reporter;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.enums.GamingBonusAdminServiceUsers;
import tests.gamingbonusadminservice.request.AddCreditedUsersCommandReq;
import tests.gamingbonusadminservice.request.GetUsersForBonusActionsCommandReq;
import tests.gamingbonusadminservice.request.SpecificBonusCancelByAdminCommandReq;
import tests.gamingbonusadminservice.requestobjects.UserBonus;
import tests.gamingbonusadminservice.response.GetUsersForBonusActionsCommandResp;

public class SpecificBonusCancelByAdminCommand extends BaseClassSetup {

	@Test(description = "Make a request to addCreditedUsersCommand. End to end Scenario.")
	public void specificBonusCancelByAdminCommand_End_To_End_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_POS1.getUserId();
		BigInteger bonustemplateId = new BigInteger("467");
		Integer versionId = 999;

		Reporter.log("01. Check that there is no bonus data for the user.");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		CustomErrorResponse actNoDataResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);

		CustomErrorResponse expNoDataResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("No data was found for passed parameters")
				.code(1001)
				.build();

		assertReflectionEquals(expNoDataResp, actNoDataResp);

		Reporter.log("02. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("0.1"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);


		Reporter.log("03. Get userbonusId using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		Reporter.log("04. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);

		Reporter.log("05. Check that there is no bonus data for the user.");
		actNoDataResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);
		assertReflectionEquals(expNoDataResp, actNoDataResp);
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Already cancelled bonus.")
	public void specificBonusCancelByAdminCommand_Already_Cancelled_Bonus() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_NEG.getUserId())
				.userBonusId(6862)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to cancel the bonus. Reason: The bonus is already cancelled by an admin.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Not existing user bonus id.")
	public void specificBonusCancelByAdminCommand_Not_Existing_User_Bonus_Id() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_NEG2.getUserId())
				.userBonusId(1)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to cancel the bonus. Can't retrieve failed reason")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Missing user_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void specificBonusCancelByAdminCommand_Missing_User_Id(String userIdProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = userIdProvider.equals("null") ? null : Integer.parseInt(userIdProvider);

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(userId)
				.userBonusId(1)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: user_id")
				.code(1003)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Missing userbonus_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void specificBonusCancelByAdminCommand_Missing_Userbonus_Id(String userbonusIdProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userbonusId = userbonusIdProvider.equals("null") ? null : Integer.parseInt(userbonusIdProvider);

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userBonusId(userbonusId)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: userbonus_id")
				.code(1003)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Missing admin.",
			dataProviderClass = DataProviders.class, dataProvider = "nullEmptyString")
	public void specificBonusCancelByAdminCommand_Missing_Admin(String adminProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String admin = adminProvider.equals("null") ? null : adminProvider;

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.admin(admin)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: admin")
				.code(1003)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Claim time for bonus is expired.")
	public void specificBonusCancelByAdminCommand_Claim_Time_Expired() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_NEG3.getUserId())
				.userBonusId(6909)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to cancel the bonus. Reason: The claim time for bonus is expired.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. The bonus is expired.")
	public void specificBonusCancelByAdminCommand_Bonus_Expired() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_NEG3.getUserId())
				.userBonusId(6908)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to cancel the bonus. Reason: The bonus is expired.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Cancelled by withdrawal.")
	public void specificBonusCancelByAdminCommand_Cancelled_By_Withdrawal() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_NEG3.getUserId())
				.userBonusId(6913)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to cancel the bonus. Reason: The bonus is already Cancelled by withdrawal.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Cancelled by user.")
	public void specificBonusCancelByAdminCommand_Cancelled_By_User() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_NEG3.getUserId())
				.userBonusId(6914)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to cancel the bonus. Reason: The bonus is already cancelled by the user.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Redeemed by admin.")
	public void specificBonusCancelByAdminCommand_Redeemed_By_Admin() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_NEG3.getUserId())
				.userBonusId(6918)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to cancel the bonus. Reason: The bonus is redeemed by admin already.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Bonus is lost.")
	public void specificBonusCancelByAdminCommand_Bonus_Is_Lost() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_NEG4.getUserId())
				.userBonusId(6923)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to cancel the bonus. Reason: The bonus is lost.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Bonus is redeemed.")
	public void specificBonusCancelByAdminCommand_Bonus_Is_Redeemed() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_NEG4.getUserId())
				.userBonusId(6933)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to cancel the bonus. Reason: The bonus is redeemed already.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificbonuscancelbyadmincommand. Redeemedby threshold.")
	public void specificBonusCancelByAdminCommand_Redeemed_By_Threshold() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_CANCEL_NEG4.getUserId())
				.userBonusId(6935)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to cancel the bonus. Reason: The bonus is redeemed by the threshold.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}
}
