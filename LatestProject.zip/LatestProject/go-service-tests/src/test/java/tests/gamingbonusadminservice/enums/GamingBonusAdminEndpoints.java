package tests.gamingbonusadminservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.response.ActiveDepositBonusQueryCommandResp;
import tests.gamingbonusadminservice.response.ExportClaimedByVersionCommandResp;
import tests.gamingbonusadminservice.response.ExportCreditButNotClaimedCommandResp;
import tests.gamingbonusadminservice.response.GetClaimedAndCompletedBonusCountCommandResp;
import tests.gamingbonusadminservice.response.GetUsersForBonusActionsCommandResp;

public enum GamingBonusAdminEndpoints implements ResponseEndpoints {

	getUsersForBonusActionsCommandSuccess(GetUsersForBonusActionsCommandResp.class, "getUsersForBonusActionsCommand"),
	getUsersForBonusActionsCommandError(CustomErrorResponse.class, "getUsersForBonusActionsCommand"),
	addCreditedUsersCommandSuccess(ResultOKResp.class, "addcrediteduserscommand"),
	addCreditedUsersCommandError(CustomErrorResponse.class, "addcrediteduserscommand"),
	specificBonusRedeemByAdminCommandSuccess(ResultOKResp.class, "specificbonusredeembyadmincommand"),
	specificBonusRedeemByAdminCommandError(CustomErrorResponse.class, "specificbonusredeembyadmincommand"),
	specificBonusCancelByAdminCommandSuccess(ResultOKResp.class, "specificbonuscancelbyadmincommand"),
	specificBonusCancelByAdminCommandError(CustomErrorResponse.class, "specificbonuscancelbyadmincommand"),
	activeDepositBonusQueryCommandSuccess(ActiveDepositBonusQueryCommandResp.class, "activedepositbonusquerycommand"),
	activeDepositBonusQueryCommandError(CustomErrorResponse.class, "activedepositbonusquerycommand"),
	getClaimedAndCompletedBonusCountCommandSuccess(GetClaimedAndCompletedBonusCountCommandResp.class, "getclaimedandcompletedbonuscountcommand"),
	getClaimedAndCompletedBonusCountCommandError(CustomErrorResponse.class, "getclaimedandcompletedbonuscountcommand"),
	gameWeightingTemplateUpdateCommandSuccess(ResultOKResp.class, "gameweightingtemplateupdatecommand"),
	gameWeightingTemplateUpdateCommandError(CustomErrorResponse.class, "gameweightingtemplateupdatecommand"),
	exportClaimedByVersionCommandSuccess(ExportClaimedByVersionCommandResp.class, "exportclaimedbyversioncommand"),
	exportClaimedByVersionCommandError(CustomErrorResponse.class, "exportclaimedbyversioncommand"),
	exportCreditButNotClaimedCommandSuccess(ExportCreditButNotClaimedCommandResp.class, "exportcreditbutnotclaimedcommand"),
	exportCreditButNotClaimedCommandError(CustomErrorResponse.class, "exportcreditbutnotclaimedcommand"),
	insertGamePositionsCommandSuccess(ResultOKResp.class, "insertgamepositionscommand"),
	insertGamePositionsCommandError(CustomErrorResponse.class, "insertgamepositionscommand"),
	bonusTemplateUpdateCommandSuccess(ResultOKResp.class, "bonusTemplateUpdateCommand"),
	bonusTemplateUpdateCommandError(CustomErrorResponse.class, "bonusTemplateUpdateCommand"),
	bonusClaimByAdminCommandSuccess(ResultOKResp.class, "bonusClaimByAdminCommand"),
	bonusClaimByAdminCommandError(CustomErrorResponse.class, "bonusClaimByAdminCommand");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GamingBonusAdminEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
