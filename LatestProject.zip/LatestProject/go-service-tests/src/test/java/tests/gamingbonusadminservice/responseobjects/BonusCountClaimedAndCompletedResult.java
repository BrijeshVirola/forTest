package tests.gamingbonusadminservice.responseobjects;

public class BonusCountClaimedAndCompletedResult {
	
	Integer bonustemplate_id;
	Integer claimed_bonus;
	Integer completed_bonus;
	Integer credited_bonus;
	
	public BonusCountClaimedAndCompletedResult() {
	}
	
	private BonusCountClaimedAndCompletedResult(Builder builder) {
		bonustemplate_id = builder.bonustemplate_id;
		claimed_bonus = builder.claimed_bonus;
		completed_bonus = builder.completed_bonus;
		credited_bonus = builder.credited_bonus;
	}
	
	public Integer getBonustemplate_id() {
		return bonustemplate_id;
	}

	public Integer getClaimed_bonus() {
		return claimed_bonus;
	}

	public Integer getCompleted_bonus() {
		return completed_bonus;
	}

	public Integer getCredited_bonus() {
		return credited_bonus;
	}

	public static class Builder {
		
		Integer bonustemplate_id;
		Integer claimed_bonus;
		Integer completed_bonus;
		Integer credited_bonus;
		
		public Builder bonustemplateId(Integer bonustemplateId) {
			bonustemplate_id = bonustemplateId;
			return this;
		}
		
		public Builder claimedBonus(Integer claimedBonus) {
			claimed_bonus = claimedBonus;
			return this;
		}
		
		public Builder completedBonus(Integer completedBonus) {
			completed_bonus = completedBonus;
			return this;
		}
		
		public Builder creditedBonus(Integer creditedBonus) {
			credited_bonus = creditedBonus;
			return this;
		}
		
		public Builder defaults() {
			bonustemplate_id = 0;
			claimed_bonus = 0;
			completed_bonus = 0;
			credited_bonus = 0;
			return this;
		}
		
		public BonusCountClaimedAndCompletedResult build() {
			return new BonusCountClaimedAndCompletedResult(this);
		}
	}

}
