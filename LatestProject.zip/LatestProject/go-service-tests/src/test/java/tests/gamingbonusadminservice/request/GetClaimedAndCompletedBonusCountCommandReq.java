package tests.gamingbonusadminservice.request;

import java.util.ArrayList;
import java.util.List;

public class GetClaimedAndCompletedBonusCountCommandReq {
	
	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private GetClaimedAndCompletedBonusCountCommandReq(Builder builder) {
		Id = builder.Id;
		Method = builder.Method;
		params = new Params(builder);
	}
	
	public static class Builder {
		
		private String Id;
		private String Method;
		private List<Integer> bonustemplate_ids;
		
		public Builder defaults() {
			Id = "defaultTestId";
			Method = "getclaimedandcompletedbonuscountcommand";
			bonustemplate_ids = new ArrayList<>();
			return this;
		}
		
		public Builder id(String id) {
			this.Id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder addBonustemplateId(int bonustemplateId) {
			bonustemplate_ids.add(bonustemplateId);
			return this;
		}

		public GetClaimedAndCompletedBonusCountCommandReq build() {
			return new GetClaimedAndCompletedBonusCountCommandReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		private List<Integer> bonustemplate_ids;
		
		public Params(Builder builder) {
			bonustemplate_ids = builder.bonustemplate_ids;
		}
	}
}
