package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.Reporter;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.enums.GamingBonusAdminServiceUsers;
import tests.gamingbonusadminservice.request.AddCreditedUsersCommandReq;
import tests.gamingbonusadminservice.request.GetUsersForBonusActionsCommandReq;
import tests.gamingbonusadminservice.request.SpecificBonusRedeemByAdminCommandReq;
import tests.gamingbonusadminservice.requestobjects.UserBonus;
import tests.gamingbonusadminservice.response.GetUsersForBonusActionsCommandResp;

public class SpecificBonusRedeemByAdminCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to specificbonusredeembyadmincommand. End to end Scenario Pre-Wager.")
	public void specificBonusRedeemByAdminCommand_Pre_Wager_End_To_End_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_POS1.getUserId();
		BigInteger bonusTemplateId = new BigInteger("484");
		Integer bonusVersionId = 1021;

		Reporter.log("01. Precondition - Cancel the last bonus user using specificbonuscancelbyadmincommand for user: " + userId);
		Utils.cancelLastBonusIdOfUser(userId);

		Reporter.log("02. Check that there is no bonus data for the user.");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.addUserId(userId)
				.bonusTemplateId(bonusTemplateId)
				.versionId(bonusVersionId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actNoDataResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);

		CustomErrorResponse expNoDataResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("No data was found for passed parameters")
				.code(1001)
				.build();

		assertReflectionEquals(expNoDataResp, actNoDataResp);

		Reporter.log("03. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonusTemplateId)
				.amount(new BigDecimal("0.1"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		Reporter.log("04. Get userbonusId using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		Reporter.log("05. Redeem the bonus using getusersforbonusactionscommand");
		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actRedeemResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandSuccess);

		ResultOKResp expRedeemResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expRedeemResp, actRedeemResp);

		Reporter.log("06. Check that there is no bonus data for the user.");
		actNoDataResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);
		assertReflectionEquals(expNoDataResp, actNoDataResp);
	}

	@Test(description = "Make a request to specificbonusredeembyadmincommand. End to end Scenario After-Wager.")
	public void specificBonusRedeemByAdminCommand_After_Wager_End_To_End_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_POS2.getUserId();
		BigInteger bonusTemplateId = new BigInteger("468");
		Integer bonusVersionId = 1000;

		Reporter.log("01. Check that there is no bonus data for the user.");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.addUserId(userId)
				.bonusTemplateId(bonusTemplateId)
				.versionId(bonusVersionId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actNoDataResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);

		CustomErrorResponse expNoDataResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("No data was found for passed parameters")
				.code(1001)
				.build();

		assertReflectionEquals(expNoDataResp, actNoDataResp);

		Reporter.log("02. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonusTemplateId)
				.amount(new BigDecimal("0.1"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);


		Reporter.log("03. Get userbonusId using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		Reporter.log("04. Redeem the bonus using getusersforbonusactionscommand");
		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actRedeemResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandSuccess);

		ResultOKResp expRedeemResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expRedeemResp, actRedeemResp);

		Reporter.log("05. Check that there is no bonus data for the user.");
		actNoDataResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);
		assertReflectionEquals(expNoDataResp, actNoDataResp);
	}

	@Test(description = "Make a request to specificbonusredeembyadmincommand. End to end Scenario Cash.")
	public void specificBonusRedeemByAdminCommand_Cash_End_To_End_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_POS3.getUserId();
		BigInteger bonusTemplateId = new BigInteger("482");
		Integer bonusVersionId = 1020;

		Reporter.log("01. Precondition - Cancel the last bonus user using specificbonuscancelbyadmincommand for user: " + userId);
		Utils.cancelLastBonusIdOfUser(userId);

		Reporter.log("02. Check that there is no bonus data for the user.");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.addUserId(userId)
				.bonusTemplateId(bonusTemplateId)
				.versionId(bonusVersionId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actNoDataResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);

		CustomErrorResponse expNoDataResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("No data was found for passed parameters")
				.code(1001)
				.build();

		assertReflectionEquals(expNoDataResp, actNoDataResp);

		Reporter.log("03. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonusTemplateId)
				.amount(new BigDecimal("0.1"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);


		Reporter.log("04. Get userbonusId using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		Reporter.log("05. Redeem the bonus using getusersforbonusactionscommand");
		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actRedeemResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandSuccess);

		ResultOKResp expRedeemResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expRedeemResp, actRedeemResp);

		Reporter.log("06. Check that there is no bonus data for the user.");
		actNoDataResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);
		assertReflectionEquals(expNoDataResp, actNoDataResp);
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Missing user_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void specificBonusRedeemByAdminCommand_Missing_User_Id(String userIdProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = userIdProvider.equals("null") ? null : Integer.parseInt(userIdProvider);

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(userId)
				.userBonusId(1)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: user_id")
				.code(1003)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Missing userbonus_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void specificBonusRedeemByAdminCommand_Missing_Userbonus_id(String userBonusIdProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userBonusId = userBonusIdProvider.equals("null") ? null : Integer.parseInt(userBonusIdProvider);

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userBonusId(userBonusId)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: userbonus_id")
				.code(1003)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Missing admin.",
			dataProviderClass = DataProviders.class, dataProvider = "nullEmptyString")
	public void specificBonusRedeemByAdminCommand_Missing_Admin(String adminProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		String admin = adminProvider.equals("null") ? null : adminProvider;

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.admin(admin)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: admin")
				.code(1003)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Redeemed by admin already.")
	public void specificBonusRedeemByAdminCommand_Redeemed_By_Admin_Already() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_NEG.getUserId())
				.userBonusId(7546)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to redeem the bonus. Reason: The bonus is redeemed by admin already.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Claim time for bonus is expired.")
	public void specificBonusRedeemByAdminCommand_Claim_Time_For_Bonus_Expired() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_NEG2.getUserId())
				.userBonusId(7458)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to redeem the bonus. Reason: The claim time for bonus is expired.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Bonus is expired.")
	public void specificBonusRedeemByAdminCommand_Bonus_Expired() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_NEG3.getUserId())
				.userBonusId(7459)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to redeem the bonus. Reason: The bonus is expired.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Already cancelled by admin.")
	public void specificBonusRedeemByAdminCommand_Already_Cancelled_By_Admin() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_NEG.getUserId())
				.userBonusId(7563)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to redeem the bonus. Reason: The bonus is already cancelled by an admin.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Already cancelled by user.")
	public void specificBonusRedeemByAdminCommand_Already_Cancelled_By_User() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_NEG.getUserId())
				.userBonusId(7564)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to redeem the bonus. Reason: The bonus is already cancelled by the user.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Already cancelled by withdrawal.")
	public void specificBonusRedeemByAdminCommand_Already_Cancelled_By_Withdrawal() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_NEG.getUserId())
				.userBonusId(7572)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to redeem the bonus. Reason: The bonus is already Cancelled by withdrawal.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Inactive deposit matched.")
	public void specificBonusRedeemByAdminCommand_Inactive_Deposit_Matched() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_NEG4.getUserId())
				.userBonusId(10346)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);
		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Cannot redeem inactive deposit matched bonus")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Bonus is lost.")
	public void specificBonusRedeemByAdminCommand_Bonus_Is_Lost() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_NEG4.getUserId())
				.userBonusId(7586)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);
		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to redeem the bonus. Reason: The bonus is lost.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}

	@Test(description = "Make a request to specificBonusRedeemByAdminCommand. Redeemed by threshold.")
	public void specificBonusRedeemByAdminCommand_Redeemed_By_Threshold() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SpecificBonusRedeemByAdminCommandReq cancelBonusReq = new SpecificBonusRedeemByAdminCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingBonusAdminServiceUsers.SPECIFIC_BONUS_REDEEM_NEG4.getUserId())
				.userBonusId(7587)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusRedeemByAdminCommandError);
		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Failed to redeem the bonus. Reason: The bonus is redeemed by the threshold.")
				.code(1002)
				.build();

		assertReflectionEquals(expResponse, actResponse);	
	}
}
