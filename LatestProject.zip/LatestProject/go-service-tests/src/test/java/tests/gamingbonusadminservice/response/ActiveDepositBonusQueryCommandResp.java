package tests.gamingbonusadminservice.response;

public class ActiveDepositBonusQueryCommandResp {
	
	private String id;
	private Result result;
	
	public ActiveDepositBonusQueryCommandResp() {
	}
	
	private ActiveDepositBonusQueryCommandResp(Builder builder) {
		this.id = builder.id;
		this.result = new Result(builder);
	}
	
	public String getId() {
		return id;
	}

	public Result getResult() {
		return result;
	}

	public static class Builder {
		private String id;
		private Boolean exists;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder exists(Boolean exists) {
			this.exists = exists;
			return this;
		}
		
		public Builder defaults() {
			id = "defaultTestId";
			exists = false;
			return this;
		}
		
		public ActiveDepositBonusQueryCommandResp build() {
			return new ActiveDepositBonusQueryCommandResp(this);
		}	
	}
	
	private class Result {

		Boolean exists;
		
		@SuppressWarnings("unused")
		public Result() {
		}
		
		public Result(Builder builder) {
			exists = builder.exists;
		}

		@SuppressWarnings("unused")
		public Boolean getExists() {
			return exists;
		}
	}
}
