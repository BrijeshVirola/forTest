package tests.gamingbonusadminservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.gamingbonusadminservice.responseobjects.ExportCreditButNotClaimedCommandResult;

public class ExportCreditButNotClaimedCommandResp {

	private String id;
	private List<ExportCreditButNotClaimedCommandResult> result;
	
	public ExportCreditButNotClaimedCommandResp() {
	}
	
	public ExportCreditButNotClaimedCommandResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public String getId() {
		return id;
	}

	public List<ExportCreditButNotClaimedCommandResult> getResult() {
		return result;
	}
	
	public static class Builder {
		
		private String id;
		private List<ExportCreditButNotClaimedCommandResult> result;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addResult(ExportCreditButNotClaimedCommandResult result) {
			this.result.add(result);
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.result = new ArrayList<>();
			
			return this;
		}
		
		public ExportCreditButNotClaimedCommandResp build() {
			return new ExportCreditButNotClaimedCommandResp(this);
		}
	}
}
