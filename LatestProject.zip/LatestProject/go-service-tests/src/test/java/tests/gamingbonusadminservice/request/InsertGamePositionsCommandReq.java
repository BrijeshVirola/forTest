package tests.gamingbonusadminservice.request;

import java.util.ArrayList;
import java.util.List;

import tests.gamingbonusadminservice.responseobjects.Game;

public class InsertGamePositionsCommandReq {

	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private InsertGamePositionsCommandReq(Builder builder) {
		Id = builder.Id;
		Method = builder.Method;
		params = new Params(builder);
	}

	public static class Builder {

		private String Id;
		private String Method;
		private List<Game> games;
		private Integer bonustemplate_id;
		private Integer regulatedzone_id; 
		private Integer product_id; 

		public Builder defaults() {
			Id = "defaultTestId";
			Method = "insertgamepositionscommand";
			games = new ArrayList<>();
			return this;
		}

		public Builder id(String id) {
			this.Id = id;
			return this;
		}

		public Builder method(String method) {
			this.Method = method;
			return this;
		}

		public Builder addGame(Integer gametoken_id, Integer position) {
			games.add(new Game(gametoken_id, position));
			return this;
		}

		public Builder bonustemplateId(Integer bonustemplateId) {
			this.bonustemplate_id = bonustemplateId;
			return this;
		}

		public Builder regulatedzoneId(Integer regulatedzoneId) {
			this.regulatedzone_id = regulatedzoneId;
			return this;
		}

		public Builder productId(Integer productId) {
			this.product_id = productId;
			return this;
		}

		public InsertGamePositionsCommandReq build() {
			return new InsertGamePositionsCommandReq(this);
		}
	}

	private class Params {

		@SuppressWarnings("unused")
		private List<Game> games;
		@SuppressWarnings("unused")
		private Integer bonustemplate_id;
		@SuppressWarnings("unused")
		private Integer regulatedzone_id;
		@SuppressWarnings("unused")
		private Integer product_id;

		public Params(Builder builder) {
			games = builder.games;
			bonustemplate_id = builder.bonustemplate_id;
			regulatedzone_id = builder.regulatedzone_id;
			product_id = builder.product_id;
		}
	}
}
