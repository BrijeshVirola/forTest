package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.Reporter;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.DatabaseQueries;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.enums.GamingBonusAdminServiceUsers;
import tests.gamingbonusadminservice.request.AddCreditedUsersCommandReq;
import tests.gamingbonusadminservice.request.GetUsersForBonusActionsCommandReq;
import tests.gamingbonusadminservice.request.SpecificBonusCancelByAdminCommandReq;
import tests.gamingbonusadminservice.requestobjects.UserBonus;
import tests.gamingbonusadminservice.response.GetUsersForBonusActionsCommandResp;
import tests.gamingbonusadminservice.responseobjects.UserBonusAction;

public class GetUsersForBonusActionsCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to getusersforbonusactionscommand. Single user after-wager bonus games.")
	public void getUsersForBonusActionsCommand_Single_User_After_Wager_Bonus_Games() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS1.getUserId();
		BigInteger bonustemplateId = new BigInteger("468");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("10"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		Reporter.log("02. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(bonustemplateId)
				.versionId(1000)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actualResponse.getUserbonusId();

		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS35")
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(1000)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Single user pre-wager bonus games.")
	public void getUsersForBonusActionsCommand_Single_User_Pre_Wager_Bonus_Games() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS2.getUserId();
		String userName = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS2.getUsername();
		BigInteger bonustemplateId = new BigInteger("467");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("5.20"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		Reporter.log("02. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(bonustemplateId)
				.versionId(999)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actualResponse.getUserbonusId();

		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username(userName)
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(520)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Single user cash bonus games.")
	public void getUsersForBonusActionsCommand_Single_User_Cash_Bonus_Games() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS3.getUserId();
		String userName = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS3.getUsername();
		BigInteger bonustemplateId = new BigInteger("466");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("0.16"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		Reporter.log("02. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(bonustemplateId)
				.versionId(998)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actualResponse.getUserbonusId();

		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username(userName)
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(16)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Single user after-wager bonus casino.")
	public void getUsersForBonusActionsCommand_Single_User_After_Wager_Casino() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS1.getUserId();
		String userName = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS1.getUsername();
		BigInteger bonustemplateId = new BigInteger("465");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("0.2"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		Reporter.log("02. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(bonustemplateId)
				.versionId(997)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actualResponse.getUserbonusId();

		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username(userName)
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(20)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Single user pre-wager bonus casino.")
	public void getUsersForBonusActionsCommand_Single_User_Pre_Wager_Casino() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS2.getUserId();
		String userName = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS2.getUsername();
		BigInteger bonustemplateId = new BigInteger("464");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("2"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		Reporter.log("02. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(bonustemplateId)
				.versionId(995)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actualResponse.getUserbonusId();

		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username(userName)
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(200)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);

		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Single user cash bonus casino. include_offered = true")
	public void getUsersForBonusActionsCommand_Single_User_Cash_Casino_Offered_True() throws InterruptedException {
		Integer userId = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS4.getUserId();
		String userName = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS4.getUsername();
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Reporter.log("01. Precondition - Cancel the last bonus of the user");
		Utils.cancelLastBonusIdOfUser(userId);

		Reporter.log("02. Credit user  using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(new BigInteger("1615"))
				.amount(new BigDecimal("1.36"))
				.historyToken(UUID.randomUUID().toString())
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);
		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("03. Get details using getUsersForBonusActionsCommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(new BigInteger("1615"))
				.versionId(2213)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);

		Integer userBonusId = DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username(userName)
				.userId(userId)
				.userbonusId(userBonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(136)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Single user. include_offered = false")
	public void getUsersForBonusActionsCommand_Single_User_Offered_False() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(new BigInteger("452"))
				.versionId(958)
				.includeOffered(false)
				.addUserId(GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_NEG.getUserId())
				.removeAll(false)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("No data was found for passed parameters")
				.code(1001)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);		
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Multiple users.")
	public void getUsersForBonusActionsCommand_Multiple_Users() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer userId1 = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS5.getUserId();
		String userName1 = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS5.getUsername();
		Integer userId2 = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS6.getUserId();
		String userName2 = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS6.getUsername();
		BigInteger bonusTemplateId = new BigInteger("1614");

		Reporter.log("01. Precondition - Cancel the last bonus user using specificbonuscancelbyadmincommand for user: " + userId1);
		Utils.cancelLastBonusIdOfUser(userId1);

		Reporter.log("02. Precondition - Cancel the last bonus user using specificbonuscancelbyadmincommand for user: " + userId2);
		Utils.cancelLastBonusIdOfUser(userId2);

		Reporter.log("03. Credit user " + userId1 + " using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId1)
				.bonustemplateId(bonusTemplateId)
				.amount(new BigDecimal("1.36"))
				.historyToken(UUID.randomUUID().toString())
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);
		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("04. Credit user " + userId2 + " using addCreditedUsersCommand");
		userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId2)
				.bonustemplateId(bonusTemplateId)
				.amount(new BigDecimal("0.12"))
				.historyToken(UUID.randomUUID().toString())
				.build();

		addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);
		expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonusTemplateId)
				.versionId(2212)
				.includeOffered(true)
				.addUserId(userId1)
				.addUserId(userId2)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);

		Integer userBonusId1 =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId1);
		UserBonusAction expUserBonusAction1 = new UserBonusAction.Builder()
				.defaults()
				.username(userName1)
				.userId(userId1)
				.userbonusId(userBonusId1)
				.userbonusStatus("Offered(Credited)")
				.amountPence(136)
				.versionId(0)
				.currency("GBP")
				.build();

		Integer userBonusId2 =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId2);
		UserBonusAction expUserBonusAction2 = new UserBonusAction.Builder()
				.defaults()
				.username(userName2)
				.userId(userId2)
				.userbonusId(userBonusId2)
				.userbonusStatus("Offered(Credited)")
				.amountPence(12)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(id)
				.addUserBonusAction(expUserBonusAction1)
				.addUserBonusAction(expUserBonusAction2)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Single user. Remove all = true")
	public void getUsersForBonusActionsCommand_Single_User_Remove_All() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer userId1 = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS7.getUserId();
		String userName1 = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS7.getUsername();
		Integer userId2 = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS8.getUserId();
		String userName2 = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS8.getUsername();
		BigInteger bonusTemplateId = new BigInteger("1617");

		Reporter.log("01. Precondition - Cancel the last bonus user using specificbonuscancelbyadmincommand for user: " + userId1);
		Utils.cancelLastBonusIdOfUser(userId1);

		Reporter.log("02. Precondition - Cancel the last bonus user using specificbonuscancelbyadmincommand for user: " + userId2);
		Utils.cancelLastBonusIdOfUser(userId2);

		Reporter.log("03. Credit user " + userId1 + " using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId1)
				.bonustemplateId(bonusTemplateId)
				.amount(new BigDecimal("1.36"))
				.historyToken(UUID.randomUUID().toString())
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);
		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("04. Credit user " + userId2 + " using addCreditedUsersCommand");
		userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId2)
				.bonustemplateId(bonusTemplateId)
				.amount(new BigDecimal("0.12"))
				.historyToken(UUID.randomUUID().toString())
				.build();

		addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);
		expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonusTemplateId)
				.versionId(2212)
				.includeOffered(true)
				.addUserId(userId1)
				.removeAll(true)
				.build();

		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);

		Integer userBonusId1 =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId1);
		UserBonusAction expUserBonusAction1 = new UserBonusAction.Builder()
				.defaults()
				.username(userName1)
				.userId(userId1)
				.userbonusId(userBonusId1)
				.userbonusStatus("Offered(Credited)")
				.amountPence(136)
				.versionId(0)
				.currency("GBP")
				.build();

		Integer userBonusId2 =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId2);
		UserBonusAction expUserBonusAction2 = new UserBonusAction.Builder()
				.defaults()
				.username(userName2)
				.userId(userId2)
				.userbonusId(userBonusId2)
				.userbonusStatus("Offered(Credited)")
				.amountPence(12)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(id)
				.addUserBonusAction(expUserBonusAction1)
				.addUserBonusAction(expUserBonusAction2)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Offered and granted user. include_offered = true")
	public void getUsersForBonusActionsCommand_Offered_And_Granted_Offered_True() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS9.getUserId();
		String username = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS9.getUsername();

		Reporter.log("01. Credit user using addCreditedUsersCommand - this is a preconditon as this bonus is expiring after some time");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(new BigInteger("467"))
				.amount(new BigDecimal("1.1"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);


		Reporter.log("02. Check that offered and granted bonuses are shown using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(new BigInteger("467"))
				.versionId(999)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer secondUserBonusId = actualResponse.getUserbonusId(2);

		UserBonusAction expUserBonusAction1 = new UserBonusAction.Builder()
				.defaults()
				.username(username)
				.userId(userId)
				.userbonusId(6824)
				.userbonusStatus("Granted")
				.amountPence(100)
				.versionId(1)
				.currency("GBP")
				.build();

		UserBonusAction expUserBonusAction2 = new UserBonusAction.Builder()
				.defaults()
				.username(username)
				.userId(userId)
				.userbonusId(secondUserBonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(110)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonusAction(expUserBonusAction1)
				.addUserBonusAction(expUserBonusAction2)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	

		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand. This is cleaning everytime the offered bonus at the end.");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(secondUserBonusId)
				.build();

		BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Offered and granted user. include_offered = false")
	public void getUsersForBonusActionsCommand_Offered_And_Granted_Offered_False() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS10.getUserId();
		String username = GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_POS10.getUsername();

		Reporter.log("01. Credit user using addCreditedUsersCommand - this is a preconditon as this bonus is expiring after some time");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(new BigInteger("467"))
				.amount(new BigDecimal("1.1"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		Reporter.log("02. Check that only granted bonus is shown using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(new BigInteger("467"))
				.versionId(999)
				.includeOffered(false)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);

		UserBonusAction expUserBonusAction1 = new UserBonusAction.Builder()
				.defaults()
				.username(username)
				.userId(userId)
				.userbonusId(8060)
				.userbonusStatus("Granted")
				.amountPence(100)
				.versionId(1)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonusAction(expUserBonusAction1)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Bonus Template id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void getUsersForBonusActionsCommand_Bonus_Template_Missing(String bonusTemplId) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		BigInteger bonusTemplateId = bonusTemplId.equals("null") ? null : new BigInteger(bonusTemplId);

		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserId(GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_NEG2.getUserId())
				.bonusTemplateId(bonusTemplateId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);


		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: bonustemplate_id")
				.code(1003)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Version id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void getUsersForBonusActionsCommand_Version_Id_Missing(String versionIdString) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer versionId = versionIdString.equals("null") ? null : Integer.parseInt(versionIdString);

		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserId(GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_NEG2.getUserId())
				.versionId(versionId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);


		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: version_id")
				.code(1003)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to getusersforbonusactionscommand. Not proper version id.")
	public void getUsersForBonusActionsCommand_No_Data() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserId(GamingBonusAdminServiceUsers.GET_USER_FOR_BONUS_NEG2.getUserId())
				.versionId(1)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("No data was found for passed parameters")
				.code(1001)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to getusersforbonusactionscommand.User Ids invalid.")
	public void getUsersForBonusActionsCommand_User_Ids_Invalid() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserId(0)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);


		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Invalid user id: 0")
				.code(1003)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@Test(description = "Make a request to getusersforbonusactionscommand.User Ids missing.")
	public void getUsersForBonusActionsCommand_User_Ids_Missing() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);


		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: user_ids")
				.code(1003)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}
}
