package tests.gamingbonusadminservice.responseobjects;

public class Game {
	
	Integer gametoken_id;
	Integer position;
	
	public Game(Integer gametoken_id, Integer position) {
		this.gametoken_id = gametoken_id;
		this.position = position;
	}
}
