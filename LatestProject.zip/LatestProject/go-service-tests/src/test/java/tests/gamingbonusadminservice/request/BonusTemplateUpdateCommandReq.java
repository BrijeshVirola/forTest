package tests.gamingbonusadminservice.request;

import java.util.ArrayList;
import java.util.List;

import tests.gamingbonusadminservice.requestobjects.BonusAffiliateCodes;
import tests.gamingbonusadminservice.requestobjects.BonusCurrencyAmount;

public class BonusTemplateUpdateCommandReq {
	
	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private BonusTemplateUpdateCommandReq(Builder builder) {
		Id = builder.Id;
		Method = builder.Method;
		params = new Params(builder);
	}
	
	public static class Builder {
		
		private String Id;
		private String Method;
		private Integer bonustemplate_id;
		private Integer version_id;
		private Integer history_id;
		private Integer templateversion;
		private Integer product_id;
		private Integer bonustype_id;
		private Integer wageringrequirementtype_id;
		private String startdate;
		private String templatename;
		private String templatedescription;
		private String enddate;
		private Integer priority;
		private Boolean showinaccountmanager;
		private Integer gameweighttemplate_id;
		private String promotiontermstoken;
		private Integer expiryinhours;
		private Integer claimperiodinhours;
		private Boolean requireacceptance;
		private Boolean active;
		private Integer wageringrequirementmultiplier;
		private List<BonusCurrencyAmount> bonuscurrencyamounts;
		private Boolean depositmatched;
		private Boolean use_ringfencing;
		private Boolean newplayerbonus;
		private List<Integer> regulatedzones;
		private List<Integer> countries;
		private String createddate;
		private String history_createddate;
		private String version_createddate;
		private Boolean isaffiliatebonus;
		private BonusAffiliateCodes bonusaffiliatecodes;
		private Integer defaultaffiliatebonus_id;
		private Boolean hassubsequentbonus;
		private Integer subsequentbonustemplate_id;
		private Integer subsequentbonustype;
		private Boolean triggersubsequentbonusoncomplete;
		private Boolean triggersubsequentbonusonexpiry;
		private Boolean triggersubsequentbonusonlost;
		private Boolean rewardcash;
		private Integer bonuspercentage;
		private Integer ringfencedpercentage;
		private Integer maxbet_percentage;
		private Integer subsequentimsgoldenchips;
		
		public Builder defaults() {
			Id = "defaultTestId";
			Method = "bonustemplateupdatecommand";
			bonustemplate_id = 482;
			version_id = 1;
			history_id = 1;
			templateversion = 33;
			product_id = 2;
			bonustype_id = 3;
			wageringrequirementtype_id = 1;
			startdate = "2021-11-30T10:50:00.000Z";
			templatename = "Go Services - bonustemplateupdatecommand";
			templatedescription = "Use for bonustemplateupdatecommand automation";
			enddate = "2030-11-30T12:50:00.000Z";
			priority = 1;
			showinaccountmanager = false;
			gameweighttemplate_id = null;
			promotiontermstoken = "go-services-cash-casino-bonustemplateupdatecommand";
			expiryinhours = 0;
			claimperiodinhours = 720;
			requireacceptance = true;
			active = true;
			wageringrequirementmultiplier = null;
			bonuscurrencyamounts = new ArrayList<>();
			depositmatched = false;
			use_ringfencing = false;
			newplayerbonus = false;
			regulatedzones = new ArrayList<>();
			countries = new ArrayList<>();
			createddate = "2021-11-30T10:50:00.000Z";
			history_createddate = "2021-12-01T10:50:00.000Z";
			version_createddate = "2021-12-01T10:50:00.000Z";
			isaffiliatebonus = false;
			bonusaffiliatecodes = new BonusAffiliateCodes.Builder().defaults().build();
			defaultaffiliatebonus_id = 0;
			hassubsequentbonus = false;
			subsequentbonustemplate_id = 0;
			subsequentbonustype = 0;
			triggersubsequentbonusoncomplete = false;
			triggersubsequentbonusonexpiry = false;
			triggersubsequentbonusonlost = false;
			rewardcash = false;
			bonuspercentage = null;
			ringfencedpercentage = null;
			maxbet_percentage = null;
			subsequentimsgoldenchips = null;
			return this;
		}
		
		public Builder subsequentImsGoldenChips(Integer subsequentimsgoldenchips) {
			this.subsequentimsgoldenchips = subsequentimsgoldenchips;
			return this;
		}
		
		public Builder maxbetPercentage(Integer maxbetPercentage) {
			maxbet_percentage = maxbetPercentage;
			return this;
		}
		
		public Builder ringfencedPercentage(Integer ringfencedPercentage) {
			ringfencedpercentage = ringfencedPercentage;
			return this;
		}
		
		public Builder bonusPercentage(Integer bonusPercentage) {
			bonuspercentage = bonusPercentage;
			return this;
		}
		
		public Builder triggerSubsequentBonusOnComplete(Boolean triggerSubsequentBonusOnComplete) {
			triggersubsequentbonusoncomplete = triggerSubsequentBonusOnComplete;
			return this;
		}
		
		public Builder triggerSubsequentBonusOnExpiry(Boolean triggerSubsequentBonusOnExpiry) {
			triggersubsequentbonusonexpiry = triggerSubsequentBonusOnExpiry;
			return this;
		}
		
		public Builder triggerSubsequentBonusOnLost(Boolean triggerSubsequentBonusOnLost) {
			triggersubsequentbonusonlost = triggerSubsequentBonusOnLost;
			return this;
		}
		
		public Builder rewardCash(Boolean rewardCash) {
			rewardcash = rewardCash;
			return this;
		}
		
		public Builder subsequentBonusType(Integer subsequentBonusType) {
			subsequentbonustype = subsequentBonusType;
			return this;
		}
		
		public Builder subsequentBonusTemplateId(Integer subsequentBonusTemplateId) {
			subsequentbonustemplate_id = subsequentBonusTemplateId;
			return this;
		}
		
		public Builder hasSubsequentBonus(Boolean hasSubsequentBonus) {
			hassubsequentbonus = hasSubsequentBonus;
			return this;
		}
		
		public Builder defaultAffiliateBonusId(Integer defaultAffiliateBonusId) {
			defaultaffiliatebonus_id = defaultAffiliateBonusId;
			return this;
		}
		
		public Builder bonusAffiliateCodes(BonusAffiliateCodes bonusAffiliateCodes) {
			bonusaffiliatecodes = bonusAffiliateCodes;
			return this;
		}
		
		public Builder isAffiliateBonus(Boolean isAffiliateBonus) {
			isaffiliatebonus = isAffiliateBonus;
			return this;
		}
		
		public Builder versionCreatedDate(String versionCreatedDate) {
			version_createddate = versionCreatedDate;
			return this;
		}
		
		public Builder historyCreatedDate(String historyCreatedDate) {
			history_createddate = historyCreatedDate;
			return this;
		}
		
		public Builder createdDate(String createdDate) {
			createddate = createdDate;
			return this;
		}

		public Builder addRegulatedZone(Integer regulatedZone) {
			regulatedzones.add(regulatedZone);
			return this;
		}
		
		public Builder addCountry(Integer country) {
			countries.add(country);
			return this;
		}
		
		public Builder depositMatched(Boolean depositMatched) {
			depositmatched = depositMatched;
			return this;
		}
		
		public Builder useRingfencing(Boolean useRingfencing) {
			use_ringfencing = useRingfencing;
			return this;
		}
		
		public Builder newPlayerBonus(Boolean newPlayerBonus) {
			newplayerbonus = newPlayerBonus;
			return this;
		}
		
		public Builder addBonusCurrencyamount(BonusCurrencyAmount bonusCurrencyAmount) {
			bonuscurrencyamounts.add(bonusCurrencyAmount);
			return this;
		}
		
		public Builder wageringRequirementMultiplier(Integer wageringRequirementMultiplier) {
			wageringrequirementmultiplier = wageringRequirementMultiplier;
			return this;
		}
		
		public Builder active(Boolean active) {
			this.active = active;
			return this;
		}
		
		public Builder requireAcceptance(Boolean requireAcceptance) {
			requireacceptance = requireAcceptance;
			return this;
		}
		
		public Builder claimPeriodInHours(Integer claimPeriodInHours) {
			claimperiodinhours = claimPeriodInHours;
			return this;
		}
		
		public Builder expiryInHours(Integer expiryInHours) {
			expiryinhours = expiryInHours;
			return this;
		}
		
		public Builder promotionTermsToken(String promotionTermsToken) {
			promotiontermstoken = promotionTermsToken;
			return this;
		}
		
		public Builder gameweighttemplateId(Integer gameweighttemplateId) {
			gameweighttemplate_id = gameweighttemplateId;
			return this;
		}
		
		public Builder showinaccountmanager(Boolean showInAccountManager) {
			showinaccountmanager = showInAccountManager;
			return this;
		}
		
		public Builder id(String id) {
			this.Id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder bonustemplateId(Integer bonustemplateId) {
			bonustemplate_id = bonustemplateId;
			return this;
		}
		
		public Builder versionId(Integer versionId) {
			version_id = versionId;
			return this;
		}
		
		public Builder historyId(Integer historyId) {
			history_id = historyId;
			return this;
		}
		
		public Builder templateVersion(Integer templateVersion) {
			templateversion = templateVersion;
			return this;
		}
		
		public Builder productId(Integer productId) {
			product_id = productId;
			return this;
		}
		
		public Builder bonustypeId(Integer bonustypeId) {
			bonustype_id = bonustypeId;
			return this;
		}
		
		public Builder wageringrequirementtypeId(Integer wageringrequirementtypeId) {
			wageringrequirementtype_id = wageringrequirementtypeId;
			return this;
		}
		
		public Builder startDate(String startDate) {
			startdate = startDate;
			return this;
		}
		
		public Builder templateName(String templateName) {
			templatename = templateName;
			return this;
		}
		
		public Builder templateDescription(String templateDescription) {
			templatedescription = templateDescription;
			return this;
		}
		
		public Builder endDate(String endDate) {
			enddate = endDate;
			return this;
		}
		
		public Builder priority(Integer priority) {
			this.priority = priority;
			return this;
		}
		
		public BonusTemplateUpdateCommandReq build() {
			return new BonusTemplateUpdateCommandReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		private Integer bonustemplate_id;
		@SuppressWarnings("unused")
		private Integer version_id;
		@SuppressWarnings("unused")
		private Integer history_id;
		@SuppressWarnings("unused")
		private Integer templateversion;
		@SuppressWarnings("unused")
		private Integer product_id;
		@SuppressWarnings("unused")
		private Integer bonustype_id;
		@SuppressWarnings("unused")
		private Integer wageringrequirementtype_id;
		@SuppressWarnings("unused")
		private String startdate;
		@SuppressWarnings("unused")
		private String templatename;
		@SuppressWarnings("unused")
		private String templatedescription;
		@SuppressWarnings("unused")
		private String enddate;
		@SuppressWarnings("unused")
		private Integer priority;
		@SuppressWarnings("unused")
		private Boolean showinaccountmanager;
		@SuppressWarnings("unused")
		private Integer gameweighttemplate_id;
		@SuppressWarnings("unused")
		private String promotiontermstoken;
		@SuppressWarnings("unused")
		private Integer expiryinhours;
		@SuppressWarnings("unused")
		private Integer claimperiodinhours;
		@SuppressWarnings("unused")
		private Boolean requireacceptance;
		@SuppressWarnings("unused")
		private Boolean active;
		@SuppressWarnings("unused")
		private Integer wageringrequirementmultiplier;
		@SuppressWarnings("unused")
		private List<BonusCurrencyAmount> bonuscurrencyamounts;
		@SuppressWarnings("unused")
		private Boolean depositmatched;
		@SuppressWarnings("unused")
		private Boolean use_ringfencing;
		@SuppressWarnings("unused")
		private Boolean newplayerbonus;
		@SuppressWarnings("unused")
		private List<Integer> regulatedzones;
		@SuppressWarnings("unused")
		private List<Integer> countries;
		@SuppressWarnings("unused")
		private String createddate;
		@SuppressWarnings("unused")
		private String history_createddate;
		@SuppressWarnings("unused")
		private String version_createddate;
		@SuppressWarnings("unused")
		private Boolean isaffiliatebonus;
		@SuppressWarnings("unused")
		private BonusAffiliateCodes bonusaffiliatecodes;
		@SuppressWarnings("unused")
		private Integer defaultaffiliatebonus_id;
		@SuppressWarnings("unused")
		private Boolean hassubsequentbonus;
		@SuppressWarnings("unused")
		private Integer subsequentbonustemplate_id;
		@SuppressWarnings("unused")
		private Integer subsequentbonustype;
		@SuppressWarnings("unused")
		private Boolean triggersubsequentbonusoncomplete;
		@SuppressWarnings("unused")
		private Boolean triggersubsequentbonusonexpiry;
		@SuppressWarnings("unused")
		private Boolean triggersubsequentbonusonlost;
		@SuppressWarnings("unused")
		private Boolean rewardcash;
		@SuppressWarnings("unused")
		private Integer minimumtoqualify;
		@SuppressWarnings("unused")
		private Integer bonuspercentage;
		@SuppressWarnings("unused")
		private Integer ringfencedpercentage;
		@SuppressWarnings("unused")
		private Integer maxbet_percentage;
		@SuppressWarnings("unused")
		private Integer subsequentimsgoldenchips;
		
		public Params(Builder builder) {
			bonustemplate_id = builder.bonustemplate_id;
			version_id = builder.version_id;
			history_id = builder.history_id;
			templateversion = builder.templateversion;
			product_id = builder.product_id;
			bonustype_id = builder.bonustype_id;
			wageringrequirementtype_id = builder.wageringrequirementtype_id;
			startdate = builder.startdate;
			templatename = builder.templatename;
			templatedescription = builder.templatedescription;
			enddate = builder.enddate;
			priority = builder.priority;
			showinaccountmanager = builder.showinaccountmanager;
			gameweighttemplate_id = builder.gameweighttemplate_id;
			promotiontermstoken = builder.promotiontermstoken;
			expiryinhours = builder.expiryinhours;
			claimperiodinhours = builder.claimperiodinhours;
			requireacceptance = builder.requireacceptance;
			active = builder.active;
			wageringrequirementmultiplier = builder.wageringrequirementmultiplier;
			bonuscurrencyamounts = builder.bonuscurrencyamounts;
			depositmatched = builder.depositmatched;
			use_ringfencing = builder.use_ringfencing;
			newplayerbonus = builder.newplayerbonus;
			regulatedzones = builder.regulatedzones;
			countries = builder.countries;
			createddate = builder.createddate;
			history_createddate = builder.history_createddate;
			version_createddate = builder.version_createddate;
			isaffiliatebonus = builder.isaffiliatebonus;
			bonusaffiliatecodes = builder.bonusaffiliatecodes;
			defaultaffiliatebonus_id = builder.defaultaffiliatebonus_id;
			hassubsequentbonus = builder.hassubsequentbonus;
			subsequentbonustemplate_id = builder.subsequentbonustemplate_id;
			subsequentbonustype = builder.subsequentbonustype;
			triggersubsequentbonusoncomplete = builder.triggersubsequentbonusoncomplete;
			triggersubsequentbonusonexpiry = builder.triggersubsequentbonusonexpiry;
			triggersubsequentbonusonlost = builder.triggersubsequentbonusonlost;
			rewardcash = builder.rewardcash;
			bonuspercentage = builder.bonuspercentage;
			ringfencedpercentage = builder.ringfencedpercentage;
			maxbet_percentage = builder.maxbet_percentage;
			subsequentimsgoldenchips = builder.subsequentimsgoldenchips;
		}
	}
}
