package tests.gamingbonusadminservice.requestobjects;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.Instant;

public class UserBonus {
	
	Integer user_id;
	BigInteger bonustemplate_id;
	BigDecimal amount;
	String credittimeutc;
	String historytoken;
	
	private UserBonus(Builder builder) {
		user_id = builder.user_id;
		bonustemplate_id = builder.bonustemplate_id;
		amount = builder.amount;
		credittimeutc = builder.creditTimeUtc;
		historytoken = builder.historyToken;
	}
	
	public static class Builder {
		
		private Integer user_id;
		private BigInteger bonustemplate_id;
		private BigDecimal amount;
		private String creditTimeUtc;
		private String historyToken;
		
		public Builder userId(Integer userId) {
			user_id = userId;
			return this;
		}
		
		public Builder bonustemplateId(BigInteger bonustemplateId) {
			bonustemplate_id = bonustemplateId;
			return this;
		}
		
		public Builder amount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}
		
		public Builder creditTimeUtc(String creditTimeUtc) {
			this.creditTimeUtc = creditTimeUtc;
			return this;
		}
		
		
		public Builder historyToken(String historyToken) {
			this.historyToken = historyToken;
			return this;
		}
		
		public Builder defaults() {
			user_id = 1;
			bonustemplate_id = new BigInteger("1");
			amount = new BigDecimal("0.1");
			creditTimeUtc = Instant.now().toString();
			historyToken = "8fc8ed6d-44c5-41c9-90a1-9ea0b8154f2a";
			return this;
		}
		
		public UserBonus build() {
			return new UserBonus(this);
		}
	}
}
