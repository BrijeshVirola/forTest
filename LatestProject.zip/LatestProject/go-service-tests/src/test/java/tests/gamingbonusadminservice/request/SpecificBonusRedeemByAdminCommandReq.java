package tests.gamingbonusadminservice.request;

public class SpecificBonusRedeemByAdminCommandReq {

	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private SpecificBonusRedeemByAdminCommandReq(Builder builder) {
		Id = builder.Id;
		Method = builder.Method;
		params = new Params(builder);
	}

	public static class Builder {

		private String Id;
		private String Method;
		private Integer user_id;
		private Integer userbonus_id;
		private String admin;

		public Builder defaults() {
			Id = "defaultTestId";
			Method = "specificbonusredeembyadmincommand";
			user_id = 1;
			userbonus_id = 2;
			admin = "adminTest";
			return this;
		}

		public Builder id(String id) {
			this.Id = id;
			return this;
		}

		public Builder method(String method) {
			this.Method = method;
			return this;
		}

		public Builder userId(Integer userId) {
			user_id = userId;
			return this;
		}

		public Builder userBonusId(Integer userBonusId) {
			userbonus_id = userBonusId;
			return this;
		}

		public Builder admin(String admin) {
			this.admin = admin;
			return this;
		}

		public SpecificBonusRedeemByAdminCommandReq build() {
			return new SpecificBonusRedeemByAdminCommandReq(this);
		}
	}

	private class Params {

		@SuppressWarnings("unused")
		private Integer user_id;
		@SuppressWarnings("unused")
		private Integer userbonus_id;
		@SuppressWarnings("unused")
		private String admin;

		public Params(Builder builder) {
			user_id = builder.user_id;
			userbonus_id = builder.userbonus_id;
			admin = builder.admin;
		}
	}
}
