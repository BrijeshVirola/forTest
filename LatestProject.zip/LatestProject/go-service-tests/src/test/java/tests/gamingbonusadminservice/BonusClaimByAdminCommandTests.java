package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.Reporter;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import junit.framework.AssertionFailedError;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.enums.GamingBonusAdminServiceUsers;
import tests.gamingbonusadminservice.request.AddCreditedUsersCommandReq;
import tests.gamingbonusadminservice.request.BonusClaimByAdminCommandReq;
import tests.gamingbonusadminservice.request.GetUsersForBonusActionsCommandReq;
import tests.gamingbonusadminservice.request.SpecificBonusCancelByAdminCommandReq;
import tests.gamingbonusadminservice.requestobjects.UserBonus;
import tests.gamingbonusadminservice.response.GetUsersForBonusActionsCommandResp;
import tests.gamingbonusadminservice.responseobjects.UserBonusAction;

public class BonusClaimByAdminCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to bonusClaimByAdminCommand. Pre-wager End to end Scenario.")
	public void bonusClaimByAdminCommand_Pre_Wager_End_To_End_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.BONUS_CLAIM_BY_ADMIN_POS1.getUserId();
		String username = GamingBonusAdminServiceUsers.BONUS_CLAIM_BY_ADMIN_POS1.getUsername();
		BigInteger bonustemplateId = new BigInteger("467");
		Integer versionId = 999;

		Reporter.log("01. Precondition - Cancel the last bonus user using specificbonuscancelbyadmincommand for user: " + userId);
		Utils.cancelLastBonusIdOfUser(userId);

		Reporter.log("02. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("0.2"))
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("03. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp = BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username(username)
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(20)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expGetUsersForBonusActionsResp = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(id)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expGetUsersForBonusActionsResp, actGetUsersForBonusActionsResp);

		Reporter.log("04. Claim the bonus");
		BonusClaimByAdminCommandReq bonusClaimReq = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userBonusId(userbonusId)
				.userId(userId)
				.build();

		ResultOKResp actResultOKResp = BaseRequest.post(bonusClaimReq, GamingBonusAdminEndpoints.bonusClaimByAdminCommandSuccess);
		ResultOKResp expResultOKResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expResultOKResp, actResultOKResp);	

		Reporter.log("05. Check that bonus is granted using getusersforbonusactionscommand");
		actGetUsersForBonusActionsResp = BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		expUserBonusAction.setUserbonusStatus("Granted");
		expUserBonusAction.setVersionId(1);

		expGetUsersForBonusActionsResp = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(id)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expGetUsersForBonusActionsResp, actGetUsersForBonusActionsResp);

		//Clear the bonus again. If not cleared the next day the bonus is with different status and can't be cancelled at the starting of the case
		try {
			Utils.cancelLastBonusIdOfUser(userId);
		} catch (AssertionFailedError e) {}
	}

	@Test(description = "Make a request to bonusClaimByAdminCommand. After-wager End to end Scenario.")
	public void bonusClaimByAdminCommand_After_Wager_End_To_End_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.BONUS_CLAIM_BY_ADMIN_POS2.getUserId();
		String username = GamingBonusAdminServiceUsers.BONUS_CLAIM_BY_ADMIN_POS2.getUsername();
		BigInteger bonustemplateId = new BigInteger("468");
		Integer versionId = 1000;

		Reporter.log("01. Precondition - Cancel the last bonus user using specificbonuscancelbyadmincommand for user: " + userId);
		Utils.cancelLastBonusIdOfUser(userId);

		Reporter.log("02. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("0.1"))
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("03. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp = BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username(username)
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(10)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expGetUsersForBonusActionsResp = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(id)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expGetUsersForBonusActionsResp, actGetUsersForBonusActionsResp);

		Reporter.log("04. Claim the bonus");
		BonusClaimByAdminCommandReq bonusClaimReq = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userBonusId(userbonusId)
				.userId(userId)
				.build();

		ResultOKResp actResultOKResp = BaseRequest.post(bonusClaimReq, GamingBonusAdminEndpoints.bonusClaimByAdminCommandSuccess);
		ResultOKResp expResultOKResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expResultOKResp, actResultOKResp);	

		Reporter.log("05. Check that bonus is granted using getusersforbonusactionscommand");
		actGetUsersForBonusActionsResp = BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		expUserBonusAction.setUserbonusStatus("Granted");
		expUserBonusAction.setVersionId(1);
		expGetUsersForBonusActionsResp = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(id)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expGetUsersForBonusActionsResp, actGetUsersForBonusActionsResp);
	}

	@Test(description = "Make a request to bonusClaimByAdminCommand. Cash End to end Scenario.")
	public void bonusClaimByAdminCommand_Cash_End_To_End_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.BONUS_CLAIM_BY_ADMIN_POS3.getUserId();
		String username = GamingBonusAdminServiceUsers.BONUS_CLAIM_BY_ADMIN_POS3.getUsername();
		BigInteger bonustemplateId = new BigInteger("482");
		Integer versionId = 1020;

		Reporter.log("01. Precondition - Cancel the last bonus user using specificbonuscancelbyadmincommand for user: " + userId);
		Utils.cancelLastBonusIdOfUser(userId);

		Reporter.log("02. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("0.1"))
				.creditTimeUtc("2021-11-16T12:34:23.390Z")
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("03. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp = BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username(username)
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(10)
				.versionId(0)
				.currency("GBP")
				.build();

		GetUsersForBonusActionsCommandResp expGetUsersForBonusActionsResp = new GetUsersForBonusActionsCommandResp.Builder()
				.defaults()
				.id(id)
				.addUserBonusAction(expUserBonusAction)
				.build();

		assertReflectionEquals(expGetUsersForBonusActionsResp, actGetUsersForBonusActionsResp);

		Reporter.log("04. Claim the bonus.");
		BonusClaimByAdminCommandReq bonusClaimReq = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userBonusId(userbonusId)
				.userId(userId)
				.admin("testAdmin")
				.build();

		ResultOKResp actResultOKResp = BaseRequest.post(bonusClaimReq, GamingBonusAdminEndpoints.bonusClaimByAdminCommandSuccess);
		ResultOKResp expResultOKResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expResultOKResp, actResultOKResp);	

		Reporter.log("05. Check that there is no bonus data for the user after claiming the cash bonus.");
		CustomErrorResponse actNoDataResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandError);

		CustomErrorResponse expNoDataResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("No data was found for passed parameters")
				.code(1001)
				.build();

		assertReflectionEquals(expNoDataResp, actNoDataResp);	
	}

	@Test(description = "Make a request to bonusClaimByAdminCommand. Missing parameter user_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusClaimByAdminCommand_Invalid_Missing_User_Id(String userIdProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer user_id = userIdProvider.equals("null") ? null : Integer.parseInt(userIdProvider);

		BonusClaimByAdminCommandReq req = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userId(user_id)
				.build();

		CustomErrorResponse actResp =  BaseRequest.post(req, GamingBonusAdminEndpoints.bonusClaimByAdminCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: user_id")
				.code(1003)
				.build();

		assertReflectionEquals(expResp, actResp);	
	}

	@Test(description = "Make a request to bonusClaimByAdminCommand. Missing parameter userbonus_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void bonusClaimByAdminCommand_Missing_Invalid_Userbonus_id(String userBonusIdProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer userBonusId = userBonusIdProvider.equals("null") ? null : Integer.parseInt(userBonusIdProvider);

		BonusClaimByAdminCommandReq req = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userBonusId(userBonusId)
				.build();

		CustomErrorResponse actResp =  BaseRequest.post(req, GamingBonusAdminEndpoints.bonusClaimByAdminCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: userbonus_id")
				.code(1003)
				.build();

		assertReflectionEquals(expResp, actResp);	
	}

	@Test(description = "Make a request to bonusClaimByAdminCommand. Missing parameter admin.",
			dataProviderClass = DataProviders.class, dataProvider = "nullEmptyString")
	public void bonusClaimByAdminCommand_Missing_Invalid_Admin(String adminProvider) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String admin = adminProvider.equals("null") ? null : adminProvider;

		BonusClaimByAdminCommandReq req = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.admin(admin)
				.build();

		CustomErrorResponse actResp =  BaseRequest.post(req, GamingBonusAdminEndpoints.bonusClaimByAdminCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Missing/invalid parameter: admin")
				.code(1003)
				.build();

		assertReflectionEquals(expResp, actResp);	
	}

	@Test(description = "Make a request to bonusClaimByAdminCommand. Error in retrieving bonus for claiming - doesn't exist.")
	public void bonusClaimByAdminCommand_Doesnt_Exist() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusClaimByAdminCommandReq req = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userBonusId(7440)
				.build();

		CustomErrorResponse actResp =  BaseRequest.post(req, GamingBonusAdminEndpoints.bonusClaimByAdminCommandError);
		CustomErrorResponse expResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Error in retrieving bonus for redeeming - doesn't exist")
				.code(1001)
				.build();

		assertReflectionEquals(expResp, actResp);	
	}


	@Test(description = "Make a request to bonusClaimByAdminCommand. Cannot claim a deposit matched bonus by admin.")
	public void bonusClaimByAdminCommand_Cannot_Claim_Deposit_Matched() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer userId = GamingBonusAdminServiceUsers.BONUS_CLAIM_BY_ADMIN_POS4.getUserId();
		BigInteger bonustemplateId = new BigInteger("490");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("0.2"))
				.historyToken("8ac7ed6d-48a5-31c9-90a1-9ea0b8154f2a")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.post(addCreditReq, GamingBonusAdminEndpoints.addCreditedUsersCommandSuccess);

		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("02. Get userbonus_id using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.bonusTemplateId(bonustemplateId)
				.versionId(1029)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();

		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp =  BaseRequest.post(getUsersForBonusActionsReq, GamingBonusAdminEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();

		Reporter.log("03. Claim the bonus using bonusClaimByAdminCommand");
		BonusClaimByAdminCommandReq req = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		CustomErrorResponse actResp =  BaseRequest.post(req, GamingBonusAdminEndpoints.bonusClaimByAdminCommandError);
		CustomErrorResponse expResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("Cannot claim a deposit matched bonus by admin - please refer to manualcreditandclaimcommand")
				.code(1002)
				.build();

		assertReflectionEquals(expResp, actResp);

		Reporter.log("04. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess);
	}

	@Test(description = "Make a request to bonusClaimByAdminCommand. Cannot claim a deposit matched bonus by admin.")
	public void bonusClaimByAdminCommand_NoOffers_Status() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		BonusClaimByAdminCommandReq req = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userId(GamingBonusAdminServiceUsers.BONUS_CLAIM_BY_ADMIN_NEG.getUserId())
				.userBonusId(20854)
				.build();

		CustomErrorResponse actResp =  BaseRequest.post(req, GamingBonusAdminEndpoints.bonusClaimByAdminCommandError);
		CustomErrorResponse expResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("User cannot receive offers - NoOffers status set to true")
				.code(1002)
				.build();

		assertReflectionEquals(expResp, actResp);	
	}
}
