package tests.gamingbonusadminservice.responseobjects;

public class UserBonusAction {
	
	String username;
	Integer user_id;
	Integer userbonus_id;
	String userbonus_status;
	Integer amount_pence;
	Integer version_id;
	String currency;
	
	public UserBonusAction() {
	}
	
	private UserBonusAction(Builder builder) {
		username = builder.username;
		user_id = builder.user_id;
	    userbonus_id = builder.userbonus_id;
		userbonus_status = builder.userbonus_status;
		amount_pence = builder.amount_pence;
		version_id = builder.version_id;
		currency = builder.currency;
	}
	
	public void setUserbonusStatus(String userbonusStatus) {
		userbonus_status = userbonusStatus;
	}
	
	public void setVersionId(Integer versionId) {
		version_id = versionId;
	}
	
	public String getUsername() {
		return username;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public Integer getUserbonus_id() {
		return userbonus_id;
	}

	public String getUserbonus_status() {
		return userbonus_status;
	}

	public Integer getAmount_pence() {
		return amount_pence;
	}

	public Integer getVersion_id() {
		return version_id;
	}

	public String getCurrency() {
		return currency;
	}
	
	public static class Builder {
		
		String username;
		Integer user_id;
		Integer userbonus_id;
		String userbonus_status;
		Integer amount_pence;
		Integer version_id;
		String currency;
		
		public Builder username(String username) {
			this.username = username;
			return this;
		}
		
		public Builder userId(Integer userId) {
			user_id = userId;
			return this;
		}
		
		public Builder userbonusId(Integer userbonusId) {
			userbonus_id = userbonusId;
			return this;
		}
		
		public Builder userbonusStatus(String userbonusStatus) {
			this.userbonus_status = userbonusStatus;
			return this;
		}
		
		public Builder amountPence(Integer amountPence) {
			amount_pence = amountPence;
			return this;
		}
		
		public Builder versionId(Integer versionId) {
			version_id = versionId;
			return this;
		}
		
		public Builder currency(String currency) {
			this.currency = currency;
			return this;
		}
		
		public Builder defaults() {
			userbonus_id = 6373;
			userbonus_status = "Granted";
			amount_pence = 1000;
			version_id = 4;
			currency = "GBP";
			return this;
		}
		
		public UserBonusAction build() {
			return new UserBonusAction(this);
		}
	}

}
	