package tests.gamingbonusadminservice;

import common.DatabaseQueries;
import domain.BaseRequest;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.request.SpecificBonusCancelByAdminCommandReq;

public class Utils {
	
	public static void cancelLastBonusIdOfUser(Integer userId) {
		
		Integer userBonusId =  DatabaseQueries.getLastUserBonusIdFromUserBonus(userId);
		if (userBonusId != null) {
			SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
					.defaults()
					.userId(userId)
					.userBonusId(userBonusId)
					.build();
			
			BaseRequest.post(cancelBonusReq, GamingBonusAdminEndpoints.specificBonusCancelByAdminCommandSuccess.getEndPoint());
		}
	}
}
