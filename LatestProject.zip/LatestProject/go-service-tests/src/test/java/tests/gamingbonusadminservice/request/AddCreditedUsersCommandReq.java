package tests.gamingbonusadminservice.request;

import java.util.ArrayList;
import java.util.List;

import tests.gamingbonusadminservice.requestobjects.UserBonus;

public class AddCreditedUsersCommandReq {

	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;
	
	public AddCreditedUsersCommandReq(Builder builder) {
		this.Id = builder.id;
		Method = builder.method;
		this.params = new Params(builder);
	}
	
	public static class Builder {
		
		private String id;
		private String method;
		private List<UserBonus> userBonuses;
		private String creditedBy;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder addUserBonus(UserBonus userBonus) {
			userBonuses.add(userBonus);
			return this;
		}
		
		public Builder creditedby(String creditedBy) {
			this.creditedBy = creditedBy;
			return this;
		}
		
		public Builder defaults() {
			id = "defaultTestId";
			method = "addcrediteduserscommand";
			userBonuses = new ArrayList<>();
			creditedBy = "vasilz";
			
			return this;
		}
		
		public AddCreditedUsersCommandReq build() {
			return new AddCreditedUsersCommandReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		private List<UserBonus> userbonuses;
		@SuppressWarnings("unused")
		private String creditedby;

		public Params(Builder builder) {
			this.userbonuses = builder.userBonuses;
			this.creditedby = builder.creditedBy;
		}
	}
}
