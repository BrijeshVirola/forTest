package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.testng.Reporter;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.DatabaseQueries;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.enums.GamingBonusAdminEndpoints;
import tests.gamingbonusadminservice.request.InsertGamePositionsCommandReq;

public class InsertGamePositionsCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to insertgamepositionscommand. Positive Scenario.")
	public void insertGamePositionsCommand_Positive_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		int gameTokenId1 = 3268;
		int gameTokenId2 = 17743;
		int bonustemplateId = 515;
		
		Reporter.log("00. Precondition - Make insert with empty games to clear the game positions of the template.");
		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.regulatedzoneId(1)
				.productId(2)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		Reporter.log("01. Insert two game positions.");
		Map<String, Integer> expGamePosition1 = new HashMap<>();
		expGamePosition1.put("BonusTemplateId", bonustemplateId);
		expGamePosition1.put("RegulatedZoneId", 1);
		expGamePosition1.put("Position", 1);
		expGamePosition1.put("GameTokenId", gameTokenId1);
		expGamePosition1.put("ProductId", 2);

		Map<String, Integer> expGamePosition2 = new HashMap<>();
		expGamePosition2.put("BonusTemplateId", bonustemplateId);
		expGamePosition2.put("RegulatedZoneId", 1);
		expGamePosition2.put("Position", 2);
		expGamePosition2.put("GameTokenId", gameTokenId2);
		expGamePosition2.put("ProductId", 2);

		request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(gameTokenId1, 1)
				.addGame(gameTokenId2, 2)
				.bonustemplateId(bonustemplateId)
				.regulatedzoneId(1)
				.productId(2)
				.build();

		actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandSuccess);

		expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		Reporter.log("02. Check that repsponse is properly returned.");
		assertReflectionEquals(expectedResponse, actualResponse);

		Reporter.log("03. Check that game positions are properly inserted in the database.");
		Map<String, Integer> actGamePosition1 = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId1);
		Map<String, Integer> actGamePosition2 = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId2);

		assertReflectionEquals(expGamePosition1, actGamePosition1);
		assertReflectionEquals(expGamePosition2, actGamePosition2);
	}
	
	@Test(description = "Make a request to insertgamepositionscommand. Change the positions of two games.")
	public void insertGamePositionsCommand_Positive_Change_Game_Positions_Of_Two_Games() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		int gameTokenId1 = 3268;
		int gameTokenId2 = 17743;
		int bonustemplateId = 1628;
		
		Reporter.log("01. Insert two game positions.");
		Map<String, Integer> expGame1Position = new HashMap<>();
		expGame1Position.put("BonusTemplateId", bonustemplateId);
		expGame1Position.put("RegulatedZoneId", 1);
		expGame1Position.put("Position", 1);
		expGame1Position.put("GameTokenId", gameTokenId1);
		expGame1Position.put("ProductId", 2);

		Map<String, Integer> expGame2Position = new HashMap<>();
		expGame2Position.put("BonusTemplateId", bonustemplateId);
		expGame2Position.put("RegulatedZoneId", 1);
		expGame2Position.put("Position", 2);
		expGame2Position.put("GameTokenId", gameTokenId2);
		expGame2Position.put("ProductId", 2);

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(gameTokenId1, 1)
				.addGame(gameTokenId2, 2)
				.bonustemplateId(bonustemplateId)
				.regulatedzoneId(1)
				.productId(2)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		Reporter.log("02. Check that repsponse is properly returned.");
		assertReflectionEquals(expectedResponse, actualResponse);

		Reporter.log("03. Check that game positions are properly inserted in the database.");
		Map<String, Integer> actGame1Position = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId1);
		Map<String, Integer> actGame2Position = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId2);

		assertReflectionEquals(expGame1Position, actGame1Position);
		assertReflectionEquals(expGame2Position, actGame2Position);
		
		Reporter.log("04. Change the positions of the two games.");
		expGame2Position = new HashMap<>();
		expGame2Position.put("BonusTemplateId", bonustemplateId);
		expGame2Position.put("RegulatedZoneId", 1);
		expGame2Position.put("Position", 1);
		expGame2Position.put("GameTokenId", gameTokenId2);
		expGame2Position.put("ProductId", 2);

		expGame1Position = new HashMap<>();
		expGame1Position.put("BonusTemplateId", bonustemplateId);
		expGame1Position.put("RegulatedZoneId", 1);
		expGame1Position.put("Position", 2);
		expGame1Position.put("GameTokenId", gameTokenId1);
		expGame1Position.put("ProductId", 2);

		request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(gameTokenId2, 1)
				.addGame(gameTokenId1, 2)
				.bonustemplateId(bonustemplateId)
				.regulatedzoneId(1)
				.productId(2)
				.build();

		actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandSuccess);

		expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		Reporter.log("05. Check that repsponse is properly returned.");
		assertReflectionEquals(expectedResponse, actualResponse);

		Reporter.log("06. Check that game positions are properly inserted in the database.");
		actGame1Position = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId1);
		actGame2Position = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId2);

		assertReflectionEquals(expGame1Position, actGame1Position);
		assertReflectionEquals(expGame2Position, actGame2Position);
	}
	
	@Test(description = "Make a request to insertgamepositionscommand. Empty games.")
	public void insertGamePositionsCommand_Empty_Games() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		int gameTokenId1 = 3268;
		int gameTokenId2 = 17743;
		int bonustemplateId = 1620;
		
		Reporter.log("01. Insert two game positions.");
		Map<String, Integer> expGamePosition1 = new HashMap<>();
		expGamePosition1.put("BonusTemplateId", bonustemplateId);
		expGamePosition1.put("RegulatedZoneId", 1);
		expGamePosition1.put("Position", 1);
		expGamePosition1.put("GameTokenId", gameTokenId1);
		expGamePosition1.put("ProductId", 2);

		Map<String, Integer> expGamePosition2 = new HashMap<>();
		expGamePosition2.put("BonusTemplateId", bonustemplateId);
		expGamePosition2.put("RegulatedZoneId", 1);
		expGamePosition2.put("Position", 2);
		expGamePosition2.put("GameTokenId", gameTokenId2);
		expGamePosition2.put("ProductId", 2);

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(gameTokenId1, 1)
				.addGame(gameTokenId2, 2)
				.bonustemplateId(bonustemplateId)
				.regulatedzoneId(1)
				.productId(2)
				.build();

		ResultOKResp actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		Reporter.log("02. Check that repsponse is properly returned.");
		assertReflectionEquals(expectedResponse, actualResponse);

		Reporter.log("03. Check that game positions are properly inserted in the database.");
		Map<String, Integer> actGamePosition1 = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId1);
		Map<String, Integer> actGamePosition2 = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId2);

		assertReflectionEquals(expGamePosition1, actGamePosition1);
		assertReflectionEquals(expGamePosition2, actGamePosition2);
		
		Reporter.log("04. Make insert again but with empty games.");
		request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.regulatedzoneId(1)
				.productId(2)
				.build();

		actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandSuccess);

		expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
		
		Reporter.log("05. Check that game positions are empty in the database.");
		actGamePosition1 = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId1);
		actGamePosition2 = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId2);
		
		expGamePosition1 = new HashMap<>();
		expGamePosition2 = new HashMap<>();
		
		assertReflectionEquals(expGamePosition1, actGamePosition1);
		assertReflectionEquals(expGamePosition2, actGamePosition2);
	}

	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid bonustemplate_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void insertGamePositionsCommand_Missing_Invalid_Bonustemplate_Id(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer bonustemplateId = nullZero.equals("null") ? null : 0;

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(3268, 1)
				.bonustemplateId(bonustemplateId)
				.regulatedzoneId(1)
				.productId(2)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: bonustemplate_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid product_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void insertGamePositionsCommand_Missing_Invalid_Product_Id(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer productId = nullZero.equals("null") ? null : 0;

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(3268, 1)
				.bonustemplateId(515)
				.regulatedzoneId(1)
				.productId(productId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: product_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid regulatedzone_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void insertGamePositionsCommand_Missing_Invalid_Regulatedzone_Id(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer regulatedzoneId = nullZero.equals("null") ? null : 0;

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(3268, 1)
				.bonustemplateId(515)
				.regulatedzoneId(regulatedzoneId)
				.productId(2)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: regulatedzone_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid position.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void insertGamePositionsCommand_Missing_Invalid_Position(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer position = nullZero.equals("null") ? null : 0;

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(3268, position)
				.bonustemplateId(515)
				.regulatedzoneId(2)
				.productId(2)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: position")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid gametoken_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void insertGamePositionsCommand_Missing_Invalid_Gametoken_id(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer gameTokenId = nullZero.equals("null") ? null : 0;

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(gameTokenId, 1)
				.bonustemplateId(515)
				.regulatedzoneId(2)
				.productId(2)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.post(
				request, GamingBonusAdminEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: gametoken_id")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
