package tests.gamingserviceadapter.response;

public class GetUserBalanceForDateTimeResp {

	private String id;
	private Result result;

	public GetUserBalanceForDateTimeResp() {
	}
	
	private GetUserBalanceForDateTimeResp(Builder builder) {
		this.id = builder.id;
		this.result = new Result(builder);
	}

	public String getId() {
		return id;
	}
	
	public Result getResult() {
		return result;
	}

	public String getUserBalance() {
		return result.userbalance;
	}

	public static class Builder {

		private String id;
		private String userbalance;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder userBalance(String userbalance) {
			this.userbalance = userbalance;
			return this;
		}

		public Builder defaults() {
			this.id = "Id";
			this.userbalance = "5";
			return this;
		}

		public GetUserBalanceForDateTimeResp build() {
			return new GetUserBalanceForDateTimeResp(this);
		}
	}

	private class Result {
		
		String userbalance;

		@SuppressWarnings("unused")
		public Result() {
		}
		
		public Result(Builder builder) {
			this.userbalance = builder.userbalance;
		}
		
		@SuppressWarnings("unused")
		public String getUserbalance() {
			return userbalance;
		}
	}
}
