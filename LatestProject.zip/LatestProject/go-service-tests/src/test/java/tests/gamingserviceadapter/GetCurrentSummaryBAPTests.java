package tests.gamingserviceadapter;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gamingserviceadapter.enums.GamingAdapterEndpoints;
import tests.gamingserviceadapter.enums.GamingAdapterServiceUsers;
import tests.gamingserviceadapter.request.GetCurrentSummaryReq;
import tests.gamingserviceadapter.response.GetCurrentSummaryResp;
import tests.gamingserviceadapter.responseobjects.GameplaySummary;

public class GetCurrentSummaryBAPTests extends BaseClassSetup {

	@Test(description = "Make a request to GetCurrentSummary for BAP. Positive scenario.")
	public void getCurrentSummary_User_BAP_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingAdapterServiceUsers.GET_CURRENT_SUM_BAP_POS1.getUserId())
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getCurrentSummaryBACSuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturn_total();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary for BAP. Min Session Id - Positive scenario.")
	public void getCurrentSummary_Min_Session_ID_User_BAP_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingAdapterServiceUsers.GET_CURRENT_SUM_BAP_POS1.getUserId())
				.sessionId("E")
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getCurrentSummaryBACSuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturn_total();

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponse = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponse.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary for BAP. User Id - Not Found - Negative scenario.")
	public void getCurrentSummary_UserId_Not_Found_BAP_Negative_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(999999999)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getCurrentSummaryBACError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("User not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary for BAP. User Id - Unexpected Error - Negative scenario.")
	public void getCurrentSummary_User_Id_Unexpected_Error_BAC_Negative_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GamingAdapterServiceUsers.GET_CURRENT_SUM_BAP_NEG.getUserId())
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getCurrentSummaryBACError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1001)
				.message("Failed to get current summary")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetCurrentSummary. Wrong method.")
	public void getCurrentSummary_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getCurrentSummaryBACError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Missing user_id parameter.")
	public void GetCurrentSummary_UserId_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getCurrentSummaryBACError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: user_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Missing session_id parameter.")
	public void GetCurrentSummary_Session_Id_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.userId(GamingAdapterServiceUsers.GET_CURRENT_SUM_BAP_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.sessionId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getCurrentSummaryBACError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: session_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
