package tests.gamingserviceadapter;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.Utils;
import domain.BaseRequest;
import tests.gamingserviceadapter.enums.GamingAdapterEndpoints;
import tests.gamingserviceadapter.enums.GamingAdapterServiceUsers;
import tests.gamingserviceadapter.request.GetUserBalanceForDateTimeReq;
import tests.gamingserviceadapter.response.GetUserBalanceForDateTimeResp;

public class GetUserBalanceForDateTimeTests extends BaseClassSetup {

	@Test(description = "Make a request to Get User Balance for PResent DateTime. Positive scenario.")
	public void getUserBalanceForPresentDateTime_Positive_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUserBalanceForDateTimeReq request = new GetUserBalanceForDateTimeReq.Builder()
				.defaults()
				.userId(GamingAdapterServiceUsers.GET_USER_BALANCE_POS1.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.dateTimeUtc(Utils.dateTimeUtc())
				.build();

		GetUserBalanceForDateTimeResp actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getUserBalanceForDateTimeSuccess);

		GetUserBalanceForDateTimeResp expResponse = new GetUserBalanceForDateTimeResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userBalance("380.01")
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to Get User Balance for Past DateTime. Positive scenario.")
	public void getUserBalanceForPastDateTime_Positive_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUserBalanceForDateTimeReq request = new GetUserBalanceForDateTimeReq.Builder()
				.defaults()
				.userId(GamingAdapterServiceUsers.GET_USER_BALANCE_POS1.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetUserBalanceForDateTimeResp actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getUserBalanceForDateTimeSuccess);

		GetUserBalanceForDateTimeResp expResponse = new GetUserBalanceForDateTimeResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expResponse, actualResponse);		
	}

	@Test(description = "Make a request to Get User balance for date time .User Id - Not Found - Negative scenario.")
	public void getUserBalanceForDateTime_NoUser_Negative_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUserBalanceForDateTimeReq request = new GetUserBalanceForDateTimeReq.Builder()
				.defaults()
				.userId(GamingAdapterServiceUsers.GET_USER_BALANCE_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getUserBalanceForDateTimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1001)
				.message("Failed to get user balance")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);		
	}

	@Test(description = "Make a request to GetUserBalanceForDateTime. Wrong method.")
	public void getUserBalanceForDateTime_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUserBalanceForDateTimeReq request = new GetUserBalanceForDateTimeReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getUserBalanceForDateTimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetUserBalanceForDateTime. Unknown user_id parameter.")
	public void GetUserBalanceForDateTime_UnknownUserId__Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUserBalanceForDateTimeReq request = new GetUserBalanceForDateTimeReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(999999999)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getUserBalanceForDateTimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1001)
				.message("Failed to get user balance")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetUserBalanceForDateTime. Missing user_id parameter.")
	public void GetUserBalanceForDateTime_UserId_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUserBalanceForDateTimeReq request = new GetUserBalanceForDateTimeReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getUserBalanceForDateTimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: user_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetUserBalanceForDateTime. Missing dateTime parameter.")
	public void GetUserBalanceForDateTime_DateTime_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetUserBalanceForDateTimeReq request = new GetUserBalanceForDateTimeReq.Builder()
				.defaults()
				.userId(GamingAdapterServiceUsers.GET_USER_BALANCE_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.dateTimeUtc(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GamingAdapterEndpoints.getUserBalanceForDateTimeError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: datetime_utc is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}
