package tests.gamingserviceadapter.enums;

import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.gamingserviceadapter.response.GetCurrentSummaryResp;
import tests.gamingserviceadapter.response.GetUserBalanceForDateTimeResp;

public enum GamingAdapterEndpoints implements ResponseEndpoints {

	getCurrentSummaryBACSuccess(GetCurrentSummaryResp.class, "GameplayLimits/GetCurrentSummary"),
	getCurrentSummaryBACError(CustomErrorResponse.class, "GameplayLimits/GetCurrentSummary"),
	getUserBalanceForDateTimeSuccess(GetUserBalanceForDateTimeResp.class, "user/getuserbalancefordatetime"),
	getUserBalanceForDateTimeError(CustomErrorResponse.class, "user/getuserbalancefordatetime");
	
	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> GamingAdapterEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
