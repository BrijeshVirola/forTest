package tests.gamingserviceadapter.request;

public class GetUserBalanceForDateTimeReq {

	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;

	private GetUserBalanceForDateTimeReq(Builder builder) {
		this.Id = builder.id;
		this.Method = builder.method;
		this.params = new Params(builder);
	}

	public static class Builder {

		private String id;
		private String method;
		private Integer user_id;
		private String datetime_utc;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder dateTimeUtc(String datetime_utc) {
			this.datetime_utc = datetime_utc;
			return this;
		}

		public Builder defaults() {
			this.id = "Id";
			this.method = "getuserbalancefordatetime";
			this.datetime_utc = "2020-10-29T10:00:00+00:00";
			return this;
		}

		public GetUserBalanceForDateTimeReq build() {
			return new GetUserBalanceForDateTimeReq(this);
		}
	}

	private class Params {
		@SuppressWarnings("unused")
		Integer user_id;
		@SuppressWarnings("unused")
		String datetime_utc;

		public Params(Builder builder) {
			this.user_id = builder.user_id;
			this.datetime_utc = builder.datetime_utc;

		}
	}
}
