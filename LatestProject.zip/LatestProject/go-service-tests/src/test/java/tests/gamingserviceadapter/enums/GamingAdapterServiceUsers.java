package tests.gamingserviceadapter.enums;

import common.DatabaseQueries;

public enum GamingAdapterServiceUsers {

	GET_CURRENT_SUM_BAC_POS1("COGENA_ONT_02"),
	GET_CURRENT_SUM_BAC_NEG("fredrika55"),
	GET_CURRENT_SUM_BAP_POS1("DTT0111153P"),
	GET_CURRENT_SUM_BAP_NEG("fredrika55"),
	GET_USER_BALANCE_POS1("fredrika55"),
	GET_USER_BALANCE_NEG("DLOI7164035078");

	private String username;

	private GamingAdapterServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}