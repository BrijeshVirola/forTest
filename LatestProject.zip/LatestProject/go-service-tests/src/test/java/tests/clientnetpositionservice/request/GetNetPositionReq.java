package tests.clientnetpositionservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetNetPositionReq {

	private Map<String, Object> parameters = new HashMap<>();

	private GetNetPositionReq(Builder builder) {
		this.parameters.put("glt", builder.glt);
	}

	public Map<String, Object> getParameters() {
		return parameters;
	}

	public static class Builder {
		private String glt;

		public Builder params(String glt) {
			this.glt = glt;
			return this;
		}

		public Builder glt(String glt) {
			this.glt = glt;
			return this;
		}


		public Builder defaults() {
			this.glt = "6b5132de-5dc3-4da7-a82b-16f60e168dcf";
			return this;
		}

		public GetNetPositionReq build() {
			return new GetNetPositionReq(this);
		}
	}
}
