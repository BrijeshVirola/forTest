package tests.clientnetpositionservice.request;

import java.util.HashMap;
import java.util.Map;

import common.Utils;
import tests.clientnetpositionservice.enums.ClientNetPositionServiceUsers;

public class NetPositionHeaders {

	private Map<String, Object> headers = new HashMap<>();

	private NetPositionHeaders(Builder builder) {
		this.headers.put("Cookie", builder.gstkCookie);
	}

	public Map<String, Object> getHeaders() {
		return headers;
	}

	public static class Builder {
		private String gstkCookie;

		public Builder gstkCookie(String gstkCookie) {
			this.gstkCookie = "gstk=" + gstkCookie;
			return this;
		}

		public Builder defaults() {
			this.gstkCookie = "gstk="+ Utils.createSession(ClientNetPositionServiceUsers.NET_POSITION_HEADER_REQ.getUsername()).getSessionId();
			return this;
		}

		public NetPositionHeaders build() {
			return new NetPositionHeaders(this);
		}
	}
}
