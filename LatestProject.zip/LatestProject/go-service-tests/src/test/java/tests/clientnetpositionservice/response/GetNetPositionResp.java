package tests.clientnetpositionservice.response;


public class GetNetPositionResp {

	private Long sd;
	private Long np;
	private Long ba;
	private Long wa;

	public GetNetPositionResp() {
	}
	
	private GetNetPositionResp(Builder builder) {
		this.sd = builder.sd;
		this.np = builder.np;
		this.ba = builder.ba;
		this.wa = builder.wa;
	}

	public Long getSd() {
		return sd;
	}

	public Long getNp() {
		return np;
	}

	public Long getBa() {
		return ba;
	}

	public Long getWa() {
		return wa;
	}

	public static class Builder {
		private Long sd;
		private Long np;
		private Long ba;
		private Long wa;

		public Builder sd(Long sd) {
			this.sd = sd;
			return this;
		}

		public Builder np(Long np) {
			this.np = np;
			return this;
		}

		public Builder ba(Long ba) {
			this.ba = ba;
			return this;
		}

		public Builder wa(Long wa) {
			this.wa = wa;
			return this;
		}

		public Builder defaults() {
			this.sd = 0L;
			this.np = 0L;
			this.ba = 0L;
			this.wa = 0L;
			return this;
		}

		public GetNetPositionResp build() {
			return new GetNetPositionResp(this);
		}
	}
}
