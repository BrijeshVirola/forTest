	package tests.clientnetpositionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.TransactionType;
import common.Utils;
import domain.BaseRequest;
import tests.clientnetpositionservice.enums.ClientNetPositionEndPoints;
import tests.clientnetpositionservice.enums.ClientNetPositionServiceUsers;
import tests.clientnetpositionservice.request.GetNetPositionReq;
import tests.clientnetpositionservice.request.NetPositionHeaders;
import tests.clientnetpositionservice.response.GetNetPositionResp;

public class GetNetPositionTests extends BaseClassSetup {	

	@Test(description = "Make a request to GetNetPosition valid glt parameter and headers. Positive scenario.")
	public void GetNetPosition_Positive_Scenario() {
		String negativeStake = "-1";
		BigDecimal positiveStake = new BigDecimal(1);
		BigDecimal returnTransaction = new BigDecimal(3);
		BigDecimal netPosition = returnTransaction.subtract(positiveStake);

		// Create new session
		String sessionId = Utils.createSession(ClientNetPositionServiceUsers.GET_NET_POSITION_POS1.getUsername()).getSessionId();

		String glt = Utils.createGlt(sessionId);

		// Prepare the headers for the request
		NetPositionHeaders headers = new NetPositionHeaders.Builder()
				.gstkCookie(sessionId)
				.build();

		GetNetPositionReq request = new GetNetPositionReq.Builder()
				.glt(glt)
				.build();

		// Get the net position for the specific user with created session
		GetNetPositionResp currentNetPositionResp = BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionSuccess, headers.getHeaders());

		// Create new stake and return transactions for the specific userId
		Utils.createTransaction(TransactionType.STAKE, ClientNetPositionServiceUsers.GET_NET_POSITION_POS1.getUserId(), negativeStake);
		Utils.createTransaction(TransactionType.RETURN, ClientNetPositionServiceUsers.GET_NET_POSITION_POS1.getUserId(), returnTransaction.toPlainString());

		// Call getNetPosition again to get the new values after stake and return transactions
		GetNetPositionResp afterTransactionNetPositionResp = BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionSuccess, headers.getHeaders());

		// Prepare the expected response object
		GetNetPositionResp expResponse = new GetNetPositionResp.Builder()
				.defaults()
				.sd(afterTransactionNetPositionResp.getSd())
				.np(currentNetPositionResp.getNp() + netPosition.longValue())
				.ba(currentNetPositionResp.getBa() + positiveStake.longValue())
				.wa(currentNetPositionResp.getWa() + returnTransaction.longValue())
				.build();

		assertReflectionEquals(expResponse, afterTransactionNetPositionResp);
		// Check that the session duration after the second call has been equal or greater than the first call
		Assert.assertTrue(afterTransactionNetPositionResp.getSd() >= currentNetPositionResp.getSd());
	}

	@Test(description = "Make a request to GetNetPosition - missing glt parameter - optional. Positive scenario.")
	public void GetNetPosition_Missing_GLT_Positive_Scenario() {
		String negativeStake = "-1";
		BigDecimal positiveStake = new BigDecimal(1);
		BigDecimal returnTransaction = new BigDecimal(3);
		BigDecimal netPosition = returnTransaction.subtract(positiveStake);

		// Create new session
		String sessionId = Utils.createSession(ClientNetPositionServiceUsers.GET_NET_POSITION_POS2.getUsername()).getSessionId();

		// Prepare the headers for the request
		NetPositionHeaders headers = new NetPositionHeaders.Builder()
				.gstkCookie(sessionId)
				.build();

		GetNetPositionReq request = new GetNetPositionReq.Builder()
				.build();

		// Get the net position for the specific user with created session
		GetNetPositionResp currentNetPositionResp = BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionSuccess, headers.getHeaders());

		// Create new stake and return transactions for the specific userId
		Utils.createTransaction(TransactionType.STAKE, ClientNetPositionServiceUsers.GET_NET_POSITION_POS2.getUserId(), negativeStake);
		Utils.createTransaction(TransactionType.RETURN, ClientNetPositionServiceUsers.GET_NET_POSITION_POS2.getUserId(), returnTransaction.toPlainString());

		// Call getNetPosition again to get the new values after stake and return transactions
		GetNetPositionResp afterTransactionNetPositionResp = BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionSuccess, headers.getHeaders());

		// Prepare the expected response object
		GetNetPositionResp expResponse = new GetNetPositionResp.Builder()
				.defaults()
				.sd(afterTransactionNetPositionResp.getSd())
				.np(currentNetPositionResp.getNp() + netPosition.longValue())
				.ba(currentNetPositionResp.getBa() + positiveStake.longValue())
				.wa(currentNetPositionResp.getWa() + returnTransaction.longValue())
				.build();

		assertReflectionEquals(expResponse, afterTransactionNetPositionResp);
		// Check that the session duration after the second call has been equal or greater than the first call
		Assert.assertTrue(afterTransactionNetPositionResp.getSd() >= currentNetPositionResp.getSd());
	}

	@Test(description = "Make a request to GetNetPosition with missing header and valid glt. Positive scenario.")
	public void GetNetPosition_Missing_Header_Valid_GLT_Positive_Scenario() {
		String negativeStake = "-1";
		BigDecimal positiveStake = new BigDecimal(1);
		BigDecimal returnTransaction = new BigDecimal(3);
		BigDecimal netPosition = returnTransaction.subtract(positiveStake);

		// Create new session
		String sessionId = Utils.createSession(ClientNetPositionServiceUsers.GET_NET_POSITION_POS3.getUsername()).getSessionId();

		String glt = Utils.createGlt(sessionId);

		GetNetPositionReq request = new GetNetPositionReq.Builder()
				.defaults()
				.glt(glt)
				.build();

		GetNetPositionResp currentNetPositionResp = BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionSuccess);

		// Create new stake and return transactions for the specific userId
		Utils.createTransaction(TransactionType.STAKE, ClientNetPositionServiceUsers.GET_NET_POSITION_POS3.getUserId(), negativeStake);
		Utils.createTransaction(TransactionType.RETURN, ClientNetPositionServiceUsers.GET_NET_POSITION_POS3.getUserId(), returnTransaction.toPlainString());

		// Call getNetPosition again to get the new values after stake and return transactions
		GetNetPositionResp afterTransactionNetPositionResp = BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionSuccess);

		// Prepare the expected response object
		GetNetPositionResp expResponse = new GetNetPositionResp.Builder()
				.defaults()
				.sd(afterTransactionNetPositionResp.getSd())
				.np(currentNetPositionResp.getNp() + netPosition.longValue())
				.ba(currentNetPositionResp.getBa() + positiveStake.longValue())
				.wa(currentNetPositionResp.getWa() + returnTransaction.longValue())
				.build();

		assertReflectionEquals(expResponse, afterTransactionNetPositionResp);
		// Check that the session duration after the second call has been equal or greater than the first call
		Assert.assertTrue(afterTransactionNetPositionResp.getSd() >= currentNetPositionResp.getSd());
	}	

	@Test(description = "Make a request to GetNetPosition with missing header and invalid glt. Negative scenario.")
	public void GetNetPosition_Missing_Header_Invalid_GLT_Negative_Scenario() {

		GetNetPositionReq request = new GetNetPositionReq.Builder()
				.defaults()
				.glt(UUID.randomUUID().toString())
				.build();

		GetNetPositionResp actResponse = BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionSuccess, 403);

		GetNetPositionResp expResponse = new GetNetPositionResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}	

}
