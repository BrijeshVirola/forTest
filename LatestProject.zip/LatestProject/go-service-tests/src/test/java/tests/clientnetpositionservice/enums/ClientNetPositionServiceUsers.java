package tests.clientnetpositionservice.enums;

import common.DatabaseQueries;

public enum ClientNetPositionServiceUsers {

	NET_POSITION_HEADER_REQ("BV08122021"),
	GET_NET_POSITION_POS1("go_svc_tests09"),
	GET_NET_POSITION_POS2("GO_SVC_CNP_01"),
	GET_NET_POSITION_POS3("go_svc_tests22");

	private String username;

	private ClientNetPositionServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}