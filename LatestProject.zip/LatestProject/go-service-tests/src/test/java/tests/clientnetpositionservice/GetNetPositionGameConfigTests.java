package tests.clientnetpositionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import domain.BaseRequest;
import tests.clientnetpositionservice.enums.ClientNetPositionEndPoints;
import tests.clientnetpositionservice.request.GetNetPositionGameConfigReq;
import tests.clientnetpositionservice.response.GetNetPositionGameConfigResp;

public class GetNetPositionGameConfigTests extends BaseClassSetup {

	@Test(description = "Make a request to getNetPositionGameConfig. Positive scenario.")
	public void GetNetPositionGameConfig_Positive_Scenario() {
		GetNetPositionGameConfigReq request = new GetNetPositionGameConfigReq.Builder()
				.defaults()
				.build();

		GetNetPositionGameConfigResp actResponse =  BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionGameConfigSuccess);

		GetNetPositionGameConfigResp expResponse =  new GetNetPositionGameConfigResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to getNetPositionGameConfig - Missing gt parameter. Negative scenario.")
	public void GetNetPositionGameConfig_Missing_Gt_Parameter_Negative_Scenario() {
		GetNetPositionGameConfigReq request = new GetNetPositionGameConfigReq.Builder()
				.defaults()
				.gt(null)
				.build();

		GetNetPositionGameConfigResp actResponse =  BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionGameConfigSuccess, 400);

		GetNetPositionGameConfigResp expResponse =  new GetNetPositionGameConfigResp.Builder()
				.defaults()
				.npr(false)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to getNetPositionGameConfig - Missing gmpid parameter. Negative scenario.")
	public void GetNetPositionGameConfig_Missing_Gmpid_Parameter_Negative_Scenario() {
		GetNetPositionGameConfigReq request = new GetNetPositionGameConfigReq.Builder()
				.defaults()
				.gmpid(null)
				.build();

		GetNetPositionGameConfigResp actResponse =  BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionGameConfigSuccess, 400);

		GetNetPositionGameConfigResp expResponse =  new GetNetPositionGameConfigResp.Builder()
				.defaults()
				.npr(false)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to getNetPositionGameConfig - Unmatching gt parameter. Negative scenario.")
	public void GetNetPositionGameConfig_Unmatching_Gt_Parameter_Negative_Scenario() {
		GetNetPositionGameConfigReq request = new GetNetPositionGameConfigReq.Builder()
				.defaults()
				.gt("Unmatching")
				.build();

		GetNetPositionGameConfigResp actResponse =  BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionGameConfigSuccess, 404);

		GetNetPositionGameConfigResp expResponse =  new GetNetPositionGameConfigResp.Builder()
				.defaults()
				.npr(false)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to getNetPositionGameConfig - Unmatching gmpid parameter. Negative scenario.")
	public void GetNetPositionGameConfig_Unmatching_Gmpid_Parameter_Negative_Scenario() {
		GetNetPositionGameConfigReq request = new GetNetPositionGameConfigReq.Builder()
				.defaults()
				.gmpid(1)
				.build();

		GetNetPositionGameConfigResp actResponse =  BaseRequest.get(request.getParameters(), ClientNetPositionEndPoints.getNetPositionGameConfigSuccess, 404);

		GetNetPositionGameConfigResp expResponse =  new GetNetPositionGameConfigResp.Builder()
				.defaults()
				.npr(false)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
}
