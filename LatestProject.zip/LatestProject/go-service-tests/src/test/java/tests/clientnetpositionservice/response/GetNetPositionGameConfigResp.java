package tests.clientnetpositionservice.response;


public class GetNetPositionGameConfigResp {
	
	private Boolean npr;
	
	public GetNetPositionGameConfigResp() {
	}

	private GetNetPositionGameConfigResp(Builder builder) {
		this.npr = builder.npr;
	}

	public Boolean getNpr() {
		return npr;
	}

	public static class Builder {
		private Boolean npr;

		public Builder npr(Boolean npr) {
			this.npr = npr;
			return this;
		}

		public Builder defaults() {
			this.npr = true;
			return this;
		}

		public GetNetPositionGameConfigResp build() {
			return new GetNetPositionGameConfigResp(this);
		}
	}
}
