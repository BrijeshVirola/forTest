package tests.italyservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetBet365GamesTransactionByIdResp {
	private String id = null;
	private Map<String, Object> result = new HashMap<>();

	public GetBet365GamesTransactionByIdResp() {
	}

	public String getId() {
		return id;
	}

	public Map<String, Object> getResult() {
		return result;
	}

	private GetBet365GamesTransactionByIdResp(Builder builder) {
		this.id = builder.id;
		this.result.put("transaction_type_id", builder.transaction_type_id);
		this.result.put("user_id", builder.user_id);
		this.result.put("total_amount", builder.total_amount);
		this.result.put("withdrawable_amount", builder.withdrawable_amount);
		this.result.put("games_bonus_amount", builder.games_bonus_amount);
		this.result.put("non_withdrawable_amount", builder.non_withdrawable_amount);
	}
	
	public int getUserId() {
		Double userId = new Double(this.result.get("user_id").toString());
		return userId.intValue();
	}
	
	public int getTransactionTypeId() {
		Double transactionTypeId = new Double(this.result.get("transaction_type_id").toString());
		return transactionTypeId.intValue();
	}
	
	public String getWithdrowableAmount() {
		return this.result.get("withdrawable_amount").toString();
	}
	
	public String getNonWithdrowableAmount() {
		return this.result.get("non_withdrawable_amount").toString();
	}
	
	public String getGamesBonusAmount() {
		return this.result.get("games_bonus_amount").toString();
	}
	
	public String getTotalAmount() {
		return this.result.get("total_amount").toString();
	}
	
	public static class Builder {
		private String id;
		private String withdrawable_amount;
		private String non_withdrawable_amount;
		private String games_bonus_amount;
		private String total_amount;
		private Integer user_id;
		private Integer transaction_type_id;


		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder withdrowableAmount(String withdrawable_amount) {
			this.withdrawable_amount = withdrawable_amount;
			return this;
		}

		public Builder nonWithdrowableAmount(String non_withdrawable_amount) {
			this.non_withdrawable_amount = non_withdrawable_amount;
			return this;
		}

		public Builder gamesBonusAmount(String games_bonus_amount) {
			this.games_bonus_amount = games_bonus_amount;
			return this;
		}
		
		public Builder totalAmount(String total_amount) {
			this.total_amount = total_amount;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder transactionTypeId(Integer transaction_type_id) {
			this.transaction_type_id = transaction_type_id;
			return this;
		}

		public Builder defaults() {
			this.id = null;
			this.transaction_type_id = 98;
			this.user_id = 4794514;
			this.total_amount = "1.82";
			this.withdrawable_amount = "1.82";
			this.games_bonus_amount = "0";
			this.non_withdrawable_amount = "0";

			return this;
		}

		public GetBet365GamesTransactionByIdResp build() {
			return new GetBet365GamesTransactionByIdResp(this);
		}	
	}
	
}
