package tests.italyservice.enums;

import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.italyservice.response.GetBet365GamesTransactionByIdResp;

public enum ItalyEndpoints implements ResponseEndpoints{
	
	getBet365GamesTransactionByIdSuccess(GetBet365GamesTransactionByIdResp.class, "GetBet365GamesTransactionById"),
	getBet365GamesTransactionByIdError(CustomErrorResponse.class, "GetBet365GamesTransactionById");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> ItalyEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}	
}
