package tests.italyservice.request;

import java.util.HashMap;
import java.util.Map;


public class GetBet365GamesTransactionByIdReq {
	
	@SuppressWarnings("unused")
	private String method;	
	
	private Map<String, Object> params = new HashMap<>();

	private GetBet365GamesTransactionByIdReq(Builder builder) {
		this.method = builder.method;
		this.params.put("bet365_games_transaction_id", builder.bet365_games_transaction_id);
	}
	
	public static class Builder {
		private String method;
		private Integer bet365_games_transaction_id;

		public Builder bet365GamesTransactionId(Integer bet365_games_transaction_id) {
			this.bet365_games_transaction_id = bet365_games_transaction_id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder defaults() {
			this.method  = "getbet365gamestransactionbyid";
			this.bet365_games_transaction_id = 1838961;
			return this;
		}

		public GetBet365GamesTransactionByIdReq build() {
			return new GetBet365GamesTransactionByIdReq(this);
		}
	}	
}
