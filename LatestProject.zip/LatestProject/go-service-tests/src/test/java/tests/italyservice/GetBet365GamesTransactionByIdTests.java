package tests.italyservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.italyservice.enums.ItalyEndpoints;
import tests.italyservice.request.GetBet365GamesTransactionByIdReq;
import tests.italyservice.response.GetBet365GamesTransactionByIdResp;

public class GetBet365GamesTransactionByIdTests extends BaseClassSetup{

	@Test(description = "Make a request to GetBet365GamesTransactionById. Positive scenario.")
	public void getBet365GamesTransactionById_Positive_Scenario(){
		
		GetBet365GamesTransactionByIdReq request = new GetBet365GamesTransactionByIdReq.Builder()
				.defaults()
				.build();
	
		GetBet365GamesTransactionByIdResp actResponse  =  BaseRequest.post(request, ItalyEndpoints.getBet365GamesTransactionByIdSuccess);
		
		GetBet365GamesTransactionByIdResp expResponse =  new GetBet365GamesTransactionByIdResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse, actResponse);		
	}
	
	@Test(description = "Make a request to GetBet365GamesTransactionById. Missing parameter.")
	public void getBet365GamesTransactionById_Missing_Parameter(){
		
		GetBet365GamesTransactionByIdReq request = new GetBet365GamesTransactionByIdReq.Builder()
				.defaults()
				.bet365GamesTransactionId(null)
				.build();
		
		CustomErrorResponse actResponse =  BaseRequest.post(request, ItalyEndpoints.getBet365GamesTransactionByIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(1000)
				.message("Missing or invalid parameter: bet365_games_transaction_id")
				.build();

		assertReflectionEquals(expResponse, actResponse);		
	}
	
	@Test(description = "Make a request to GetBet365GamesTransactionById. Invalid parameter.")
	public void getBet365GamesTransactionById_Invalid_Parameter(){
		
		GetBet365GamesTransactionByIdReq request = new GetBet365GamesTransactionByIdReq.Builder()
				.defaults()
				.bet365GamesTransactionId(999999999)
				.build();
		
		CustomErrorResponse actResponse =  BaseRequest.post(request, ItalyEndpoints.getBet365GamesTransactionByIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(1011)
				.message("IGP transaction not found")
				.build();

		assertReflectionEquals(expResponse, actResponse);		
	}
	
	@Test(description = "Make a request to GetBet365GamesTransactionById. Wrong method.")
	public void getBet365GamesTransactionById_Wrong_Method(){
		
		GetBet365GamesTransactionByIdReq request = new GetBet365GamesTransactionByIdReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();
		
		CustomErrorResponse actResponse =  BaseRequest.post(request, ItalyEndpoints.getBet365GamesTransactionByIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.build();

		assertReflectionEquals(expResponse, actResponse);		
	}
}
