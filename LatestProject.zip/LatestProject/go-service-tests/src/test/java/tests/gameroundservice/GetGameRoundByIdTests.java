package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import domain.BaseRequest;
import tests.gameroundservice.enums.GameRoundEndpoints;
import tests.gameroundservice.request.CreateGameRoundReq;
import tests.gameroundservice.request.GetGameRoundByIdReq;
import tests.gameroundservice.response.CreateGameRoundResp;

public class GetGameRoundByIdTests extends BaseClassSetup {

	@Test(description = "Make a request to GetGameRoundById. Positive scenario.")
	public void getGameRoundById_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess); 

		GetGameRoundByIdReq getGameRoundByIdRequest = new GetGameRoundByIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.Id(actualResponse.getResultId())
				.build();

		CreateGameRoundResp getGameRoundByIdActualResponse =  BaseRequest.post(getGameRoundByIdRequest, GameRoundEndpoints.getGameRoundByIdSuccess);

		assertReflectionEquals(actualResponse, getGameRoundByIdActualResponse);
	}

	@Test(description = "Make a request to GetGameRoundById - Range test - id parameter . Negative scenario.")
	public void getGameRoundById_Range_Test_Id_Parameter_Negative_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundByIdReq request = new GetGameRoundByIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.Id(2147483647)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundByIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Game round not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getGameRoundById. Wrong method.")
	public void getGameRoundById_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundByIdReq request = new GetGameRoundByIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();   	

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundByIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getGameRoundById. Missing parameter: id.")
	public void getGameRoundById_Missing_id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundByIdReq request = new GetGameRoundByIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.Id(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundByIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
