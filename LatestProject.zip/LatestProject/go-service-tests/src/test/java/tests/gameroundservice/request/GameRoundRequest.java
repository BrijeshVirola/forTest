package tests.gameroundservice.request;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import common.BaseURI;
import common.TimeUtils;
import common.enumsconstants.ServiceErrors;
import domain.BaseRequest;
import tests.gameroundservice.enums.GameRoundEndpoints;
import tests.gameroundservice.response.GameRoundResp;

public class GameRoundRequest extends BaseRequest {

	public static GameRoundResp createGameRound(int requestedUserId, String requestedPartnerGameRoundId, int requestedPartnerId, int requestedRegulatedGameId, int requestedProviderRegionId, int channelId) {
		assertThatGameRoundDoesNotAlreadyExist(requestedUserId,
				requestedPartnerId,
				requestedProviderRegionId,
				requestedPartnerGameRoundId);

		String currentTime = TimeUtils.getCurrentTimeAsIsoString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.userId(requestedUserId)
				.partnerId(requestedPartnerId)
				.regulatedGameId(requestedRegulatedGameId)
				.providerRegionId(requestedProviderRegionId)
				.partnerGameRoundId(requestedPartnerGameRoundId)
				.channelId(channelId)
				.partnerStartTimestampUtc(currentTime)
				.build();

		GameRoundResp response = BaseRequest.post(request, GameRoundEndpoints.createGameRound, BaseURI.GAME_ROUND_SERVICE);

		return response;
	}

	public static GameRoundResp createGameRound(int requestedUserId, String requestedPartnerGameRoundId, int requestedPartnerId, int requestedRegulatedGameId, int requestedProviderRegionId) {

		int channelId = 0;
		GameRoundResp response = createGameRound(requestedUserId, requestedPartnerGameRoundId, requestedPartnerId, requestedProviderRegionId, requestedRegulatedGameId, channelId);

		return response;
	}

	public static void assertThatGameRoundDoesNotAlreadyExist(int requestedUserId, int requestedPartnerId, int requestedProviderRegionId, String requestedPartnerGameRoundId) {

		GameRoundResp response = getGameRoundByPartnerGameRoundId(requestedUserId, requestedPartnerGameRoundId, requestedPartnerId, requestedProviderRegionId);
		GameRoundResp expResp =  new GameRoundResp(ServiceErrors.GameRound.GAME_ROUND_NOT_FOUND);

		assertReflectionEquals(expResp, response);
	}

	public static GameRoundResp getGameRoundByPartnerGameRoundId(int userId, String partnerGameRoundId, int partnerId, int providerRegionId) {

		GetGameRoundByPartnerGameRoundIdReq request = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.userId(userId)
				.partnerGameRoundId(partnerGameRoundId)
				.partnerId(partnerId)
				.providerRegionId(providerRegionId)
				.build();

		GameRoundResp response = BaseRequest.post(request, GameRoundEndpoints.getGameRoundByPartnerGameRoundId, BaseURI.GAME_ROUND_SERVICE);

		return response;
	}
	
	public static GameRoundResp closeGameRoundBybet365GameRoundId(GameRoundResp gameRoundResp) {
		CloseGameRoundByBet365GameRoundIdReq request = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.userId(gameRoundResp.getResult().getUser_id())
				.bet365GameRoundId(gameRoundResp.getResult().getBet365_game_round_id())
				.partnerEndTimestampTtc(gameRoundResp.getResult().getPartner_end_date())
				.build();
		GameRoundResp response = BaseRequest.post(request, GameRoundEndpoints.closeGameRoundByBet365GameRoundId, BaseURI.GAME_ROUND_SERVICE);

		return response;
	}

}
