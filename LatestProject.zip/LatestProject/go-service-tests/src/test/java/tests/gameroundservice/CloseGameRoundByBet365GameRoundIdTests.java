package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Instant;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.gameroundservice.enums.GameRoundEndpoints;
import tests.gameroundservice.request.CloseGameRoundByBet365GameRoundIdReq;
import tests.gameroundservice.request.CreateGameRoundReq;
import tests.gameroundservice.response.CloseGameRoundByBet365GameRoundIdResp;
import tests.gameroundservice.response.CreateGameRoundResp;

public class CloseGameRoundByBet365GameRoundIdTests extends BaseClassSetup {

	@Test(description = "Make a request to CloseGameRoundByBet365GameRoundId. Positive scenario.")
	public void CloseGameRoundByBet365GameRoundId_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess); 

		String idForRequestCloseGameRoundByBet365GameRoundIdResponseId = UUID.randomUUID().toString();

		CloseGameRoundByBet365GameRoundIdReq CloseGameRoundByBet365GameRoundIdrequest = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestCloseGameRoundByBet365GameRoundIdResponseId)
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partnerEndTimestampTtc(actualResponse.getPartnerEndDate())
				.build();

		CloseGameRoundByBet365GameRoundIdResp closeGameRoundByBet365GameRoundIdActualResponse =  BaseRequest.post(CloseGameRoundByBet365GameRoundIdrequest, GameRoundEndpoints.closeGameRoundByBet365GameRoundIdSuccess);

		CloseGameRoundByBet365GameRoundIdResp expResponse = new CloseGameRoundByBet365GameRoundIdResp.Builder()
				.defaults()
				.globalId(idForRequestCloseGameRoundByBet365GameRoundIdResponseId)
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partneGameRoundId(actualResponse.getPartnerGameRoundId())
				.id(actualResponse.getResultId())
				.startDate(actualResponse.getStartDate())
				.partnerStartDate(actualResponse.getPartnerStartDate())
				.endDate(closeGameRoundByBet365GameRoundIdActualResponse.getEndDate())
				.partnerEndDate(actualResponse.getPartnerEndDate())
				.build();

		assertReflectionEquals(expResponse, closeGameRoundByBet365GameRoundIdActualResponse);
		Assert.assertNotNull(actualResponse.getEndDate());
	}

	@Test(description = "Make a request to CloseGameRoundByBet365GameRoundId - Range Paremeter - closed_reason_id. Positive scenario.", dataProvider = "closedReasonIdSuccess", dataProviderClass = DataProviders.class)
	public void CloseGameRoundByBet365GameRoundId_Closed_Reason_Id_Parameter_Positive_Scenario(Integer closed_reason_id) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess); 

		String idForRequestCloseGameRoundByBet365GameRoundIdResponseId = UUID.randomUUID().toString();

		CloseGameRoundByBet365GameRoundIdReq CloseGameRoundByBet365GameRoundIdrequest = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestCloseGameRoundByBet365GameRoundIdResponseId)
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partnerEndTimestampTtc(actualResponse.getPartnerEndDate())
				.closedReasonId(closed_reason_id)
				.build();

		CloseGameRoundByBet365GameRoundIdResp closeGameRoundByBet365GameRoundIdActualResponse =  BaseRequest.post(CloseGameRoundByBet365GameRoundIdrequest, GameRoundEndpoints.closeGameRoundByBet365GameRoundIdSuccess);

		CloseGameRoundByBet365GameRoundIdResp expResponse = new CloseGameRoundByBet365GameRoundIdResp.Builder()
				.defaults()
				.closedReasonId(closed_reason_id)
				.globalId(idForRequestCloseGameRoundByBet365GameRoundIdResponseId)
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partneGameRoundId(actualResponse.getPartnerGameRoundId())
				.id(actualResponse.getResultId())
				.startDate(actualResponse.getStartDate())
				.partnerStartDate(actualResponse.getPartnerStartDate())
				.endDate(closeGameRoundByBet365GameRoundIdActualResponse.getEndDate())
				.partnerEndDate(actualResponse.getPartnerEndDate())
				.build();

		assertReflectionEquals(expResponse, closeGameRoundByBet365GameRoundIdActualResponse);
		Assert.assertNotNull(actualResponse.getEndDate());
	}

	@Test(description = "Make a request to CloseGameRoundByBet365GameRoundId - Range Paremeter - user_id. Positive scenario.", dataProvider = "closedUserIdSuccess", dataProviderClass = DataProviders.class)
	public void CloseGameRoundByBet365GameRoundId_User_Id_Parameter_Positive_Scenario(Integer user_id) {
		Integer partnerId = 100;
		Integer regulatedGameId = 20;
		Integer providerRegionId = 6403;
		Integer channelId = 0;
		String partnerGameRoundId = UUID.randomUUID().toString();
		String partnerStartTimestampUtc = StringUtils.strip(Instant.now().toString(), "0");

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(user_id)
				.partnerId(partnerId)
				.regulatedGameId(regulatedGameId)
				.providerRegionId(providerRegionId)
				.channelId(channelId)
				.partnerGameRoundId(partnerGameRoundId)
				.partnerStartTimestampUtc(partnerStartTimestampUtc)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess);

		String idForRequestCloseGameRoundByBet365GameRoundIdResponseId = UUID.randomUUID().toString();

		CloseGameRoundByBet365GameRoundIdReq CloseGameRoundByBet365GameRoundIdrequest = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestCloseGameRoundByBet365GameRoundIdResponseId)
				.userId(user_id)
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partnerEndTimestampTtc(actualResponse.getPartnerEndDate())
				.build();

		CloseGameRoundByBet365GameRoundIdResp closeGameRoundByBet365GameRoundIdActualResponse =  BaseRequest.post(CloseGameRoundByBet365GameRoundIdrequest, GameRoundEndpoints.closeGameRoundByBet365GameRoundIdSuccess);

		CloseGameRoundByBet365GameRoundIdResp expResponse = new CloseGameRoundByBet365GameRoundIdResp.Builder()
				.defaults()
				.userId(user_id)
				.globalId(idForRequestCloseGameRoundByBet365GameRoundIdResponseId)
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partneGameRoundId(actualResponse.getPartnerGameRoundId())
				.id(actualResponse.getResultId())
				.startDate(actualResponse.getStartDate())
				.partnerStartDate(actualResponse.getPartnerStartDate())
				.endDate(closeGameRoundByBet365GameRoundIdActualResponse.getEndDate())
				.partnerEndDate(actualResponse.getPartnerEndDate())
				.build();

		assertReflectionEquals(expResponse, closeGameRoundByBet365GameRoundIdActualResponse);
		Assert.assertNotNull(actualResponse.getEndDate());
	}

	@Test(description = "Make a request to CloseGameRoundByBet365GameRoundId - Game round not found. Negative scenario.")
	public void CloseGameRoundByBet365GameRoundId_Game_Round_Not_Found_Parameter_Positive_Scenario() {
		String idForRequestCloseGameRoundByBet365GameRoundIdResponseId = UUID.randomUUID().toString();

		CloseGameRoundByBet365GameRoundIdReq CloseGameRoundByBet365GameRoundIdrequest = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestCloseGameRoundByBet365GameRoundIdResponseId)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(CloseGameRoundByBet365GameRoundIdrequest, GameRoundEndpoints.closeGameRoundByBet365GameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Game round not found")
				.id(idForRequestCloseGameRoundByBet365GameRoundIdResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to CloseGameRoundByBet365GameRoundId. Wrong method.")
	public void closeGameRoundByBet365GameRoundId_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CloseGameRoundByBet365GameRoundIdReq request = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();   	

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.closeGameRoundByBet365GameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to CloseGameRoundByBet365GameRoundId.  Missing parameter: user_id.")
	public void closeGameRoundByBet365GameRoundId_Missing_User_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CloseGameRoundByBet365GameRoundIdReq request = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build();   	

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.closeGameRoundByBet365GameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to CloseGameRoundByBet365GameRoundId. Invalid: user_id.")
	public void closeGameRoundByBet365GameRoundId_Invalid_User_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CloseGameRoundByBet365GameRoundIdReq request = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(99999999)
				.build();   	

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.closeGameRoundByBet365GameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Game round not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to CloseGameRoundByBet365GameRoundId.  Missing parameter: bet365_game_round_id.")
	public void closeGameRoundByBet365GameRoundId_Missing_Bet365_Game_Round_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CloseGameRoundByBet365GameRoundIdReq request = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bet365GameRoundId(null)
				.build();   	

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.closeGameRoundByBet365GameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Game round not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to CloseGameRoundByBet365GameRoundId.  Missing parameter: partner_end_timestamp_utc.")
	public void closeGameRoundByBet365GameRoundId_Missing_Partner_End_Timestamp_Utc_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess); 

		String idForRequestCloseGameRoundByBet365GameRoundIdResponseId = UUID.randomUUID().toString();

		CloseGameRoundByBet365GameRoundIdReq CloseGameRoundByBet365GameRoundIdrequest = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestCloseGameRoundByBet365GameRoundIdResponseId)
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partnerEndTimestampTtc(null)
				.build();

		CloseGameRoundByBet365GameRoundIdResp closeGameRoundByBet365GameRoundIdActualResponse =  BaseRequest.post(CloseGameRoundByBet365GameRoundIdrequest, GameRoundEndpoints.closeGameRoundByBet365GameRoundIdSuccess);

		CloseGameRoundByBet365GameRoundIdResp expResponse = new CloseGameRoundByBet365GameRoundIdResp.Builder()
				.defaults()
				.globalId(idForRequestCloseGameRoundByBet365GameRoundIdResponseId)
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partneGameRoundId(actualResponse.getPartnerGameRoundId())
				.id(actualResponse.getResultId())
				.startDate(actualResponse.getStartDate())
				.partnerStartDate(actualResponse.getPartnerStartDate())
				.endDate(closeGameRoundByBet365GameRoundIdActualResponse.getEndDate())
				.partnerEndDate(actualResponse.getPartnerEndDate())
				.build();

		assertReflectionEquals(expResponse, closeGameRoundByBet365GameRoundIdActualResponse);

		Assert.assertNotNull(actualResponse.getEndDate());		
	}

	@Test(description = "Make a request to CloseGameRoundByBet365GameRoundId.  Missing parameter: closed_reason_id.")
	public void closeGameRoundByBet365GameRoundId_Missing_Closed_Reason_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CloseGameRoundByBet365GameRoundIdReq request = new CloseGameRoundByBet365GameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.closedReasonId(null)
				.build();   	

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.closeGameRoundByBet365GameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: closed_reason_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
