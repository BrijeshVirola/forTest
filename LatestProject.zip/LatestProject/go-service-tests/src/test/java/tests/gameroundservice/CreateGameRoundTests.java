package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.time.Instant;
import java.util.UUID;
import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import junit.framework.Assert;
import tests.gameroundservice.enums.GameRoundEndpoints;
import tests.gameroundservice.request.CreateGameRoundReq;
import tests.gameroundservice.response.CreateGameRoundResp;

public class CreateGameRoundTests extends BaseClassSetup  {

	private Integer userId = 1000179041;
	private Integer partnerId = 12;
	private Integer regulatedGameId = 11;
	private Integer providerRegionId = 6403;
	private Integer channelId = 1;
	private String partnerGameRoundId = UUID.randomUUID().toString();
	private String partnerStartTimestampUtc = StringUtils.strip(Instant.now().toString(), "0");

	@Test(description = "Make a request to CreateGameRound. Positive scenario.")
	public void CreateGameRound_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		//1. Create new game round
		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(userId)
				.partnerId(partnerId)
				.regulatedGameId(regulatedGameId)
				.providerRegionId(providerRegionId)
				.partnerGameRoundId(partnerGameRoundId)
				.partnerStartTimestampUtc(partnerStartTimestampUtc)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess);

		// 3. Prepare the expected response object in order to validate the actual response
		CreateGameRoundResp expResponse = new CreateGameRoundResp.Builder()
				.defaults()
				.globalId(idForRequestToBeEchoedBackInResponseId)
				.id(actualResponse.getResultId())
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partneGameRoundId(partnerGameRoundId)
				.partnerId(partnerId)
				.userId(userId)
				.providerRegionId(providerRegionId)
				.regulatedGameId(regulatedGameId)
				.startDate(actualResponse.getStartDate())
				.partnerStartDate(StringUtils.stripEnd(StringUtils.chop(partnerStartTimestampUtc), "0") + "Z")
				.endDate("0001-01-01T00:00:00Z")
				.partnerEndDate("0001-01-01T00:00:00Z")
				.build();

		// 3. Validate the response of the CreateGameRound
		assertReflectionEquals(expResponse, actualResponse);
		Assert.assertNotNull(actualResponse.getStartDate());
		Assert.assertNotNull(actualResponse.getBet365GameRoundId());
		Assert.assertNotNull(actualResponse.getResultId());
	}

	@Test(description = "Make a request to CreateGameRound - Range Parameter - user_id. Positive scenario.", dataProvider = "createGameRoundUseridSuccess", dataProviderClass = DataProviders.class)
	public void CreateGameRound_Range_Parameter_User_Id_Positive_Scenario(Integer user_id) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(user_id)
				.partnerId(partnerId)
				.regulatedGameId(regulatedGameId)
				.providerRegionId(providerRegionId)
				.channelId(channelId)
				.partnerGameRoundId(partnerGameRoundId)
				.partnerStartTimestampUtc(partnerStartTimestampUtc)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess);

		CreateGameRoundResp expResponse = new CreateGameRoundResp.Builder()
				.defaults()
				.globalId(idForRequestToBeEchoedBackInResponseId)
				.id(actualResponse.getResultId())
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partneGameRoundId(partnerGameRoundId)
				.partnerId(partnerId)
				.userId(user_id)
				.channelId(channelId)
				.providerRegionId(providerRegionId)
				.regulatedGameId(regulatedGameId)
				.startDate(actualResponse.getStartDate())
				.partnerStartDate(StringUtils.stripEnd(StringUtils.chop(partnerStartTimestampUtc), "0") + "Z")
				.endDate("0001-01-01T00:00:00Z")
				.partnerEndDate("0001-01-01T00:00:00Z")
				.build();

		assertReflectionEquals(expResponse, actualResponse);
		Assert.assertNotNull(actualResponse.getStartDate());
		Assert.assertNotNull(actualResponse.getBet365GameRoundId());
		Assert.assertNotNull(actualResponse.getResultId());
	}

	@Test(description = "Make a request to CreateGameRound - Range Parameter - partner_id. Positive scenario.", dataProvider = "createGameRoundPartnerIdSuccess", dataProviderClass = DataProviders.class)
	public void CreateGameRound_Range_Parameter_Partner_Id_Positive_Scenario(Integer partner_id) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(userId)
				.partnerId(partner_id)
				.regulatedGameId(regulatedGameId)
				.providerRegionId(providerRegionId)
				.channelId(channelId)
				.partnerGameRoundId(partnerGameRoundId)
				.partnerStartTimestampUtc(partnerStartTimestampUtc)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess);

		CreateGameRoundResp expResponse = new CreateGameRoundResp.Builder()
				.defaults()
				.globalId(idForRequestToBeEchoedBackInResponseId)
				.id(actualResponse.getResultId())
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partneGameRoundId(partnerGameRoundId)
				.partnerId(partner_id)
				.userId(userId)
				.channelId(channelId)
				.providerRegionId(providerRegionId)
				.regulatedGameId(regulatedGameId)
				.startDate(actualResponse.getStartDate())
				.partnerStartDate(StringUtils.stripEnd(StringUtils.chop(partnerStartTimestampUtc), "0") + "Z")
				.endDate("0001-01-01T00:00:00Z")
				.partnerEndDate("0001-01-01T00:00:00Z")
				.build();

		assertReflectionEquals(expResponse, actualResponse);
		Assert.assertNotNull(actualResponse.getStartDate());
		Assert.assertNotNull(actualResponse.getBet365GameRoundId());
		Assert.assertNotNull(actualResponse.getResultId());
	}

	@Test(description = "Make a request to CreateGameRound - Range Parameter - provider_region_id. Positive scenario.", dataProvider = "createGameRoundProviderRegionIdSuccess", dataProviderClass = DataProviders.class)
	public void CreateGameRound_Range_Parameter_Provider_Region_Id_Positive_Scenario(Integer provider_region_id) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(userId)
				.partnerId(partnerId)
				.regulatedGameId(regulatedGameId)
				.providerRegionId(provider_region_id)
				.channelId(channelId)
				.partnerGameRoundId(partnerGameRoundId)
				.partnerStartTimestampUtc(partnerStartTimestampUtc)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess);

		CreateGameRoundResp expResponse = new CreateGameRoundResp.Builder()
				.defaults()
				.globalId(idForRequestToBeEchoedBackInResponseId)
				.id(actualResponse.getResultId())
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partneGameRoundId(partnerGameRoundId)
				.partnerId(partnerId)
				.userId(userId)
				.channelId(channelId)
				.providerRegionId(provider_region_id)
				.regulatedGameId(regulatedGameId)
				.startDate(actualResponse.getStartDate())
				.partnerStartDate(StringUtils.stripEnd(StringUtils.chop(partnerStartTimestampUtc), "0") + "Z")
				.endDate("0001-01-01T00:00:00Z")
				.partnerEndDate("0001-01-01T00:00:00Z")
				.build();

		assertReflectionEquals(expResponse, actualResponse);
		Assert.assertNotNull(actualResponse.getStartDate());
		Assert.assertNotNull(actualResponse.getBet365GameRoundId());
		Assert.assertNotNull(actualResponse.getResultId());
	}

	@Test(description = "Make a request to CreateGameRound - Optional Parameter - channel_id. Positive scenario.")
	public void CreateGameRound_Optional_Parameter_Channel_Id_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(userId)
				.partnerId(partnerId)
				.channelId(null)
				.regulatedGameId(regulatedGameId)
				.providerRegionId(providerRegionId)
				.partnerGameRoundId(partnerGameRoundId)
				.partnerStartTimestampUtc(partnerStartTimestampUtc)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess);

		CreateGameRoundResp expResponse = new CreateGameRoundResp.Builder()
				.defaults()
				.globalId(idForRequestToBeEchoedBackInResponseId)
				.id(actualResponse.getResultId())
				.bet365GameRoundId(actualResponse.getBet365GameRoundId())
				.partneGameRoundId(partnerGameRoundId)
				.partnerId(partnerId)
				.userId(userId)
				.providerRegionId(providerRegionId)
				.regulatedGameId(regulatedGameId)
				.startDate(actualResponse.getStartDate())
				.partnerStartDate(StringUtils.stripEnd(StringUtils.chop(partnerStartTimestampUtc), "0") + "Z")
				.endDate("0001-01-01T00:00:00Z")
				.partnerEndDate("0001-01-01T00:00:00Z")
				.build();

		assertReflectionEquals(expResponse, actualResponse);
		Assert.assertNotNull(actualResponse.getStartDate());
		Assert.assertNotNull(actualResponse.getBet365GameRoundId());
		Assert.assertNotNull(actualResponse.getResultId());
	}

	@Test(description = "Make a request to CreateGameRound - Out of Range - partner_game_round_id. Positive scenario.")
	public void CreateGameRound_Out_Of_Range_Partner_Game_round_Id_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerGameRoundId("nhzQwkXvtR9JPuzJuYX2JpksZahFDU3FNEfvtatD2zH6vfzA12nWMyn2zt2vq2dgEKw4NvacN7jQPAMdcJLqpPNeFa30hmnDWlaFr")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1001)
				.message("partner_game_round_id should be between 1 and 100 long")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to createGameRound. Wrong method.")
	public void createGameRound_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();   	

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to createGameRound. Missing parameter: user_id.")
	public void createGameRound_Missing_User_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to createGameRound. Missing parameter: partner_id.")
	public void createGameRound_Missing_Partner_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to createGameRound. Missing parameter: regulated_game_id.")
	public void createGameRound_Missing_Regulated_Game_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.regulatedGameId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: regulated_game_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to createGameRound. Missing parameter: provider_region_id.")
	public void createGameRound_Missing_Provided_Region_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerRegionId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: provider_region_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to createGameRound. Missing parameter: partner_game_round_id.")
	public void createGameRound_Missing_Partner_Game_Round_Id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerGameRoundId(null)	
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1001)
				.message("partner_game_round_id should be between 1 and 100 long")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to createGameRound. Missing parameter: partner_start_timestamp_utc.")
	public void createGameRound_Missing_Partner_Start_Timestamp_Utc_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerStartTimestampUtc(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_start_timestamp_utc")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to CreateGameRound - Negative value - channel_id. Negative scenario.")
	public void CreateGameRound_Negative_Channel_Id_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(userId)
				.partnerId(partnerId)
				.channelId(-1)
				.regulatedGameId(regulatedGameId)
				.providerRegionId(providerRegionId)
				.partnerGameRoundId(partnerGameRoundId)
				.partnerStartTimestampUtc(partnerStartTimestampUtc)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("channel_id is invalid")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}
