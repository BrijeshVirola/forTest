package tests.gameroundservice.response;

public class InsertRngDetailsResp {

	public String id;
	public String result;
	
	public InsertRngDetailsResp() {
	}

	public InsertRngDetailsResp(Builder builder) {

		this.id = builder.id;
		this.result = builder.result;
	}
	
	public String getId() {
		return id;
	}
	
	public String getResult() {
		return result;
	}

	public static class Builder {
		
		private String id;
		private String result;

		public Builder getId(String id) {
			this.id = id;
			return this;
		}

		public Builder getResult(String result) {
			this.result = result;
			return this;

		}
		public Builder defaults() {
			this.id = "1";
			this.result = "OK";
			return this;
		}

		public InsertRngDetailsResp build() {
			return new InsertRngDetailsResp (this);
		}
	}

}
