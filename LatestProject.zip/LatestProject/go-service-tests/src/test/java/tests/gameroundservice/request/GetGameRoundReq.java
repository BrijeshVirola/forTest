package tests.gameroundservice.request;


public class GetGameRoundReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Params params;

	private GetGameRoundReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params = new Params(builder);
	}

	public String getBet365GameRoundId() {
		return params.bet365_game_round_id;
	}
	
	public static class Builder {
		private String id;
		private String method;
		private Integer user_id;
		private String bet365_game_round_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder bet365GameRoundId(String bet365_game_round_id) {
			this.bet365_game_round_id = bet365_game_round_id;
			return this;
		}

		public Builder defaults() {
			this.method = "getgameround";
			this.id = "1";
			this.user_id = 100017904;
			this.bet365_game_round_id = "7ba1f588-2861-4955-bedb-5bb505c9dbe8";
			return this;
		}

		public GetGameRoundReq build() {
			return new GetGameRoundReq(this);
		}
	}

	public class Params {
		@SuppressWarnings("unused")
		private Integer user_id;
		@SuppressWarnings("unused")
		private String bet365_game_round_id;

		public Params(Builder builder) {			
			this.user_id = builder.user_id;
			this.bet365_game_round_id = builder.bet365_game_round_id;
		}
	}
}
