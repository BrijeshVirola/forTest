package tests.gameroundservice.request;

import java.time.Instant;
import java.util.UUID;

public class CreateGameRoundReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Params params;

	private CreateGameRoundReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params = new Params(builder);
	}

	public String getPartnerGameRoundId() {
		return params.partner_game_round_id;

	}
	public static class Builder {
		private String method;
		private String id;
		private Integer user_id;
		private Integer partner_id;
		private Integer regulated_game_id;
		private Integer provider_region_id;
		private Integer channel_id;
		private String partner_game_round_id;
		private String partner_start_timestamp_utc;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}
		
		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}
		
		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}
		
		public Builder channelId(Integer channel_id) {
			this.channel_id = channel_id;
			return this;
		}
		
		public Builder partnerGameRoundId(String partner_game_round_id) {
			this.partner_game_round_id = partner_game_round_id;
			return this;
		}

		public Builder partnerStartTimestampUtc(String partner_start_timestamp_utc) {
			this.partner_start_timestamp_utc = partner_start_timestamp_utc;
			return this;
		}
		
		public Builder defaults() {
			this.method = "creategameround";
			this.id = "1";
			this.user_id = 100017904;
			this.partner_id = 100;
			this.regulated_game_id = 20;
			this.provider_region_id = 6403;
			this.channel_id = 0;
			this.partner_game_round_id = UUID.randomUUID().toString();
			this.partner_start_timestamp_utc = Instant.now().toString();
			return this;
		}

		public CreateGameRoundReq build() {
			return new CreateGameRoundReq(this);
		}
	}

	public class Params {
		@SuppressWarnings("unused")
		private Integer user_id;
		@SuppressWarnings("unused")
		private Integer partner_id;
		@SuppressWarnings("unused")
		private Integer regulated_game_id;
		@SuppressWarnings("unused")
		private Integer provider_region_id;
		@SuppressWarnings("unused")
		private Integer channel_id;
		@SuppressWarnings("unused")
		private String partner_game_round_id;
		@SuppressWarnings("unused")
		private String partner_start_timestamp_utc;
		
		public Params(Builder builder) {	
			this.user_id = builder.user_id;
			this.partner_id = builder.partner_id;
			this.regulated_game_id = builder.regulated_game_id;
			this.provider_region_id = builder.provider_region_id;
			this.channel_id = builder.channel_id;
			this.partner_game_round_id = builder.partner_game_round_id;
			this.partner_start_timestamp_utc = builder.partner_start_timestamp_utc;		
		}
	}
}
