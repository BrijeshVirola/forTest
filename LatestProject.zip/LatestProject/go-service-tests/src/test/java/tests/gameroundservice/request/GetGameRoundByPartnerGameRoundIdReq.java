package tests.gameroundservice.request;

public class GetGameRoundByPartnerGameRoundIdReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Params params;

	private GetGameRoundByPartnerGameRoundIdReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params = new Params(builder);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer user_id;
		private String partner_game_round_id;
		private Integer partner_id;
		private Integer provider_region_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder partnerGameRoundId(String partner_game_round_id) {
			this.partner_game_round_id = partner_game_round_id;
			return this;
		}

		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}

		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}
		
		public Builder defaults() {
			this.method = "getgameroundbypartnergameroundid";
			this.id = "1";
			this.user_id = 100017904;
			this.partner_game_round_id = "0f36b17f-d60c-4629-be40-a4294767c3fb";
			this.partner_id = 100;
			this.provider_region_id = 6403;
			return this;
		}

		public GetGameRoundByPartnerGameRoundIdReq build() {
			return new GetGameRoundByPartnerGameRoundIdReq(this);
		}
	}

	public class Params {
		@SuppressWarnings("unused")
		private Integer user_id;
		@SuppressWarnings("unused")
		private String partner_game_round_id;
		@SuppressWarnings("unused")
		private Integer partner_id;
		@SuppressWarnings("unused")
		private Integer provider_region_id;
		
		public Params(Builder builder) {	
			this.user_id = builder.user_id;
			this.partner_game_round_id = builder.partner_game_round_id;
			this.partner_id = builder.partner_id;
			this.provider_region_id = builder.provider_region_id;
		}
	}


}
