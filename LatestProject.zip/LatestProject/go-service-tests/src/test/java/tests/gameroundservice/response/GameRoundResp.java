package tests.gameroundservice.response;

import common.enumsconstants.Errors; 
import domain.ErrorResponse;

public class GameRoundResp extends ErrorResponse {
	
	private String id = "1";
	private GameRoundResult result;
		
	public GameRoundResp() {
	}
	
	public GameRoundResp(Errors error) {
		super(error);
	}
	
	public String getId() {
		return id;
	}
	
	public GameRoundResult getResult() {
		return result;
	}
	
	/**
	 * Make end dates and closed reason same as the closed game round response.
	 * This will be used when asserting that both both responses for created game round and closed game round are equal.
	 * Only Partner end date, end date and closed reason id are different initially.
	 * @param closeGameRoundResp
	 */
	public void setEndDateAndCloseReason(GameRoundResp closeGameRoundResp) {
		getResult().setPartner_end_date(closeGameRoundResp.getResult().getPartner_end_date());
		getResult().setEnd_date(closeGameRoundResp.getResult().getEnd_date());
		getResult().setClosed_reason_id(closeGameRoundResp.getResult().getClosed_reason_id());
	}

	public class GameRoundResult {
		
		private int id, partner_id, user_id, channel_id, provider_region_id, regulated_game_id, closed_reason_id;
		private String bet365_game_round_id, partner_game_round_id, start_date, partner_start_date, end_date, partner_end_date;

		public int getId() {
			return id;
		}
		public int getPartner_id() {
			return partner_id;
		}
		public int getUser_id() {
			return user_id;
		}
		public int getChannel_id() {
			return channel_id;
		}
		public int getProvider_region_id() {
			return provider_region_id;
		}
		public int getRegulated_game_id() {
			return regulated_game_id;
		}
		public int getClosed_reason_id() {
			return closed_reason_id;
		}
		public void setClosed_reason_id(int closedReasonId) {
			this.closed_reason_id = closedReasonId;
		}
		public String getBet365_game_round_id() {
			return bet365_game_round_id;
		}
		public String getPartner_game_round_id() {
			return partner_game_round_id;
		}
		public String getStart_date() {
			return start_date;
		}
		public String getPartner_start_date() {
			return partner_start_date;
		}
		public String getEnd_date() {
			return end_date;
		}
		public void setEnd_date(String endDate) {
			this.end_date = endDate;
		}
		public String getPartner_end_date() {
			return partner_end_date;
		}
		public void setPartner_end_date(String partnerEndDate) {
			this.partner_end_date = partnerEndDate;
		}
	}
}
