package tests.gameroundservice.request;

public class GetGameRoundByIdReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Params params;


	private GetGameRoundByIdReq(Builder builder) {
		this.method = builder.method;
		this.id = builder.id;
        this.params = new Params(builder);
	}

	public static class Builder {

		private String method;
		private String id;
		private Integer Id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder Id(Integer Id) {
			this.Id = Id;
			return this;
		}
		public Builder defaults() {
			this.method = "getgameroundbyid";
			this.id = "1";	
			this.Id = 100;
			return this;
		}

		public GetGameRoundByIdReq build() {
			return new GetGameRoundByIdReq(this);
		}
	}

	public class Params{
		@SuppressWarnings("unused")
		private Integer Id;
		
		public Params(Builder builder) {
			this.Id = builder.Id;
		}
	}
}
