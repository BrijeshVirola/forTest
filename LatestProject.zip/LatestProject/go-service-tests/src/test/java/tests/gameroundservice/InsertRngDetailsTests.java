package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.gameroundservice.enums.GameRoundEndpoints;
import tests.gameroundservice.request.InsertRngDetailsReq;
import tests.gameroundservice.response.InsertRngDetailsResp;

public class InsertRngDetailsTests extends BaseClassSetup {

	@Test(description = "Make a request to InsertRngDetails. Positive scenario.")
	public void insertRngDetails_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		InsertRngDetailsReq request = new InsertRngDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		InsertRngDetailsResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.insertRngDetailsSuccess);

		InsertRngDetailsResp expResponse = new InsertRngDetailsResp.Builder()
				.defaults()
				.getId(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to InsertRngDetails game round id parameter. Positive scenario.", dataProvider = "gameroundidSuccess", dataProviderClass = DataProviders.class)
	public void insertRngDetails_game_round_id_Positive_Scenario(Long game_round_id) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		InsertRngDetailsReq request = new InsertRngDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.gameRoundId(game_round_id)
				.build();

		InsertRngDetailsResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.insertRngDetailsSuccess);

		InsertRngDetailsResp expResponse = new InsertRngDetailsResp.Builder()
				.defaults()
				.getId(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to InsertRngDetails - Range parameter - rng_id. Positive scenario.", dataProvider = "gameRngIdSuccess", dataProviderClass = DataProviders.class)
	public void insertRngDetails_Rng_id_Positive_Scenario(String rng_id) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		InsertRngDetailsReq request = new InsertRngDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.rngId(rng_id)
				.build();

		InsertRngDetailsResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.insertRngDetailsSuccess);

		InsertRngDetailsResp expResponse = new InsertRngDetailsResp.Builder()
				.defaults()
				.getId(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to InsertRngDetails - Range parameter - software_id. Positive scenario.", dataProvider = "softwareIdSuccess", dataProviderClass = DataProviders.class)
	public void insertRngDetails_Software_id_Positive_Scenario(String software_id) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		InsertRngDetailsReq request = new InsertRngDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.softwareId(software_id)
				.build();

		InsertRngDetailsResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.insertRngDetailsSuccess);

		InsertRngDetailsResp expResponse = new InsertRngDetailsResp.Builder()
				.defaults()
				.getId(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expResponse, actualResponse);
	}

	@Test(description = "Make a request to InsertRngDetails - Out of Range parameter - rng_id. Negative scenario.")
	public void insertRngDetails_Out_Of_Range_Rng_id_Negative_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		InsertRngDetailsReq request = new InsertRngDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.rngId("qrSX2@woy&NRCdsANONKeF8U8bRbHMp=FbyVKf4BP3QZ8MbVk4A")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.insertRngDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1008)
				.message("Invalid parameter value: rng_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to InsertRngDetails - Out of Range parameter - software_id. Negative scenario.")
	public void insertRngDetails_Out_Of_Range_Software_id_Negative_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		InsertRngDetailsReq request = new InsertRngDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.softwareId("qrSX2@woy&NRCdsANONKeF8U8bRbHMp=FbyVKf4BP3QZ8MbVk4A")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.insertRngDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1008)
				.message("Invalid parameter value: software_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to InsertRngDetails. Wrong method.")
	public void insertRgnDetails_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		InsertRngDetailsReq request = new InsertRngDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();   	

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.insertRngDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to InsertRngDetails. Missing parameter: game_round_id.")
	public void insertRngDetails_Missing_game_round_id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		InsertRngDetailsReq request = new InsertRngDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.gameRoundId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.insertRngDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: game_round_id")
			.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to InsertRngDetails. Missing parameter: rng_id.")
	public void insertRngDetails_Missing_rng_id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		InsertRngDetailsReq request = new InsertRngDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.rngId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.insertRngDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: rng_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to InsertRngDetails. Missing parameter: software_id.")
	public void insertRngDetails_Missing_software_id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		InsertRngDetailsReq request = new InsertRngDetailsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.softwareId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.insertRngDetailsError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: software_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
