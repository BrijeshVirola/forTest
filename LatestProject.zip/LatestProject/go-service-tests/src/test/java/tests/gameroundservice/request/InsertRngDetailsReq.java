package tests.gameroundservice.request;

public class InsertRngDetailsReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Params params;

	private InsertRngDetailsReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params = new Params(builder);
	}

	public static class Builder {
		private String id;
		private String method;
		private Long game_round_id;
		private String rng_id;
		private String software_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder gameRoundId(Long game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}

		public Builder rngId(String rng_id) {
			this.rng_id = rng_id;
			return this;
		}

		public Builder softwareId(String software_id) {
			this.software_id = software_id;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.method = "insertrngdetails";
			this.game_round_id = 100017904L;
			this.rng_id = "RNG ID";
			this.software_id = "RNG Software ID";
			return this;
		}

		public InsertRngDetailsReq build() {
			return new InsertRngDetailsReq(this);
		}
	}

	public class Params {
		@SuppressWarnings("unused")
		private Long game_round_id;
		@SuppressWarnings("unused")
		private String rng_id;
		@SuppressWarnings("unused")
		private String software_id;


		public Params(Builder builder) {			
			this.game_round_id = builder.game_round_id;
			this.rng_id = builder.rng_id;
			this.software_id = builder.software_id;
		}
	}
}
