package tests.gameroundservice.response;

public class CreateGameRoundResp {
	
	private String id;
	private Result result;

	public CreateGameRoundResp() {
	}
	
	private CreateGameRoundResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public String getId() {
		return id;
	}
	
	public Result getResult() {
		return result;
	}

	public Integer getResultId() {
		return result.id;
	}
	
	public Integer getUserId() {
		return result.user_id;
	}
	
	public Integer getClosedReasonId() {
		return result.closed_reason_id;
	}
	public String getStartDate() {
		return result.start_date;
	}
	
	public String getPartnerStartDate() {
		return result.partner_start_date;
	}
	
	public String getPartnerGameRoundId() {
		return result.partner_game_round_id;
	}
	
	public String getEndDate() {
		return result.end_date;
	}
	
	public String getPartnerEndDate() {
		return result.partner_end_date;
	}
	
	public String getBet365GameRoundId() {
		return result.bet365_game_round_id;

	}

	
	public static class Builder {
		private String id;
		private Integer Id;
        private String bet365_game_round_id;
		private String partner_game_round_id;
		private Integer partner_id;
		private Integer user_id;
		private Integer channel_id;
		private Integer provider_region_id;
		private Integer regulated_game_id;
		private Integer closed_reason_id;
		private String start_date;
		private String partner_start_date;
		private String end_date;
		private String partner_end_date;

		public Builder id(Integer Id) {
			this.Id = Id;
			return this;
		}

		public Builder globalId(String id) {
			this.id = id;
			return this;
		}

		public Builder bet365GameRoundId(String bet365_game_round_id) {
			this.bet365_game_round_id = bet365_game_round_id;
			return this;
		}

		public Builder partneGameRoundId(String partner_game_round_id) {
			this.partner_game_round_id = partner_game_round_id;
			return this;
		}
		
		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder channelId(Integer channel_id) {
			this.channel_id = channel_id;
			return this;
		}
		
		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}
		
		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}
		
		public Builder closedReasonId(Integer closed_reason_id) {
			this.closed_reason_id = closed_reason_id;
			return this;
		}
		
		public Builder startDate(String start_date) {
			this.start_date = start_date;
			return this;
		}
		
		public Builder partnerStartDate(String partner_start_date) {
			this.partner_start_date = partner_start_date;
			return this;
		}
		
		public Builder endDate(String end_date) {
			this.end_date = end_date;
			return this;
		}
		
		public Builder partnerEndDate(String partner_end_date) {
			this.partner_end_date = partner_end_date;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.Id = 716495;
			this.bet365_game_round_id = "";
			this.partner_game_round_id = "";
			this.partner_id = 12;
			this.user_id = 1000179041;
			this.channel_id = 0;
			this.provider_region_id = 6403;
			this.regulated_game_id = 11;
			this.closed_reason_id = 0;
			this.start_date = "";
			this.partner_start_date = "";
			this.end_date = "";
			this.partner_end_date = "";
			return this;
		}
		
		public CreateGameRoundResp build() {
			return new CreateGameRoundResp(this);
		}		
	}

	private class Result {

		private Integer id;
		private String bet365_game_round_id;
		private String partner_game_round_id;
		private Integer partner_id;
		private Integer user_id;
		private Integer channel_id;
		private Integer provider_region_id;
		private Integer regulated_game_id;
		private Integer closed_reason_id;
		public String start_date;
		private String partner_start_date;
		private String end_date;
		private String partner_end_date;

		@SuppressWarnings("unused")
		public Result() {
		}
		
		public Result(Builder builder) {

			this.id = builder.Id;
			this.bet365_game_round_id = builder.bet365_game_round_id;
			this.partner_game_round_id = builder.partner_game_round_id;
			this.partner_id = builder.partner_id;
			this.user_id = builder.user_id;
			this.channel_id = builder.channel_id;
			this.provider_region_id = builder.provider_region_id;
			this.regulated_game_id = builder.regulated_game_id;
			this.closed_reason_id = builder.closed_reason_id;
			this.start_date = builder.start_date;
			this.partner_start_date = builder.partner_start_date;
			this.end_date = builder.end_date;
			this.partner_end_date = builder.partner_end_date;						
		}
		
		@SuppressWarnings("unused")
		public Integer getId() {
			return id;
		}

		@SuppressWarnings("unused")
		public String getBet365_game_round_id() {
			return bet365_game_round_id;
		}

		@SuppressWarnings("unused")
		public String getPartner_game_round_id() {
			return partner_game_round_id;
		}

		@SuppressWarnings("unused")
		public Integer getPartner_id() {
			return partner_id;
		}

		@SuppressWarnings("unused")
		public Integer getUser_id() {
			return user_id;
		}

		@SuppressWarnings("unused")
		public Integer getChannel_id() {
			return channel_id;
		}

		@SuppressWarnings("unused")
		public Integer getProvider_region_id() {
			return provider_region_id;
		}

		@SuppressWarnings("unused")
		public Integer getRegulated_game_id() {
			return regulated_game_id;
		}

		@SuppressWarnings("unused")
		public Integer getClosed_reason_id() {
			return closed_reason_id;
		}

		@SuppressWarnings("unused")
		public String getStart_date() {
			return start_date;
		}

		@SuppressWarnings("unused")
		public String getPartner_start_date() {
			return partner_start_date;
		}

		@SuppressWarnings("unused")
		public String getEnd_date() {
			return end_date;
		}

		@SuppressWarnings("unused")
		public String getPartner_end_date() {
			return partner_end_date;
		}

	}	
}
