package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.gameroundservice.enums.GameRoundEndpoints;
import tests.gameroundservice.request.CreateGameRoundReq;
import tests.gameroundservice.request.GetGameRoundByPartnerGameRoundIdReq;
import tests.gameroundservice.response.CreateGameRoundResp;

public class GetGameRoundByPartnerGameRoundIdTests extends BaseClassSetup {

	@Test(description = "Make a request to GetGameRoundByPartnerGameRoundId. Positive scenario.")
	public void getGameRoundByPartnerGameRoundId_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess); 

		GetGameRoundByPartnerGameRoundIdReq getGameRoundByPartnerRoundIdRequest = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerGameRoundId(actualResponse.getPartnerGameRoundId())
				.build();

		CreateGameRoundResp getGameRoundByPartnerRoundIdActualResponse =  BaseRequest.post(getGameRoundByPartnerRoundIdRequest, GameRoundEndpoints.getGameRoundByPartnerGameRoundIdSuccess);

		assertReflectionEquals(actualResponse, getGameRoundByPartnerRoundIdActualResponse);
	}

	@Test(description = "Make a request to GetGameRoundByPartnerGameRoundId - Range Parameter - user_id. Positive scenario.", dataProvider = "createGameRoundUseridSuccess", dataProviderClass = DataProviders.class)
	public void getGameRoundByPartnerGameRoundId_Range_Parameter_User_Id_Positive_Scenario(Integer user_id) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(user_id)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess); 

		GetGameRoundByPartnerGameRoundIdReq getGameRoundByPartnerRoundIdRequest = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerGameRoundId(actualResponse.getPartnerGameRoundId())
				.userId(user_id)
				.build();

		CreateGameRoundResp getGameRoundByPartnerRoundIdActualResponse =  BaseRequest.post(getGameRoundByPartnerRoundIdRequest, GameRoundEndpoints.getGameRoundByPartnerGameRoundIdSuccess);

		assertReflectionEquals(actualResponse, getGameRoundByPartnerRoundIdActualResponse);
	}

	@Test(description = "Make a request to GetGameRoundByPartnerGameRoundId - Range Parameter - partner_id. Positive scenario.", dataProvider = "createGameRoundPartnerIdSuccess", dataProviderClass = DataProviders.class)
	public void getGameRoundByPartnerGameRoundId_Range_Parameter_Partner_Id_Positive_Scenario(Integer partner_id) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerId(partner_id)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess); 

		GetGameRoundByPartnerGameRoundIdReq getGameRoundByPartnerRoundIdRequest = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerGameRoundId(actualResponse.getPartnerGameRoundId())
				.partnerId(partner_id)
				.build();

		CreateGameRoundResp getGameRoundByPartnerRoundIdActualResponse =  BaseRequest.post(getGameRoundByPartnerRoundIdRequest, GameRoundEndpoints.getGameRoundByPartnerGameRoundIdSuccess);

		assertReflectionEquals(actualResponse, getGameRoundByPartnerRoundIdActualResponse);
	}

	@Test(description = "Make a request to GetGameRoundByPartnerGameRoundId - Range Parameter - provider_region_id. Positive scenario.", dataProvider = "createGameRoundProviderRegionIdSuccess", dataProviderClass = DataProviders.class)
	public void getGameRoundByPartnerGameRoundId_Range_Parameter_Provider_Region_Id_Positive_Scenario(Integer provider_region_id) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CreateGameRoundReq request = new CreateGameRoundReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerRegionId(provider_region_id)
				.build();

		CreateGameRoundResp actualResponse =  BaseRequest.post(request, GameRoundEndpoints.createGameRoundSuccess); 

		GetGameRoundByPartnerGameRoundIdReq getGameRoundByPartnerRoundIdRequest = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerGameRoundId(actualResponse.getPartnerGameRoundId())
				.providerRegionId(provider_region_id)
				.build();

		CreateGameRoundResp getGameRoundByPartnerRoundIdActualResponse =  BaseRequest.post(getGameRoundByPartnerRoundIdRequest, GameRoundEndpoints.getGameRoundByPartnerGameRoundIdSuccess);

		assertReflectionEquals(actualResponse, getGameRoundByPartnerRoundIdActualResponse);
	}

	@Test(description = "Make a request to GetGameRoundByPartnerGameRoundId. Wrong method.")
	public void getGameRoundByPartnerGameRoundId_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundByPartnerGameRoundIdReq request = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();   	

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundByPartnerGameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetGameRoundByPartnerGameRoundId. Missing parameter: user_id.")
	public void GetGameRoundByPartnerGameRoundId_Missing_user_id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundByPartnerGameRoundIdReq request = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundByPartnerGameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetGameRoundByPartnerGameRoundId. Invalid user_id.")
	public void GetGameRoundByPartnerGameRoundId_Invalid_user_id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundByPartnerGameRoundIdReq request = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(999999999)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundByPartnerGameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Game round not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetGameRoundByPartnerGameRoundId. Missing parameter: partner_game_round_id.")
	public void GetGameRoundByPartnerGameRoundId_Missing_partner_game_round_id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundByPartnerGameRoundIdReq request = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerGameRoundId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundByPartnerGameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_game_round_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetGameRoundByPartnerGameRoundId. Missing parameter: partner_id.")
	public void GetGameRoundByPartnerGameRoundId_Missing_partner_id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundByPartnerGameRoundIdReq request = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.partnerId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundByPartnerGameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetGameRoundByPartnerGameRoundId. Missing parameter: provider_region_id.")
	public void GetGameRoundByPartnerGameRoundId_Missing_provider_region_id_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetGameRoundByPartnerGameRoundIdReq request = new GetGameRoundByPartnerGameRoundIdReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.providerRegionId(null)
				.build(); 

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameRoundEndpoints.getGameRoundByPartnerGameRoundIdError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: provider_region_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
