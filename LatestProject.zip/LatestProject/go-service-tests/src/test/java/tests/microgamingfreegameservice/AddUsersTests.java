package tests.microgamingfreegameservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import domain.BaseRequest;
import tests.microgamingfreegameservice.enums.MicroGamingFreeGamesEndPoints;
import tests.microgamingfreegameservice.request.PassPromotionId;
import tests.microgamingfreegameservice.response.AddUsersResp;
import tests.microgamingfreegameservice.response.ErrorResponse;

public class AddUsersTests extends BaseClassSetup {

	@Test(description = "Make a request to Add Users to Promotion with valid Promotion Id. Positive scenario.")
	public void AddUsersWithValidPromoId_Positive_Scenario() {

		PassPromotionId request = new PassPromotionId.Builder()
				.defaults()
				.build();

		AddUsersResp actResponse =  BaseRequest.sendGet(request.getParameters(), MicroGamingFreeGamesEndPoints.addusersSuccess);

		AddUsersResp expResponse =  new AddUsersResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse,actResponse);
	}
	
	@Test(description = "Make a request to Add Users to Promotion with invalid Promotion Id.")
	public void AddUsersWithInValidPromoId() {
		
		Long promotionId  = 45898098734L;
	
		PassPromotionId request = new PassPromotionId.Builder()
				.defaults()
				.promotionId(promotionId)
				.build();
		
		ErrorResponse actResponse =  BaseRequest.sendGet(request.getParameters(), MicroGamingFreeGamesEndPoints.addusersError, 500);

		ErrorResponse expResponse =  new ErrorResponse.Builder()
				.defaults()
				.errorMessage(String.format("PromotionId '%d' is invalid", promotionId))
				.build();

		assertReflectionEquals(expResponse,actResponse);
	}
	
	@Test(description = "Make a request to Add Users to Promotion with null Promotion Id.")
	public void AddUsersWithNullPromoId() {
	
		PassPromotionId request = new PassPromotionId.Builder()
				.defaults()
				.promotionId(null)
				.build();
		
		ErrorResponse actResponse =  BaseRequest.sendGet(request.getParameters(), MicroGamingFreeGamesEndPoints.addusersError, 500);		

		ErrorResponse expResponse =  new ErrorResponse.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse,actResponse);
	}


}


