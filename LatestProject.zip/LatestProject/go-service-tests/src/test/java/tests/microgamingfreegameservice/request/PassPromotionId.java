package tests.microgamingfreegameservice.request;

import java.util.HashMap;
import java.util.Map;

public class PassPromotionId {

	private Map<String, Object> parameters = new HashMap<>();

	private PassPromotionId(Builder builder) {
		this.parameters.put("promotionid", builder.promotionid);
	}

	public Map<String, Object> getParameters() {
		return parameters;
	}

	public static class Builder {
		private Long promotionid;


		public Builder promotionId(Long promotionId) {
			this.promotionid = promotionId;
			return this;
		}


		public Builder defaults() {
			this.promotionid = 28752L;
			return this;
		}

		public PassPromotionId build() {
			return new PassPromotionId(this);
		}
	}
}
