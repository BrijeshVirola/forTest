package tests.microgamingfreegameservice.response;


public class GetProgressResp {

	@SuppressWarnings("unused")
	private Integer TotalRecords;
	@SuppressWarnings("unused")
	private Integer TotalProcessed;
	@SuppressWarnings("unused")
	private String LastProcessedDate;
	@SuppressWarnings("unused")
	private String LastError;

	private GetProgressResp(Builder builder) {
		this.TotalRecords = builder.TotalRecords;
		this.TotalProcessed = builder.TotalProcessed;
		this.LastProcessedDate = builder.LastProcessedDate;
		this.LastError = builder.LastError;
	}


	public static class Builder {
		private Integer TotalRecords;
		private Integer TotalProcessed;
		private String LastProcessedDate;
		private String LastError;

		public Builder totalRecords(Integer TotalRecords) {
			this.TotalRecords = TotalRecords;
			return this;
		}

		public Builder totalProcessed(Integer TotalProcessed) {
			this.TotalProcessed = TotalProcessed;
			return this;
		}

		public Builder lastProcessedDate(String LastProcessedDate) {
			this.LastProcessedDate = LastProcessedDate;
			return this;
		}

		public Builder lastError(String LastError) {
			this.LastError = LastError;
			return this;
		}

		public Builder defaults() {
			this.TotalRecords = 1;
			this.TotalProcessed = 1;
			this.LastProcessedDate = "2021-10-27T07:51:02.607+01:00";
			this.LastError = "";
			return this;
		}

		public GetProgressResp build() {
			return new GetProgressResp(this);
		}
	}
}
