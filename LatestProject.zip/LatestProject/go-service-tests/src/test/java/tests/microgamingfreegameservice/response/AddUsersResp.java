package tests.microgamingfreegameservice.response;


public class AddUsersResp {
	
	@SuppressWarnings("unused")
	private String StatusMessage;

	private AddUsersResp(Builder builder) {
		this.StatusMessage = builder.StatusMessage;
	}

	public static class Builder {
		private String StatusMessage;

		public Builder statusMessage(String StatusMessage) {
			this.StatusMessage = StatusMessage;
			return this;
		}

		public Builder defaults() {
			this.StatusMessage = "Request received";
			return this;
		}

		public AddUsersResp build() {
			return new AddUsersResp(this);
		}
	}
}
