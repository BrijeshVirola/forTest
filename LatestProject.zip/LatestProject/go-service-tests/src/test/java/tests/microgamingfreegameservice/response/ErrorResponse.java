package tests.microgamingfreegameservice.response;


public class ErrorResponse {
	
	@SuppressWarnings("unused")
	private String ErrorMessage;

	private ErrorResponse(Builder builder) {
		this.ErrorMessage = builder.ErrorMessage;
	}

	public static class Builder {
		private String ErrorMessage;

		public Builder errorMessage(String ErrorMessage) {
			this.ErrorMessage = ErrorMessage;
			return this;
		}

		public  Builder defaults() {
		    this.ErrorMessage = "PromotionId "+"''"+" is invalid";			
			return this;
		}

		public ErrorResponse build() {
			return new ErrorResponse(this);
		}
	}
}
