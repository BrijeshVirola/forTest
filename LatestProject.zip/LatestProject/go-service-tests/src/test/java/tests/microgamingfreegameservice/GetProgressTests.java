package tests.microgamingfreegameservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import domain.BaseRequest;
import tests.microgamingfreegameservice.enums.MicroGamingFreeGamesEndPoints;
import tests.microgamingfreegameservice.request.PassPromotionId;
import tests.microgamingfreegameservice.response.ErrorResponse;
import tests.microgamingfreegameservice.response.GetProgressResp;

public class GetProgressTests extends BaseClassSetup {

	@Test(description = "Make a request to GetProgress to Promotion with valid Promotion Id with users. Positive scenario.")
	public void GetProgressWithValidPromoId_Positive_Scenario() {

		PassPromotionId request = new PassPromotionId.Builder()
				.defaults()
				.promotionId(28746L)
				.build();

		GetProgressResp actResponse =  BaseRequest.sendGet(request.getParameters(), MicroGamingFreeGamesEndPoints.getprogressSuccess);

		GetProgressResp expResponse =  new GetProgressResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse,actResponse);
	}
	
	@Test(description = "Make a request to GetProgress to Promotion with valid Promotion Id without users. Positive scenario.")
	public void GetProgressWithValidPromoId_withoutUsers_Positive_Scenario() {

		PassPromotionId request = new PassPromotionId.Builder()
				.defaults()
				.promotionId(28752L)
				.build();

		GetProgressResp actResponse =  BaseRequest.sendGet(request.getParameters(), MicroGamingFreeGamesEndPoints.getprogressSuccess);

		GetProgressResp expResponse =  new GetProgressResp.Builder()
				.defaults()
				.totalRecords(0)
				.totalProcessed(0)
				.lastProcessedDate("0001-01-01T00:00:00Z")
				.lastError("No users could be found for Promotion")
				.build();

		assertReflectionEquals(expResponse,actResponse);
	}
	
	@Test(description = "Make a request to GetProgress to Promotion with Promo id not exists.")
	public void GetProgressWithPromoIdNotExists() {

		PassPromotionId request = new PassPromotionId.Builder()
				.defaults()
				.promotionId((long) 145627)
				.build();

		GetProgressResp actResponse =  BaseRequest.sendGet(request.getParameters(), MicroGamingFreeGamesEndPoints.getprogressSuccess);

		GetProgressResp expResponse =  new GetProgressResp.Builder()
				.defaults()
				.totalRecords(0)
				.totalProcessed(0)
				.lastProcessedDate("0001-01-01T00:00:00Z")
				.lastError("")
				.build();

		assertReflectionEquals(expResponse,actResponse);
	}
	
	@Test(description = "Make a request to Get Progress to Promotion with invalid Promotion Id.")
	public void GetProgressWithInValidPromoId() {
		
		Long promotionId  = 45898098734L;
	
		PassPromotionId request = new PassPromotionId.Builder()
				.defaults()
				.promotionId(promotionId)
				.build();
		
		ErrorResponse actResponse =  BaseRequest.sendGet(request.getParameters(), MicroGamingFreeGamesEndPoints.getprogressError, 500);

		ErrorResponse expResponse =  new ErrorResponse.Builder()
				.defaults()
				.errorMessage(String.format("PromotionId '%d' is invalid", promotionId))
				.build();

		assertReflectionEquals(expResponse,actResponse);
	}
	
	@Test(description = "Make a request to Get Progress to Promotion with null Promotion Id.")
	public void getProgressWithNullPromoId() {
	
		PassPromotionId request = new PassPromotionId.Builder()
				.defaults()
				.promotionId(null)
				.build();
		
		ErrorResponse actResponse =  BaseRequest.sendGet(request.getParameters(), MicroGamingFreeGamesEndPoints.getprogressError, 500);

		ErrorResponse expResponse =  new ErrorResponse.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse,actResponse);
	}


}


