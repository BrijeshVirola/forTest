package tests.microgamingfreegameservice.enums;

import common.enumsconstants.ResponseEndpoints;
import tests.microgamingfreegameservice.response.AddUsersResp;
import tests.microgamingfreegameservice.response.ErrorResponse;
import tests.microgamingfreegameservice.response.GetProgressResp;

public enum MicroGamingFreeGamesEndPoints implements ResponseEndpoints {

	addusersSuccess(AddUsersResp.class, "addusers"),
	addusersError(ErrorResponse.class, "addusers"),
	getprogressSuccess(GetProgressResp.class, "getprogress"),
	getprogressError(ErrorResponse.class, "getprogress");


	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> MicroGamingFreeGamesEndPoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
