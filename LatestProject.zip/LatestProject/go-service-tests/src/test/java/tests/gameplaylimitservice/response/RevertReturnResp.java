package tests.gameplaylimitservice.response;

public class RevertReturnResp{

		private String id;
		private Result result;

		public RevertReturnResp() {
		}
		
		private RevertReturnResp(Builder builder) {
			this.id = builder.id;	
			result = new Result(builder);
		}

		public String getId() {
			return id;
		}
		
		public Result getResult() {
			return result;
		}
		
		public String getRevertReturnDatetimeUtc() {
			return result.revert_return_datetime_utc;
		}
				
		public static class Builder {
			private String id;
			private String revert_return_datetime_utc;
		
			public Builder id(String id) {
				this.id = id;
				return this;
			}

			public Builder revertReturnDatetimeUtc(String revert_return_datetime_utc) {
				this.revert_return_datetime_utc = revert_return_datetime_utc;
				return this;
			}
			
			public Builder defaults() {
				this.id = "1";
				this.revert_return_datetime_utc = "";
				return this;
			}

			public RevertReturnResp build() {
				return new RevertReturnResp(this);
			}
		}
		
		private class Result {

			@SuppressWarnings("unused")
			public Result() {
			}
			
			String revert_return_datetime_utc;
			
			@SuppressWarnings("unused")
			public String getRevert_return_datetime_utc() {
				return revert_return_datetime_utc;
			}

			public Result(Builder builder) {
				this.revert_return_datetime_utc = builder.revert_return_datetime_utc;

			}
		}
	}

