package tests.gameplaylimitservice.response;

public class ApplyReturnResp{

	private String id;
	private Result result;

	public ApplyReturnResp() {
	}
	
	private ApplyReturnResp(Builder builder) {
		this.id = builder.id;	
		result = new Result(builder);
	}

	public String getId() {
		return id;
	}
	
	public Result getResult() {
		return result;
	}
	
	public String getApplyReturnDatetimeUtc() {
		return result.apply_return_datetime_utc;
	}
		
	public static class Builder {
		private String id;
		private String apply_return_datetime_utc;
	
		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder applyReturnDatetimeUtc(String apply_return_datetime_utc) {
			this.apply_return_datetime_utc = apply_return_datetime_utc;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.apply_return_datetime_utc = "";
			return this;
		}

		public ApplyReturnResp build() {
			return new ApplyReturnResp(this);
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		public Result() {
		}
		
		String apply_return_datetime_utc;
		
		@SuppressWarnings("unused")
		public String getApply_return_datetime_utc() {
			return apply_return_datetime_utc;
		}

		public Result(Builder builder) {
			this.apply_return_datetime_utc = builder.apply_return_datetime_utc;

		}
	}
}