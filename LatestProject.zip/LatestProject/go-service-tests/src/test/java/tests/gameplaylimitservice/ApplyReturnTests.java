package tests.gameplaylimitservice;

import static org.junit.Assert.assertNotNull;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.gameplaylimitservice.enums.GameplayLimitEndpoints;
import tests.gameplaylimitservice.enums.GameplayLimitServiceUsers;
import tests.gameplaylimitservice.request.ApplyReturnReq;
import tests.gameplaylimitservice.request.GetCurrentSummaryReq;
import tests.gameplaylimitservice.requestobjects.PerGroupLimitDetails;
import tests.gameplaylimitservice.response.ApplyReturnResp;
import tests.gameplaylimitservice.response.GetCurrentSummaryResp;
import tests.gameplaylimitservice.responseobjects.GameplaySummary;

public class ApplyReturnTests extends BaseClassSetup {

	@Test(description = "Make a request to ApplyReturn. Positive scenario.")
	public void applyReturn_Positive_Scenario() {
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		//1. Create  per group limit details for GetCurrentSummary request
		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		//2. Send GetCurrentySummary request to obtain user's current summary
		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS1.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.APPLY_RETURN_POS2.getUserId())
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		//3. Store actual response for verification
		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.returnAmount(returnAmount)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS1.getUserId())
				.build();

		ApplyReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnSuccess);

		assertNotNull(actualResponse.getApplyReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		//8. Build the GetCurrentSummary response for a user for validation
		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		//9. Validate GetCurrentSummary response for a user
		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to ApplyReturn - Week Start Day. Positive scenario.", dataProvider = "setWeekStartDaySuccess", dataProviderClass = DataProviders.class)
	public void applyReturn_Week_Start_Day_Range_Parameter_Positive_Scenario(Integer week_start_day){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.weekStartDay(week_start_day)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS3.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.APPLY_RETURN_POS3.getUserId())
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.weekStartDay(week_start_day)
				.returnAmount(returnAmount)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS3.getUserId())
				.build();

		ApplyReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnSuccess);

		assertNotNull(actualResponse.getApplyReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to ApplyReturn - Min Revert Amount - 0.01. Positive scenario.")
	public void applyReturn_Min_Revert_Amount_0_01_Positive_Scenario(){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS4.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.APPLY_RETURN_POS4.getUserId())
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal returnAmount = new BigDecimal(0.01).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.returnAmount(returnAmount)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS4.getUserId())
				.build();

		ApplyReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnSuccess);

		assertNotNull(actualResponse.getApplyReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to ApplyReturn - Local Date Time - Range parameter. Positive scenario.", dataProvider = "localDateTimeSuccess", dataProviderClass = DataProviders.class)
	public void applyReturn_Local_Date_Time_Range_Parameter_Positive_Scenario(Long local_date_utc_offset){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.localDateUtcOffset(local_date_utc_offset)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS5.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.APPLY_RETURN_POS5.getUserId())
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.localDateUtcOffset(local_date_utc_offset)
				.returnAmount(returnAmount)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS5.getUserId())
				.build();

		ApplyReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnSuccess);

		assertNotNull(actualResponse.getApplyReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to ApplyReturn - Max UserId - Range parameter. Positive scenario.", dataProvider = "UserIdSuccess", dataProviderClass = DataProviders.class)
	public void applyReturn_Max_UserId_Range_Parameter_Positive_Scenario(Integer User_Id){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.userId(User_Id)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.addSpendGroupUserIds(GameplayLimitServiceUsers.APPLY_RETURN_POS6.getUserId())
				.userId(User_Id)
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(User_Id)
				.returnAmount(returnAmount)
				.build();

		ApplyReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnSuccess);

		assertNotNull(actualResponse.getApplyReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to ApplyReturn - Local Date UTC Offset - Defaults to 0. Positive scenario.")
	public void applyReturn_Local_Date_UTC_Defaults_0_Positive_Scenario(){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS7.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.APPLY_RETURN_POS7.getUserId())
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.returnAmount(returnAmount)
				.localDateUtcOffset(null)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS7.getUserId())
				.build();

		ApplyReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnSuccess);

		assertNotNull(actualResponse.getApplyReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to ApplyReturn - Week Start Day - Defaults to 0. Positive scenario.")
	public void applyReturn_Week_Start_Day_Defaults_0_Positive_Scenario(){
		String idForGetCurrentSummaryResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq getCurrentSummaryRequest = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS8.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.APPLY_RETURN_POS8.getUserId())
				.build();

		GetCurrentSummaryResp gtCurrentSummaryActualResponse =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = gtCurrentSummaryActualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal returnAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.returnAmount(returnAmount)
				.localDateUtcOffset(null)
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_POS8.getUserId())
				.build();

		ApplyReturnResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnSuccess);

		assertNotNull(actualResponse.getApplyReturnDatetimeUtc());

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(getCurrentSummaryRequest, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).add(returnAmount).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForGetCurrentSummaryResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to ApplyReturn. Missing user_id parameter.")
	public void applyReturn_UserId_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: user_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplyReturn. Missing return_amount parameter.")
	public void applyReturn_Return_Amount_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.returnAmount(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: return_amount must be > 0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplyReturn. return_amount - 0. Negative Scenario")
	public void applyReturn_Return_Amount_0_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.returnAmount(new BigDecimal(0.00))
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: return_amount must be > 0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplyReturn. local_date_utc_offset - Out Of Range. Negative Scenario", dataProvider = "localDateTimeFailure", dataProviderClass = DataProviders.class)
	public void applyReturn_Local_Date_Utc_Offset_Out_Of_Range_Parameter(Long local_date_utc_offset) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.localDateUtcOffset(local_date_utc_offset)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: local_date_utc_offset must be between -86400000000000 and 86400000000000")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplyReturn. Week start day out of range parameter. Negative Scenario", dataProvider = "setWeekStartDayFailure", dataProviderClass = DataProviders.class)
	public void applyReturn_Week_Start_Day_Out_Of_Range_Parameter(Integer week_start_day) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.userId(GameplayLimitServiceUsers.APPLY_RETURN_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.weekStartDay(week_start_day)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: week_start_day must be between 0 and 6")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to ApplyReturn. Wrong method.")
	public void applyReturn_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		ApplyReturnReq request = new ApplyReturnReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.applyReturnError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
