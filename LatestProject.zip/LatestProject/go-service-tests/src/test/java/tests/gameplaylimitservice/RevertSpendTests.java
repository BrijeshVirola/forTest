package tests.gameplaylimitservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import domain.BaseRequest;
import tests.gameplaylimitservice.enums.GameplayLimitEndpoints;
import tests.gameplaylimitservice.enums.GameplayLimitServiceUsers;
import tests.gameplaylimitservice.request.GetCurrentSummaryReq;
import tests.gameplaylimitservice.request.RevertSpendReq;
import tests.gameplaylimitservice.requestobjects.PerGroupLimitDetails;
import tests.gameplaylimitservice.response.GetCurrentSummaryResp;
import tests.gameplaylimitservice.response.RevertSpendResp;
import tests.gameplaylimitservice.responseobjects.GameplaySummary;

public class RevertSpendTests extends BaseClassSetup {

	@Test(description = "Make a request to RevertReturn. Positive scenario.")
	public void RevertReturn_Positive_Scenario() throws InterruptedException {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		//1. Create  per group limit details for GetCurrentSummary request
		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		//2. Send GetCurrentySummary request to obtain user's current summary
		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS1.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.REVERT_SPEND_POS1.getUserId())
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		//3. Store actual response for verification
		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal revertAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idRevertSpendResponseId = UUID.randomUUID().toString();

		//4. Send ApplySpend request to revert spend for a user
		RevertSpendReq requestRevertSpend = new RevertSpendReq.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS1.getUserId())
				.revertAmount(revertAmount)
				.build();

		RevertSpendResp actualResponseRevertSpend =  BaseRequest.post(requestRevertSpend, GameplayLimitEndpoints.revertSpendSuccess);

		//5. Build RevertSpend response 
		RevertSpendResp expResponse = new RevertSpendResp.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.getRevertSpendDatetimeUtc(actualResponseRevertSpend.getRevertSpendDatetimeUtc())
				.build();

		//6. Validate RevertSpend response
		assertReflectionEquals(expResponse, actualResponseRevertSpend);

		//7. Resend GetCurrentSummary request to obtain a user's current summary
		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		//8. Build the GetCurrentSummary response for a user for validation
		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		//9. Validate GetCurrentSummary response for a user
		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);

	}

	@Test(description = "Make a request to RevertSpend. Week Start Day parameter - Positive scenario.", dataProvider = "setWeekStartDaySuccess", dataProviderClass = DataProviders.class)
	public void RevertSpend_Week_Start_Day_Range_Parameter(Integer week_start_day) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.weekStartDay(week_start_day)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS2.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.REVERT_SPEND_POS2.getUserId())
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal revertAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idRevertSpendResponseId = UUID.randomUUID().toString();

		RevertSpendReq requestRevertSpend = new RevertSpendReq.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS2.getUserId())
				.weekStartDay(week_start_day)
				.revertAmount(revertAmount)
				.build();

		RevertSpendResp actualResponseRevertSpend =  BaseRequest.post(requestRevertSpend, GameplayLimitEndpoints.revertSpendSuccess);

		RevertSpendResp expResponse = new RevertSpendResp.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.getRevertSpendDatetimeUtc(actualResponseRevertSpend.getRevertSpendDatetimeUtc())
				.build();

		assertReflectionEquals(expResponse, actualResponseRevertSpend);

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();


		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertSpend. Bucket_type - success range parameter for Per Group Limit Details - Positive Scenario.", dataProvider = "bucketTypeRangeSuccess", dataProviderClass = DataProviders.class)
	public void RevertSpend_Per_Group_Limit_Details_Bucket_Type_range_success_Parameter(String bucket_type) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS3.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.REVERT_SPEND_POS3.getUserId())
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal revertAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idRevertSpendResponseId = UUID.randomUUID().toString();

		RevertSpendReq requestRevertSpend = new RevertSpendReq.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS3.getUserId())
				.revertAmount(revertAmount)
				.build();

		RevertSpendResp actualResponseRevertSpend =  BaseRequest.post(requestRevertSpend, GameplayLimitEndpoints.revertSpendSuccess);

		RevertSpendResp expResponse = new RevertSpendResp.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.getRevertSpendDatetimeUtc(actualResponseRevertSpend.getRevertSpendDatetimeUtc())
				.build();

		assertReflectionEquals(expResponse, actualResponseRevertSpend);

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertSpend. Group_identifier range parameter for Per Group Limit Details - Positive Scenario.", dataProvider = "groupIdentifierSuccess", dataProviderClass = DataProviders.class)
	public void RevertSpend_Per_Group_Limit_Details_group_identifier_range_success_Parameter(String group_identifier) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier(group_identifier)
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS4.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.REVERT_SPEND_POS4.getUserId())
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal revertAmount = new BigDecimal(4.54).setScale(2, RoundingMode.DOWN);

		String idRevertSpendResponseId = UUID.randomUUID().toString();

		RevertSpendReq requestRevertSpend = new RevertSpendReq.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS4.getUserId())
				.revertAmount(revertAmount)
				.build();

		RevertSpendResp actualResponseRevertSpend =  BaseRequest.post(requestRevertSpend, GameplayLimitEndpoints.revertSpendSuccess);

		RevertSpendResp expResponse = new RevertSpendResp.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.getRevertSpendDatetimeUtc(actualResponseRevertSpend.getRevertSpendDatetimeUtc())
				.build();

		assertReflectionEquals(expResponse, actualResponseRevertSpend);

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertSpend - Min Revert Amount - 0.01. Positive scenario.")
	public void RevertSpend_Revert_Amount_0_01_Positive_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS5.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.REVERT_SPEND_POS5.getUserId())
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal revertAmount = new BigDecimal(0.01).setScale(2, RoundingMode.DOWN);

		String idRevertSpendResponseId = UUID.randomUUID().toString();

		RevertSpendReq requestRevertSpend = new RevertSpendReq.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS5.getUserId())
				.revertAmount(revertAmount)
				.build();

		RevertSpendResp actualResponseRevertSpend =  BaseRequest.post(requestRevertSpend, GameplayLimitEndpoints.revertSpendSuccess);

		RevertSpendResp expResponse = new RevertSpendResp.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.getRevertSpendDatetimeUtc(actualResponseRevertSpend.getRevertSpendDatetimeUtc())
				.build();

		assertReflectionEquals(expResponse, actualResponseRevertSpend);

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertSpend. Local Date Time - Range parameter - Positive Scenario.", dataProvider = "localDateTimeSuccess", dataProviderClass = DataProviders.class)
	public void RevertSpend_Local_Date_Utc_Offset_Range_Parameter_positive_scenario(Long local_date_utc_offset) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS6.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.REVERT_SPEND_POS6.getUserId())
				.localDateUtcOffset(local_date_utc_offset)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal revertAmount = new BigDecimal(5.45).setScale(2, RoundingMode.DOWN);

		String idRevertSpendResponseId = UUID.randomUUID().toString();

		RevertSpendReq requestRevertSpend = new RevertSpendReq.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS6.getUserId())
				.revertAmount(revertAmount)
				.localDateUtcOffset(local_date_utc_offset)
				.build();

		RevertSpendResp actualResponseRevertSpend =  BaseRequest.post(requestRevertSpend, GameplayLimitEndpoints.revertSpendSuccess);

		RevertSpendResp expResponse = new RevertSpendResp.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.getRevertSpendDatetimeUtc(actualResponseRevertSpend.getRevertSpendDatetimeUtc())
				.build();

		assertReflectionEquals(expResponse, actualResponseRevertSpend);

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertSpend. Local Date Time - Defaults to O - Positive Scenario.")
	public void RevertSpend_Local_Date_Utc_Offset_Defaults_To_0_positive_scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS7.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.REVERT_SPEND_POS7.getUserId())
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal revertAmount = new BigDecimal(5.45).setScale(2, RoundingMode.DOWN);

		String idRevertSpendResponseId = UUID.randomUUID().toString();

		RevertSpendReq requestRevertSpend = new RevertSpendReq.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS7.getUserId())
				.revertAmount(revertAmount)
				.localDateUtcOffset(null)
				.build();

		RevertSpendResp actualResponseRevertSpend =  BaseRequest.post(requestRevertSpend, GameplayLimitEndpoints.revertSpendSuccess);

		RevertSpendResp expResponse = new RevertSpendResp.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.getRevertSpendDatetimeUtc(actualResponseRevertSpend.getRevertSpendDatetimeUtc())
				.build();

		assertReflectionEquals(expResponse, actualResponseRevertSpend);

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertSpend. Week Start Day - Defaults to O - Positive Scenario.")
	public void RevertSpend_Week_Start_Day_Defaults_To_0_positive_scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS8.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.REVERT_SPEND_POS8.getUserId())
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();
		String getCurrentSummarySessionSpendTotal = actualResponse.getGameplaySummary().get(3).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();
		String getCurrentSummarySessionReturnTotal = actualResponse.getGameplaySummary().get(3).getReturn_total();

		BigDecimal revertAmount = new BigDecimal(5.45).setScale(2, RoundingMode.DOWN);

		String idRevertSpendResponseId = UUID.randomUUID().toString();

		RevertSpendReq requestRevertSpend = new RevertSpendReq.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS8.getUserId())
				.revertAmount(revertAmount)
				.weekStartDay(null)
				.build();

		RevertSpendResp actualResponseRevertSpend =  BaseRequest.post(requestRevertSpend, GameplayLimitEndpoints.revertSpendSuccess);

		RevertSpendResp expResponse = new RevertSpendResp.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.getRevertSpendDatetimeUtc(actualResponseRevertSpend.getRevertSpendDatetimeUtc())
				.build();

		assertReflectionEquals(expResponse, actualResponseRevertSpend);

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal(new BigDecimal(getCurrentSummarySessionSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummarySessionReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.addGameplaySummary(expectedGameplaySummarySession)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertSpend. Per Group Limit Details - Optional Field - Positive Scenario.")
	public void RevertSpend_Per_Group_Limit_Details_Optional_positive_scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS9.getUserId())
				.addSpendGroupUserIds(GameplayLimitServiceUsers.REVERT_SPEND_POS9.getUserId())
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		String getCurrentSummaryDaySpendTotal = actualResponse.getGameplaySummary().get(0).getSpend_total();
		String getCurrentSummaryMonthSpendTotal = actualResponse.getGameplaySummary().get(1).getSpend_total();
		String getCurrentSummaryWeekSpendTotal = actualResponse.getGameplaySummary().get(2).getSpend_total();

		String getCurrentSummaryDayReturnTotal = actualResponse.getGameplaySummary().get(0).getReturn_total();
		String getCurrentSummaryMonthReturnTotal = actualResponse.getGameplaySummary().get(1).getReturn_total();
		String getCurrentSummaryWeekReturnTotal = actualResponse.getGameplaySummary().get(2).getReturn_total();

		BigDecimal revertAmount = new BigDecimal(5.45).setScale(2, RoundingMode.DOWN);

		String idRevertSpendResponseId = UUID.randomUUID().toString();

		RevertSpendReq requestRevertSpend = new RevertSpendReq.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.addPerGroupLimitDetails(null)
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_POS9.getUserId())
				.revertAmount(revertAmount)
				.weekStartDay(null)
				.build();

		RevertSpendResp actualResponseRevertSpend =  BaseRequest.post(requestRevertSpend, GameplayLimitEndpoints.revertSpendSuccess);

		RevertSpendResp expResponse = new RevertSpendResp.Builder()
				.defaults()
				.id(idRevertSpendResponseId)
				.getRevertSpendDatetimeUtc(actualResponseRevertSpend.getRevertSpendDatetimeUtc())
				.build();

		assertReflectionEquals(expResponse, actualResponseRevertSpend);

		GetCurrentSummaryResp actualResponseSecondRequest =  BaseRequest.post(request, GameplayLimitEndpoints.getCurrentSummarySuccess);

		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal(new BigDecimal(getCurrentSummaryDaySpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryDayReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal(new BigDecimal(getCurrentSummaryMonthSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryMonthReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal(new BigDecimal(getCurrentSummaryWeekSpendTotal).subtract(revertAmount).stripTrailingZeros().toPlainString())
				.returnTotal(new BigDecimal(getCurrentSummaryWeekReturnTotal).stripTrailingZeros().toPlainString())
				.build();

		GetCurrentSummaryResp expResponseSecondRequest = new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.currentSummaryDatetimeUtc(actualResponseSecondRequest.getCurrentSummaryDatetimeUtc())
				.addGameplaySummary(expectedGameplaySummaryDay)
				.addGameplaySummary(expectedGameplaySummaryMonth)
				.addGameplaySummary(expectedGameplaySummaryWeek)
				.build();

		assertReflectionEquals(expResponseSecondRequest, actualResponseSecondRequest);
	}

	@Test(description = "Make a request to RevertSpend. Wrong method.")
	public void RevertSpend_Wrong_Method() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertSpend. Missing user_id parameter.")
	public void RevertSpend_UserId_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: user_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertSpend. Missing revert_amount parameter.")
	public void RevertSpend_Revert_Amount_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.revertAmount(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: revert_amount must be > 0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}


	//@ExpectedFailure(jiraRef="PRJSAK-2524", action="test commented. Week Start Day not marked as optional in the requirement - but can't due to PRJSAK-2113")
	//@Test(description = "Make a request to RevertSpend. Missing week_start_day parameter.")
	public void RevertSpend_Week_Start_Day_Missing_Parameter() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.weekStartDay(null)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: ")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertSpend - Revert Amount - 0. Negative scenario.")
	public void RevertSpend_Revert_Amount_0_Negative_Scenario() {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		BigDecimal revertAmount = new BigDecimal(0).setScale(2, RoundingMode.DOWN);

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.revertAmount(revertAmount)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: revert_amount must be > 0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertSpend. Week start day out of range parameter - Negative scenario.", dataProvider = "setWeekStartDayFailure", dataProviderClass = DataProviders.class)
	public void RevertSpend_Week_Start_Day_Out_Of_Range_Parameter(Integer week_start_day) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_NEG.getUserId())
				.weekStartDay(week_start_day)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: week_start_day must be between 0 and 6")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertSpend. Local time out of range - parameter.", dataProvider = "localDateTimeFailure", dataProviderClass = DataProviders.class)
	public void RevertSpend_Local_Date_Utc_Offset_Out_Of_Range_Parameter(Long local_date_utc_offset) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_NEG.getUserId())
				.localDateUtcOffset(local_date_utc_offset)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: local_date_utc_offset must be between -86400000000000 and 86400000000000")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertSpend. Bucket_type out of range - parameter.", dataProvider = "bucketTypeRangeFailure", dataProviderClass = DataProviders.class)
	public void RevertSpend_Bucket_Type_Out_Of_Range_Parameter(String bucket_type) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.bucketType(bucket_type)
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.bucket_type must be between 1 and 20 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertSpend. group_identifier out of range - parameter.", dataProvider = "groupIdentifierFailure", dataProviderClass = DataProviders.class)
	public void RevertSpend_Group_Identifier_Out_Of_Range_Parameter(String group_identifier) {
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier(group_identifier)
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.userId(GameplayLimitServiceUsers.REVERT_SPEND_NEG.getUserId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.post(request, GameplayLimitEndpoints.revertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.group_identifier must be between 1 and 100 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}
