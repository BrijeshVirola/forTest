package tests.gameplaylimitservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.gameplaylimitservice.responseobjects.GameplaySummary;

public class ApplySpendResp {

	private String id;
	private Result result;

	public ApplySpendResp() {
	}
	
	private ApplySpendResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}

	public String getId() {
		return id;
	}
	
	public Result getResult() {
		return result;
	}

	public String getSpendDatetimeUtc() {
		return result.apply_spend_datetime_utc;
	}

	public List<GameplaySummary> getGameplaySummary() {
		return result.gameplay_summary;		
	}

	public static class Builder {
		private String id;
		List<GameplaySummary> gameplay_summary;
		private String apply_spend_datetime_utc;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addGameplaySummary(GameplaySummary gameplaySummary) {
			this.gameplay_summary.add(gameplaySummary);
			return this;
		}

		public Builder applySpendDatetimeUtc(String applySpendDatetimeUtc) {
			this.apply_spend_datetime_utc = applySpendDatetimeUtc;
			return this;
		}

		public Builder defaults() {
			this.id = "Id";
			this.gameplay_summary = new ArrayList<GameplaySummary>();

			return this;
		}

		public ApplySpendResp build() {
			return new ApplySpendResp(this);
		}		
	}

	private class Result {
		
		@SuppressWarnings("unused")
		public Result() {
		}
		
		List<GameplaySummary> gameplay_summary;
		String apply_spend_datetime_utc;
		
		@SuppressWarnings("unused")
		public List<GameplaySummary> getGameplay_summary() {
			return gameplay_summary;
		}

		@SuppressWarnings("unused")
		public String getApply_spend_datetime_utc() {
			return apply_spend_datetime_utc;
		}

		public Result(Builder builder) {
			this.gameplay_summary = builder.gameplay_summary;
			this.apply_spend_datetime_utc = builder.apply_spend_datetime_utc;
		}
	}
}
