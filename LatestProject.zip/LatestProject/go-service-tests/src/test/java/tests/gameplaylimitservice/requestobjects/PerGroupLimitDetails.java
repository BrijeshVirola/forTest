package tests.gameplaylimitservice.requestobjects;

public class PerGroupLimitDetails {
	@SuppressWarnings("unused")
	private String bucket_Type;
	@SuppressWarnings("unused")
	private String group_Identifier;
	
	private PerGroupLimitDetails(Builder builder) {
		bucket_Type = builder.bucket_Type;
		group_Identifier = builder.group_Identifier;
	}

	public PerGroupLimitDetails bucketType(String bucket_Type) {
		this.bucket_Type = bucket_Type;
		return this;
	}

	public PerGroupLimitDetails groupIdentifier(String group_Identifier) {
		this.group_Identifier = group_Identifier;
		return this;
	}
	public static class Builder{
		private String bucket_Type;
		private String group_Identifier;
		
		public Builder bucketType(String bucketType) {
			bucket_Type = bucketType;
			return this;
		}
		
		public Builder groupIdentifier(String groupIdentifier) {
			group_Identifier = groupIdentifier;
			return this;
		}
		
		public Builder defaults() {
			bucket_Type = "session";
			group_Identifier = "E3C36F861FEF4CFB9414A174144C5A98000004";
			return this;
		}
				
		public PerGroupLimitDetails build() {
			return new PerGroupLimitDetails(this);
		}
	}

}
