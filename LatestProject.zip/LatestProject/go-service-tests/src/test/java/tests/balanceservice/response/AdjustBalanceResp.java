package tests.balanceservice.response;

import common.enumsconstants.Errors;
import tests.balanceservice.request.AdjustBalanceReq;

public class AdjustBalanceResp extends TransactionRecord {
	
	public AdjustBalanceResp() {
	}
	
	public AdjustBalanceResp(AdjustBalanceReq request, AdjustBalanceResp response, boolean isNew) {
		super(request, response, isNew);
	}

	public AdjustBalanceResp(Errors error) {
		super(error);
	}

}
