package tests.balanceservice.request;

public class GetTransactionsByGameRoundReq {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String Method = "GetTransactionsByGameRound";
	@SuppressWarnings("unused")
	private GetTransactionsByGameRoundParams Params;
	
	public GetTransactionsByGameRoundReq(String id, Long gameRoundId) {
		this.id = id;
		Params = new GetTransactionsByGameRoundParams(gameRoundId);
	}
	
	class GetTransactionsByGameRoundParams {
		
		@SuppressWarnings("unused")
		private Long game_round_id;
		
		public GetTransactionsByGameRoundParams(Long gameRoundId) {
			this.game_round_id = gameRoundId;
		}
	}
}
