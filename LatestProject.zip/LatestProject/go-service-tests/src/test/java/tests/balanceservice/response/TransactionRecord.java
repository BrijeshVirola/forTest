package tests.balanceservice.response;

import common.enumsconstants.Errors;
import domain.ErrorResponse;
import tests.balanceservice.request.AdjustBalanceReq;
import tests.balanceservice.responseobjects.TransactionResult;

public class TransactionRecord extends ErrorResponse {
	
	String id;
	private TransactionResult result;
	
	public TransactionRecord() {
	}
	
	public void setRealAmount(String realAmount) {
		result.setRealAmount(realAmount);
	}
	
	public void setBonusAmount(String bonusAmount) {
		result.setBonusAmount(bonusAmount);
	}
	
	public TransactionRecord(Errors error) {
		super(error);
	}
	
	public String getId() {
		return id;
	}
	
	public TransactionResult getResult() {
		return result;
	}
	
	public TransactionRecord(AdjustBalanceReq request, TransactionRecord transaction) {
		this.id = request.getId();
		this.result = new TransactionResult(request, transaction);
	}
	
	public TransactionRecord(AdjustBalanceReq request, AdjustBalanceResp response, boolean isNew) {
		this.id = request.getId();
		this.result = new TransactionResult(request, response, isNew);
	}

}