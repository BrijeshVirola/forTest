package tests.balanceservice.responseobjects;

import java.text.ParseException;

import tests.balanceservice.request.AdjustBalanceReq;
import tests.balanceservice.response.TransactionRecord;

public class TransactionResult {

	private long bet365_games_transaction_id, game_round_id, bet365_transaction_id;
	private long flake_id, source_transaction_id;
	private int transaction_type_id, action_type_id, provider_region_id;
	private int regulated_game_id;
	private String user_token;
	private String partner_transaction_id, real_amount, ring_fenced_amount, bonus_amount,
	total_amount, total_amount_gbp, currency_code, partner_timestamp_utc;
	private boolean is_new = false;

	public TransactionResult() {
	}
	
	/**
	 * This constructs TransactionResult object from existing inserted transaction.
	 * @param transaction
	 * @param source_bet365_games_transaction_id
	 * @param regulated_game_id
	 * @param token
	 * @param flake_id
	 */
	public TransactionResult(AdjustBalanceReq request, TransactionRecord response) {
		
		Long sourceTransactionIdFromReq = (Long) request.getParams().get("source_bet365_games_transaction_id");
		
		this.bet365_games_transaction_id = response.getResult().getBet365_games_transaction_id();
		this.transaction_type_id = response.getResult().getTransaction_type_id();
		this.action_type_id = response.getResult().getAction_type_id();
		this.partner_transaction_id = response.getResult().getPartner_transaction_id();
		this.real_amount = response.getResult().getReal_amount();
		this.ring_fenced_amount = response.getResult().getRing_fenced_amount();
		this.bonus_amount = response.getResult().getBonus_amount();
		this.total_amount = response.getResult().getTotal_amount();
		this.total_amount_gbp = response.getResult().getTotal_amount_gbp();
		this.currency_code = response.getResult().getCurrency_code();
		this.partner_timestamp_utc = response.getResult().getPartner_timestamp_utc();
		this.game_round_id = response.getResult().getGame_round_id();
		this.bet365_transaction_id = response.getResult().getBet365_transaction_id();
		this.provider_region_id = response.getResult().getProvider_region_id();
		this.source_transaction_id = sourceTransactionIdFromReq == null ? 0 : sourceTransactionIdFromReq;
		this.regulated_game_id = (Integer) request.getParams().get("regulated_game_id");
		this.user_token = (String) request.getParams().get("token");
		this.flake_id = (Long) request.getParams().get("flake_id");
	}
	
	/**
	 * This constructs TransactionResult object from Adjust Balance request object.
	 * @param request AdjustBalanceReq
	 * @param is_new if the transaction is for the first time created, or it is already existing
	 * @throws ParseException 
	 */
	public TransactionResult(AdjustBalanceReq request, TransactionRecord response, boolean is_new) {
		
		String bonusAmountFromReq = (String) request.getParams().get("bonus_amount");
		Long bet365transactionIdFromReq = (Long) request.getParams().get("bet365_transaction_id");
		String ringFencedAmountFromReq = (String) request.getParams().get("ring_fenced_amount");
		
		this.bet365_games_transaction_id = response.getResult().getBet365_games_transaction_id();
		this.transaction_type_id = (int) request.getParams().get("transaction_type_id");
		this.action_type_id = (int) request.getParams().get("action_type_id");
		this.partner_transaction_id = (String) request.getParams().get("partner_transaction_id");
		this.real_amount = (String) request.getParams().get("real_amount");
		this.ring_fenced_amount = ringFencedAmountFromReq == null ? "0" : ringFencedAmountFromReq;
		this.bonus_amount = bonusAmountFromReq == null ? "0" : bonusAmountFromReq;
		this.total_amount = (String) request.getParams().get("total_amount");
		this.total_amount_gbp = (String) request.getParams().get("total_amount");
		this.currency_code = "GBP";
		this.partner_timestamp_utc = (String) request.getParams().get("partner_timestamp_utc");
		this.game_round_id = (long) request.getParams().get("game_round_id");
		this.bet365_transaction_id = bet365transactionIdFromReq == null ? 0 : bet365transactionIdFromReq;
		this.provider_region_id = (int) request.getParams().get("provider_region_id");
		this.is_new = is_new;
	}

	public boolean getIs_new() {
		return is_new;
	}

	public void setIs_new(boolean is_new) {
		this.is_new = is_new;
	}

	public long getBet365_games_transaction_id() {
		return bet365_games_transaction_id;
	}

	public void setBet365_games_transaction_id(long bet365_games_transaction_id) {
		this.bet365_games_transaction_id = bet365_games_transaction_id;
	}

	public long getGame_round_id() {
		return game_round_id;
	}

	public long getBet365_transaction_id() {
		return bet365_transaction_id;
	}

	public int getTransaction_type_id() {
		return transaction_type_id;
	}

	public int getAction_type_id() {
		return action_type_id;
	}

	public int getProvider_region_id() {
		return provider_region_id;
	}

	public String getPartner_transaction_id() {
		return partner_transaction_id;
	}

	public String getReal_amount() {
		return real_amount;
	}
	
	public void setRealAmount(String realAmount) {
		real_amount = realAmount;
	}

	public String getRing_fenced_amount() {
		return ring_fenced_amount;
	}

	public String getBonus_amount() {
		return bonus_amount;
	}
	
	public void setBonusAmount(String bonusAmount) {
		bonus_amount = bonusAmount;
	}

	public String getTotal_amount() {
		return total_amount;
	}

	public String getTotal_amount_gbp() {
		return total_amount_gbp;
	}

	public String getCurrency_code() {
		return currency_code;
	}

	public String getPartner_timestamp_utc() {
		return partner_timestamp_utc;
	}

	public long getSource_transaction_id() {
		return source_transaction_id;
	}

	public int getRegulated_game_id() {
		return regulated_game_id;
	}

	public long getFlake_id() {
		return flake_id;
	}

	public String getUser_token() {
		return user_token;
	}
}
