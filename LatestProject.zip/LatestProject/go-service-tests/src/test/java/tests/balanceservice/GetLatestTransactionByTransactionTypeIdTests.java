package tests.balanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.FlakeGenerator;
import common.TransactionType;
import common.enumsconstants.Constants;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.balanceservice.enums.BalanceEndpoints;
import tests.balanceservice.request.AdjustBalanceReq;
import tests.balanceservice.request.GetLatestTransactionByTransactionTypeIdReq;
import tests.balanceservice.response.AdjustBalanceResp;
import tests.balanceservice.response.GetLatestTransactionByTransactionTypeIdResp;

public class GetLatestTransactionByTransactionTypeIdTests extends BaseClassSetup {
	@Test(description = "Get Latest Transaction By Transaction Type Id - Stake and Return transactions")
	public void givenStakeAndReturnTransactions_WhenGetLatestTransactionByTransactionTypeId_ThenTheExpectedResultIsReturned() {

		//Create new stake transaction
		AdjustBalanceReq request1 = new AdjustBalanceReq
				.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_TESTS05)
				.realAmount("-1.00")
				.totalAmount("-1.00")
				.build();
		AdjustBalanceResp actResp = BaseRequest.post(request1, BalanceEndpoints.adjustBalance);

		long getBet365_games_transaction_id = actResp.getResult().getBet365_games_transaction_id();
		int partnerId = 100;
		int providerRegionId = 20;
		request1.setId(null);
		GetLatestTransactionByTransactionTypeIdReq getLatestTransactionByTransactionTypeId = new GetLatestTransactionByTransactionTypeIdReq
				(UsersId.GO_SVC_TESTS05, providerRegionId, partnerId, TransactionType.STAKE);

		GetLatestTransactionByTransactionTypeIdResp actResponse = BaseRequest.post(getLatestTransactionByTransactionTypeId, BalanceEndpoints.getLatestTransactionByTransactionTypeId);
		GetLatestTransactionByTransactionTypeIdResp expResponse = new GetLatestTransactionByTransactionTypeIdResp(request1, actResp);
		assertReflectionEquals(expResponse, actResponse);

		//Create new return transaction
		long flakeId = FlakeGenerator.nextId(Constants.nodeId);
		AdjustBalanceReq request2 = new AdjustBalanceReq
				.Builder()
				.defaults()
				.transactionType(TransactionType.RETURN)
				.sourceBet365GamesTransactionIid(getBet365_games_transaction_id)
				.realAmount("2.00")
				.totalAmount("2.00")
				.flakeId(flakeId)
				.partnerTransactionId("Transaction" + flakeId)
				.userId(UsersId.GO_SVC_TESTS05)
				.build();
		actResp = BaseRequest.post(request2, BalanceEndpoints.adjustBalance);

		getBet365_games_transaction_id = actResp.getResult().getBet365_games_transaction_id();
		request2.setId(null);
		getLatestTransactionByTransactionTypeId = new GetLatestTransactionByTransactionTypeIdReq
				(UsersId.GO_SVC_TESTS05, providerRegionId, partnerId, TransactionType.RETURN);

		actResponse = BaseRequest.post(getLatestTransactionByTransactionTypeId, BalanceEndpoints.getLatestTransactionByTransactionTypeId);
		expResponse = new GetLatestTransactionByTransactionTypeIdResp(request2, actResp);
		assertReflectionEquals(expResponse, actResponse);
	}
}
