package tests.balanceservice.response;

import common.enumsconstants.Errors;
import domain.ErrorResponse;
import tests.balanceservice.responseobjects.GetUserBalanceResult;

public class GetUserBalanceResp extends ErrorResponse {
	
	private String id = "defaultId";
	private GetUserBalanceResult result;
	
	public GetUserBalanceResp() {
	}
	
	public GetUserBalanceResp(int user_id, String balance, String bonus, String ring_fenced) {
		this.result = new GetUserBalanceResult(user_id, balance, bonus, ring_fenced);
	}
	
	public GetUserBalanceResp(Errors error) {
		super(error);
	}

	public String getId() {
		return id;
	}
	
	public GetUserBalanceResult getResult() {
		return result;
	}
	
}
