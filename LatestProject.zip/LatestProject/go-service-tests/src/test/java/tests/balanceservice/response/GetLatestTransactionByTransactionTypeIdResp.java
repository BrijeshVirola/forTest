package tests.balanceservice.response;

import common.enumsconstants.Errors;
import tests.balanceservice.request.AdjustBalanceReq;

public class GetLatestTransactionByTransactionTypeIdResp extends TransactionRecord {
	
	public GetLatestTransactionByTransactionTypeIdResp() {
	}
	
	public GetLatestTransactionByTransactionTypeIdResp(AdjustBalanceReq request, TransactionRecord transaction) {
		super(request, transaction);
	}
	
	public GetLatestTransactionByTransactionTypeIdResp(Errors error) {
		super(error);
	}

}
