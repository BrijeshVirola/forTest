package tests.balanceservice.responseobjects;

public class GetUserBalanceResult {
	
	private int user_id;
	private String balance;
	private String bonus;
	private String ring_fenced;

	public GetUserBalanceResult() {
	}
	
	public GetUserBalanceResult(int user_id, String balance, String bonus, String ring_fenced) {
		this.user_id = user_id;
		this.balance = balance;
		this.bonus = bonus;
		this.ring_fenced = ring_fenced;
	}

	public int getUser_id() {
		return user_id;
	}

	public String getBalance() {
		return balance;
	}

	public String getBonus() {
		return bonus;
	}

	public String getRing_fenced() {
		return ring_fenced;
	}
}
