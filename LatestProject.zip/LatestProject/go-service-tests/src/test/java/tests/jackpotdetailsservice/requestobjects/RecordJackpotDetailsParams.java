package tests.jackpotdetailsservice.requestobjects;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class RecordJackpotDetailsParams {

	private BigInteger transaction_id;
	private List<RecordJackpotDetailsParamsJackpot> jackpots;

	public RecordJackpotDetailsParams() {
	}

	public BigInteger getTransaction_id() {
		return transaction_id;
	}

	public List<RecordJackpotDetailsParamsJackpot> getJackpots() {
		return jackpots;
	}

	private RecordJackpotDetailsParams(Builder builder) {
		this.transaction_id = builder.transaction_id;
		this.jackpots = builder.jackpots;
	}

	public static class Builder {
		
		private BigInteger transaction_id;
		private List<RecordJackpotDetailsParamsJackpot> jackpots = new ArrayList<>();

		public Builder transactionId(BigInteger transactionId) {
			this.transaction_id = transactionId;
			return this;
		}

		public Builder addJackpot(RecordJackpotDetailsParamsJackpot jackpot) {
			jackpots.add(jackpot);
			return this;
		}
		
		public Builder defaults() {
			transaction_id = new BigInteger("2150039052");
			jackpots = new ArrayList<>();
			return this;
		}

		public RecordJackpotDetailsParams build() {
			return new RecordJackpotDetailsParams(this);
		}
	}
}
