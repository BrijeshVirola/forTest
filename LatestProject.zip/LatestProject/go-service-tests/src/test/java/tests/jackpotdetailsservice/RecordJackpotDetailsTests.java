package tests.jackpotdetailsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.DatabaseQueries;
import domain.BaseRequest;
import tests.jackpotdetailsservice.enums.JackpotDetailsEndpoints;
import tests.jackpotdetailsservice.request.RecordJackpotDetailsReq;
import tests.jackpotdetailsservice.requestobjects.RecordJackpotDetailsParams;
import tests.jackpotdetailsservice.requestobjects.RecordJackpotDetailsParamsJackpot;
import tests.jackpotdetailsservice.response.RecordjackpotdetailsResp;

public class RecordJackpotDetailsTests extends BaseClassSetup {

	@Test(description = "Make a request to recordjackpotdetails. Positive scenario.")
	public void recordjackpotdetails_Positive_Scenario() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("0.78"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("0"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to recordjackpotdetails - Range parameter - transaction_id. Positive scenario.", dataProvider = "transactionIdSuccess", dataProviderClass = DataProviders.class)
	public void recordjackpotdetails_Range_Parameter_Transaction_Id_Positive_Scenario(BigInteger transaction_id) {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("0.78"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("0"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(transaction_id)
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to recordjackpotdetails - Range parameter - transaction_id - below 100000000000000. Positive scenario.")
	public void recordjackpotdetails_Range_Parameter_Transaction_Below_100000000000000_Positive_Scenario() {
		String id = UUID.randomUUID().toString();
		BigInteger transaction_id = new BigInteger("99999999999999");
		
		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("0.78"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("0"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(transaction_id)
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		String checkedIdInDB = DatabaseQueries.checkJackpotDetails("bet365GamesTransactionId", "Bet365_Games_Base", transaction_id);
		
		Assert.assertEquals(transaction_id.toString(), checkedIdInDB);
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to recordjackpotdetails - Range parameter - transaction_id - 100000000000000 and above. Positive scenario.", dataProvider = "transactionIdRange", dataProviderClass = DataProviders.class)
	public void recordjackpotdetails_Range_Parameter_Transaction_Id_100000000000000_And_Above_Positive_Scenario(BigInteger transaction_id) {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("0.78"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("0"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(transaction_id)
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		String checkedIdInDB = DatabaseQueries.checkJackpotDetails("TransactionFlakeId", "gam_jackpotdetails", transaction_id);
		
		Assert.assertEquals(transaction_id.toString(), checkedIdInDB);		
		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to recordjackpotdetails - Range parameter - code. Positive scenario.", dataProvider = "codeSuccess", dataProviderClass = DataProviders.class)
	public void recordjackpotdetails_Range_Parameter_Code_Positive_Scenario(String code) {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("0.78"))
				.code(code)
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("0"))
				.code(code)
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to recordjackpotdetails - Range parameter - code. Positive scenario.", dataProvider = "networkIdSuccess", dataProviderClass = DataProviders.class)
	public void recordjackpotdetails_Range_Parameter_Network_Id_Positive_Scenario(String network_id) {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("0.78"))
				.code("MegaPot")
				.networkId(network_id)
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("0"))
				.code("MegaPot")
				.networkId(network_id)
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to recordjackpotdetails - Out Of Range parameter - code. Negative scenario.")
	public void recordjackpotdetails_Out_Of_Range_Parameter_Code_Positive_Scenario() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("0.78"))
				.code("ForA#6VHf35uSZf$@&QN00$VyDc1*dDRMce2685mN4HpMjZdpF3")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("0"))
				.code("ForA#6VHf35uSZf$@&QN00$VyDc1*dDRMce2685mN4HpMjZdpF3")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Field length exceeded: code")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to recordjackpotdetails - Out Of Range parameter - network_id. Negative scenario.")
	public void recordjackpotdetails_Out_Of_Range_Parameter_Network_Id_Positive_Scenario() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("0.78"))
				.code("MegaPot")
				.networkId("ForA#6VHf35uSZf$@&QN00$VyDc1*dDRMce2685mN4HpMjZdpF3")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("0"))
				.code("MegaPot")
				.networkId("ForA#6VHf35uSZf$@&QN00$VyDc1*dDRMce2685mN4HpMjZdpF3")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Field length exceeded: network_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to recordjackpotdetails - Range parameter - win - positive value. Positive scenario.", dataProvider = "jackpotWinSuccess", dataProviderClass = DataProviders.class)
	public void recordjackpotdetails_Range_Parameter_Win_Positive_Value_Positive_Scenario(BigDecimal win) {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(win)
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(win)
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to recordjackpotdetails - Range parameter - Contribution - positive value. Positive scenario.", dataProvider = "jackpotContributionSuccess", dataProviderClass = DataProviders.class)
	public void recordjackpotdetails_Range_Parameter_Contribution_Positive_Value_Positive_Scenario(BigDecimal contribution) {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(contribution)
				.win(new BigDecimal("5.78"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(contribution)
				.win(new BigDecimal("10.78"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to recordjackpotdetails - Range parameter - win - negative value. Negative scenario.", dataProvider = "jackpotWinNegativeValuesSuccess", dataProviderClass = DataProviders.class)
	public void recordjackpotdetails_Range_Parameter_Win_Negative_Value_Positive_Scenario(BigDecimal win) {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(win)
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(win)
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Field value invalid: win")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to recordjackpotdetails - Range parameter - Contribution - negative value. Negative scenario.", dataProvider = "jackpotContributionNegativeValuesSuccess", dataProviderClass = DataProviders.class)
	public void recordjackpotdetails_Range_Parameter_Contribution_Negative_Value_Positive_Scenario(BigDecimal contribution) {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(contribution)
				.win(new BigDecimal("5.78"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(contribution)
				.win(new BigDecimal("10.78"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1006)
				.message("Field value invalid: contribution")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to recordjackpotdetails - Out Of Range parameter - win. Negative scenario.")
	public void recordjackpotdetails_Out_Of_Range_Parameter_Win_Negative_Scenario() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("999999999999999.999999"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("999999999999999.999999"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1004)
				.message("Jackpot details not saved")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to recordjackpotdetails - Out Of Range parameter - transaction_id. Negative scenario.")
	public void recordjackpotdetails_Out_Of_Range_Parameter_Transaction_Id_Negative_Scenario() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("2.99"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("3.76"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(new BigInteger("9223372036854775808"))
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(4)
				.message("Couldn't unmarshal params into target type : json: cannot unmarshal number 9223372036854775808 into Go struct field recordJackpotDetailsRequest.transaction_id of type int64")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to recordjackpotdetails. Invalid method name.")
	public void recordjackpotdetails_Invalid_Method() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to recordjackpotdetails. Missing transaction_id.")
	public void recordjackpotdetails_Missing_Parameter() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(null)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing required parameter: transaction_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to recordjackpotdetails. Missing jackpots.")
	public void recordjackpotdetails_Missing_Jackpots_Parameter() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(null)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Field value not supplied: code")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to recordjackpotdetails - Missing parameter - contribution. Optional - Positive scenario.")
	public void recordjackpotdetails_Missing_Parameter_Contribution_Negative_Scenario() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(null)
				.win(new BigDecimal("2.99"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(null)
				.win(new BigDecimal("3.76"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(new BigInteger("9254775808"))
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();


		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to recordjackpotdetails - Missing parameter - win. Optional - Positive scenario.")
	public void recordjackpotdetails_Missing_Parameter_Win_Negative_Scenario() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.99"))
				.win(null)
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("3.76"))
				.win(null)
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(new BigInteger("854775808"))
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();


		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to recordjackpotdetails - Missing parameter - network_id. Optional Parameter - Positive scenario.")
	public void recordjackpotdetails_Missing_Parameter_Network_Id_Negative_Scenario() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.99"))
				.win(new BigDecimal("5.59"))
				.code("MegaPot")
				.networkId(null)
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("3.76"))
				.win(new BigDecimal("6.87"))
				.code("MegaPot")
				.networkId(null)
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(new BigInteger("854775808"))
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();


		RecordjackpotdetailsResp actualResponse =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsSuccess);

		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to recordjackpotdetails - Missing parameter - Code. Negative scenario.")
	public void recordjackpotdetails_Missing_Parameter_Code_Negative_Scenario() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.99"))
				.win(new BigDecimal("5.59"))
				.code(null)
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("3.76"))
				.win(new BigDecimal("6.87"))
				.code(null)
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(new BigInteger("854775808"))
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Field value not supplied: code")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to recordjackpotdetails - Missing parameter - win/contribution. Mandatory - Negative scenario.")
	public void recordjackpotdetails_Missing_Parameter_Win_Contribution_Mandatory_Negative_Scenario() {
		String id = UUID.randomUUID().toString();

		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(null)
				.win(null)
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(null)
				.win(null)
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();

		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(new BigInteger("854775808"))
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();

		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();

		CustomErrorResponse actualError =  BaseRequest.post(requestBody, JackpotDetailsEndpoints.recordJackpotDetailsError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Field value not supplied for either: win or contribution")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

}
