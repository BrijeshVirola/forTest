package tests.jackpotdetailsservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.jackpotdetailsservice.response.RecordjackpotdetailsResp;

public enum JackpotDetailsEndpoints implements ResponseEndpoints {

	recordJackpotDetailsSuccess(RecordjackpotdetailsResp.class, "recordjackpotdetails"),
	recordJackpotDetailsError(CustomErrorResponse.class, "recordjackpotdetails");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> JackpotDetailsEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
