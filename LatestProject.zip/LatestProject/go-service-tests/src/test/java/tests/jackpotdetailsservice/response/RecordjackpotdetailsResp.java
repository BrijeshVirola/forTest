package tests.jackpotdetailsservice.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RecordjackpotdetailsResp {
	
	private String id;
	private Result result;
	
	public RecordjackpotdetailsResp() {
	}

	public String getId() {
		return id;
	}

	public Result getResult() {
		return result;
	}

	public RecordjackpotdetailsResp(String id, boolean ok) {
		this.id = id;
		result = new Result(ok);
	}
	
	
	private class Result {
		
		@JsonProperty("OK")
		boolean OK;

		@SuppressWarnings("unused")
		public Result() {
		}
		
		public Result(boolean ok) {
			this.OK = ok;
		}

		@SuppressWarnings("unused")
		public boolean getOK() {
			return OK;
		}
	
	}
}
