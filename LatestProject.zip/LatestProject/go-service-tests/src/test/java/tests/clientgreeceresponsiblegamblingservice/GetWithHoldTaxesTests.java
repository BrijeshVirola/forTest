package tests.clientgreeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.Utils;
import domain.BaseRequest;
import tests.clientgreeceresponsiblegamblingservice.enums.ClientGreeceResponsibleGamblingServiceEndpoints;
import tests.clientgreeceresponsiblegamblingservice.enums.ClientGreeceResponsibleGamblingServiceUsers;
import tests.clientgreeceresponsiblegamblingservice.request.ClientGreeceGamblingReq;
import tests.clientgreeceresponsiblegamblingservice.request.ClientRespHeaders;
import tests.clientgreeceresponsiblegamblingservice.response.GetWithholdTaxesResp;

public class GetWithHoldTaxesTests extends BaseClassSetup {	

	// TODO: This test case should be enabled when we find a way to create a cookie with withold taxes
	@Test(enabled = false, description = "Make a request to getwithholdtaxes. Positive scenario, True ")
	public void GetWithHoldTaxes_Yes_Positive_Scenario() {

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie("75A45B3A279ED65982C7CF04D79EAD34020004")
				.build();

		ClientGreeceGamblingReq request = new ClientGreeceGamblingReq.Builder()
				.defaults()
				.build();

		GetWithholdTaxesResp actualResponse =  BaseRequest.get(request.getParameters(), ClientGreeceResponsibleGamblingServiceEndpoints.getWithholdTaxesSuccess, 200, headers.getHeaders());
		GetWithholdTaxesResp expectedResponse =  new GetWithholdTaxesResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
		
	}
	

	@Test(description = "Make a request to getwithholdtaxes. Positive scenario, False ")
	public void GetWithHoldTaxes_No_Positive_Scenario() {
		
		String username = ClientGreeceResponsibleGamblingServiceUsers.GET_WITH_HOLD_TAXES_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		ClientGreeceGamblingReq request = new ClientGreeceGamblingReq.Builder()
				.defaults()
				.build();

		GetWithholdTaxesResp actualResponse =  BaseRequest.get(request.getParameters(), ClientGreeceResponsibleGamblingServiceEndpoints.getWithholdTaxesSuccess, 200, headers.getHeaders());
		GetWithholdTaxesResp expectedResponse =  new GetWithholdTaxesResp.Builder()
				.defaults()
				.ita(false)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
		
	}
	
	@Test(description = "Make a request to sessiontimelimitreached without gstkCookie. Negative scenario")
	public void GetWithHoldTaxes_NoGstkCookie() {

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(null)
				.build();

		ClientGreeceGamblingReq request = new ClientGreeceGamblingReq.Builder()
				.defaults()
				.build();

		GetWithholdTaxesResp response =  BaseRequest.get(request.getParameters(), ClientGreeceResponsibleGamblingServiceEndpoints.getWithholdTaxesSuccess, 400, headers.getHeaders());

		Assert.assertEquals(response, null);		

	}
	
	
}
