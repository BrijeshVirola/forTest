package tests.clientgreeceresponsiblegamblingservice.response;


public class SessionTimeLimitReachedResp {
	
	private Boolean ilb;

	public SessionTimeLimitReachedResp() {
	}
	
	private SessionTimeLimitReachedResp(Builder builder) {
		this.ilb = builder.ilb;
	}	

	public Boolean getIlb() {
		return ilb;
	}

	public static class Builder {
		private Boolean ilb;

		public Builder ilb(Boolean ilb) {
			this.ilb = ilb;
			return this;
		}

		public Builder defaults() {
			this.ilb = false;
			return this;
		}

		public SessionTimeLimitReachedResp build() {
			return new SessionTimeLimitReachedResp(this);
		}
	}
}
