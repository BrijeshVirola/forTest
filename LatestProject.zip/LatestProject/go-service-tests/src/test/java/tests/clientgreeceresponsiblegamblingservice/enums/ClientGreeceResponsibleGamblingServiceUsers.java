package tests.clientgreeceresponsiblegamblingservice.enums;

import common.DatabaseQueries;

public enum ClientGreeceResponsibleGamblingServiceUsers {

	GET_WITH_HOLD_TAXES_POS1("GOSVCGRUSER12"),
	SESSION_TIME_LIMIT_POS1("GOSVCGRUSER43"),
	SESSION_TIME_LIMIT_POS2("GOSVCGRUSER41"),
	SESSION_TIME_LIMIT_POS3("GOSVCGRUSER40");

	private String username;

	private ClientGreeceResponsibleGamblingServiceUsers(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public int getUserId() {
		return DatabaseQueries.getUserIdFromUserTable(getUsername());
	}

}