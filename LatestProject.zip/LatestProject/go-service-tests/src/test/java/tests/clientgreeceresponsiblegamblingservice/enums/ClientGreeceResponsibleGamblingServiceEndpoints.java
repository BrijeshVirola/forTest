package tests.clientgreeceresponsiblegamblingservice.enums;

import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.clientgreeceresponsiblegamblingservice.response.GetWithholdTaxesResp;
import tests.clientgreeceresponsiblegamblingservice.response.SessionTimeLimitReachedResp;

public enum ClientGreeceResponsibleGamblingServiceEndpoints implements ResponseEndpoints {

	getSessionTimeLimitReachedSuccess(SessionTimeLimitReachedResp.class, "sessiontimelimitreached"),
	getSessionTimeLimitReachedError(CustomErrorResponse.class, "sessiontimelimitreached"),
	getWithholdTaxesSuccess(GetWithholdTaxesResp.class, "getwithholdtaxes"),
	getWithholdTaxesError(CustomErrorResponse.class, "getwithholdtaxes");


	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> ClientGreeceResponsibleGamblingServiceEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
