package tests.clientgreeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class ClientRespHeaders {

	private Map<String, Object> headers = new HashMap<>();

	private ClientRespHeaders(Builder builder) {
		this.headers.put("Cookie", builder.gstkCookie);
	}

	public Map<String, Object> getHeaders() {
		return headers;
	}

	public static class Builder {
		private String gstkCookie;

		public Builder gstkCookie(String gsktCookie) {
			this.gstkCookie = "gstk=" + gsktCookie;
			return this;
		}

		public Builder defaults() {
			this.gstkCookie = "gstk=C48171EE19834F879DB846ED0FC65B4A020004";
			return this;
		}

		public ClientRespHeaders build() {
			return new ClientRespHeaders(this);
		}
	}
}
