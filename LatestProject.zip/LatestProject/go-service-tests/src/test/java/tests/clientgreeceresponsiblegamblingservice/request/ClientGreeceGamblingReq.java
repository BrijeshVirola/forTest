package tests.clientgreeceresponsiblegamblingservice.request;

import java.util.HashMap;
import java.util.Map;

public class ClientGreeceGamblingReq {

	private Map<String, Object> parameters = new HashMap<>();	

	private ClientGreeceGamblingReq(Builder builder) {
		if(builder.gmpid!=null)
		this.parameters.put("gmpid", builder.gmpid);
	}
	
	public Map<String, Object> getParameters() {
		return parameters;
	}

	public static class Builder {
		private Integer gmpid;

		
		public Builder gmpId(Integer gmpid) {
			this.gmpid = gmpid;
			return this;
		}
		
		public Builder defaults() {
			this.gmpid = null;
			return this;
		}

		public ClientGreeceGamblingReq build() {
			return new ClientGreeceGamblingReq(this);
		}
	}
}
