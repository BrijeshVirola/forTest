package tests.clientgreeceresponsiblegamblingservice.response;


public class GetWithholdTaxesResp {
	
	private Boolean ita;

	public GetWithholdTaxesResp() {
	}
	
	private GetWithholdTaxesResp(Builder builder) {
		this.ita = builder.ita;
	}	

	public Boolean getIta() {
		return ita;
	}

	public static class Builder {
		private Boolean ita;

		public Builder ita(Boolean ita) {
			this.ita = ita;
			return this;
		}

		public Builder defaults() {
			this.ita = true;
			return this;
		}

		public GetWithholdTaxesResp build() {
			return new GetWithholdTaxesResp(this);
		}
	}
}
