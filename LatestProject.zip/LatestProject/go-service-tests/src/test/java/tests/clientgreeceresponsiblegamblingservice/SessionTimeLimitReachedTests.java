package tests.clientgreeceresponsiblegamblingservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.Utils;
import domain.BaseRequest;
import tests.clientgreeceresponsiblegamblingservice.enums.ClientGreeceResponsibleGamblingServiceEndpoints;
import tests.clientgreeceresponsiblegamblingservice.enums.ClientGreeceResponsibleGamblingServiceUsers;
import tests.clientgreeceresponsiblegamblingservice.request.ClientGreeceGamblingReq;
import tests.clientgreeceresponsiblegamblingservice.request.ClientRespHeaders;
import tests.clientgreeceresponsiblegamblingservice.response.SessionTimeLimitReachedResp;

public class SessionTimeLimitReachedTests extends BaseClassSetup {	

	//TODO: To create a automated journey of session where time limit is breached 	
	@Test(enabled = false, description = "Make a request to sessiontimelimitreached with gmpid parameter. Positive scenario - Limit Reached.")
	public void SessionTimeLimitReached_Yes_Positive_Scenario() {

		String username = ClientGreeceResponsibleGamblingServiceUsers.SESSION_TIME_LIMIT_POS1.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		ClientGreeceGamblingReq request = new ClientGreeceGamblingReq.Builder()
				.defaults()
				.gmpId(2)
				.build();

		SessionTimeLimitReachedResp actualResponse =  BaseRequest.get(request.getParameters(), ClientGreeceResponsibleGamblingServiceEndpoints.getSessionTimeLimitReachedSuccess, 200, headers.getHeaders());

		SessionTimeLimitReachedResp expectedResponse =  new SessionTimeLimitReachedResp.Builder()
				.defaults()
				.ilb(true)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
		
		Utils.terminateSessionBySessionId(sessionId);

	}
	
	@Test(description = "Make a request to sessiontimelimitreached with gmpid parameter. Positive scenario - No Limit Reached.")
	public void SessionTimeLimitReached_No_Positive_Scenario() {

		String username = ClientGreeceResponsibleGamblingServiceUsers.SESSION_TIME_LIMIT_POS2.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();
		
		ClientGreeceGamblingReq request = new ClientGreeceGamblingReq.Builder()
				.defaults()
				.gmpId(2)
				.build();

		SessionTimeLimitReachedResp actualResponse =  BaseRequest.get(request.getParameters(), ClientGreeceResponsibleGamblingServiceEndpoints.getSessionTimeLimitReachedSuccess, 200, headers.getHeaders());

		SessionTimeLimitReachedResp expectedResponse =  new SessionTimeLimitReachedResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
		
		Utils.terminateSessionBySessionId(sessionId);

	}

	
	@Test(description = "Make a request to sessiontimelimitreached without gmpid parameter. Negative scenario")
	public void SessionTimeLimitReached_NoGmpId() {

		String username = ClientGreeceResponsibleGamblingServiceUsers.SESSION_TIME_LIMIT_POS3.getUsername();
		String sessionId = Utils.createSession(username).getSessionId();

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(sessionId)
				.build();

		ClientGreeceGamblingReq request = new ClientGreeceGamblingReq.Builder()
				.defaults()
				.build();
		
		SessionTimeLimitReachedResp response =  BaseRequest.get(request.getParameters(), ClientGreeceResponsibleGamblingServiceEndpoints.getSessionTimeLimitReachedSuccess, 400, headers.getHeaders());

		Assert.assertEquals(response, null);		

	}
	
	
	@Test(description = "Make a request to sessiontimelimitreached without gstkCookie. Negative scenario")
	public void SessionTimeLimitReached_NoGstkCookie() {

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie(null)
				.build();

		ClientGreeceGamblingReq request = new ClientGreeceGamblingReq.Builder()
				.defaults()
				.gmpId(2)
				.build();

		SessionTimeLimitReachedResp response =  BaseRequest.get(request.getParameters(), ClientGreeceResponsibleGamblingServiceEndpoints.getSessionTimeLimitReachedSuccess, 400, headers.getHeaders());

		Assert.assertEquals(response, null);		

	}
	
	
	
	@Test(description = "Make a request to sessiontimelimitreached with completed session. Negative scenario")
	public void SessionTimeLimitReached_existing_session() {

		ClientRespHeaders headers = new ClientRespHeaders.Builder()
				.defaults()
				.gstkCookie("25188B47EC044643B8911F43826BFF17000004")
				.build();

		ClientGreeceGamblingReq request = new ClientGreeceGamblingReq.Builder()
				.defaults()
				.gmpId(2)
				.build();

		SessionTimeLimitReachedResp response =  BaseRequest.get(request.getParameters(), ClientGreeceResponsibleGamblingServiceEndpoints.getSessionTimeLimitReachedSuccess, 403, headers.getHeaders());

		Assert.assertEquals(response, null);		

	}

}
