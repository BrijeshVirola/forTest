package tests.gahoosearch.response;

import java.util.ArrayList;
import java.util.List;
import tests.gahoosearch.responseobjects.UserSearchDetails;

public class GahooSearchResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	List<UserSearchDetails> result;

	private GahooSearchResp(Builder builder) {
		this.id = builder.id;
		//result = new Result(builder);
		this.result = builder.result;
	}

	public String id() {
		return id;
	}


	public List<UserSearchDetails> getUserSearchDetails() {
		return result;
	}

	/*
	 * public List<UserSearchDetails> getUserSearchDetails(){ return
	 * result.usersearch_details; }
	 */

	public static class Builder {
		public List<UserSearchDetails> result;
		private String id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addUserSearchDetails(UserSearchDetails result) {
			this.result.add(result);
			return this;
		}


		public Builder defaults() {
			this.id = "Id";
			this.result = new ArrayList<>();
			return this;
		}

		public GahooSearchResp build() {
			return new GahooSearchResp(this);
		}

	}		
}

