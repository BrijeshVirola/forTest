package tests.gahoosearch.responseobjects;


public class DebugInfo {

	protected Integer indexPriority;
	protected Integer indexRanking;
	protected Integer productGameId;
	protected String why; 

	public DebugInfo(Builder builder) {

		indexPriority = builder.indexPriority;
		indexRanking = builder.indexRanking;
		productGameId = builder.productGameId;
		why = builder.why; 

	}

	public Integer getIndexPriority() {
		return indexPriority;
	}

	public Integer getIndexRanking() {
		return indexRanking;
	}

	public Integer getProductGameId() {
		return productGameId;
	}

	public String getWhy() {
		return why;
	} 

	public static class Builder{



		protected Integer indexPriority;
		protected Integer indexRanking;
		protected Integer productGameId;
		protected String why; 

		public Builder indexPriority(Integer indexPriority){
			this.indexPriority = indexPriority;
			return this;
		}

		public Builder indexRanking(Integer indexRanking) {
			this.indexRanking = indexRanking;
			return this;
		}

		public Builder productGameId(Integer productGameId) {
			this.productGameId = productGameId;
			return this;
		}

		public Builder why(String why) {
			this.why = why;
			return this;
		} 

		public Builder defaults() {

			indexPriority = 2;
			indexRanking = 9;
			productGameId = 19394;	
			why = ""; 

			return this;
		}

		public DebugInfo build() {
			return new DebugInfo(this);
		}
	}
}
