package tests.playtechlivedealerfeedservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.playtechlivedealerfeedservice.response.GetAllTablesResp;

public enum PTLiveDealerFeedEndpoints implements ResponseEndpoints {

	getAllTablesSuccess(GetAllTablesResp.class, "getalltables"),
	getAllTablesError(CustomErrorResponse.class, "getalltables");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> PTLiveDealerFeedEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
