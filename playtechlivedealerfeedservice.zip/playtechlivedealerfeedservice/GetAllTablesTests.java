package tests.playtechlivedealerfeedservice;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.matchesPattern;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.List;
import java.util.UUID;
import org.testng.Assert;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ServiceErrors;
import domain.BaseRequest;
import domain.ErrorResponse;
import io.restassured.response.Response;
import tests.playtechlivedealerfeedservice.enums.PTLiveDealerFeedEndpoints;
import tests.playtechlivedealerfeedservice.request.GetAllTablesReq;
import tests.playtechlivedealerfeedservice.response.GetAllTablesResp;
import tests.playtechlivedealerfeedservice.responseobjects.Event;
import tests.playtechlivedealerfeedservice.responseobjects.GameInfoLimit;

public class GetAllTablesTests extends BaseClassSetup{

	@Test(description = "Make a request to getAllTables. Positive Scenario.")
	public void getAllTables_Postitive_Scenario() {

		String id = UUID.randomUUID().toString();

		GetAllTablesReq request = new GetAllTablesReq.Builder()
				.defaults()
				.id(id)
				.build();

		GetAllTablesResp actResp = BaseRequest.post(request, PTLiveDealerFeedEndpoints.getAllTablesSuccess);
		actResp.leaveEventsInResp(4);

		Event expGameInfoEvent = Utils.createGameInfoEvent(actResp);
		Event expDealerInfoEvent = Utils.createDealerInfoEvent(actResp);
		Event expOnlinePlayersEvent = Utils.createOnlinePlayersEvent(actResp);
		Event expGameStatusEvent = Utils.createGameStatusEvent(actResp);
		
		Event actGameInfoEvent = actResp.getResultEvent(0);
		Event actDealerInfoEvent = actResp.getResultEvent(1);
		Event actOnlinePlayersEvent = actResp.getResultEvent(2);
		Event actGameStatusEvent = actResp.getResultEvent(3);
		List<GameInfoLimit> actGameInfoLimits = actGameInfoEvent.getMessage().getPayload().getLimits();
		
		Assert.assertEquals(expGameInfoEvent.getTopic(), actGameInfoEvent.getTopic());
		Assert.assertEquals(expGameInfoEvent.getKey(), actGameInfoEvent.getKey());
		Assert.assertEquals(expGameInfoEvent.getMessage().getGameTableId(), actGameInfoEvent.getMessage().getGameTableId());
		Assert.assertEquals(expGameInfoEvent.getMessage().getGameTokenId(), actGameInfoEvent.getMessage().getGameTokenId());
		Assert.assertEquals(expGameInfoEvent.getMessage().getGameTokenName(), actGameInfoEvent.getMessage().getGameTokenName());
		Assert.assertEquals(expGameInfoEvent.getMessage().getEventType(), actGameInfoEvent.getMessage().getEventType());
		Assert.assertEquals(expGameInfoEvent.getMessage().getPayload().getOpeningTimestamp(),
				actGameInfoEvent.getMessage().getPayload().getOpeningTimestamp());
		
		for(GameInfoLimit gameInfoLimit: actGameInfoLimits) {
			assertThat("currency", gameInfoLimit.getCurrency(), matchesPattern("^[A-Z]{3}$"));
			assertThat("vip_level", gameInfoLimit.getVipLevel().toString(), matchesPattern("^\\d$"));
			assertThat("min", gameInfoLimit.getMin(), matchesPattern("^\\d{1,10}$"));
			assertThat("max", gameInfoLimit.getMax(), matchesPattern("^\\d{1,10}$"));
		}
		
		assertReflectionEquals(expDealerInfoEvent, actDealerInfoEvent);
		assertReflectionEquals(expOnlinePlayersEvent, actOnlinePlayersEvent);
		assertReflectionEquals(expGameStatusEvent, actGameStatusEvent);
	}

	@Test(description = "Make a request to getAllTables. Wrong method name.")
	public void getAllTables_Wrong_Method_Name() {

		String id = UUID.randomUUID().toString();

		GetAllTablesReq request = new GetAllTablesReq.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();

		CustomErrorResponse actResp = BaseRequest.post(request, PTLiveDealerFeedEndpoints.getAllTablesError);


		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.id(null)
				.code(6)
				.message("Incorrect method in request")
				.build();

		assertReflectionEquals(expError, actResp);
	}

	@Test(description = "Make a request to getAllTables. Missing params.")
	public void getAllTables_Wrong_Missing_Params() {

		String id = UUID.randomUUID().toString();

		GetAllTablesReq request = new GetAllTablesReq.Builder()
				.defaults()
				.id(id)
				.build();
		request.removeParams();

		CustomErrorResponse actResp = BaseRequest.post(request, PTLiveDealerFeedEndpoints.getAllTablesError);


		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.id(null)
				.code(5)
				.message("Params missing from request")
				.build();

		assertReflectionEquals(expError, actResp);
	}

	@Test(description = "Make a request with GET instead of POST method - Error code 1")
	public void get_Method_Instead_Of_Post() {

		Response response = BaseRequest.callEmptyBodyRequest("getalltables",
				true, true, false);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.NOT_HTTP_POST);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with no content type header - Error code 2")
	public void header_Content_Type_Not_Set() {

		Response response = BaseRequest.callEmptyBodyRequest("getalltables",
				true, false, true);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.THE_CONTENT_TYPE_HEADER_WAS_MISSING_OR_INVALID);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request wihtout Accept Header - Error code 3")
	public void header_Accept_Not_Set() {

		Response response = BaseRequest.callEmptyBodyRequest("getalltables",
				false, true, true);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.THE_ACCEPT_HEADER_WAS_MISSING_OR_INVALID);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with no json in the body - Error code 4")
	public void no_Json() {

		Response response = BaseRequest.callNoJsonRequest("getalltables",
				true, true, true);
		response.then().statusCode(200);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.NO_JSON_REQUEST);

		assertReflectionEquals(expError, actError);
	}

	@Test(description = "Make a request with empty json in the body - Error code 5")
	public void json_Body_Empty() {

		Response response = BaseRequest.callEmptyBodyRequest("getalltables",
				true, true, true);

		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.EMPTY_JSON_BODY_REQUEST);

		assertReflectionEquals(expError, actError);
	}
}
