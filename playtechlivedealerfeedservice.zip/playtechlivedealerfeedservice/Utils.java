package tests.playtechlivedealerfeedservice;

import tests.playtechlivedealerfeedservice.response.GetAllTablesResp;
import tests.playtechlivedealerfeedservice.responseobjects.Event;
import tests.playtechlivedealerfeedservice.responseobjects.Message;
import tests.playtechlivedealerfeedservice.responseobjects.Payload;

public class Utils {
	
	public static Event createGameInfoEvent(GetAllTablesResp resp) {
		
		Integer gameInfoEventTableId = resp.getGameTableId(0);
		String topic = resp.getTopic(0);
		
		Message gameInfoMessage = new Message.Builder()
				.defaults()
				.gameInfoEvent(gameInfoEventTableId)
				.payload(new Payload.Builder().openingTimestamp(0).defaultLimits().build())
				.build();
		
		Event gameInfoEvent = new Event.Builder()
				.defaults()
				.topic(topic)
				.gameInfoEvent(gameInfoEventTableId)
				.message(gameInfoMessage)
				.build();
		
		return gameInfoEvent;
	}
	
	public static Event createDealerInfoEvent(GetAllTablesResp resp) {
		
		Integer gameInfoEventTableId = resp.getGameTableId(0);
		String dealerInfoDealerName = resp.getDealerName(1);
		String topic = resp.getTopic(0);
		
		Message dealerInfoMessage = new Message.Builder()
				.defaults()
				.dealerInfoEvent(gameInfoEventTableId)
				.payload(new Payload.Builder().dealerName(dealerInfoDealerName).dealerPictureUrl("").build())
				.build();
		
		Event dealerInfoEvent = new Event.Builder()
				.defaults()
				.dealerInfoEvent(gameInfoEventTableId)
				.message(dealerInfoMessage)
				.topic(topic)
				.build();
		
		return dealerInfoEvent;
	}
	
	public static Event createOnlinePlayersEvent(GetAllTablesResp resp) {
		
		Integer gameInfoEventTableId = resp.getGameTableId(0);
		String topic = resp.getTopic(0);
		
		Message onlinePlayersMessage = new Message.Builder()
				.defaults()
				.onlinePlayersEvent(gameInfoEventTableId)
				.payload(new Payload.Builder().playerCount(0).build())
				.build();
		
		Event onlinePlayersEvent = new Event.Builder()
				.defaults()
				.topic(topic)
				.onlinePlayersEvent(gameInfoEventTableId)
				.message(onlinePlayersMessage)
				.build();
		
		return onlinePlayersEvent;
	}
	
	public static Event createGameStatusEvent(GetAllTablesResp resp) {
		
		Integer gameInfoEventTableId = resp.getGameTableId(0);
		String topic = resp.getTopic(0);
		
		Message gameStatusMessage = new Message.Builder()
				.defaults()
				.gameStatusEvent(gameInfoEventTableId)
				.payload(new Payload.Builder().status("open").build())
				.build();
		
		Event gameStatusEvent = new Event.Builder()
				.defaults()
				.topic(topic)
				.gameStatusEvent(gameInfoEventTableId)
				.message(gameStatusMessage)
				.build();
		
		return gameStatusEvent;
	}

}
