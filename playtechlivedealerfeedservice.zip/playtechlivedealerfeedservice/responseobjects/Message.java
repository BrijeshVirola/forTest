package tests.playtechlivedealerfeedservice.responseobjects;

public class Message {
	
	protected Integer game_table_id;
	protected Integer game_token_id;
	protected String game_token_name;
	protected String event_type;
	protected Payload payload;

	private Message(Builder builder) {
		game_table_id = builder.game_table_id;
		game_token_id = builder.game_token_id;
		game_token_name = builder.game_token_name;
		event_type = builder.event_type;
		payload = builder.payload;
	}
	
	public Payload getPayload() {
		return payload;
	}
	
	public Integer getGameTableId() {
		return game_table_id;
	}
	
	public Integer getGameTokenId() {
		return game_token_id;
	}
	
	public String getDealerName() {
		return payload.getDealerName();
	}
	
	public String getGameTokenName() {
		return game_token_name;
	}
	
	public String getEventType() {
		return event_type;
	}
	
	public static class Builder {
		
		protected Integer game_table_id;
		protected Integer game_token_id;
		protected String game_token_name;
		protected String event_type;
		protected Payload payload;
		
		public Builder gameInfoEvent(int gameTableId) {
			event_type = "GameInfoEvent";
			this.game_table_id = gameTableId;
			return this;
		}
		
		public Builder dealerInfoEvent(int gameTableId) {
			event_type = "DealerInfoEvent";
			this.game_table_id = gameTableId;
			return this;
		}
		
		public Builder onlinePlayersEvent(int gameTableId) {
			event_type = "OnlinePlayersEvent";
			this.game_table_id = gameTableId;
			return this;
		}
		
		public Builder gameStatusEvent(int gameTableId) {
			event_type = "GameStatusEvent";
			this.game_table_id = gameTableId;
			return this;
		}
		
		public Builder gameTokenId(Integer game_token_id) {
			this.game_token_id = game_token_id;
			return this;
		}
		
		public Builder gameTokenName(String game_token_name) {
			this.game_token_name = game_token_name;
			return this;
		}
		
		public Builder eventType(String event_type) {
			this.event_type = event_type;
			return this;
		}
		
		public Builder payload(Payload payload) {
			this.payload = payload;
			return this;
		}
		
		public Builder defaults() {
			game_table_id = 1792;
			game_token_id = 0;
			game_token_name = "";
			event_type = "GameInfoEvent";
			return this;
		}
		
		public Message build() {
			return new Message(this);
		}
	}

}
